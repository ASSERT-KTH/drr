import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.Week.FIRST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Week week1 = new org.jfree.data.time.Week(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(12, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test019");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = week0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("org.jfree.data.time.TimePeriodFormatException: ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test022");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            week0.peg(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test024");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Calendar calendar4 = null;
//        try {
//            week0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test025");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        boolean boolean4 = week0.equals((java.lang.Object) 3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        boolean boolean5 = week3.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test027");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = week0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
        long long11 = week6.getLastMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546156799999L + "'", long11 == 1546156799999L);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test032");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = year3.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
//        java.util.Date date4 = year2.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        int int8 = week6.getWeek();
//        int int9 = week6.getYearValue();
//        java.util.Date date10 = week6.getStart();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        java.util.Locale locale13 = null;
//        try {
//            org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date4, timeZone11, locale13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 100, (int) (byte) 10);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        int int3 = week1.getWeek();
//        int int4 = week1.getYearValue();
//        java.util.Date date5 = week1.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        try {
//            org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date0, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.data.time.Week.LAST_WEEK_IN_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 53 + "'", int0 == 53);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getStart();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2, (int) ' ');
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        int int4 = week0.getWeek();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 24, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        long long4 = week0.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.lang.Object obj4 = null;
        boolean boolean5 = week0.equals(obj4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        long long5 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560668399999L + "'", long5 == 1560668399999L);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 2019");
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getMiddleMillisecond();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        java.util.Calendar calendar11 = null;
        try {
            week10.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        int int9 = week7.getWeek();
//        long long10 = week7.getSerialIndex();
//        boolean boolean11 = week0.equals((java.lang.Object) long10);
//        long long12 = week0.getLastMillisecond();
//        java.util.Calendar calendar13 = null;
//        try {
//            week0.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560668399999L + "'", long12 == 1560668399999L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException8.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable throwable15 = null;
        try {
            timePeriodFormatException11.addSuppressed(throwable15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.String str7 = week6.toString();
//        int int8 = week6.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(0, year3);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year3.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
        java.lang.String str12 = week6.toString();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = week6.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getYearValue();
//        long long3 = week0.getSerialIndex();
//        int int4 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable6 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test067");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        java.lang.Class<?> wildcardClass6 = regularTimePeriod5.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize(class16);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.util.Date date3 = week0.getStart();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test070");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getFirstMillisecond();
//        long long7 = week0.getLastMillisecond();
//        int int8 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        java.util.Date date0 = null;
//        java.lang.Object obj1 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass2 = obj1.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.util.Date date6 = null;
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date6, timeZone7);
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(10, year13);
//        java.util.Date date15 = year13.getStart();
//        java.util.Date date16 = year13.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week19.next();
//        long long22 = week19.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass23 = week19.getClass();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        java.lang.String str25 = week24.toString();
//        java.lang.String str26 = week24.toString();
//        org.jfree.data.time.Year year27 = week24.getYear();
//        java.util.Date date28 = year27.getEnd();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date28, timeZone29);
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date28, timeZone31);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(10, year36);
//        java.util.Date date38 = year36.getStart();
//        java.util.Date date39 = year36.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date39, timeZone40);
//        java.lang.Class class42 = null;
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year45 = week44.getYear();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(10, year45);
//        java.util.Date date47 = year45.getStart();
//        java.util.Date date48 = year45.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date48, timeZone49);
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date39, timeZone49);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date28, timeZone49);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date16, timeZone49);
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        java.lang.String str55 = week54.toString();
//        int int56 = week54.getWeek();
//        int int57 = week54.getYearValue();
//        java.util.Date date58 = week54.getStart();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date16, timeZone59);
//        java.util.Locale locale62 = null;
//        try {
//            org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date0, timeZone59, locale62);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Week 24, 2019" + "'", str25.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Week 24, 2019" + "'", str26.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 24, 2019" + "'", str55.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 24 + "'", int56 == 24);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test074");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        long long5 = week0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.util.Date date4 = week0.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        java.util.Date date9 = week6.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week0.compareTo((java.lang.Object) date9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        long long13 = week12.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        boolean boolean7 = week0.equals((java.lang.Object) (-1));
//        org.jfree.data.time.Year year8 = week0.getYear();
//        java.lang.Class<?> wildcardClass9 = year8.getClass();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
        int int7 = week6.getWeek();
        long long8 = week6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1564902000000L + "'", long8 == 1564902000000L);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.Class<?> wildcardClass2 = week0.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass2);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Year year4 = week0.getYear();
        org.jfree.data.time.Year year5 = week0.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        java.util.Date date9 = week6.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        int int11 = week0.compareTo((java.lang.Object) date9);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week0.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week0.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        long long10 = week7.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass11 = week7.getClass();
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
//        long long16 = week13.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass17 = week13.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week13.next();
//        long long19 = week13.getFirstMillisecond();
//        java.util.Date date20 = week13.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.lang.String str22 = week21.toString();
//        java.lang.String str23 = week21.toString();
//        org.jfree.data.time.Year year24 = week21.getYear();
//        java.util.Date date25 = year24.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date20, timeZone26);
//        java.util.Locale locale29 = null;
//        try {
//            org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(date4, timeZone26, locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560365999999L + "'", long16 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560063600000L + "'", long19 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 24, 2019" + "'", str22.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        java.lang.String str10 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(10, year8);
        java.util.Date date10 = year8.getStart();
        java.util.Date date11 = year8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone12);
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year17 = week16.getYear();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
        java.util.Date date19 = year17.getStart();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date11, timeZone21);
        boolean boolean24 = week3.equals((java.lang.Object) week23);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = week3.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        long long9 = week6.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass10 = week6.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
//        long long12 = week6.getFirstMillisecond();
//        java.util.Date date13 = week6.getEnd();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        java.lang.String str15 = week14.toString();
//        java.lang.String str16 = week14.toString();
//        org.jfree.data.time.Year year17 = week14.getYear();
//        java.util.Date date18 = year17.getEnd();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date18, timeZone19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date13, timeZone19);
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.util.Locale locale23 = null;
//        try {
//            org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date13, timeZone22, locale23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560365999999L + "'", long9 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertNotNull(timeZone22);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException4.getClass();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = week0.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test089");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        int int9 = week7.getWeek();
//        int int10 = week7.getYearValue();
//        java.util.Date date11 = week7.getStart();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
//        java.lang.String str14 = week13.toString();
//        int int15 = week0.compareTo((java.lang.Object) week13);
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = week13.getMiddleMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int7 = week5.compareTo((java.lang.Object) '#');
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week5.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week6.next();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.Calendar calendar5 = null;
//        try {
//            week0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.lang.String str35 = week34.toString();
//        java.lang.String str36 = week34.toString();
//        org.jfree.data.time.Year year37 = week34.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        int int41 = week33.compareTo((java.lang.Object) week40);
//        java.util.Calendar calendar42 = null;
//        try {
//            long long43 = week40.getMiddleMillisecond(calendar42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 24, 2019" + "'", str35.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) ' ');
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week0.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        int int6 = week4.getWeek();
//        int int7 = week4.getYearValue();
//        java.util.Date date8 = week4.getStart();
//        int int9 = week0.compareTo((java.lang.Object) date8);
//        org.jfree.data.time.Year year10 = week0.getYear();
//        int int11 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.lang.String str35 = week34.toString();
//        java.lang.String str36 = week34.toString();
//        org.jfree.data.time.Year year37 = week34.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        int int41 = week33.compareTo((java.lang.Object) week40);
//        java.util.Date date42 = week33.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.util.Locale locale44 = null;
//        try {
//            org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date42, timeZone43, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 24, 2019" + "'", str35.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
        int int7 = week6.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
        long long9 = week6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1564902000000L + "'", long9 == 1564902000000L);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        java.util.Date date10 = week7.getStart();
//        org.jfree.data.time.Year year11 = week7.getYear();
//        org.jfree.data.time.Year year12 = week7.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
//        java.util.Date date16 = week13.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        int int18 = week7.compareTo((java.lang.Object) date16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
//        int int20 = week0.compareTo((java.lang.Object) date16);
//        java.lang.String str21 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        java.lang.Class class11 = null;
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year14 = week13.getYear();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(10, year14);
        java.util.Date date16 = year14.getStart();
        java.util.Date date17 = year14.getEnd();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date17, timeZone18);
        java.util.Locale locale20 = null;
        try {
            org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date9, timeZone18, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod19);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year35 = week34.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = week34.next();
//        long long37 = week34.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass38 = week34.getClass();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        java.lang.String str40 = week39.toString();
//        java.lang.String str41 = week39.toString();
//        org.jfree.data.time.Year year42 = week39.getYear();
//        java.util.Date date43 = year42.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date43, timeZone44);
//        java.util.TimeZone timeZone46 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date43, timeZone46);
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        java.util.Date date49 = null;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year51 = week50.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = week50.next();
//        long long53 = week50.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass54 = week50.getClass();
//        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass54);
//        java.lang.Class class56 = null;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year59 = week58.getYear();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(10, year59);
//        java.util.Date date61 = year59.getStart();
//        java.util.Date date62 = year59.getEnd();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date62, timeZone63);
//        java.lang.Class class65 = null;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year68 = week67.getYear();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(10, year68);
//        java.util.Date date70 = year68.getStart();
//        java.util.Date date71 = year68.getEnd();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date71, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date62, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date49, timeZone72);
//        java.util.Locale locale76 = null;
//        try {
//            org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date9, timeZone72, locale76);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560365999999L + "'", long37 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Week 24, 2019" + "'", str40.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Week 24, 2019" + "'", str41.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560365999999L + "'", long53 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(class55);
//        org.junit.Assert.assertNotNull(year59);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getYearValue();
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        long long3 = week2.getMiddleMillisecond();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62131723200001L) + "'", long3 == (-62131723200001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = week0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(10, year8);
        java.util.Date date10 = year8.getStart();
        java.util.Date date11 = year8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone12);
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year17 = week16.getYear();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
        java.util.Date date19 = year17.getStart();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date11, timeZone21);
        boolean boolean24 = week3.equals((java.lang.Object) week23);
        long long25 = week23.getSerialIndex();
        long long26 = week23.getSerialIndex();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107061L + "'", long25 == 107061L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 107061L + "'", long26 == 107061L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getMiddleMillisecond();
        int int7 = week5.getWeek();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546459199999L + "'", long6 == 1546459199999L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.util.Date date4 = year3.getEnd();
//        long long5 = year3.getMiddleMillisecond();
//        long long6 = year3.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getFirstMillisecond();
//        java.util.Date date7 = week0.getEnd();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(10, year11);
//        java.util.Date date13 = year11.getStart();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone15);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(10, year20);
//        java.util.Date date22 = year20.getStart();
//        java.util.Date date23 = year20.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date14, timeZone24);
//        java.util.Locale locale27 = null;
//        try {
//            org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date7, timeZone24, locale27);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        boolean boolean4 = week0.equals((java.lang.Object) 3);
//        int int5 = week0.getWeek();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getFirstMillisecond();
//        java.util.Calendar calendar7 = null;
//        try {
//            week0.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getYearValue();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        long long3 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '#');
        java.lang.String str3 = week2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 0, 35" + "'", str3.equals("Week 0, 35"));
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        int int10 = week8.getWeek();
//        int int11 = week8.getYearValue();
//        java.util.Date date12 = week8.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
//        long long16 = week13.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass17 = week13.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.lang.String str19 = week18.toString();
//        java.lang.String str20 = week18.toString();
//        org.jfree.data.time.Year year21 = week18.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone25);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(10, year30);
//        java.util.Date date32 = year30.getStart();
//        java.util.Date date33 = year30.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date33, timeZone34);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year39 = week38.getYear();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(10, year39);
//        java.util.Date date41 = year39.getStart();
//        java.util.Date date42 = year39.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date42, timeZone43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date33, timeZone43);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date22, timeZone43);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date12, timeZone43);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.lang.String str49 = week48.toString();
//        java.lang.String str50 = week48.toString();
//        org.jfree.data.time.Year year51 = week48.getYear();
//        java.util.Date date52 = year51.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date52, timeZone53);
//        java.util.Locale locale55 = null;
//        try {
//            org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date12, timeZone53, locale55);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560365999999L + "'", long16 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 24, 2019" + "'", str19.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 24, 2019" + "'", str20.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Week 24, 2019" + "'", str49.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 24, 2019" + "'", str50.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        java.util.Date date9 = week6.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week0.compareTo((java.lang.Object) date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
//        int int13 = week0.getWeek();
//        boolean boolean15 = week0.equals((java.lang.Object) 10);
//        boolean boolean17 = week0.equals((java.lang.Object) 32);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.next();
//        long long4 = week1.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass5 = week1.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week1.next();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        java.lang.Throwable[] throwableArray13 = timePeriodFormatException11.getSuppressed();
//        java.lang.Throwable[] throwableArray14 = timePeriodFormatException11.getSuppressed();
//        int int15 = week7.compareTo((java.lang.Object) timePeriodFormatException11);
//        java.util.Date date16 = week7.getStart();
//        org.jfree.data.time.Year year17 = week7.getYear();
//        java.util.Date date18 = year17.getEnd();
//        int int19 = week1.compareTo((java.lang.Object) year17);
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(12, year17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week20.next();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(throwableArray13);
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        int int5 = week3.getWeek();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(10, year8);
        java.util.Date date10 = year8.getStart();
        java.util.Date date11 = year8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone12);
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year17 = week16.getYear();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
        java.util.Date date19 = year17.getStart();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date11, timeZone21);
        boolean boolean24 = week3.equals((java.lang.Object) week23);
        long long25 = week3.getLastMillisecond();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1552204799999L + "'", long25 == 1552204799999L);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getStart();
//        int int6 = week0.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        long long7 = week6.getSerialIndex();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107007L + "'", long7 == 107007L);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        int int5 = week4.getWeek();
//        long long6 = week4.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(2019, year3);
        java.util.Date date8 = year3.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        long long10 = week9.getLastMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1578211199999L + "'", long10 == 1578211199999L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.next();
//        long long4 = week1.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass5 = week1.getClass();
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.lang.String str10 = week9.toString();
//        int int11 = week9.getWeek();
//        int int12 = week9.getYearValue();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.next();
//        long long17 = week14.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass18 = week14.getClass();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.lang.String str20 = week19.toString();
//        java.lang.String str21 = week19.toString();
//        org.jfree.data.time.Year year22 = week19.getYear();
//        java.util.Date date23 = year22.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23, timeZone24);
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date23, timeZone26);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(10, year31);
//        java.util.Date date33 = year31.getStart();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date34, timeZone35);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(10, year40);
//        java.util.Date date42 = year40.getStart();
//        java.util.Date date43 = year40.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date43, timeZone44);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date34, timeZone44);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date23, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date13, timeZone44);
//        java.util.Locale locale49 = null;
//        try {
//            org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date0, timeZone44, locale49);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560365999999L + "'", long17 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 24, 2019" + "'", str20.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
//        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
//        java.util.Date date9 = week0.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week10.getWeek();
//        java.util.Calendar calendar12 = null;
//        try {
//            week10.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 32);
        int int4 = week2.compareTo((java.lang.Object) 2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException8.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray16 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        java.util.Date date10 = week0.getEnd();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        org.jfree.data.time.Year year10 = week0.getYear();
        java.util.Calendar calendar11 = null;
        try {
            week0.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        long long5 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        org.jfree.data.time.Year year10 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week0.next();
        java.util.Date date12 = regularTimePeriod11.getEnd();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        long long8 = week6.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1564902000000L + "'", long8 == 1564902000000L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2020, 4);
        int int4 = week2.compareTo((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Year year4 = week0.getYear();
        org.jfree.data.time.Year year5 = week0.getYear();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        java.util.Date date9 = week6.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        int int11 = week0.compareTo((java.lang.Object) date9);
        java.util.Calendar calendar12 = null;
        try {
            week0.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        java.util.Date date6 = week0.getStart();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 0, 35");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        int int6 = week0.getWeek();
//        int int7 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.lang.String str35 = week34.toString();
//        java.lang.String str36 = week34.toString();
//        org.jfree.data.time.Year year37 = week34.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        int int41 = week33.compareTo((java.lang.Object) week40);
//        int int42 = week40.getYearValue();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str45 = timePeriodFormatException44.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str48 = timePeriodFormatException47.toString();
//        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
//        boolean boolean50 = week40.equals((java.lang.Object) timePeriodFormatException44);
//        long long51 = week40.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 24, 2019" + "'", str35.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2020 + "'", int42 == 2020);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str45.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str48.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1578211199999L + "'", long51 == 1578211199999L);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.Class<?> wildcardClass7 = date4.getClass();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        int int6 = week0.getYearValue();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, (int) (short) 1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.next();
//        long long4 = week1.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass5 = week1.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.lang.String str8 = week6.toString();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone13);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(10, year20);
//        java.util.Date date22 = year20.getStart();
//        java.util.Date date23 = year20.getEnd();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(2019, year20);
//        java.util.Date date25 = year20.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(date25);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass29 = timePeriodFormatException28.getClass();
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date30, timeZone31);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass29);
//        java.lang.Class class34 = null;
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(10, year37);
//        java.util.Date date39 = year37.getStart();
//        java.util.Date date40 = year37.getEnd();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date40, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year44 = week43.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = week43.next();
//        long long46 = week43.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass47 = week43.getClass();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        java.lang.String str49 = week48.toString();
//        java.lang.String str50 = week48.toString();
//        org.jfree.data.time.Year year51 = week48.getYear();
//        java.util.Date date52 = year51.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(date52, timeZone53);
//        java.util.TimeZone timeZone55 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass47, date52, timeZone55);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year60 = week59.getYear();
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week(10, year60);
//        java.util.Date date62 = year60.getStart();
//        java.util.Date date63 = year60.getEnd();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date63, timeZone64);
//        java.lang.Class class66 = null;
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year69 = week68.getYear();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(10, year69);
//        java.util.Date date71 = year69.getStart();
//        java.util.Date date72 = year69.getEnd();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date72, timeZone73);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date63, timeZone73);
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date52, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date40, timeZone73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date25, timeZone73);
//        java.util.Locale locale79 = null;
//        try {
//            org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date0, timeZone73, locale79);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560365999999L + "'", long46 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Week 24, 2019" + "'", str49.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 24, 2019" + "'", str50.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(year60);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(year69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        java.util.Date date4 = year2.getStart();
        java.util.Date date5 = year2.getEnd();
        java.util.Date date6 = year2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year2.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
        int int7 = week6.getWeek();
        java.util.Date date8 = week6.getStart();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        java.lang.Object obj10 = null;
        boolean boolean11 = week9.equals(obj10);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = week9.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        java.util.Date date7 = regularTimePeriod6.getEnd();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test150");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.String str7 = week6.toString();
//        long long8 = week6.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668399999L + "'", long8 == 1560668399999L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Year year4 = week0.getYear();
        java.util.Date date5 = week0.getEnd();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, (int) '4');
        long long3 = week2.getMiddleMillisecond();
        try {
            org.jfree.data.time.Year year4 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60495134400001L) + "'", long3 == (-60495134400001L));
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        int int6 = week4.getWeek();
//        int int7 = week4.getYearValue();
//        java.util.Date date8 = week4.getStart();
//        int int9 = week0.compareTo((java.lang.Object) date8);
//        boolean boolean11 = week0.equals((java.lang.Object) 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        java.util.Date date9 = week6.getStart();
//        org.jfree.data.time.Year year10 = week6.getYear();
//        org.jfree.data.time.Year year11 = week6.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
//        java.util.Date date15 = week12.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(date15);
//        int int17 = week6.compareTo((java.lang.Object) date15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week6.next();
//        int int19 = week0.compareTo((java.lang.Object) regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year19 = week18.getYear();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(10, year19);
//        java.util.Date date21 = year19.getStart();
//        java.util.Date date22 = year19.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(2019, year19);
//        java.util.Date date24 = year19.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass28 = timePeriodFormatException27.getClass();
//        java.util.Date date29 = null;
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date29, timeZone30);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year36 = week35.getYear();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(10, year36);
//        java.util.Date date38 = year36.getStart();
//        java.util.Date date39 = year36.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date39, timeZone40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year43 = week42.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week42.next();
//        long long45 = week42.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass46 = week42.getClass();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week();
//        java.lang.String str48 = week47.toString();
//        java.lang.String str49 = week47.toString();
//        org.jfree.data.time.Year year50 = week47.getYear();
//        java.util.Date date51 = year50.getEnd();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(date51, timeZone52);
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date51, timeZone54);
//        java.lang.Class class56 = null;
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year59 = week58.getYear();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(10, year59);
//        java.util.Date date61 = year59.getStart();
//        java.util.Date date62 = year59.getEnd();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date62, timeZone63);
//        java.lang.Class class65 = null;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year68 = week67.getYear();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(10, year68);
//        java.util.Date date70 = year68.getStart();
//        java.util.Date date71 = year68.getEnd();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date71, timeZone72);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date62, timeZone72);
//        org.jfree.data.time.Week week75 = new org.jfree.data.time.Week(date51, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date39, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date24, timeZone72);
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.util.Locale locale79 = null;
//        try {
//            org.jfree.data.time.Week week80 = new org.jfree.data.time.Week(date24, timeZone78, locale79);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(year19);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560365999999L + "'", long45 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Week 24, 2019" + "'", str48.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Week 24, 2019" + "'", str49.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(year59);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(timeZone78);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        int int6 = week4.getWeek();
//        int int7 = week4.getYearValue();
//        java.util.Date date8 = week4.getStart();
//        int int9 = week0.compareTo((java.lang.Object) date8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass12 = timePeriodFormatException11.getClass();
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone14);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(10, year20);
//        java.util.Date date22 = year20.getStart();
//        java.util.Date date23 = year20.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week26.next();
//        long long29 = week26.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass30 = week26.getClass();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.lang.String str32 = week31.toString();
//        java.lang.String str33 = week31.toString();
//        org.jfree.data.time.Year year34 = week31.getYear();
//        java.util.Date date35 = year34.getEnd();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date35, timeZone36);
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date35, timeZone38);
//        java.lang.Class class40 = null;
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year43 = week42.getYear();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week(10, year43);
//        java.util.Date date45 = year43.getStart();
//        java.util.Date date46 = year43.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date46, timeZone47);
//        java.lang.Class class49 = null;
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year52 = week51.getYear();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week(10, year52);
//        java.util.Date date54 = year52.getStart();
//        java.util.Date date55 = year52.getEnd();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class49, date55, timeZone56);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date46, timeZone56);
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(date35, timeZone56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date23, timeZone56);
//        java.util.Locale locale61 = null;
//        try {
//            org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(date8, timeZone56, locale61);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560365999999L + "'", long29 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 24, 2019" + "'", str32.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Week 24, 2019" + "'", str33.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(year52);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(1, 2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        java.util.Date date9 = week6.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week0.compareTo((java.lang.Object) date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
//        long long13 = week0.getSerialIndex();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getLastMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 107031L + "'", long13 == 107031L);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        long long7 = week6.getSerialIndex();
        long long8 = week6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107007L + "'", long7 == 107007L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1545854399999L + "'", long8 == 1545854399999L);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getYearValue();
//        long long3 = week0.getSerialIndex();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        int int11 = week0.compareTo((java.lang.Object) timePeriodFormatException9);
//        int int12 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
        int int7 = week6.getWeek();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
        java.lang.String str9 = week6.toString();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 32, 2019" + "'", str9.equals("Week 32, 2019"));
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        int int6 = week4.getWeek();
//        int int7 = week4.getYearValue();
//        java.util.Date date8 = week4.getStart();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8, timeZone9);
//        boolean boolean11 = week0.equals((java.lang.Object) date8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.lang.String str13 = week12.toString();
//        java.lang.String str14 = week12.toString();
//        org.jfree.data.time.Year year15 = week12.getYear();
//        java.util.Date date16 = year15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date8, timeZone17);
//        java.lang.Object obj20 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass21 = obj20.getClass();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = week22.next();
//        long long25 = week22.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass26 = week22.getClass();
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass26);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(10, year31);
//        java.util.Date date33 = year31.getStart();
//        java.util.Date date34 = year31.getEnd();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date34, timeZone35);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(10, year40);
//        java.util.Date date42 = year40.getStart();
//        java.util.Date date43 = year40.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date43, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date34, timeZone44);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year50 = week49.getYear();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(10, year50);
//        java.util.Date date52 = year50.getStart();
//        java.util.Date date53 = year50.getEnd();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date53, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date34, timeZone54);
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date34);
//        java.lang.Object obj58 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass59 = obj58.getClass();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year61 = week60.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = week60.next();
//        long long63 = week60.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass64 = week60.getClass();
//        java.lang.Class class65 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass64);
//        java.lang.Class class66 = null;
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year69 = week68.getYear();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(10, year69);
//        java.util.Date date71 = year69.getStart();
//        java.util.Date date72 = year69.getEnd();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date72, timeZone73);
//        java.lang.Class class75 = null;
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year78 = week77.getYear();
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(10, year78);
//        java.util.Date date80 = year78.getStart();
//        java.util.Date date81 = year78.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date81, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date72, timeZone82);
//        java.lang.Class class85 = null;
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year88 = week87.getYear();
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(10, year88);
//        java.util.Date date90 = year88.getStart();
//        java.util.Date date91 = year88.getEnd();
//        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class85, date91, timeZone92);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date72, timeZone92);
//        boolean boolean95 = week57.equals((java.lang.Object) timeZone92);
//        java.util.Locale locale96 = null;
//        try {
//            org.jfree.data.time.Week week97 = new org.jfree.data.time.Week(date8, timeZone92, locale96);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560365999999L + "'", long25 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNull(regularTimePeriod56);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560365999999L + "'", long63 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertNotNull(year69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(year78);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNotNull(year88);
//        org.junit.Assert.assertNotNull(date90);
//        org.junit.Assert.assertNotNull(date91);
//        org.junit.Assert.assertNotNull(timeZone92);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//        org.junit.Assert.assertNull(regularTimePeriod94);
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year10 = week9.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(10, year10);
//        java.util.Date date12 = year10.getStart();
//        java.util.Date date13 = year10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week16.next();
//        long long19 = week16.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass20 = week16.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.lang.String str22 = week21.toString();
//        java.lang.String str23 = week21.toString();
//        org.jfree.data.time.Year year24 = week21.getYear();
//        java.util.Date date25 = year24.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date25, timeZone28);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year33 = week32.getYear();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(10, year33);
//        java.util.Date date35 = year33.getStart();
//        java.util.Date date36 = year33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date36, timeZone37);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(10, year42);
//        java.util.Date date44 = year42.getStart();
//        java.util.Date date45 = year42.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date45, timeZone46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date36, timeZone46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date25, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date13, timeZone46);
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560365999999L + "'", long19 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 24, 2019" + "'", str22.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(class51);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        long long3 = week2.getFirstMillisecond();
        int int4 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62132025600000L) + "'", long3 == (-62132025600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 0, 35");
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
        java.util.Date date3 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        java.util.Date date9 = week6.getEnd();
        java.util.Date date10 = week6.getEnd();
        java.util.Calendar calendar11 = null;
        try {
            week6.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        int int9 = week7.getWeek();
//        int int10 = week7.getYearValue();
//        java.util.Date date11 = week7.getStart();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
//        java.lang.String str14 = week13.toString();
//        int int15 = week0.compareTo((java.lang.Object) week13);
//        java.lang.String str16 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
        java.lang.String str12 = week6.toString();
        java.util.Date date13 = week6.getStart();
        long long14 = week6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1545854399999L + "'", long14 == 1545854399999L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        long long6 = week5.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = week5.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546459199999L + "'", long6 == 1546459199999L);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test176");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        java.util.Date date9 = week6.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week0.compareTo((java.lang.Object) date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
//        int int13 = week0.getWeek();
//        boolean boolean15 = week0.equals((java.lang.Object) 10);
//        java.lang.String str16 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 24 + "'", int13 == 24);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
//        int int7 = week6.getWeek();
//        java.util.Date date8 = week6.getStart();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.next();
//        long long13 = week10.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass14 = week10.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.lang.String str19 = week18.toString();
//        int int20 = week18.getWeek();
//        int int21 = week18.getYearValue();
//        java.util.Date date22 = week18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week23.next();
//        long long26 = week23.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass27 = week23.getClass();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        java.lang.String str29 = week28.toString();
//        java.lang.String str30 = week28.toString();
//        org.jfree.data.time.Year year31 = week28.getYear();
//        java.util.Date date32 = year31.getEnd();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date32, timeZone33);
//        java.util.TimeZone timeZone35 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date32, timeZone35);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(10, year40);
//        java.util.Date date42 = year40.getStart();
//        java.util.Date date43 = year40.getEnd();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date43, timeZone44);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year49 = week48.getYear();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(10, year49);
//        java.util.Date date51 = year49.getStart();
//        java.util.Date date52 = year49.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date52, timeZone53);
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week(date43, timeZone53);
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(date32, timeZone53);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date22, timeZone53);
//        org.jfree.data.time.Week week58 = new org.jfree.data.time.Week(date8, timeZone53);
//        java.util.Calendar calendar59 = null;
//        try {
//            week58.peg(calendar59);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//        org.junit.Assert.assertNotNull(class17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 24, 2019" + "'", str19.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 24 + "'", int20 == 24);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560365999999L + "'", long26 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Week 24, 2019" + "'", str29.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 24, 2019" + "'", str30.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        long long9 = week6.getSerialIndex();
        java.lang.String str10 = week6.toString();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107007L + "'", long9 == 107007L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 0, 2019" + "'", str10.equals("Week 0, 2019"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week5.previous();
        java.util.Calendar calendar7 = null;
        try {
            week5.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 32, 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        int int7 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(10, year8);
        java.util.Date date10 = year8.getStart();
        java.util.Date date11 = year8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone12);
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year17 = week16.getYear();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
        java.util.Date date19 = year17.getStart();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date11, timeZone21);
        boolean boolean24 = week3.equals((java.lang.Object) week23);
        long long25 = week23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week23.previous();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107061L + "'", long25 == 107061L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, (int) '#');
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week3.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        java.util.Date date9 = week7.getEnd();
//        boolean boolean10 = week6.equals((java.lang.Object) date9);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        java.util.Date date7 = week6.getStart();
        java.util.Date date8 = week6.getEnd();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        java.lang.Object obj0 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass1 = obj0.getClass();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
//        long long5 = week2.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass6 = week2.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(10, year11);
//        java.util.Date date13 = year11.getStart();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone15);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(10, year20);
//        java.util.Date date22 = year20.getStart();
//        java.util.Date date23 = year20.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date14, timeZone24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(10, year30);
//        java.util.Date date32 = year30.getStart();
//        java.util.Date date33 = year30.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date33, timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date14, timeZone34);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14);
//        java.lang.Object obj38 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass39 = obj38.getClass();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year41 = week40.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = week40.next();
//        long long43 = week40.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass44 = week40.getClass();
//        java.lang.Class class45 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass44);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year49 = week48.getYear();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(10, year49);
//        java.util.Date date51 = year49.getStart();
//        java.util.Date date52 = year49.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date52, timeZone53);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year58 = week57.getYear();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(10, year58);
//        java.util.Date date60 = year58.getStart();
//        java.util.Date date61 = year58.getEnd();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date61, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date52, timeZone62);
//        java.lang.Class class65 = null;
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year68 = week67.getYear();
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(10, year68);
//        java.util.Date date70 = year68.getStart();
//        java.util.Date date71 = year68.getEnd();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date71, timeZone72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date52, timeZone72);
//        boolean boolean75 = week37.equals((java.lang.Object) timeZone72);
//        long long76 = week37.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(year41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560365999999L + "'", long43 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(class45);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(regularTimePeriod64);
//        org.junit.Assert.assertNotNull(year68);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNull(regularTimePeriod73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1578211199999L + "'", long76 == 1578211199999L);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Year year4 = week0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            week0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        java.util.Date date10 = week7.getStart();
//        org.jfree.data.time.Year year11 = week7.getYear();
//        org.jfree.data.time.Year year12 = week7.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
//        java.util.Date date16 = week13.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        int int18 = week7.compareTo((java.lang.Object) date16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
//        int int20 = week0.compareTo((java.lang.Object) date16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week0.previous();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        java.util.Date date4 = year2.getStart();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
        int int7 = week5.compareTo((java.lang.Object) '#');
        long long8 = week5.getLastMillisecond();
        java.util.Date date9 = week5.getEnd();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546761599999L + "'", long8 == 1546761599999L);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.String str7 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
        int int10 = week6.getWeek();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.Class class0 = null;
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        java.util.Date date6 = year3.getEnd();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date6, timeZone7);
        java.lang.Class class9 = null;
        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year12 = week11.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(10, year12);
        java.util.Date date14 = year12.getStart();
        java.util.Date date15 = year12.getEnd();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date15, timeZone16);
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date6, timeZone16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week18.next();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date9);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
//        int int9 = week0.compareTo((java.lang.Object) throwableArray8);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(throwableArray8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        long long6 = week0.getMiddleMillisecond();
//        java.lang.String str7 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (byte) 0, 0);
        int int3 = week2.getYearValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
        java.util.Date date5 = week2.getStart();
        org.jfree.data.time.Year year6 = week2.getYear();
        org.jfree.data.time.Year year7 = week2.getYear();
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(53, year7);
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(2, year7);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertNotNull(year4);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        java.lang.Class<?> wildcardClass5 = week0.getClass();
//        java.lang.String str6 = week0.toString();
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = week0.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
//        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
//        java.util.Date date9 = week0.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week10.getWeek();
//        int int12 = week10.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 24 + "'", int12 == 24);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.util.Date date5 = week3.getEnd();
        long long6 = week3.getLastMillisecond();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1552204799999L + "'", long6 == 1552204799999L);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        java.util.Date date9 = week6.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week0.compareTo((java.lang.Object) date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
//        long long13 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560063600000L + "'", long13 == 1560063600000L);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize(class15);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(class16);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        int int5 = week0.getWeek();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int8 = week6.compareTo((java.lang.Object) ' ');
//        long long9 = week6.getSerialIndex();
//        long long10 = week6.getSerialIndex();
//        java.util.Date date11 = week6.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = week12.next();
//        java.util.Date date15 = week12.getStart();
//        org.jfree.data.time.Year year16 = week12.getYear();
//        org.jfree.data.time.Year year17 = week12.getYear();
//        boolean boolean18 = week6.equals((java.lang.Object) year17);
//        boolean boolean19 = week0.equals((java.lang.Object) boolean18);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        long long5 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
        long long12 = week6.getFirstMillisecond();
        java.lang.String str13 = week6.toString();
        java.util.Date date14 = week6.getStart();
        int int15 = week6.getWeek();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1545552000000L + "'", long12 == 1545552000000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 0, 2019" + "'", str13.equals("Week 0, 2019"));
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        int int9 = week7.getWeek();
//        int int10 = week7.getYearValue();
//        java.util.Date date11 = week7.getStart();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(date11, timeZone12);
//        java.lang.String str14 = week13.toString();
//        int int15 = week0.compareTo((java.lang.Object) week13);
//        long long16 = week0.getSerialIndex();
//        java.util.Date date17 = week0.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 107031L + "'", long16 == 107031L);
//        org.junit.Assert.assertNotNull(date17);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getLastMillisecond();
//        int int8 = week0.getYearValue();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        boolean boolean7 = week0.equals((java.lang.Object) (-1));
//        org.jfree.data.time.Year year8 = week0.getYear();
//        long long9 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(10, year8);
        java.util.Date date10 = year8.getStart();
        java.util.Date date11 = year8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone12);
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year17 = week16.getYear();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
        java.util.Date date19 = year17.getStart();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date11, timeZone21);
        boolean boolean24 = week3.equals((java.lang.Object) week23);
        long long25 = week23.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week23.next();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107061L + "'", long25 == 107061L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.util.Calendar calendar5 = null;
        try {
            week3.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass8 = timePeriodFormatException7.getClass();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.String str10 = timePeriodFormatException7.toString();
        java.lang.String str11 = timePeriodFormatException7.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
        long long12 = week6.getFirstMillisecond();
        java.lang.String str13 = week6.toString();
        java.util.Date date14 = week6.getStart();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = week6.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1545552000000L + "'", long12 == 1545552000000L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 0, 2019" + "'", str13.equals("Week 0, 2019"));
        org.junit.Assert.assertNotNull(date14);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        boolean boolean7 = week0.equals((java.lang.Object) (-1));
//        long long8 = week0.getSerialIndex();
//        java.lang.String str9 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        int int6 = week4.getWeek();
//        int int7 = week4.getYearValue();
//        java.util.Date date8 = week4.getStart();
//        int int9 = week0.compareTo((java.lang.Object) date8);
//        org.jfree.data.time.Year year10 = week0.getYear();
//        long long11 = year10.getMiddleMillisecond();
//        java.util.Date date12 = year10.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1562097599999L + "'", long11 == 1562097599999L);
//        org.junit.Assert.assertNotNull(date12);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        java.util.Date date10 = week7.getStart();
//        org.jfree.data.time.Year year11 = week7.getYear();
//        org.jfree.data.time.Year year12 = week7.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
//        java.util.Date date16 = week13.getStart();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week(date16);
//        int int18 = week7.compareTo((java.lang.Object) date16);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date16);
//        int int20 = week0.compareTo((java.lang.Object) date16);
//        int int22 = week0.compareTo((java.lang.Object) 1552204799999L);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        java.util.Date date0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.next();
//        long long4 = week1.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass5 = week1.getClass();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.lang.String str8 = week6.toString();
//        org.jfree.data.time.Year year9 = week6.getYear();
//        java.util.Date date10 = year9.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date10, timeZone11);
//        java.util.TimeZone timeZone13 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date10, timeZone13);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
//        java.util.Date date16 = null;
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = week17.next();
//        long long20 = week17.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass21 = week17.getClass();
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year35 = week34.getYear();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(10, year35);
//        java.util.Date date37 = year35.getStart();
//        java.util.Date date38 = year35.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date29, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass5, date16, timeZone39);
//        try {
//            org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date0, timeZone39);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560365999999L + "'", long20 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
//        java.util.Date date5 = week3.getEnd();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        java.lang.String str9 = week7.toString();
//        boolean boolean10 = week6.equals((java.lang.Object) str9);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable7 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        org.jfree.data.time.Year year8 = week6.getYear();
        java.util.Date date9 = year8.getStart();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
//        java.util.Date date11 = week8.getStart();
//        int int12 = week0.compareTo((java.lang.Object) date11);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((-1), 24);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        java.util.Date date3 = week0.getStart();
        org.jfree.data.time.Year year4 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str8 = timePeriodFormatException7.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.String str13 = timePeriodFormatException10.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        int int15 = week0.compareTo((java.lang.Object) timePeriodFormatException7);
        java.lang.String str16 = timePeriodFormatException7.toString();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str16.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week4.next();
        java.lang.Class class6 = null;
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year9 = week8.getYear();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(10, year9);
        java.util.Date date11 = year9.getStart();
        java.util.Date date12 = year9.getEnd();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date12, timeZone13);
        java.lang.Class class15 = null;
        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year18 = week17.getYear();
        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(10, year18);
        java.util.Date date20 = year18.getStart();
        java.util.Date date21 = year18.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date21, timeZone22);
        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date12, timeZone22);
        boolean boolean25 = week4.equals((java.lang.Object) week24);
        long long26 = week24.getSerialIndex();
        org.jfree.data.time.Year year27 = week24.getYear();
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week((int) (short) -1, year27);
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 107061L + "'", long26 == 107061L);
        org.junit.Assert.assertNotNull(year27);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(2019, year3);
        org.jfree.data.time.Year year8 = week7.getYear();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(year8);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getYearValue();
//        long long3 = week0.getSerialIndex();
//        java.lang.String str4 = week0.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
//        int int11 = week0.compareTo((java.lang.Object) timePeriodFormatException9);
//        long long12 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Week 24, 2019" + "'", str4.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560063600000L + "'", long12 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
//        java.util.Date date4 = year2.getStart();
//        java.util.Date date5 = year2.getEnd();
//        java.util.Date date6 = year2.getStart();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week7.next();
//        long long10 = week7.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass11 = week7.getClass();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.lang.String str13 = week12.toString();
//        java.lang.String str14 = week12.toString();
//        org.jfree.data.time.Year year15 = week12.getYear();
//        java.util.Date date16 = year15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date16, timeZone17);
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone19);
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        int int25 = week23.compareTo((java.lang.Object) ' ');
//        long long26 = week23.getSerialIndex();
//        long long27 = week23.getSerialIndex();
//        java.util.Date date28 = week23.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.lang.String str30 = week29.toString();
//        int int31 = week29.getWeek();
//        int int32 = week29.getYearValue();
//        java.util.Date date33 = week29.getStart();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33, timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date28, timeZone34);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date6, timeZone34);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertNotNull(class22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 107031L + "'", long26 == 107031L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 107031L + "'", long27 == 107031L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 24, 2019" + "'", str30.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 24 + "'", int31 == 24);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
//        java.util.Date date7 = week6.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        int int11 = week9.compareTo((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week9.next();
//        java.util.Date date13 = week9.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass16 = timePeriodFormatException15.getClass();
//        java.util.Date date17 = null;
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date17, timeZone18);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year23 = week22.getYear();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(10, year23);
//        java.util.Date date25 = year23.getStart();
//        java.util.Date date26 = year23.getEnd();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(2019, year23);
//        java.util.Date date28 = year23.getEnd();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date28, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year35 = week34.getYear();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week(10, year35);
//        java.util.Date date37 = year35.getStart();
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week((int) ' ', year35);
//        int int39 = week38.getWeek();
//        java.util.Date date40 = week38.getStart();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date40);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year43 = week42.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = week42.next();
//        long long45 = week42.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass46 = week42.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        java.lang.Class class49 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week();
//        java.lang.String str51 = week50.toString();
//        int int52 = week50.getWeek();
//        int int53 = week50.getYearValue();
//        java.util.Date date54 = week50.getStart();
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year56 = week55.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = week55.next();
//        long long58 = week55.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass59 = week55.getClass();
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        java.lang.String str61 = week60.toString();
//        java.lang.String str62 = week60.toString();
//        org.jfree.data.time.Year year63 = week60.getYear();
//        java.util.Date date64 = year63.getEnd();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(date64, timeZone65);
//        java.util.TimeZone timeZone67 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass59, date64, timeZone67);
//        java.lang.Class class69 = null;
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year72 = week71.getYear();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(10, year72);
//        java.util.Date date74 = year72.getStart();
//        java.util.Date date75 = year72.getEnd();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date75, timeZone76);
//        java.lang.Class class78 = null;
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year81 = week80.getYear();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(10, year81);
//        java.util.Date date83 = year81.getStart();
//        java.util.Date date84 = year81.getEnd();
//        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date84, timeZone85);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date75, timeZone85);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date64, timeZone85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date54, timeZone85);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date40, timeZone85);
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date28, timeZone85);
//        org.jfree.data.time.Week week92 = new org.jfree.data.time.Week(date13, timeZone85);
//        org.jfree.data.time.Week week93 = new org.jfree.data.time.Week(date7, timeZone85);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 32 + "'", int39 == 32);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560365999999L + "'", long45 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Week 24, 2019" + "'", str51.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 24 + "'", int52 == 24);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2019 + "'", int53 == 2019);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560365999999L + "'", long58 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Week 24, 2019" + "'", str61.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Week 24, 2019" + "'", str62.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(year72);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(year81);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(timeZone85);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        java.lang.Class<?> wildcardClass8 = throwableArray7.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, 6);
        java.util.Date date3 = week2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        long long4 = week2.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week2.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62132025600000L) + "'", long4 == (-62132025600000L));
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week16.next();
//        long long19 = week16.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass20 = week16.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week16.next();
//        long long22 = week16.getFirstMillisecond();
//        java.util.Date date23 = week16.getEnd();
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year25 = week24.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = week24.next();
//        long long27 = week24.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass28 = week24.getClass();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        java.lang.String str30 = week29.toString();
//        java.lang.String str31 = week29.toString();
//        org.jfree.data.time.Year year32 = week29.getYear();
//        java.util.Date date33 = year32.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date33, timeZone34);
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date33, timeZone36);
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass28);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week();
//        int int42 = week40.compareTo((java.lang.Object) ' ');
//        long long43 = week40.getSerialIndex();
//        long long44 = week40.getSerialIndex();
//        java.util.Date date45 = week40.getEnd();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        java.lang.String str47 = week46.toString();
//        int int48 = week46.getWeek();
//        int int49 = week46.getYearValue();
//        java.util.Date date50 = week46.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week(date50, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date45, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date23, timeZone51);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560365999999L + "'", long19 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560063600000L + "'", long22 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(year25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560365999999L + "'", long27 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Week 24, 2019" + "'", str30.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Week 24, 2019" + "'", str31.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 107031L + "'", long43 == 107031L);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 107031L + "'", long44 == 107031L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Week 24, 2019" + "'", str47.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', (int) (short) 10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        int int2 = week0.compareTo((java.lang.Object) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.util.Date date4 = week0.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = week0.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(24, 10);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getStart();
//        int int6 = week0.getYearValue();
//        java.util.Date date7 = week0.getStart();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date7);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(date7);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        int int18 = week16.compareTo((java.lang.Object) ' ');
//        long long19 = week16.getSerialIndex();
//        long long20 = week16.getSerialIndex();
//        java.util.Date date21 = week16.getEnd();
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.lang.String str23 = week22.toString();
//        int int24 = week22.getWeek();
//        int int25 = week22.getYearValue();
//        java.util.Date date26 = week22.getStart();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date26, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date21, timeZone27);
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 107031L + "'", long19 == 107031L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 107031L + "'", long20 == 107031L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(class30);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = week10.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        int int6 = week4.getWeek();
//        int int7 = week4.getYearValue();
//        java.util.Date date8 = week4.getStart();
//        int int9 = week0.compareTo((java.lang.Object) date8);
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getYearValue();
//        long long4 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = week0.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        java.util.Date date4 = year3.getEnd();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        java.lang.String str7 = week6.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 1, 2020" + "'", str7.equals("Week 1, 2020"));
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Calendar calendar9 = null;
        try {
            week0.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, (int) (short) 10);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        long long2 = week0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = week0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107031L + "'", long2 == 107031L);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(2019, year3);
        java.util.Date date8 = year3.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        int int10 = week9.getWeek();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.lang.String str35 = week34.toString();
//        java.lang.String str36 = week34.toString();
//        org.jfree.data.time.Year year37 = week34.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        int int41 = week33.compareTo((java.lang.Object) week40);
//        int int42 = week40.getYearValue();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str45 = timePeriodFormatException44.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str48 = timePeriodFormatException47.toString();
//        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
//        boolean boolean50 = week40.equals((java.lang.Object) timePeriodFormatException44);
//        java.lang.String str51 = timePeriodFormatException44.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 24, 2019" + "'", str35.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2020 + "'", int42 == 2020);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str45.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str48.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str51.equals("org.jfree.data.time.TimePeriodFormatException: "));
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
//        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
//        java.util.Date date9 = week0.getStart();
//        org.jfree.data.time.Year year10 = week0.getYear();
//        long long11 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        int int9 = week1.compareTo((java.lang.Object) timePeriodFormatException5);
        java.util.Date date10 = week1.getStart();
        org.jfree.data.time.Year year11 = week1.getYear();
        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week((int) (short) 0, year11);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(year11);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        boolean boolean7 = week0.equals((java.lang.Object) (-1));
//        long long8 = week0.getSerialIndex();
//        long long9 = week0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.next();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
        int int7 = week6.getYearValue();
        java.lang.Class<?> wildcardClass8 = week6.getClass();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(32, 53);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.lang.String str35 = week34.toString();
//        java.lang.String str36 = week34.toString();
//        org.jfree.data.time.Year year37 = week34.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        int int41 = week33.compareTo((java.lang.Object) week40);
//        int int42 = week40.getYearValue();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str45 = timePeriodFormatException44.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException47 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.String str48 = timePeriodFormatException47.toString();
//        timePeriodFormatException44.addSuppressed((java.lang.Throwable) timePeriodFormatException47);
//        boolean boolean50 = week40.equals((java.lang.Object) timePeriodFormatException44);
//        boolean boolean52 = week40.equals((java.lang.Object) 7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = week40.previous();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 24, 2019" + "'", str35.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2020 + "'", int42 == 2020);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str45.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str48.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.lang.Class class7 = null;
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year10 = week9.getYear();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(10, year10);
//        java.util.Date date12 = year10.getStart();
//        java.util.Date date13 = year10.getEnd();
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date13, timeZone14);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week16.next();
//        long long19 = week16.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass20 = week16.getClass();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        java.lang.String str22 = week21.toString();
//        java.lang.String str23 = week21.toString();
//        org.jfree.data.time.Year year24 = week21.getYear();
//        java.util.Date date25 = year24.getEnd();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(date25, timeZone26);
//        java.util.TimeZone timeZone28 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date25, timeZone28);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year33 = week32.getYear();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(10, year33);
//        java.util.Date date35 = year33.getStart();
//        java.util.Date date36 = year33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date36, timeZone37);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(10, year42);
//        java.util.Date date44 = year42.getStart();
//        java.util.Date date45 = year42.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date45, timeZone46);
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(date36, timeZone46);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week(date25, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date13, timeZone46);
//        java.lang.Object obj51 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass52 = obj51.getClass();
//        org.jfree.data.time.Week week53 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year54 = week53.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = week53.next();
//        long long56 = week53.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass57 = week53.getClass();
//        java.lang.Class class58 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass57);
//        java.lang.Class class59 = null;
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year62 = week61.getYear();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(10, year62);
//        java.util.Date date64 = year62.getStart();
//        java.util.Date date65 = year62.getEnd();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date65, timeZone66);
//        java.lang.Class class68 = null;
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year71 = week70.getYear();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(10, year71);
//        java.util.Date date73 = year71.getStart();
//        java.util.Date date74 = year71.getEnd();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date74, timeZone75);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date65, timeZone75);
//        java.lang.Class class78 = null;
//        org.jfree.data.time.Week week80 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year81 = week80.getYear();
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(10, year81);
//        java.util.Date date83 = year81.getStart();
//        java.util.Date date84 = year81.getEnd();
//        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date84, timeZone85);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date65, timeZone85);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date13, timeZone85);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560365999999L + "'", long19 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Week 24, 2019" + "'", str22.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560365999999L + "'", long56 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(class58);
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(year71);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(year81);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNotNull(timeZone85);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertNull(regularTimePeriod87);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
//        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
//        int int9 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week0.previous();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(100, 4);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        long long4 = week0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(53, (int) '4');
        try {
            org.jfree.data.time.Year year3 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (52) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(11, 24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week2.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        long long6 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560063600000L + "'", long6 == 1560063600000L);
//    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        java.util.Date date4 = week0.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass7 = timePeriodFormatException6.getClass();
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date8, timeZone9);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(10, year14);
//        java.util.Date date16 = year14.getStart();
//        java.util.Date date17 = year14.getEnd();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(2019, year14);
//        java.util.Date date19 = year14.getEnd();
//        org.jfree.data.time.Week week20 = new org.jfree.data.time.Week(date19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date19, timeZone21);
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week((int) ' ', year26);
//        int int30 = week29.getWeek();
//        java.util.Date date31 = week29.getStart();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date31);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year34 = week33.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week33.next();
//        long long36 = week33.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass37 = week33.getClass();
//        java.lang.Class class38 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        int int43 = week41.getWeek();
//        int int44 = week41.getYearValue();
//        java.util.Date date45 = week41.getStart();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week46.next();
//        long long49 = week46.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass50 = week46.getClass();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week();
//        java.lang.String str52 = week51.toString();
//        java.lang.String str53 = week51.toString();
//        org.jfree.data.time.Year year54 = week51.getYear();
//        java.util.Date date55 = year54.getEnd();
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(date55, timeZone56);
//        java.util.TimeZone timeZone58 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date55, timeZone58);
//        java.lang.Class class60 = null;
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year63 = week62.getYear();
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(10, year63);
//        java.util.Date date65 = year63.getStart();
//        java.util.Date date66 = year63.getEnd();
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class60, date66, timeZone67);
//        java.lang.Class class69 = null;
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year72 = week71.getYear();
//        org.jfree.data.time.Week week73 = new org.jfree.data.time.Week(10, year72);
//        java.util.Date date74 = year72.getStart();
//        java.util.Date date75 = year72.getEnd();
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class69, date75, timeZone76);
//        org.jfree.data.time.Week week78 = new org.jfree.data.time.Week(date66, timeZone76);
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(date55, timeZone76);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass37, date45, timeZone76);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date31, timeZone76);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date19, timeZone76);
//        org.jfree.data.time.Week week83 = new org.jfree.data.time.Week(date4, timeZone76);
//        java.util.Calendar calendar84 = null;
//        try {
//            long long85 = week83.getMiddleMillisecond(calendar84);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 32 + "'", int30 == 32);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560365999999L + "'", long36 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(class38);
//        org.junit.Assert.assertNotNull(class39);
//        org.junit.Assert.assertNotNull(class40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 24 + "'", int43 == 24);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2019 + "'", int44 == 2019);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560365999999L + "'", long49 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Week 24, 2019" + "'", str52.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Week 24, 2019" + "'", str53.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//        org.junit.Assert.assertNotNull(year63);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(year72);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertNull(regularTimePeriod77);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(2019, year3);
        java.util.Date date8 = year3.getEnd();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(date8);
        java.util.TimeZone timeZone10 = null;
        java.util.Locale locale11 = null;
        try {
            org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date8, timeZone10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(32, 53);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        int int6 = week0.getWeek();
//        long long7 = week0.getSerialIndex();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        int int10 = week8.getYearValue();
//        long long11 = week8.getSerialIndex();
//        java.lang.String str12 = week8.toString();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass15 = timePeriodFormatException14.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
//        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
//        int int19 = week8.compareTo((java.lang.Object) timePeriodFormatException17);
//        java.lang.String str20 = timePeriodFormatException17.toString();
//        boolean boolean21 = week0.equals((java.lang.Object) str20);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 24, 2019" + "'", str12.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: "));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        int int6 = week4.getWeek();
//        int int7 = week4.getYearValue();
//        java.util.Date date8 = week4.getStart();
//        int int9 = week0.compareTo((java.lang.Object) date8);
//        long long10 = week0.getMiddleMillisecond();
//        java.util.Date date11 = week0.getEnd();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date11);
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
//        long long16 = week13.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass17 = week13.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.lang.String str19 = week18.toString();
//        java.lang.String str20 = week18.toString();
//        org.jfree.data.time.Year year21 = week18.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone25);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(10, year30);
//        java.util.Date date32 = year30.getStart();
//        java.util.Date date33 = year30.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date33, timeZone34);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year39 = week38.getYear();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(10, year39);
//        java.util.Date date41 = year39.getStart();
//        java.util.Date date42 = year39.getEnd();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date42, timeZone43);
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date33, timeZone43);
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week(date22, timeZone43);
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date11, timeZone43);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560365999999L + "'", long10 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560365999999L + "'", long16 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 24, 2019" + "'", str19.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 24, 2019" + "'", str20.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(year39);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        org.jfree.data.time.Year year8 = week6.getYear();
        long long9 = week6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1565204399999L + "'", long9 == 1565204399999L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getEnd();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = week0.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getStart();
//        int int6 = week0.getYearValue();
//        int int7 = week0.getWeek();
//        boolean boolean9 = week0.equals((java.lang.Object) 32);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date9);
//        int int35 = week34.getWeek();
//        long long36 = week34.getFirstMillisecond();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year38 = week37.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week37.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass42 = timePeriodFormatException41.getClass();
//        java.lang.Throwable[] throwableArray43 = timePeriodFormatException41.getSuppressed();
//        java.lang.Throwable[] throwableArray44 = timePeriodFormatException41.getSuppressed();
//        int int45 = week37.compareTo((java.lang.Object) timePeriodFormatException41);
//        java.util.Date date46 = week37.getStart();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date46);
//        int int48 = week47.getWeek();
//        java.util.Date date49 = week47.getStart();
//        int int50 = week34.compareTo((java.lang.Object) week47);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577606400000L + "'", long36 == 1577606400000L);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertNotNull(throwableArray43);
//        org.junit.Assert.assertNotNull(throwableArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
//        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
//        java.lang.String str12 = week6.toString();
//        java.util.Date date13 = week6.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.next();
//        long long17 = week14.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass18 = week14.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        int int20 = week6.compareTo((java.lang.Object) wildcardClass18);
//        java.util.Calendar calendar21 = null;
//        try {
//            week6.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560365999999L + "'", long17 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        java.util.Date date5 = regularTimePeriod4.getEnd();
//        long long6 = regularTimePeriod4.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560970799999L + "'", long6 == 1560970799999L);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass14 = timePeriodFormatException13.getClass();
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException4.getSuppressed();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        java.util.Date date7 = week6.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.previous();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        java.util.Date date8 = week6.getEnd();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week();
//        java.lang.String str10 = week9.toString();
//        int int11 = week9.getWeek();
//        int int12 = week9.getYearValue();
//        java.util.Date date13 = week9.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(date13);
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year16 = week15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = week15.next();
//        long long18 = week15.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass19 = week15.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(10, year24);
//        java.util.Date date26 = year24.getStart();
//        java.util.Date date27 = year24.getEnd();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date27, timeZone28);
//        java.lang.Class class30 = null;
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year33 = week32.getYear();
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(10, year33);
//        java.util.Date date35 = year33.getStart();
//        java.util.Date date36 = year33.getEnd();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date36, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date27, timeZone37);
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date13, timeZone37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date8, timeZone37);
//        org.jfree.data.time.Week week42 = new org.jfree.data.time.Week(date8);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560365999999L + "'", long18 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        long long5 = week4.getFirstMillisecond();
//        org.jfree.data.time.Year year6 = week4.getYear();
//        java.util.Calendar calendar7 = null;
//        try {
//            week4.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year6);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(0, (int) (byte) 0);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        long long6 = week0.getLastMillisecond();
//        long long7 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        java.lang.Throwable[] throwableArray14 = timePeriodFormatException12.getSuppressed();
//        java.lang.Throwable[] throwableArray15 = timePeriodFormatException12.getSuppressed();
//        int int16 = week8.compareTo((java.lang.Object) timePeriodFormatException12);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass22 = timePeriodFormatException21.getClass();
//        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
//        timePeriodFormatException12.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
//        java.lang.Throwable[] throwableArray25 = timePeriodFormatException18.getSuppressed();
//        boolean boolean26 = week0.equals((java.lang.Object) throwableArray25);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertNotNull(throwableArray15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(throwableArray25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        java.util.Date date5 = week0.getEnd();
//        int int6 = week0.getWeek();
//        long long7 = week0.getFirstMillisecond();
//        long long8 = week0.getMiddleMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            week0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560063600000L + "'", long7 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        int int9 = week7.getWeek();
//        long long10 = week7.getSerialIndex();
//        boolean boolean11 = week0.equals((java.lang.Object) long10);
//        org.jfree.data.time.Year year12 = week0.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year14 = week13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = week13.next();
//        long long16 = week13.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass17 = week13.getClass();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week();
//        java.lang.String str19 = week18.toString();
//        java.lang.String str20 = week18.toString();
//        org.jfree.data.time.Year year21 = week18.getYear();
//        java.util.Date date22 = year21.getEnd();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week24 = new org.jfree.data.time.Week(date22, timeZone23);
//        java.util.TimeZone timeZone25 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date22, timeZone25);
//        java.lang.Class class27 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass17);
//        java.util.Date date28 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = week29.next();
//        long long32 = week29.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass33 = week29.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year38 = week37.getYear();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week(10, year38);
//        java.util.Date date40 = year38.getStart();
//        java.util.Date date41 = year38.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date41, timeZone42);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week(10, year47);
//        java.util.Date date49 = year47.getStart();
//        java.util.Date date50 = year47.getEnd();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance(class44, date50, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date41, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date28, timeZone51);
//        int int55 = week0.compareTo((java.lang.Object) wildcardClass17);
//        int int56 = week0.getWeek();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560365999999L + "'", long16 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Week 24, 2019" + "'", str19.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 24, 2019" + "'", str20.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(class27);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560365999999L + "'", long32 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 24 + "'", int56 == 24);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2019, (int) (byte) 10);
        int int3 = week2.getWeek();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-29) + "'", int3 == (-29));
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getWeek();
//        java.lang.String str6 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = week0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        java.lang.Object obj0 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass1 = obj0.getClass();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
//        long long5 = week2.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass6 = week2.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(10, year11);
//        java.util.Date date13 = year11.getStart();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone15);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(10, year20);
//        java.util.Date date22 = year20.getStart();
//        java.util.Date date23 = year20.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date14, timeZone24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(10, year30);
//        java.util.Date date32 = year30.getStart();
//        java.util.Date date33 = year30.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date33, timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date14, timeZone34);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        java.lang.String str38 = week37.toString();
//        int int39 = week37.getWeek();
//        int int40 = week37.getYearValue();
//        java.util.Date date41 = week37.getStart();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date41, timeZone42);
//        java.util.Locale locale44 = null;
//        try {
//            org.jfree.data.time.Week week45 = new org.jfree.data.time.Week(date14, timeZone42, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 24, 2019" + "'", str38.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 24 + "'", int39 == 24);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2020, 4);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        boolean boolean7 = week0.equals((java.lang.Object) (-1));
//        org.jfree.data.time.Year year8 = week0.getYear();
//        org.jfree.data.time.Year year9 = week0.getYear();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(year9);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        int int3 = week0.getYearValue();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException5.getSuppressed();
//        boolean boolean7 = week0.equals((java.lang.Object) timePeriodFormatException5);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = week0.getLastMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        int int9 = week7.getWeek();
//        long long10 = week7.getSerialIndex();
//        boolean boolean11 = week0.equals((java.lang.Object) long10);
//        org.jfree.data.time.Year year12 = week0.getYear();
//        long long13 = week0.getMiddleMillisecond();
//        int int14 = week0.getWeek();
//        java.util.Date date15 = week0.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 24 + "'", int14 == 24);
//        org.junit.Assert.assertNotNull(date15);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        boolean boolean7 = week0.equals((java.lang.Object) (-1));
//        long long8 = week0.getSerialIndex();
//        long long9 = week0.getFirstMillisecond();
//        java.lang.String str10 = week0.toString();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(2020, 4);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        java.lang.String str10 = week8.toString();
//        org.jfree.data.time.Year year11 = week8.getYear();
//        long long12 = week8.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week8.next();
//        boolean boolean14 = week7.equals((java.lang.Object) regularTimePeriod13);
//        int int15 = week0.compareTo((java.lang.Object) boolean14);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Week 24, 2019" + "'", str10.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560365999999L + "'", long12 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str6 = timePeriodFormatException4.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException8.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str13 = timePeriodFormatException11.toString();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass19 = timePeriodFormatException18.getClass();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException25 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass26 = timePeriodFormatException25.getClass();
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException25);
        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year29 = week28.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = week28.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass33 = timePeriodFormatException32.getClass();
        java.lang.Throwable[] throwableArray34 = timePeriodFormatException32.getSuppressed();
        java.lang.Throwable[] throwableArray35 = timePeriodFormatException32.getSuppressed();
        int int36 = week28.compareTo((java.lang.Object) timePeriodFormatException32);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass39 = timePeriodFormatException38.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException41 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass42 = timePeriodFormatException41.getClass();
        timePeriodFormatException38.addSuppressed((java.lang.Throwable) timePeriodFormatException41);
        timePeriodFormatException32.addSuppressed((java.lang.Throwable) timePeriodFormatException38);
        java.lang.String str45 = timePeriodFormatException32.toString();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
        java.lang.String str47 = timePeriodFormatException25.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException49 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass50 = timePeriodFormatException49.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException52 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException49.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        java.lang.String str54 = timePeriodFormatException52.toString();
        java.lang.Throwable[] throwableArray55 = timePeriodFormatException52.getSuppressed();
        timePeriodFormatException25.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException52);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str45.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str47.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str54.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray55);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
        int int14 = week6.compareTo((java.lang.Object) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException19.getClass();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str23 = timePeriodFormatException10.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str25 = timePeriodFormatException3.toString();
        java.lang.Throwable[] throwableArray26 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray26);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        try {
            org.jfree.data.time.Week week1 = org.jfree.data.time.Week.parseWeek("Week 1, 2020");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the week.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        org.jfree.data.time.Year year10 = week0.getYear();
        java.util.Date date11 = year10.getEnd();
        long long12 = year10.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getLastMillisecond();
//        int int7 = week0.getYearValue();
//        java.util.Calendar calendar8 = null;
//        try {
//            week0.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
        int int14 = week6.compareTo((java.lang.Object) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException19.getClass();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        java.lang.String str23 = timePeriodFormatException10.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray25 = timePeriodFormatException10.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray25);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 1);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
//        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
//        java.util.Date date9 = week0.getEnd();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.next();
//        long long13 = week10.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass14 = week10.getClass();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week();
//        java.lang.String str16 = week15.toString();
//        java.lang.String str17 = week15.toString();
//        org.jfree.data.time.Year year18 = week15.getYear();
//        java.util.Date date19 = year18.getEnd();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(date19, timeZone20);
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date19, timeZone22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year29 = week28.getYear();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(10, year29);
//        java.util.Date date31 = year29.getStart();
//        java.util.Date date32 = year29.getEnd();
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(2019, year29);
//        java.util.Date date34 = year29.getEnd();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass38 = timePeriodFormatException37.getClass();
//        java.util.Date date39 = null;
//        java.util.TimeZone timeZone40 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date39, timeZone40);
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.Week week45 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year46 = week45.getYear();
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(10, year46);
//        java.util.Date date48 = year46.getStart();
//        java.util.Date date49 = year46.getEnd();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class43, date49, timeZone50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year53 = week52.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week52.next();
//        long long55 = week52.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass56 = week52.getClass();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        java.lang.String str58 = week57.toString();
//        java.lang.String str59 = week57.toString();
//        org.jfree.data.time.Year year60 = week57.getYear();
//        java.util.Date date61 = year60.getEnd();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(date61, timeZone62);
//        java.util.TimeZone timeZone64 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass56, date61, timeZone64);
//        java.lang.Class class66 = null;
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year69 = week68.getYear();
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week(10, year69);
//        java.util.Date date71 = year69.getStart();
//        java.util.Date date72 = year69.getEnd();
//        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance(class66, date72, timeZone73);
//        java.lang.Class class75 = null;
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year78 = week77.getYear();
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week(10, year78);
//        java.util.Date date80 = year78.getStart();
//        java.util.Date date81 = year78.getEnd();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date81, timeZone82);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date72, timeZone82);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date61, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date49, timeZone82);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date34, timeZone82);
//        org.jfree.data.time.Week week88 = new org.jfree.data.time.Week(date9, timeZone82);
//        org.jfree.data.time.Year year89 = week88.getYear();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560365999999L + "'", long13 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Week 24, 2019" + "'", str16.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Week 24, 2019" + "'", str17.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(year46);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560365999999L + "'", long55 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Week 24, 2019" + "'", str58.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Week 24, 2019" + "'", str59.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(year69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(timeZone73);
//        org.junit.Assert.assertNull(regularTimePeriod74);
//        org.junit.Assert.assertNotNull(year78);
//        org.junit.Assert.assertNotNull(date80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertNotNull(year89);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize(class7);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(class8);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(10, year4);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(2019, year4);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.String str3 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.String str5 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date9);
//        java.lang.Class<?> wildcardClass35 = date9.getClass();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.lang.String str35 = week34.toString();
//        java.lang.String str36 = week34.toString();
//        org.jfree.data.time.Year year37 = week34.getYear();
//        java.util.Date date38 = year37.getEnd();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date38, timeZone39);
//        int int41 = week33.compareTo((java.lang.Object) week40);
//        long long42 = week40.getSerialIndex();
//        java.util.Date date43 = week40.getStart();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 24, 2019" + "'", str35.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 107061L + "'", long42 == 107061L);
//        org.junit.Assert.assertNotNull(date43);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week6.next();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = week6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getStart();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getStart();
//        java.lang.String str6 = week0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(2020, 4);
        long long3 = week2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62058240000001L) + "'", long3 == (-62058240000001L));
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        java.lang.String str3 = week1.toString();
//        org.jfree.data.time.Year year4 = week1.getYear();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        int int7 = week5.getWeek();
//        int int8 = week5.getYearValue();
//        java.util.Date date9 = week5.getStart();
//        int int10 = week1.compareTo((java.lang.Object) date9);
//        org.jfree.data.time.Year year11 = week1.getYear();
//        long long12 = year11.getMiddleMillisecond();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(2020, year11);
//        long long14 = week13.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1528916399999L + "'", long14 == 1528916399999L);
//    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
//        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
//        java.lang.String str12 = week6.toString();
//        java.util.Date date13 = week6.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.next();
//        long long17 = week14.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass18 = week14.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        int int20 = week6.compareTo((java.lang.Object) wildcardClass18);
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(10, year24);
//        java.util.Date date26 = year24.getStart();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(0, year24);
//        java.util.Date date28 = week27.getStart();
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week(date28);
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year31 = week30.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = week30.next();
//        long long33 = week30.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass34 = week30.getClass();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week();
//        java.lang.String str36 = week35.toString();
//        java.lang.String str37 = week35.toString();
//        org.jfree.data.time.Year year38 = week35.getYear();
//        java.util.Date date39 = year38.getEnd();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week(date39, timeZone40);
//        java.util.TimeZone timeZone42 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date39, timeZone42);
//        java.lang.Class class44 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass34);
//        java.util.Date date45 = null;
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year47 = week46.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = week46.next();
//        long long49 = week46.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass50 = week46.getClass();
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass50);
//        java.lang.Class class52 = null;
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year55 = week54.getYear();
//        org.jfree.data.time.Week week56 = new org.jfree.data.time.Week(10, year55);
//        java.util.Date date57 = year55.getStart();
//        java.util.Date date58 = year55.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class52, date58, timeZone59);
//        java.lang.Class class61 = null;
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year64 = week63.getYear();
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(10, year64);
//        java.util.Date date66 = year64.getStart();
//        java.util.Date date67 = year64.getEnd();
//        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class61, date67, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date58, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date45, timeZone68);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date28, timeZone68);
//        java.lang.Class<?> wildcardClass73 = date28.getClass();
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560365999999L + "'", long17 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(year31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560365999999L + "'", long33 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Week 24, 2019" + "'", str36.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Week 24, 2019" + "'", str37.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(class44);
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560365999999L + "'", long49 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(class51);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertNotNull(year64);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone68);
//        org.junit.Assert.assertNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.String str7 = timePeriodFormatException1.toString();
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        long long8 = week5.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week11.next();
//        long long14 = week11.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass15 = week11.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week11.next();
//        long long17 = week11.getFirstMillisecond();
//        java.util.Date date18 = week11.getEnd();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.lang.String str20 = week19.toString();
//        java.lang.String str21 = week19.toString();
//        org.jfree.data.time.Year year22 = week19.getYear();
//        java.util.Date date23 = year22.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date18, timeZone24);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year28 = week27.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week27.next();
//        long long30 = week27.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass31 = week27.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year34 = week33.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week33.next();
//        long long36 = week33.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass37 = week33.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week33.next();
//        long long39 = week33.getFirstMillisecond();
//        java.util.Date date40 = week33.getEnd();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        java.lang.String str43 = week41.toString();
//        org.jfree.data.time.Year year44 = week41.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date40, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date18, timeZone46);
//        java.lang.Class<?> wildcardClass50 = regularTimePeriod49.getClass();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560365999999L + "'", long14 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 24, 2019" + "'", str20.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560365999999L + "'", long30 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560365999999L + "'", long36 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560063600000L + "'", long39 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 24, 2019" + "'", str43.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        java.lang.Object obj0 = new java.lang.Object();
//        java.lang.Class<?> wildcardClass1 = obj0.getClass();
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week2.next();
//        long long5 = week2.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass6 = week2.getClass();
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass6);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year11 = week10.getYear();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(10, year11);
//        java.util.Date date13 = year11.getStart();
//        java.util.Date date14 = year11.getEnd();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date14, timeZone15);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(10, year20);
//        java.util.Date date22 = year20.getStart();
//        java.util.Date date23 = year20.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date14, timeZone24);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year30 = week29.getYear();
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week(10, year30);
//        java.util.Date date32 = year30.getStart();
//        java.util.Date date33 = year30.getEnd();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date33, timeZone34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date14, timeZone34);
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week(date14);
//        org.jfree.data.time.Week week38 = new org.jfree.data.time.Week(date14);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560365999999L + "'", long5 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year30);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(10, year4);
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(0, year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(24, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week8.previous();
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        long long3 = week0.getSerialIndex();
//        int int5 = week0.compareTo((java.lang.Object) 1560365999999L);
//        long long6 = week0.getLastMillisecond();
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        java.lang.String str8 = week7.toString();
//        int int9 = week7.getWeek();
//        long long10 = week7.getSerialIndex();
//        boolean boolean11 = week0.equals((java.lang.Object) long10);
//        java.util.Calendar calendar12 = null;
//        try {
//            week0.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Week 24, 2019" + "'", str8.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        int int3 = week1.getWeek();
//        int int4 = week1.getYearValue();
//        java.util.Date date5 = week1.getStart();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date5, timeZone6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(date5);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(10, year12);
//        java.util.Date date14 = year12.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) ' ', year12);
//        int int16 = week15.getWeek();
//        java.util.Date date17 = week15.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week19.next();
//        long long22 = week19.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass23 = week19.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.lang.String str28 = week27.toString();
//        int int29 = week27.getWeek();
//        int int30 = week27.getYearValue();
//        java.util.Date date31 = week27.getStart();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year33 = week32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.next();
//        long long35 = week32.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass36 = week32.getClass();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        java.lang.String str38 = week37.toString();
//        java.lang.String str39 = week37.toString();
//        org.jfree.data.time.Year year40 = week37.getYear();
//        java.util.Date date41 = year40.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date41, timeZone42);
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date41, timeZone44);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year49 = week48.getYear();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(10, year49);
//        java.util.Date date51 = year49.getStart();
//        java.util.Date date52 = year49.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date52, timeZone53);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year58 = week57.getYear();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(10, year58);
//        java.util.Date date60 = year58.getStart();
//        java.util.Date date61 = year58.getEnd();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date61, timeZone62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date52, timeZone62);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date41, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date31, timeZone62);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date17, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date5, timeZone62);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 24, 2019" + "'", str28.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560365999999L + "'", long35 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 24, 2019" + "'", str38.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 24, 2019" + "'", str39.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str9 = timePeriodFormatException7.toString();
        java.lang.String str10 = timePeriodFormatException7.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        java.util.Date date7 = week6.getStart();
        int int8 = week6.getWeek();
        org.jfree.data.time.Year year9 = week6.getYear();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(year9);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        long long4 = week0.getLastMillisecond();
//        int int5 = week0.getWeek();
//        long long6 = week0.getLastMillisecond();
//        java.util.Date date7 = week0.getEnd();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560668399999L + "'", long4 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//        org.junit.Assert.assertNotNull(date7);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        org.jfree.data.time.Year year10 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week0.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
//        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
//        long long9 = week0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(10, year4);
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) ' ', year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week(32, year4);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = week8.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year18 = week17.getYear();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(10, year18);
//        java.util.Date date20 = year18.getStart();
//        java.util.Date date21 = year18.getEnd();
//        java.util.Date date22 = year18.getStart();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year24 = week23.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = week23.next();
//        long long26 = week23.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass27 = week23.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        java.lang.Class class29 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        java.lang.Class class30 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        org.jfree.data.time.Week week31 = new org.jfree.data.time.Week();
//        java.lang.String str32 = week31.toString();
//        int int33 = week31.getWeek();
//        int int34 = week31.getYearValue();
//        java.util.Date date35 = week31.getStart();
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week36.next();
//        long long39 = week36.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass40 = week36.getClass();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        java.lang.String str43 = week41.toString();
//        org.jfree.data.time.Year year44 = week41.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        java.util.TimeZone timeZone48 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date45, timeZone48);
//        java.lang.Class class50 = null;
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year53 = week52.getYear();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week(10, year53);
//        java.util.Date date55 = year53.getStart();
//        java.util.Date date56 = year53.getEnd();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date56, timeZone57);
//        java.lang.Class class59 = null;
//        org.jfree.data.time.Week week61 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year62 = week61.getYear();
//        org.jfree.data.time.Week week63 = new org.jfree.data.time.Week(10, year62);
//        java.util.Date date64 = year62.getStart();
//        java.util.Date date65 = year62.getEnd();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class59, date65, timeZone66);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date56, timeZone66);
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week(date45, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date35, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date22, timeZone66);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date22);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(class14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560365999999L + "'", long26 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertNotNull(class29);
//        org.junit.Assert.assertNotNull(class30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Week 24, 2019" + "'", str32.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 24 + "'", int33 == 24);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560365999999L + "'", long39 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 24, 2019" + "'", str43.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        long long5 = week0.getSerialIndex();
//        long long6 = week0.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 107031L + "'", long5 == 107031L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        java.lang.String str6 = week5.toString();
//        java.lang.String str7 = week5.toString();
//        org.jfree.data.time.Year year8 = week5.getYear();
//        java.util.Date date9 = year8.getEnd();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(date9, timeZone10);
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date9, timeZone12);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year26 = week25.getYear();
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week(10, year26);
//        java.util.Date date28 = year26.getStart();
//        java.util.Date date29 = year26.getEnd();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date29, timeZone30);
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week(date20, timeZone30);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week(date9, timeZone30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week34.previous();
//        long long36 = week34.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Week 24, 2019" + "'", str6.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577606400000L + "'", long36 == 1577606400000L);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date4, timeZone5);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass10 = timePeriodFormatException9.getClass();
//        java.util.Date date11 = null;
//        java.util.TimeZone timeZone12 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone12);
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year17 = week16.getYear();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
//        java.util.Date date19 = year17.getStart();
//        java.util.Date date20 = year17.getEnd();
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week(2019, year17);
//        java.util.Date date22 = year17.getEnd();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date22);
//        java.util.TimeZone timeZone24 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date22, timeZone24);
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year29 = week28.getYear();
//        org.jfree.data.time.Week week30 = new org.jfree.data.time.Week(10, year29);
//        java.util.Date date31 = year29.getStart();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week((int) ' ', year29);
//        int int33 = week32.getWeek();
//        java.util.Date date34 = week32.getStart();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(date34);
//        org.jfree.data.time.Week week36 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year37 = week36.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week36.next();
//        long long39 = week36.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass40 = week36.getClass();
//        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        java.lang.Class class42 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        java.lang.Class class43 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        java.lang.String str45 = week44.toString();
//        int int46 = week44.getWeek();
//        int int47 = week44.getYearValue();
//        java.util.Date date48 = week44.getStart();
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year50 = week49.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = week49.next();
//        long long52 = week49.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass53 = week49.getClass();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        java.lang.String str55 = week54.toString();
//        java.lang.String str56 = week54.toString();
//        org.jfree.data.time.Year year57 = week54.getYear();
//        java.util.Date date58 = year57.getEnd();
//        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week(date58, timeZone59);
//        java.util.TimeZone timeZone61 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date58, timeZone61);
//        java.lang.Class class63 = null;
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year66 = week65.getYear();
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(10, year66);
//        java.util.Date date68 = year66.getStart();
//        java.util.Date date69 = year66.getEnd();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date69, timeZone70);
//        java.lang.Class class72 = null;
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year75 = week74.getYear();
//        org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(10, year75);
//        java.util.Date date77 = year75.getStart();
//        java.util.Date date78 = year75.getEnd();
//        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date78, timeZone79);
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(date69, timeZone79);
//        org.jfree.data.time.Week week82 = new org.jfree.data.time.Week(date58, timeZone79);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date48, timeZone79);
//        org.jfree.data.time.Week week84 = new org.jfree.data.time.Week(date34, timeZone79);
//        org.jfree.data.time.Week week85 = new org.jfree.data.time.Week(date22, timeZone79);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year88 = week87.getYear();
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(10, year88);
//        java.util.Date date90 = year88.getStart();
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date90);
//        int int92 = week85.compareTo((java.lang.Object) date90);
//        int int93 = week7.compareTo((java.lang.Object) int92);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(year17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 32 + "'", int33 == 32);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560365999999L + "'", long39 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass40);
//        org.junit.Assert.assertNotNull(class41);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNotNull(class43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Week 24, 2019" + "'", str45.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 24 + "'", int46 == 24);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(year50);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560365999999L + "'", long52 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Week 24, 2019" + "'", str55.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Week 24, 2019" + "'", str56.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(timeZone59);
//        org.junit.Assert.assertNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(year66);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(year75);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNotNull(timeZone79);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertNotNull(year88);
//        org.junit.Assert.assertNotNull(date90);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
//        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        boolean boolean4 = week0.equals((java.lang.Object) 3);
//        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year8 = week7.getYear();
//        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(10, year8);
//        java.util.Date date10 = year8.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week(0, year8);
//        java.util.Date date12 = week11.getStart();
//        boolean boolean13 = week0.equals((java.lang.Object) week11);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = week0.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        java.lang.Class<?> wildcardClass3 = week2.getClass();
        java.util.Date date4 = week2.getEnd();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week0.previous();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '4', 32);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = week2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
//        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
//        int int9 = week0.getWeek();
//        int int10 = week0.getWeek();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 24 + "'", int9 == 24);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
//        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
//        java.util.Date date9 = week0.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week10.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = week10.next();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        java.lang.String str2 = week1.toString();
//        int int3 = week1.getWeek();
//        long long4 = week1.getSerialIndex();
//        int int6 = week1.compareTo((java.lang.Object) 1560365999999L);
//        long long7 = week1.getLastMillisecond();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        java.lang.String str9 = week8.toString();
//        int int10 = week8.getWeek();
//        long long11 = week8.getSerialIndex();
//        boolean boolean12 = week1.equals((java.lang.Object) long11);
//        org.jfree.data.time.Year year13 = week1.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week((int) (byte) 100, year13);
//        int int15 = week14.getYearValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.previous();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560668399999L + "'", long7 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Week 24, 2019" + "'", str9.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 24 + "'", int10 == 24);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 107031L + "'", long11 == 107031L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week((int) ' ', year3);
//        int int7 = week6.getWeek();
//        java.util.Date date8 = week6.getStart();
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week(10, year12);
//        java.util.Date date14 = year12.getStart();
//        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week((int) ' ', year12);
//        int int16 = week15.getWeek();
//        java.util.Date date17 = week15.getStart();
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year20 = week19.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = week19.next();
//        long long22 = week19.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass23 = week19.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        java.lang.String str28 = week27.toString();
//        int int29 = week27.getWeek();
//        int int30 = week27.getYearValue();
//        java.util.Date date31 = week27.getStart();
//        org.jfree.data.time.Week week32 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year33 = week32.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = week32.next();
//        long long35 = week32.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass36 = week32.getClass();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week();
//        java.lang.String str38 = week37.toString();
//        java.lang.String str39 = week37.toString();
//        org.jfree.data.time.Year year40 = week37.getYear();
//        java.util.Date date41 = year40.getEnd();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week(date41, timeZone42);
//        java.util.TimeZone timeZone44 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date41, timeZone44);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.Week week48 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year49 = week48.getYear();
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(10, year49);
//        java.util.Date date51 = year49.getStart();
//        java.util.Date date52 = year49.getEnd();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date52, timeZone53);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year58 = week57.getYear();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week(10, year58);
//        java.util.Date date60 = year58.getStart();
//        java.util.Date date61 = year58.getEnd();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date61, timeZone62);
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week(date52, timeZone62);
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date41, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date31, timeZone62);
//        org.jfree.data.time.Week week67 = new org.jfree.data.time.Week(date17, timeZone62);
//        org.jfree.data.time.Week week68 = new org.jfree.data.time.Week(date8, timeZone62);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560365999999L + "'", long22 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(class26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Week 24, 2019" + "'", str28.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 24 + "'", int29 == 24);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560365999999L + "'", long35 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Week 24, 2019" + "'", str38.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Week 24, 2019" + "'", str39.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(year49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(year58);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNull(regularTimePeriod63);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        long long3 = week0.getSerialIndex();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
//        java.lang.String str5 = week4.toString();
//        int int6 = week4.getWeek();
//        int int7 = week4.getYearValue();
//        java.util.Date date8 = week4.getStart();
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date8, timeZone9);
//        boolean boolean11 = week0.equals((java.lang.Object) date8);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        java.lang.String str13 = week12.toString();
//        java.lang.String str14 = week12.toString();
//        org.jfree.data.time.Year year15 = week12.getYear();
//        java.util.Date date16 = year15.getEnd();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(date16, timeZone17);
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week(date8, timeZone17);
//        long long20 = week19.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Week 24, 2019" + "'", str5.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Week 24, 2019" + "'", str13.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560668399999L + "'", long20 == 1560668399999L);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.lang.Class class5 = null;
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year8 = week7.getYear();
        org.jfree.data.time.Week week9 = new org.jfree.data.time.Week(10, year8);
        java.util.Date date10 = year8.getStart();
        java.util.Date date11 = year8.getEnd();
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date11, timeZone12);
        java.lang.Class class14 = null;
        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year17 = week16.getYear();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(10, year17);
        java.util.Date date19 = year17.getStart();
        java.util.Date date20 = year17.getEnd();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date20, timeZone21);
        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(date11, timeZone21);
        boolean boolean24 = week3.equals((java.lang.Object) week23);
        long long25 = week23.getSerialIndex();
        org.jfree.data.time.Year year26 = week23.getYear();
        long long27 = week23.getFirstMillisecond();
        java.util.Calendar calendar28 = null;
        try {
            long long29 = week23.getFirstMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(year17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 107061L + "'", long25 == 107061L);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577606400000L + "'", long27 == 1577606400000L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year3 = week2.getYear();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
        java.util.Date date5 = year3.getStart();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
        long long12 = week6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week6.previous();
        long long14 = week6.getLastMillisecond();
        org.junit.Assert.assertNotNull(year3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1545552000000L + "'", long12 == 1545552000000L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546156799999L + "'", long14 == 1546156799999L);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Week 24, 2019");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException8.getClass();
        timePeriodFormatException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week0.next();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        java.lang.String str7 = week6.toString();
//        int int8 = week6.getWeek();
//        long long9 = week6.getSerialIndex();
//        int int11 = week6.compareTo((java.lang.Object) 1560365999999L);
//        int int12 = week0.compareTo((java.lang.Object) week6);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = week0.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Week 24, 2019" + "'", str7.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 24 + "'", int8 == 24);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year5 = week4.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = week4.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass9 = timePeriodFormatException8.getClass();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException8.getSuppressed();
        int int12 = week4.compareTo((java.lang.Object) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass15 = timePeriodFormatException14.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass18 = timePeriodFormatException17.getClass();
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) timePeriodFormatException17);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException14.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        java.util.Date date5 = week0.getEnd();
//        java.util.Calendar calendar6 = null;
//        try {
//            week0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year6 = week5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = week5.next();
//        long long8 = week5.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass9 = week5.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Week week11 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year12 = week11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = week11.next();
//        long long14 = week11.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass15 = week11.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week11.next();
//        long long17 = week11.getFirstMillisecond();
//        java.util.Date date18 = week11.getEnd();
//        org.jfree.data.time.Week week19 = new org.jfree.data.time.Week();
//        java.lang.String str20 = week19.toString();
//        java.lang.String str21 = week19.toString();
//        org.jfree.data.time.Year year22 = week19.getYear();
//        java.util.Date date23 = year22.getEnd();
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date23, timeZone24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date18, timeZone24);
//        org.jfree.data.time.Week week27 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year28 = week27.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = week27.next();
//        long long30 = week27.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass31 = week27.getClass();
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass31);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year34 = week33.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = week33.next();
//        long long36 = week33.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass37 = week33.getClass();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = week33.next();
//        long long39 = week33.getFirstMillisecond();
//        java.util.Date date40 = week33.getEnd();
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        java.lang.String str42 = week41.toString();
//        java.lang.String str43 = week41.toString();
//        org.jfree.data.time.Year year44 = week41.getYear();
//        java.util.Date date45 = year44.getEnd();
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week47 = new org.jfree.data.time.Week(date45, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date40, timeZone46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date18, timeZone46);
//        java.lang.Class<?> wildcardClass50 = date18.getClass();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(year6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560365999999L + "'", long8 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(year12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560365999999L + "'", long14 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560063600000L + "'", long17 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Week 24, 2019" + "'", str20.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Week 24, 2019" + "'", str21.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560365999999L + "'", long30 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560365999999L + "'", long36 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560063600000L + "'", long39 == 1560063600000L);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Week 24, 2019" + "'", str42.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Week 24, 2019" + "'", str43.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(date3);
//        long long5 = week4.getFirstMillisecond();
//        long long6 = week4.getSerialIndex();
//        long long7 = week4.getSerialIndex();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560063600000L + "'", long5 == 1560063600000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 107031L + "'", long6 == 107031L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 107031L + "'", long7 == 107031L);
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
//        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
//        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
//        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
//        java.util.Date date9 = week0.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week10.getWeek();
//        java.util.Date date12 = week10.getStart();
//        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
//        java.lang.String str14 = week13.toString();
//        java.lang.String str15 = week13.toString();
//        org.jfree.data.time.Year year16 = week13.getYear();
//        org.jfree.data.time.Week week17 = new org.jfree.data.time.Week();
//        java.lang.String str18 = week17.toString();
//        int int19 = week17.getWeek();
//        int int20 = week17.getYearValue();
//        java.util.Date date21 = week17.getStart();
//        int int22 = week13.compareTo((java.lang.Object) date21);
//        long long23 = week13.getMiddleMillisecond();
//        java.util.Date date24 = week13.getEnd();
//        org.jfree.data.time.Week week25 = new org.jfree.data.time.Week(date24);
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year27 = week26.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week26.next();
//        long long29 = week26.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass30 = week26.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        org.jfree.data.time.Week week34 = new org.jfree.data.time.Week();
//        java.lang.String str35 = week34.toString();
//        int int36 = week34.getWeek();
//        int int37 = week34.getYearValue();
//        java.util.Date date38 = week34.getStart();
//        org.jfree.data.time.Week week39 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year40 = week39.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = week39.next();
//        long long42 = week39.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass43 = week39.getClass();
//        org.jfree.data.time.Week week44 = new org.jfree.data.time.Week();
//        java.lang.String str45 = week44.toString();
//        java.lang.String str46 = week44.toString();
//        org.jfree.data.time.Year year47 = week44.getYear();
//        java.util.Date date48 = year47.getEnd();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week50 = new org.jfree.data.time.Week(date48, timeZone49);
//        java.util.TimeZone timeZone51 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date48, timeZone51);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.Week week55 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year56 = week55.getYear();
//        org.jfree.data.time.Week week57 = new org.jfree.data.time.Week(10, year56);
//        java.util.Date date58 = year56.getStart();
//        java.util.Date date59 = year56.getEnd();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance(class53, date59, timeZone60);
//        java.lang.Class class62 = null;
//        org.jfree.data.time.Week week64 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year65 = week64.getYear();
//        org.jfree.data.time.Week week66 = new org.jfree.data.time.Week(10, year65);
//        java.util.Date date67 = year65.getStart();
//        java.util.Date date68 = year65.getEnd();
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance(class62, date68, timeZone69);
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(date59, timeZone69);
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(date48, timeZone69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date38, timeZone69);
//        org.jfree.data.time.Week week74 = new org.jfree.data.time.Week(date24, timeZone69);
//        java.util.Locale locale75 = null;
//        try {
//            org.jfree.data.time.Week week76 = new org.jfree.data.time.Week(date12, timeZone69, locale75);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(throwableArray6);
//        org.junit.Assert.assertNotNull(throwableArray7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 24 + "'", int11 == 24);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Week 24, 2019" + "'", str14.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Week 24, 2019" + "'", str15.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Week 24, 2019" + "'", str18.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 24 + "'", int19 == 24);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560365999999L + "'", long23 == 1560365999999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(year27);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560365999999L + "'", long29 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Week 24, 2019" + "'", str35.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 24 + "'", int36 == 24);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2019 + "'", int37 == 2019);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(year40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560365999999L + "'", long42 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Week 24, 2019" + "'", str45.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Week 24, 2019" + "'", str46.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(regularTimePeriod52);
//        org.junit.Assert.assertNotNull(year56);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNull(regularTimePeriod61);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNotNull(timeZone69);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) (short) 0, (int) '#');
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year4 = week3.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week3.next();
//        long long6 = week3.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass7 = week3.getClass();
//        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
//        boolean boolean11 = week2.equals((java.lang.Object) class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
//        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//        org.junit.Assert.assertNotNull(class8);
//        org.junit.Assert.assertNotNull(class9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(class14);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year4 = week3.getYear();
        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(10, year4);
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.Week week7 = new org.jfree.data.time.Week((int) ' ', year4);
        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week((int) 'a', year4);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        java.util.Date date6 = regularTimePeriod5.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.lang.String str2 = week0.toString();
//        org.jfree.data.time.Year year3 = week0.getYear();
//        long long4 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week0.next();
//        long long6 = week0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Week 24, 2019" + "'", str2.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560668399999L + "'", long6 == 1560668399999L);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
//        java.util.Date date4 = year2.getStart();
//        org.jfree.data.time.Week week5 = new org.jfree.data.time.Week(date4);
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        int int8 = week6.compareTo((java.lang.Object) ' ');
//        long long9 = week6.getSerialIndex();
//        long long10 = week6.getSerialIndex();
//        int int11 = week5.compareTo((java.lang.Object) week6);
//        long long12 = week5.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 107031L + "'", long9 == 107031L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 107031L + "'", long10 == 107031L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-23) + "'", int11 == (-23));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546156800000L + "'", long12 == 1546156800000L);
//    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        java.util.Date date3 = week0.getStart();
//        org.jfree.data.time.Year year4 = week0.getYear();
//        org.jfree.data.time.Year year5 = week0.getYear();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year7 = week6.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
//        java.util.Date date9 = week6.getStart();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(date9);
//        int int11 = week0.compareTo((java.lang.Object) date9);
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week(date9);
//        long long13 = week12.getLastMillisecond();
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year4);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668399999L + "'", long13 == 1560668399999L);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        java.util.Date date2 = week0.getEnd();
//        java.lang.String str3 = week0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Week 24, 2019" + "'", str3.equals("Week 24, 2019"));
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year2 = week1.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = week1.next();
//        long long4 = week1.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = week1.next();
//        int int6 = week1.getWeek();
//        boolean boolean8 = week1.equals((java.lang.Object) (-1));
//        org.jfree.data.time.Year year9 = week1.getYear();
//        org.jfree.data.time.Week week10 = new org.jfree.data.time.Week(2020, year9);
//        org.junit.Assert.assertNotNull(year2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560365999999L + "'", long4 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(year9);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week((int) '#', 12);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year1 = week0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass5 = timePeriodFormatException4.getClass();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException4.getSuppressed();
        int int8 = week0.compareTo((java.lang.Object) timePeriodFormatException4);
        java.util.Date date9 = week0.getStart();
        org.jfree.data.time.Year year10 = week0.getYear();
        org.jfree.data.time.Week week13 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year14 = week13.getYear();
        org.jfree.data.time.Week week15 = new org.jfree.data.time.Week(10, year14);
        java.util.Date date16 = year14.getStart();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Week week18 = new org.jfree.data.time.Week(2019, year14);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass21 = timePeriodFormatException20.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException20.addSuppressed((java.lang.Throwable) timePeriodFormatException23);
        java.lang.String str25 = timePeriodFormatException23.toString();
        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year27 = week26.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = week26.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass31 = timePeriodFormatException30.getClass();
        java.lang.Throwable[] throwableArray32 = timePeriodFormatException30.getSuppressed();
        java.lang.Throwable[] throwableArray33 = timePeriodFormatException30.getSuppressed();
        int int34 = week26.compareTo((java.lang.Object) timePeriodFormatException30);
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        java.lang.Throwable[] throwableArray36 = timePeriodFormatException23.getSuppressed();
        boolean boolean37 = week18.equals((java.lang.Object) throwableArray36);
        int int38 = week0.compareTo((java.lang.Object) boolean37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = week0.next();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str25.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(year27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass4 = week0.getClass();
//        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
//        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        int int10 = week8.compareTo((java.lang.Object) ' ');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week8.next();
//        java.util.Date date12 = week8.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass15 = timePeriodFormatException14.getClass();
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone17);
//        org.jfree.data.time.Week week21 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year22 = week21.getYear();
//        org.jfree.data.time.Week week23 = new org.jfree.data.time.Week(10, year22);
//        java.util.Date date24 = year22.getStart();
//        java.util.Date date25 = year22.getEnd();
//        org.jfree.data.time.Week week26 = new org.jfree.data.time.Week(2019, year22);
//        java.util.Date date27 = year22.getEnd();
//        org.jfree.data.time.Week week28 = new org.jfree.data.time.Week(date27);
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date27, timeZone29);
//        org.jfree.data.time.Week week33 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year34 = week33.getYear();
//        org.jfree.data.time.Week week35 = new org.jfree.data.time.Week(10, year34);
//        java.util.Date date36 = year34.getStart();
//        org.jfree.data.time.Week week37 = new org.jfree.data.time.Week((int) ' ', year34);
//        int int38 = week37.getWeek();
//        java.util.Date date39 = week37.getStart();
//        org.jfree.data.time.Week week40 = new org.jfree.data.time.Week(date39);
//        org.jfree.data.time.Week week41 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year42 = week41.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = week41.next();
//        long long44 = week41.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass45 = week41.getClass();
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        java.lang.Class class48 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass45);
//        org.jfree.data.time.Week week49 = new org.jfree.data.time.Week();
//        java.lang.String str50 = week49.toString();
//        int int51 = week49.getWeek();
//        int int52 = week49.getYearValue();
//        java.util.Date date53 = week49.getStart();
//        org.jfree.data.time.Week week54 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year55 = week54.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = week54.next();
//        long long57 = week54.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass58 = week54.getClass();
//        org.jfree.data.time.Week week59 = new org.jfree.data.time.Week();
//        java.lang.String str60 = week59.toString();
//        java.lang.String str61 = week59.toString();
//        org.jfree.data.time.Year year62 = week59.getYear();
//        java.util.Date date63 = year62.getEnd();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Week week65 = new org.jfree.data.time.Week(date63, timeZone64);
//        java.util.TimeZone timeZone66 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass58, date63, timeZone66);
//        java.lang.Class class68 = null;
//        org.jfree.data.time.Week week70 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year71 = week70.getYear();
//        org.jfree.data.time.Week week72 = new org.jfree.data.time.Week(10, year71);
//        java.util.Date date73 = year71.getStart();
//        java.util.Date date74 = year71.getEnd();
//        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date74, timeZone75);
//        java.lang.Class class77 = null;
//        org.jfree.data.time.Week week79 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year80 = week79.getYear();
//        org.jfree.data.time.Week week81 = new org.jfree.data.time.Week(10, year80);
//        java.util.Date date82 = year80.getStart();
//        java.util.Date date83 = year80.getEnd();
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance(class77, date83, timeZone84);
//        org.jfree.data.time.Week week86 = new org.jfree.data.time.Week(date74, timeZone84);
//        org.jfree.data.time.Week week87 = new org.jfree.data.time.Week(date63, timeZone84);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date53, timeZone84);
//        org.jfree.data.time.Week week89 = new org.jfree.data.time.Week(date39, timeZone84);
//        org.jfree.data.time.Week week90 = new org.jfree.data.time.Week(date27, timeZone84);
//        org.jfree.data.time.Week week91 = new org.jfree.data.time.Week(date12, timeZone84);
//        java.util.TimeZone timeZone92 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date12, timeZone92);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertNotNull(class5);
//        org.junit.Assert.assertNotNull(class6);
//        org.junit.Assert.assertNotNull(class7);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(year22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(year34);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 32 + "'", int38 == 32);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(year42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560365999999L + "'", long44 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(class48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Week 24, 2019" + "'", str50.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 24 + "'", int51 == 24);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560365999999L + "'", long57 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Week 24, 2019" + "'", str60.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Week 24, 2019" + "'", str61.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(year62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(year71);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone75);
//        org.junit.Assert.assertNull(regularTimePeriod76);
//        org.junit.Assert.assertNotNull(year80);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(regularTimePeriod88);
//        org.junit.Assert.assertNull(regularTimePeriod93);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year1 = week0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = week0.next();
//        long long3 = week0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week0.next();
//        int int5 = week0.getWeek();
//        boolean boolean7 = week0.equals((java.lang.Object) (-1));
//        long long8 = week0.getSerialIndex();
//        long long9 = week0.getFirstMillisecond();
//        org.jfree.data.time.Week week12 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year13 = week12.getYear();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week(10, year13);
//        java.util.Date date15 = year13.getStart();
//        org.jfree.data.time.Week week16 = new org.jfree.data.time.Week(0, year13);
//        boolean boolean18 = week16.equals((java.lang.Object) "hi!");
//        java.util.Date date19 = week16.getEnd();
//        java.lang.Class<?> wildcardClass20 = date19.getClass();
//        int int21 = week0.compareTo((java.lang.Object) date19);
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week(date19);
//        org.junit.Assert.assertNotNull(year1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560365999999L + "'", long3 == 1560365999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 107031L + "'", long8 == 107031L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560063600000L + "'", long9 == 1560063600000L);
//        org.junit.Assert.assertNotNull(year13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year7 = week6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = week6.next();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass11 = timePeriodFormatException10.getClass();
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException10.getSuppressed();
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException10.getSuppressed();
        int int14 = week6.compareTo((java.lang.Object) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException16.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass20 = timePeriodFormatException19.getClass();
        timePeriodFormatException16.addSuppressed((java.lang.Throwable) timePeriodFormatException19);
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException16);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException10.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        java.util.Date date4 = year2.getStart();
        java.util.Date date5 = year2.getEnd();
        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(date5);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(3, (int) (short) 100);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        java.lang.String str1 = week0.toString();
//        int int2 = week0.getWeek();
//        int int3 = week0.getYearValue();
//        java.util.Date date4 = week0.getStart();
//        java.util.Date date5 = week0.getStart();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = week0.equals(obj6);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Week 24, 2019" + "'", str1.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 24 + "'", int2 == 24);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Week week0 = new org.jfree.data.time.Week();
//        int int2 = week0.compareTo((java.lang.Object) ' ');
//        long long3 = week0.getSerialIndex();
//        long long4 = week0.getSerialIndex();
//        java.util.Date date5 = week0.getEnd();
//        int int6 = week0.getWeek();
//        java.util.Date date7 = week0.getEnd();
//        org.jfree.data.time.Week week8 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year9 = week8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week8.next();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass13 = timePeriodFormatException12.getClass();
//        java.lang.Throwable[] throwableArray14 = timePeriodFormatException12.getSuppressed();
//        java.lang.Throwable[] throwableArray15 = timePeriodFormatException12.getSuppressed();
//        int int16 = week8.compareTo((java.lang.Object) timePeriodFormatException12);
//        java.util.Date date17 = week8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = week8.previous();
//        int int19 = week0.compareTo((java.lang.Object) week8);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = week8.getMiddleMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 107031L + "'", long3 == 107031L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 107031L + "'", long4 == 107031L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 24 + "'", int6 == 24);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(throwableArray14);
//        org.junit.Assert.assertNotNull(throwableArray15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week(8, (int) (short) 1);
        long long3 = week2.getFirstMillisecond();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Class<?> wildcardClass6 = timePeriodFormatException5.getClass();
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException5.getSuppressed();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException5.getSuppressed();
        int int10 = week2.compareTo((java.lang.Object) throwableArray9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week2.previous();
        try {
            org.jfree.data.time.Year year12 = week2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62132025600000L) + "'", long3 == (-62132025600000L));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Week week1 = new org.jfree.data.time.Week();
        org.jfree.data.time.Year year2 = week1.getYear();
        org.jfree.data.time.Week week3 = new org.jfree.data.time.Week(10, year2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = week3.next();
        java.util.Date date5 = week3.getEnd();
        java.lang.Class<?> wildcardClass6 = week3.getClass();
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.Week week2 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year3 = week2.getYear();
//        org.jfree.data.time.Week week4 = new org.jfree.data.time.Week(10, year3);
//        java.util.Date date5 = year3.getStart();
//        org.jfree.data.time.Week week6 = new org.jfree.data.time.Week(0, year3);
//        boolean boolean8 = week6.equals((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = week6.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = week6.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = week6.next();
//        java.lang.String str12 = week6.toString();
//        java.util.Date date13 = week6.getStart();
//        org.jfree.data.time.Week week14 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year15 = week14.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = week14.next();
//        long long17 = week14.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass18 = week14.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        int int20 = week6.compareTo((java.lang.Object) wildcardClass18);
//        java.util.Date date21 = null;
//        org.jfree.data.time.Week week22 = new org.jfree.data.time.Week();
//        java.lang.String str23 = week22.toString();
//        int int24 = week22.getWeek();
//        int int25 = week22.getYearValue();
//        java.util.Date date26 = week22.getStart();
//        java.lang.Class<?> wildcardClass27 = date26.getClass();
//        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
//        org.jfree.data.time.Week week29 = new org.jfree.data.time.Week();
//        int int31 = week29.compareTo((java.lang.Object) ' ');
//        long long32 = week29.getSerialIndex();
//        long long33 = week29.getSerialIndex();
//        java.util.Date date34 = week29.getEnd();
//        int int35 = week29.getWeek();
//        java.util.Date date36 = week29.getEnd();
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("");
//        java.lang.Class<?> wildcardClass39 = timePeriodFormatException38.getClass();
//        java.util.Date date40 = null;
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date40, timeZone41);
//        org.jfree.data.time.Week week43 = new org.jfree.data.time.Week();
//        java.lang.String str44 = week43.toString();
//        java.util.Date date45 = week43.getEnd();
//        org.jfree.data.time.Week week46 = new org.jfree.data.time.Week();
//        java.lang.String str47 = week46.toString();
//        int int48 = week46.getWeek();
//        int int49 = week46.getYearValue();
//        java.util.Date date50 = week46.getStart();
//        org.jfree.data.time.Week week51 = new org.jfree.data.time.Week(date50);
//        org.jfree.data.time.Week week52 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year53 = week52.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = week52.next();
//        long long55 = week52.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass56 = week52.getClass();
//        java.lang.Class class57 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass56);
//        java.lang.Class class58 = null;
//        org.jfree.data.time.Week week60 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year61 = week60.getYear();
//        org.jfree.data.time.Week week62 = new org.jfree.data.time.Week(10, year61);
//        java.util.Date date63 = year61.getStart();
//        java.util.Date date64 = year61.getEnd();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class58, date64, timeZone65);
//        java.lang.Class class67 = null;
//        org.jfree.data.time.Week week69 = new org.jfree.data.time.Week();
//        org.jfree.data.time.Year year70 = week69.getYear();
//        org.jfree.data.time.Week week71 = new org.jfree.data.time.Week(10, year70);
//        java.util.Date date72 = year70.getStart();
//        java.util.Date date73 = year70.getEnd();
//        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class67, date73, timeZone74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = org.jfree.data.time.RegularTimePeriod.createInstance(class57, date64, timeZone74);
//        org.jfree.data.time.Week week77 = new org.jfree.data.time.Week(date50, timeZone74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass39, date45, timeZone74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date36, timeZone74);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date21, timeZone74);
//        org.junit.Assert.assertNotNull(year3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Week 0, 2019" + "'", str12.equals("Week 0, 2019"));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(year15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560365999999L + "'", long17 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Week 24, 2019" + "'", str23.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 24 + "'", int24 == 24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(class28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 107031L + "'", long32 == 107031L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 107031L + "'", long33 == 107031L);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 24 + "'", int35 == 24);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Week 24, 2019" + "'", str44.equals("Week 24, 2019"));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Week 24, 2019" + "'", str47.equals("Week 24, 2019"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 24 + "'", int48 == 24);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(year53);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560365999999L + "'", long55 == 1560365999999L);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNotNull(class57);
//        org.junit.Assert.assertNotNull(year61);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNull(regularTimePeriod66);
//        org.junit.Assert.assertNotNull(year70);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(timeZone74);
//        org.junit.Assert.assertNull(regularTimePeriod75);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertNull(regularTimePeriod78);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertNull(regularTimePeriod80);
//    }
//}

