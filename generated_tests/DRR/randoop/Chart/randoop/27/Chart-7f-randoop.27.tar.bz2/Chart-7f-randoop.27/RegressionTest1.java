import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 1546329600000L);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean6 = timePeriodValues4.equals((java.lang.Object) 7);
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues4);
        java.util.Date date8 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.Date date22 = day14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str27 = timePeriodValues26.getDescription();
        timePeriodValues26.setRangeDescription("hi!");
        int int30 = timePeriodValues26.getMaxStartIndex();
        int int31 = day14.compareTo((java.lang.Object) int30);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day14, (double) (-1));
        int int34 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) day17);
//        java.util.Date date19 = day17.getEnd();
//        int int20 = day17.getYear();
//        int int21 = day17.getYear();
//        long long22 = day17.getFirstMillisecond();
//        long long23 = day17.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day17, "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str31 = timePeriodValues30.getDescription();
//        timePeriodValues30.setRangeDescription("hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str38 = timePeriodValues37.getDescription();
//        timePeriodValues37.setDescription("Time");
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        boolean boolean42 = timePeriodValues37.equals((java.lang.Object) day41);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean45 = day41.equals((java.lang.Object) (short) 1);
//        int int46 = day41.getMonth();
//        org.jfree.data.time.SerialDate serialDate47 = day41.getSerialDate();
//        java.util.Date date48 = day41.getStart();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date48);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        boolean boolean55 = timePeriodValues53.equals((java.lang.Object) 7);
//        boolean boolean56 = timePeriodValues53.isEmpty();
//        int int57 = year51.compareTo((java.lang.Object) boolean56);
//        java.util.Date date58 = year51.getEnd();
//        boolean boolean59 = timePeriodValues30.equals((java.lang.Object) year51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year51.next();
//        boolean boolean62 = year51.equals((java.lang.Object) 'a');
//        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str67 = timePeriodValues66.getDescription();
//        timePeriodValues66.setDescription("Time");
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        boolean boolean71 = timePeriodValues66.equals((java.lang.Object) day70);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent73 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean74 = day70.equals((java.lang.Object) (short) 1);
//        int int75 = day70.getMonth();
//        org.jfree.data.time.SerialDate serialDate76 = day70.getSerialDate();
//        java.util.Date date77 = day70.getStart();
//        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date77, timeZone78);
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date77);
//        org.jfree.data.time.TimePeriodValue timePeriodValue82 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year80, (double) (byte) 0);
//        boolean boolean83 = year51.equals((java.lang.Object) timePeriodValue82);
//        boolean boolean84 = day17.equals((java.lang.Object) timePeriodValue82);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertNull(str31);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNull(str67);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 6 + "'", int75 == 6);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(timeZone78);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        int int11 = day7.getYear();
        int int12 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "hi!", "hi!");
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) (byte) 1);
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue18.getPeriod();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(timePeriod19);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str13 = timePeriodValues12.getDescription();
        timePeriodValues12.setDescription("Time");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        boolean boolean17 = timePeriodValues12.equals((java.lang.Object) day16);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean20 = day16.equals((java.lang.Object) (short) 1);
        int int21 = day16.getMonth();
        org.jfree.data.time.SerialDate serialDate22 = day16.getSerialDate();
        java.util.Date date23 = day16.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23, timeZone24);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str30 = timePeriodValues29.getDescription();
        timePeriodValues29.setDescription("Time");
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        boolean boolean34 = timePeriodValues29.equals((java.lang.Object) day33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean37 = day33.equals((java.lang.Object) (short) 1);
        int int38 = day33.getMonth();
        org.jfree.data.time.SerialDate serialDate39 = day33.getSerialDate();
        java.util.Date date40 = day33.getStart();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date23, timeZone41);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year43, (double) 1.0f);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.setDomainDescription("");
        timePeriodValues10.setDomainDescription("hi!");
        boolean boolean15 = simpleTimePeriod2.equals((java.lang.Object) "hi!");
        java.util.Date date16 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 100L);
        java.lang.Object obj20 = timePeriodValue19.clone();
        timePeriodValue19.setValue((java.lang.Number) 1560452399999L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1.0]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1.0d + "'", obj3.equals(1.0d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.delete((int) (short) 10, 4);
        try {
            timePeriodValues3.update(0, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        boolean boolean35 = year24.equals((java.lang.Object) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues39.setDomainDescription("");
        int int42 = year24.compareTo((java.lang.Object) timePeriodValues39);
        boolean boolean43 = timePeriodValues39.isEmpty();
        java.lang.String str44 = timePeriodValues39.getDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(str44);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        int int9 = timePeriodValues7.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues7.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        timePeriodValues1.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long11 = simpleTimePeriod10.getStartMillis();
        long long12 = simpleTimePeriod10.getEndMillis();
        java.util.Date date13 = simpleTimePeriod10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str18 = timePeriodValues17.getDescription();
        timePeriodValues17.setDescription("Time");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        boolean boolean22 = timePeriodValues17.equals((java.lang.Object) day21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean25 = day21.equals((java.lang.Object) (short) 1);
        int int26 = day21.getMonth();
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        java.util.Date date28 = day21.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str35 = timePeriodValues34.getDescription();
        timePeriodValues34.setDescription("Time");
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        boolean boolean39 = timePeriodValues34.equals((java.lang.Object) day38);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean42 = day38.equals((java.lang.Object) (short) 1);
        int int43 = day38.getMonth();
        org.jfree.data.time.SerialDate serialDate44 = day38.getSerialDate();
        java.util.Date date45 = day38.getStart();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45, timeZone46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date28, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date13, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str54 = timePeriodValues53.getDescription();
        timePeriodValues53.setDescription("Time");
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        boolean boolean58 = timePeriodValues53.equals((java.lang.Object) day57);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean61 = day57.equals((java.lang.Object) (short) 1);
        int int62 = day57.getMonth();
        org.jfree.data.time.SerialDate serialDate63 = day57.getSerialDate();
        java.util.Date date64 = day57.getStart();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date64, timeZone65);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date64);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long71 = simpleTimePeriod70.getStartMillis();
        long long72 = simpleTimePeriod70.getEndMillis();
        boolean boolean74 = simpleTimePeriod70.equals((java.lang.Object) 'a');
        java.util.Date date75 = simpleTimePeriod70.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues79 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str80 = timePeriodValues79.getDescription();
        timePeriodValues79.setDescription("Time");
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day();
        boolean boolean84 = timePeriodValues79.equals((java.lang.Object) day83);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent86 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean87 = day83.equals((java.lang.Object) (short) 1);
        int int88 = day83.getMonth();
        org.jfree.data.time.SerialDate serialDate89 = day83.getSerialDate();
        java.util.Date date90 = day83.getStart();
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date90, timeZone91);
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date75, timeZone91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date64, timeZone91);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 12L + "'", long12 == 12L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 0L + "'", long71 == 0L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 12L + "'", long72 == 12L);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 6 + "'", int88 == 6);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
//        int int11 = day7.getYear();
//        int int12 = day7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
//        int int14 = day7.getMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int14, "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str22 = timePeriodValues21.getDescription();
//        timePeriodValues21.setDescription("Time");
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
//        int int30 = day25.getMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
//        java.util.Date date32 = day25.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean36 = day34.equals((java.lang.Object) day35);
//        java.util.Date date37 = day35.getEnd();
//        int int38 = day35.getYear();
//        int int39 = day35.getYear();
//        long long40 = day35.getFirstMillisecond();
//        long long41 = day35.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day35, "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!", "");
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 100L);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560409200000L + "'", long40 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43629L + "'", long41 == 43629L);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setRangeDescription("hi!");
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        int int14 = timePeriodValues1.getMaxStartIndex();
        int int15 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long21 = simpleTimePeriod20.getStartMillis();
        long long22 = simpleTimePeriod20.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str27 = timePeriodValues26.getDescription();
        timePeriodValues26.setDescription("Time");
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        boolean boolean31 = timePeriodValues26.equals((java.lang.Object) day30);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean34 = day30.equals((java.lang.Object) (short) 1);
        int int35 = day30.getMonth();
        org.jfree.data.time.SerialDate serialDate36 = day30.getSerialDate();
        java.util.Date date37 = day30.getStart();
        java.util.Date date38 = day30.getEnd();
        int int39 = simpleTimePeriod20.compareTo((java.lang.Object) day30);
        boolean boolean41 = simpleTimePeriod20.equals((java.lang.Object) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str46 = timePeriodValues45.getDescription();
        timePeriodValues45.setRangeDescription("hi!");
        java.lang.String str49 = timePeriodValues45.getDomainDescription();
        int int50 = timePeriodValues45.getMaxEndIndex();
        java.lang.Comparable comparable51 = timePeriodValues45.getKey();
        boolean boolean52 = simpleTimePeriod20.equals((java.lang.Object) timePeriodValues45);
        long long53 = simpleTimePeriod20.getStartMillis();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 12L + "'", long22 == 12L);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + comparable51 + "' != '" + (-1.0d) + "'", comparable51.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues14.addChangeListener(seriesChangeListener18);
        boolean boolean20 = timePeriodValue10.equals((java.lang.Object) timePeriodValues14);
        java.lang.Comparable comparable21 = timePeriodValues14.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str26 = timePeriodValues25.getDescription();
        timePeriodValues25.setDescription("Time");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean33 = day29.equals((java.lang.Object) (short) 1);
        int int34 = day29.getMonth();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int34);
        boolean boolean36 = timePeriodValues14.equals((java.lang.Object) seriesChangeEvent35);
        java.lang.Object obj37 = seriesChangeEvent35.getSource();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (-1.0d) + "'", comparable21.equals((-1.0d)));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + obj37 + "' != '" + 6 + "'", obj37.equals(6));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date14);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(13, (int) (short) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        boolean boolean36 = year34.equals((java.lang.Object) 0.0f);
        long long37 = year34.getSerialIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues41.setDescription("Time");
        java.lang.Object obj44 = timePeriodValues41.clone();
        int int45 = year34.compareTo((java.lang.Object) timePeriodValues41);
        boolean boolean46 = timePeriodValues41.getNotify();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.Object obj28 = null;
        boolean boolean29 = timePeriodValue14.equals(obj28);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        long long2 = day0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        timePeriodValues6.setDescription("Time");
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        boolean boolean11 = timePeriodValues6.equals((java.lang.Object) day10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean14 = day10.equals((java.lang.Object) (short) 1);
        int int15 = day10.getMonth();
        org.jfree.data.time.SerialDate serialDate16 = day10.getSerialDate();
        java.util.Date date17 = day10.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        boolean boolean21 = day19.equals((java.lang.Object) day20);
        java.util.Date date22 = day20.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str27 = timePeriodValues26.getDescription();
        timePeriodValues26.setDescription("Time");
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        boolean boolean31 = timePeriodValues26.equals((java.lang.Object) day30);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean34 = day30.equals((java.lang.Object) (short) 1);
        int int35 = day30.getMonth();
        org.jfree.data.time.SerialDate serialDate36 = day30.getSerialDate();
        java.util.Date date37 = day30.getStart();
        java.util.Date date38 = day30.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str43 = timePeriodValues42.getDescription();
        timePeriodValues42.setDescription("Time");
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        boolean boolean47 = timePeriodValues42.equals((java.lang.Object) day46);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean50 = day46.equals((java.lang.Object) (short) 1);
        int int51 = day46.getMonth();
        org.jfree.data.time.SerialDate serialDate52 = day46.getSerialDate();
        java.util.Date date53 = day46.getStart();
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date53, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date53);
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str61 = timePeriodValues60.getDescription();
        timePeriodValues60.setDescription("Time");
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        boolean boolean65 = timePeriodValues60.equals((java.lang.Object) day64);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean68 = day64.equals((java.lang.Object) (short) 1);
        int int69 = day64.getMonth();
        org.jfree.data.time.SerialDate serialDate70 = day64.getSerialDate();
        java.util.Date date71 = day64.getStart();
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date71, timeZone72);
        org.jfree.data.time.TimePeriodValues timePeriodValues77 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str78 = timePeriodValues77.getDescription();
        timePeriodValues77.setDescription("Time");
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
        boolean boolean82 = timePeriodValues77.equals((java.lang.Object) day81);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent84 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean85 = day81.equals((java.lang.Object) (short) 1);
        int int86 = day81.getMonth();
        org.jfree.data.time.SerialDate serialDate87 = day81.getSerialDate();
        java.util.Date date88 = day81.getStart();
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date88, timeZone89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date71, timeZone89);
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date53, timeZone89);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date38, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date22, timeZone89);
        java.lang.Class class95 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class96 = org.jfree.data.time.RegularTimePeriod.downsize(class95);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 6 + "'", int69 == 6);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(str78);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 6 + "'", int86 == 6);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertNotNull(class95);
        org.junit.Assert.assertNotNull(class96);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
//        int int11 = day7.getYear();
//        int int12 = day7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "hi!", "hi!");
//        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) (byte) 1);
//        int int19 = day7.getDayOfMonth();
//        java.lang.String str20 = day7.toString();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.Date date15 = day7.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str20 = timePeriodValues19.getDescription();
//        timePeriodValues19.setRangeDescription("hi!");
//        int int23 = timePeriodValues19.getMaxStartIndex();
//        int int24 = day7.compareTo((java.lang.Object) int23);
//        java.lang.String str25 = day7.toString();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
//        long long29 = simpleTimePeriod28.getStartMillis();
//        long long30 = simpleTimePeriod28.getEndMillis();
//        long long31 = simpleTimePeriod28.getStartMillis();
//        int int32 = day7.compareTo((java.lang.Object) long31);
//        java.lang.String str33 = day7.toString();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 12L + "'", long30 == 12L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "13-June-2019" + "'", str33.equals("13-June-2019"));
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.Object obj28 = timePeriodValues1.clone();
        int int29 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,1.0]");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.lang.Class<?> wildcardClass15 = date14.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setDescription("Time");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        boolean boolean24 = timePeriodValues19.equals((java.lang.Object) day23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean27 = day23.equals((java.lang.Object) (short) 1);
        int int28 = day23.getMonth();
        org.jfree.data.time.SerialDate serialDate29 = day23.getSerialDate();
        java.util.Date date30 = day23.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date14, timeZone31);
        long long34 = year33.getMiddleMillisecond();
        java.lang.String str35 = year33.toString();
        java.util.Date date36 = year33.getEnd();
        long long37 = year33.getLastMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1562097599999L + "'", long34 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.lang.Class<?> wildcardClass14 = serialDate13.getClass();
        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(class15);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setRangeDescription("hi!");
        int int17 = timePeriodValues13.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener18);
        timePeriodValues13.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        boolean boolean22 = timePeriodValues13.getNotify();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) boolean22);
        java.lang.String str24 = timePeriodValues3.getDomainDescription();
        java.lang.String str25 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        java.lang.String str12 = timePeriodValue10.toString();
//        java.lang.Number number13 = timePeriodValue10.getValue();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0d + "'", number11.equals(1.0d));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str12.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str26 = timePeriodValues25.getDescription();
        timePeriodValues25.setDescription("Time");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean33 = day29.equals((java.lang.Object) (short) 1);
        int int34 = day29.getMonth();
        org.jfree.data.time.SerialDate serialDate35 = day29.getSerialDate();
        java.util.Date date36 = day29.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean43 = timePeriodValues41.equals((java.lang.Object) 7);
        boolean boolean44 = timePeriodValues41.isEmpty();
        int int45 = year39.compareTo((java.lang.Object) boolean44);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setRangeDescription("");
        int int53 = year39.compareTo((java.lang.Object) "");
        boolean boolean54 = simpleTimePeriod2.equals((java.lang.Object) int53);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str59 = timePeriodValues58.getDescription();
        timePeriodValues58.setDescription("Time");
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        boolean boolean63 = timePeriodValues58.equals((java.lang.Object) day62);
        org.jfree.data.time.TimePeriodValue timePeriodValue65 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day62, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str70 = timePeriodValues69.getDescription();
        timePeriodValues69.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener73 = null;
        timePeriodValues69.addChangeListener(seriesChangeListener73);
        boolean boolean75 = timePeriodValue65.equals((java.lang.Object) timePeriodValues69);
        boolean boolean76 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues69);
        org.jfree.data.time.TimePeriodValues timePeriodValues80 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str81 = timePeriodValues80.getDescription();
        int int82 = timePeriodValues80.getMaxEndIndex();
        timePeriodValues80.delete((int) (short) 10, 4);
        boolean boolean86 = simpleTimePeriod2.equals((java.lang.Object) 4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNull(str81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1.0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=1.0]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1.0d + "'", obj4.equals(1.0d));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        int int9 = timePeriodValues7.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        java.lang.String str12 = timePeriodValues7.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        int int14 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Time" + "'", str12.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.Object obj28 = timePeriodValues1.clone();
        boolean boolean29 = timePeriodValues1.getNotify();
        int int30 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) day17);
//        java.util.Date date19 = day17.getEnd();
//        int int20 = day17.getYear();
//        int int21 = day17.getYear();
//        long long22 = day17.getFirstMillisecond();
//        long long23 = day17.getSerialIndex();
//        java.lang.Class<?> wildcardClass24 = day17.getClass();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        java.util.Date date11 = day7.getEnd();
//        org.jfree.data.time.SerialDate serialDate12 = day7.getSerialDate();
//        int int14 = day7.compareTo((java.lang.Object) 0L);
//        long long15 = day7.getLastMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, 0.0d);
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue19.getPeriod();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timePeriod20);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, (int) '4');
        java.lang.String str10 = timePeriodValues1.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setDescription("Time");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) 4);
        int int22 = day18.getYear();
        timePeriodValues1.setKey((java.lang.Comparable) int22);
        boolean boolean24 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.beans.PropertyChangeListener propertyChangeListener2 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
//        java.lang.String str4 = timePeriodValues1.getDomainDescription();
//        int int5 = timePeriodValues1.getMaxMiddleIndex();
//        int int6 = timePeriodValues1.getItemCount();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, (int) '4');
//        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
//        timePeriodValues1.addChangeListener(seriesChangeListener12);
//        int int14 = timePeriodValues1.getMaxEndIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        int int19 = timePeriodValues18.getMaxStartIndex();
//        boolean boolean21 = timePeriodValues18.equals((java.lang.Object) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str24 = timePeriodValues23.getDomainDescription();
//        int int25 = timePeriodValues23.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues23.removePropertyChangeListener(propertyChangeListener26);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str32 = timePeriodValues31.getDescription();
//        timePeriodValues31.setDescription("Time");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean36 = timePeriodValues31.equals((java.lang.Object) day35);
//        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day35, 1.0d);
//        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 0.0f);
//        long long41 = day35.getFirstMillisecond();
//        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 13);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day35, (double) (short) 1);
//        long long46 = day35.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(timePeriodValues9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560409200000L + "'", long41 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43629L + "'", long46 == 43629L);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 2019, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setDescription("Time");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (double) 10L);
        boolean boolean23 = timePeriodValue21.equals((java.lang.Object) 0.0f);
        timePeriodValues3.add(timePeriodValue21);
        boolean boolean25 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener26);
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = timePeriodValues3.getDataItem(0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timePeriodValue29);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setRangeDescription("hi!");
//        int int7 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str12 = timePeriodValues11.getDescription();
//        timePeriodValues11.setDescription("Time");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
//        int int20 = day15.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) (-1));
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str30 = timePeriodValues29.getDescription();
//        timePeriodValues29.setDescription("Time");
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        boolean boolean34 = timePeriodValues29.equals((java.lang.Object) day33);
//        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (double) 10L);
//        boolean boolean38 = timePeriodValue36.equals((java.lang.Object) 0.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str43 = timePeriodValues42.getDescription();
//        timePeriodValues42.setDescription("Time");
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        boolean boolean47 = timePeriodValues42.equals((java.lang.Object) day46);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean50 = day46.equals((java.lang.Object) (short) 1);
//        int int51 = day46.getMonth();
//        org.jfree.data.time.SerialDate serialDate52 = day46.getSerialDate();
//        java.util.Date date53 = day46.getStart();
//        org.jfree.data.time.SerialDate serialDate54 = day46.getSerialDate();
//        boolean boolean55 = timePeriodValue36.equals((java.lang.Object) day46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str58 = timePeriodValues57.getDomainDescription();
//        int int59 = timePeriodValues57.getMinStartIndex();
//        timePeriodValues57.setRangeDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener62 = null;
//        timePeriodValues57.addPropertyChangeListener(propertyChangeListener62);
//        boolean boolean64 = day46.equals((java.lang.Object) timePeriodValues57);
//        int int65 = day22.compareTo((java.lang.Object) timePeriodValues57);
//        java.lang.Object obj66 = timePeriodValues57.clone();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Time" + "'", str58.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertNotNull(obj66);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        int int11 = day7.getMonth();
//        long long12 = day7.getFirstMillisecond();
//        long long13 = day7.getSerialIndex();
//        long long14 = day7.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str17 = timePeriodValues16.getDomainDescription();
//        int int18 = timePeriodValues16.getMinStartIndex();
//        timePeriodValues16.setRangeDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener21);
//        int int23 = day7.compareTo((java.lang.Object) propertyChangeListener21);
//        long long24 = day7.getLastMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43629L + "'", long14 == 43629L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560495599999L + "'", long24 == 1560495599999L);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str21 = timePeriodValues20.getDescription();
//        timePeriodValues20.setDescription("Time");
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
//        int int29 = day24.getMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
//        java.util.Date date31 = day24.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str39 = timePeriodValues38.getDescription();
//        timePeriodValues38.setDescription("Time");
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
//        int int47 = day42.getMonth();
//        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
//        java.util.Date date49 = day42.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date14, date49);
//        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str57 = timePeriodValues56.getDescription();
//        timePeriodValues56.setDescription("Time");
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        boolean boolean61 = timePeriodValues56.equals((java.lang.Object) day60);
//        org.jfree.data.time.TimePeriodValue timePeriodValue63 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day60, (double) 10L);
//        int int64 = day60.getMonth();
//        long long65 = day60.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues68 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day60, "Time", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues72 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str73 = timePeriodValues72.getDescription();
//        timePeriodValues72.setRangeDescription("hi!");
//        int int76 = timePeriodValues72.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues80 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str81 = timePeriodValues80.getDescription();
//        timePeriodValues80.setDescription("Time");
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
//        boolean boolean85 = timePeriodValues80.equals((java.lang.Object) day84);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent87 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean88 = day84.equals((java.lang.Object) (short) 1);
//        int int89 = day84.getMonth();
//        org.jfree.data.time.SerialDate serialDate90 = day84.getSerialDate();
//        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(serialDate90);
//        timePeriodValues72.add((org.jfree.data.time.TimePeriod) day91, (double) (-1));
//        long long94 = day91.getSerialIndex();
//        timePeriodValues68.setKey((java.lang.Comparable) day91);
//        boolean boolean96 = simpleTimePeriod52.equals((java.lang.Object) timePeriodValues68);
//        java.lang.Object obj97 = timePeriodValues68.clone();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560409200000L + "'", long65 == 1560409200000L);
//        org.junit.Assert.assertNull(str73);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
//        org.junit.Assert.assertNull(str81);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 6 + "'", int89 == 6);
//        org.junit.Assert.assertNotNull(serialDate90);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + 43629L + "'", long94 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
//        org.junit.Assert.assertNotNull(obj97);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 8);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = timePeriodValues1.createCopy(10, 0);
        timePeriodValues4.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timePeriodValues4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.delete((int) (short) 10, 2);
        int int12 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setNotify(true);
        try {
            timePeriodValues1.delete(10, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str10 = timePeriodValues9.getDescription();
//        timePeriodValues9.setDescription("Time");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 0.0d);
//        java.util.Date date17 = day13.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str22 = timePeriodValues21.getDescription();
//        timePeriodValues21.setRangeDescription("");
//        java.lang.Class<?> wildcardClass25 = timePeriodValues21.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str30 = timePeriodValues29.getDescription();
//        timePeriodValues29.setDescription("Time");
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        boolean boolean34 = timePeriodValues29.equals((java.lang.Object) day33);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean37 = day33.equals((java.lang.Object) (short) 1);
//        int int38 = day33.getMonth();
//        org.jfree.data.time.SerialDate serialDate39 = day33.getSerialDate();
//        java.util.Date date40 = day33.getStart();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date40, timeZone44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date17, timeZone44);
//        org.jfree.data.time.SerialDate serialDate47 = day46.getSerialDate();
//        long long48 = day46.getLastMillisecond();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 0.0f);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560495599999L + "'", long48 == 1560495599999L);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
        timePeriodValue16.setValue((java.lang.Number) (-1.0d));
        java.lang.Object obj19 = timePeriodValue16.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str24 = timePeriodValues23.getDescription();
        timePeriodValues23.setDescription("Time");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        boolean boolean28 = timePeriodValues23.equals((java.lang.Object) day27);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean31 = day27.equals((java.lang.Object) (short) 1);
        int int32 = day27.getMonth();
        org.jfree.data.time.SerialDate serialDate33 = day27.getSerialDate();
        java.util.Date date34 = day27.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str41 = timePeriodValues40.getDescription();
        timePeriodValues40.setDescription("Time");
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        boolean boolean45 = timePeriodValues40.equals((java.lang.Object) day44);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent47 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean48 = day44.equals((java.lang.Object) (short) 1);
        int int49 = day44.getMonth();
        org.jfree.data.time.SerialDate serialDate50 = day44.getSerialDate();
        java.util.Date date51 = day44.getStart();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date34, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str59 = timePeriodValues58.getDescription();
        timePeriodValues58.setDescription("Time");
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        boolean boolean63 = timePeriodValues58.equals((java.lang.Object) day62);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean66 = day62.equals((java.lang.Object) (short) 1);
        int int67 = day62.getMonth();
        org.jfree.data.time.SerialDate serialDate68 = day62.getSerialDate();
        java.util.Date date69 = day62.getStart();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date69, timeZone70);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod(date34, date69);
        java.util.Date date73 = simpleTimePeriod72.getStart();
        boolean boolean74 = timePeriodValue16.equals((java.lang.Object) simpleTimePeriod72);
        boolean boolean75 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue16);
        timePeriodValue16.setValue((java.lang.Number) 10.0d);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, (int) '4');
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        int int12 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.Object obj28 = timePeriodValues1.clone();
        int int29 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setDescription("Time");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (double) 10L);
        boolean boolean23 = timePeriodValue21.equals((java.lang.Object) 0.0f);
        timePeriodValues3.add(timePeriodValue21);
        boolean boolean25 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener26);
        int int28 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues14.addChangeListener(seriesChangeListener18);
        boolean boolean20 = timePeriodValue10.equals((java.lang.Object) timePeriodValues14);
        java.lang.Comparable comparable21 = timePeriodValues14.getKey();
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener22);
        boolean boolean24 = timePeriodValues14.getNotify();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (-1.0d) + "'", comparable21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
        int int19 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str26 = timePeriodValues25.getDescription();
        timePeriodValues25.setDescription("Time");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean33 = day29.equals((java.lang.Object) (short) 1);
        int int34 = day29.getMonth();
        org.jfree.data.time.SerialDate serialDate35 = day29.getSerialDate();
        java.util.Date date36 = day29.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean43 = timePeriodValues41.equals((java.lang.Object) 7);
        boolean boolean44 = timePeriodValues41.isEmpty();
        int int45 = year39.compareTo((java.lang.Object) boolean44);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setRangeDescription("");
        int int53 = year39.compareTo((java.lang.Object) "");
        boolean boolean54 = simpleTimePeriod2.equals((java.lang.Object) int53);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str59 = timePeriodValues58.getDescription();
        timePeriodValues58.setDescription("Time");
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        boolean boolean63 = timePeriodValues58.equals((java.lang.Object) day62);
        org.jfree.data.time.TimePeriodValue timePeriodValue65 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day62, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str70 = timePeriodValues69.getDescription();
        timePeriodValues69.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener73 = null;
        timePeriodValues69.addChangeListener(seriesChangeListener73);
        boolean boolean75 = timePeriodValue65.equals((java.lang.Object) timePeriodValues69);
        boolean boolean76 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues69);
        timePeriodValues69.delete(6, 1);
        java.lang.String str80 = timePeriodValues69.getDomainDescription();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "hi!" + "'", str80.equals("hi!"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        int int5 = timePeriodValues1.getMinMiddleIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues1.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 13);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 13L + "'", long4 == 13L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 13L + "'", long5 == 13L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, 0.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str24 = timePeriodValues23.getDescription();
        timePeriodValues23.setRangeDescription("hi!");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 10.0f);
        int int30 = year17.compareTo((java.lang.Object) timePeriodValues23);
        java.util.Calendar calendar31 = null;
        try {
            year17.peg(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        timePeriodValues1.setDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy((int) 'a', (int) (byte) 0);
        boolean boolean7 = timePeriodValues6.isEmpty();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0d) + "'", comparable7.equals((-1.0d)));
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate15);
//        long long18 = day17.getFirstMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560409200000L + "'", long18 == 1560409200000L);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.Object obj28 = timePeriodValues1.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str33 = timePeriodValues32.getDescription();
        timePeriodValues32.setDescription("Time");
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        boolean boolean37 = timePeriodValues32.equals((java.lang.Object) day36);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean40 = day36.equals((java.lang.Object) (short) 1);
        int int41 = day36.getMonth();
        org.jfree.data.time.SerialDate serialDate42 = day36.getSerialDate();
        java.util.Date date43 = day36.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean50 = timePeriodValues48.equals((java.lang.Object) 7);
        boolean boolean51 = timePeriodValues48.isEmpty();
        int int52 = year46.compareTo((java.lang.Object) boolean51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year46.previous();
        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod53);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2020,10.0]");
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setRangeDescription("hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str11 = timePeriodValues10.getDescription();
//        timePeriodValues10.setDescription("Time");
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
//        int int19 = day14.getMonth();
//        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
//        java.util.Date date21 = day14.getStart();
//        java.util.Date date22 = day14.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str27 = timePeriodValues26.getDescription();
//        timePeriodValues26.setRangeDescription("hi!");
//        int int30 = timePeriodValues26.getMaxStartIndex();
//        int int31 = day14.compareTo((java.lang.Object) int30);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day14, (double) (-1));
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str38 = timePeriodValues37.getDescription();
//        timePeriodValues37.setRangeDescription("hi!");
//        int int41 = timePeriodValues37.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str46 = timePeriodValues45.getDescription();
//        timePeriodValues45.setDescription("Time");
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        boolean boolean50 = timePeriodValues45.equals((java.lang.Object) day49);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent52 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean53 = day49.equals((java.lang.Object) (short) 1);
//        int int54 = day49.getMonth();
//        org.jfree.data.time.SerialDate serialDate55 = day49.getSerialDate();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(serialDate55);
//        timePeriodValues37.add((org.jfree.data.time.TimePeriod) day56, (double) (-1));
//        long long59 = day56.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue61 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day56, (double) (short) 1);
//        int int62 = day14.compareTo((java.lang.Object) day56);
//        java.util.Calendar calendar63 = null;
//        try {
//            long long64 = day14.getFirstMillisecond(calendar63);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(str27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
//        org.junit.Assert.assertNull(str46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43629L + "'", long59 == 43629L);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date14);
        java.util.Date date55 = day54.getStart();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        java.util.Calendar calendar57 = null;
        try {
            day56.peg(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date55);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, 0.0d);
        java.util.Date date15 = day11.getEnd();
        int int16 = day11.getYear();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day11, (double) 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        java.util.Date date22 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str27 = timePeriodValues26.getDescription();
        timePeriodValues26.setDescription("Time");
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        boolean boolean31 = timePeriodValues26.equals((java.lang.Object) day30);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day30, (double) 10L);
        java.util.Date date34 = day30.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date22, date34);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str40 = timePeriodValues39.getDescription();
        timePeriodValues39.setDescription("Time");
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        boolean boolean44 = timePeriodValues39.equals((java.lang.Object) day43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean47 = day43.equals((java.lang.Object) (short) 1);
        int int48 = day43.getMonth();
        org.jfree.data.time.SerialDate serialDate49 = day43.getSerialDate();
        java.util.Date date50 = day43.getStart();
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50, timeZone51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str58 = timePeriodValues57.getDescription();
        timePeriodValues57.setDescription("Time");
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        boolean boolean62 = timePeriodValues57.equals((java.lang.Object) day61);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent64 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean65 = day61.equals((java.lang.Object) (short) 1);
        int int66 = day61.getMonth();
        org.jfree.data.time.SerialDate serialDate67 = day61.getSerialDate();
        java.util.Date date68 = day61.getStart();
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date68, timeZone69);
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str75 = timePeriodValues74.getDescription();
        timePeriodValues74.setDescription("Time");
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        boolean boolean79 = timePeriodValues74.equals((java.lang.Object) day78);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent81 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean82 = day78.equals((java.lang.Object) (short) 1);
        int int83 = day78.getMonth();
        org.jfree.data.time.SerialDate serialDate84 = day78.getSerialDate();
        java.util.Date date85 = day78.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date85, timeZone86);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date68, timeZone86);
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year(date50, timeZone86);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date50);
        java.util.Date date91 = day90.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod92 = new org.jfree.data.time.SimpleTimePeriod(date22, date91);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(date91);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        java.lang.Class<?> wildcardClass34 = year24.getClass();
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year24.getMiddleMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
//        int int11 = day7.getMonth();
//        int int12 = day7.getDayOfMonth();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 13 + "'", int12 == 13);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setRangeDescription("hi!");
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues1.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        boolean boolean28 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str33 = timePeriodValues32.getDescription();
        timePeriodValues32.setDescription("Time");
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        boolean boolean37 = timePeriodValues32.equals((java.lang.Object) day36);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean40 = day36.equals((java.lang.Object) (short) 1);
        int int41 = day36.getMonth();
        org.jfree.data.time.SerialDate serialDate42 = day36.getSerialDate();
        java.util.Date date43 = day36.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean50 = timePeriodValues48.equals((java.lang.Object) 7);
        boolean boolean51 = timePeriodValues48.isEmpty();
        int int52 = year46.compareTo((java.lang.Object) boolean51);
        java.util.Date date53 = year46.getEnd();
        long long54 = year46.getMiddleMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year46, (java.lang.Number) (-1));
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str61 = timePeriodValues60.getDescription();
        timePeriodValues60.setDescription("Time");
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        boolean boolean65 = timePeriodValues60.equals((java.lang.Object) day64);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent67 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean68 = day64.equals((java.lang.Object) (short) 1);
        int int69 = day64.getMonth();
        org.jfree.data.time.SerialDate serialDate70 = day64.getSerialDate();
        java.util.Date date71 = day64.getStart();
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date71, timeZone72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date71);
        org.jfree.data.time.TimePeriodValue timePeriodValue76 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year74, (double) 100L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod79 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long80 = simpleTimePeriod79.getStartMillis();
        java.util.Date date81 = simpleTimePeriod79.getEnd();
        boolean boolean82 = timePeriodValue76.equals((java.lang.Object) date81);
        boolean boolean83 = year46.equals((java.lang.Object) date81);
        long long84 = year46.getLastMillisecond();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1562097599999L + "'", long54 == 1562097599999L);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 6 + "'", int69 == 6);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1577865599999L + "'", long84 == 1577865599999L);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str2 = timePeriodValues1.getDomainDescription();
//        int int3 = timePeriodValues1.getMinStartIndex();
//        timePeriodValues1.setRangeDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
//        java.lang.String str8 = timePeriodValues1.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str13 = timePeriodValues12.getDescription();
//        timePeriodValues12.setDescription("Time");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean17 = timePeriodValues12.equals((java.lang.Object) day16);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean20 = day16.equals((java.lang.Object) (short) 1);
//        int int21 = day16.getMonth();
//        org.jfree.data.time.SerialDate serialDate22 = day16.getSerialDate();
//        java.util.Date date23 = day16.getStart();
//        int int24 = day16.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str27 = timePeriodValues26.getDomainDescription();
//        int int28 = timePeriodValues26.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues26.removePropertyChangeListener(propertyChangeListener29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str35 = timePeriodValues34.getDescription();
//        timePeriodValues34.setDescription("Time");
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        boolean boolean39 = timePeriodValues34.equals((java.lang.Object) day38);
//        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day38, 1.0d);
//        timePeriodValues26.add((org.jfree.data.time.TimePeriod) day38, (java.lang.Number) 0.0f);
//        boolean boolean44 = day16.equals((java.lang.Object) 0.0f);
//        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 0L);
//        timePeriodValues1.add(timePeriodValue46);
//        try {
//            timePeriodValues1.update(1, (java.lang.Number) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 13 + "'", int24 == 13);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//        org.junit.Assert.assertNull(str35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 0.0d);
//        java.util.Date date11 = day7.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str16 = timePeriodValues15.getDescription();
//        timePeriodValues15.setRangeDescription("");
//        java.lang.Class<?> wildcardClass19 = timePeriodValues15.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str24 = timePeriodValues23.getDescription();
//        timePeriodValues23.setDescription("Time");
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        boolean boolean28 = timePeriodValues23.equals((java.lang.Object) day27);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean31 = day27.equals((java.lang.Object) (short) 1);
//        int int32 = day27.getMonth();
//        org.jfree.data.time.SerialDate serialDate33 = day27.getSerialDate();
//        java.util.Date date34 = day27.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date34);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date34, timeZone38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date11, timeZone38);
//        org.jfree.data.time.SerialDate serialDate41 = day40.getSerialDate();
//        java.lang.String str42 = day40.toString();
//        long long43 = day40.getLastMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNull(str16);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560495599999L + "'", long43 == 1560495599999L);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        int int15 = day7.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str18 = timePeriodValues17.getDomainDescription();
//        int int19 = timePeriodValues17.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str26 = timePeriodValues25.getDescription();
//        timePeriodValues25.setDescription("Time");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 0.0f);
//        boolean boolean35 = day7.equals((java.lang.Object) 0.0f);
//        long long36 = day7.getMiddleMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560452399999L + "'", long36 == 1560452399999L);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date14);
        java.util.Date date55 = day54.getStart();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        org.jfree.data.time.SerialDate serialDate57 = day56.getSerialDate();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate57);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=Time]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        boolean boolean36 = year34.equals((java.lang.Object) 0.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year34);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) day17);
//        java.util.Date date19 = day17.getEnd();
//        int int20 = day17.getYear();
//        int int21 = day17.getYear();
//        org.jfree.data.time.SerialDate serialDate22 = day17.getSerialDate();
//        long long23 = day17.getFirstMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 10.0f);
        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate10);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod33, (double) 9);
        java.util.Date date36 = regularTimePeriod33.getStart();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date36);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str2 = timePeriodValues1.getDomainDescription();
//        int int3 = timePeriodValues1.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str10 = timePeriodValues9.getDescription();
//        timePeriodValues9.setDescription("Time");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
//        long long19 = day13.getFirstMillisecond();
//        int int20 = day13.getDayOfMonth();
//        java.lang.String str21 = day13.toString();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 13 + "'", int20 == 13);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod33);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod33, (double) 10);
        java.lang.Object obj37 = timePeriodValue36.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(obj37);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(12L, (long) '#');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 0.0f);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        boolean boolean33 = year17.equals((java.lang.Object) day25);
        java.lang.Object obj34 = null;
        int int35 = year17.compareTo(obj34);
        java.lang.Number number36 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, number36);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "Time");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        boolean boolean5 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 2 + "'", comparable4.equals(2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        boolean boolean23 = simpleTimePeriod2.equals((java.lang.Object) (byte) 100);
        long long24 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 12L + "'", long24 == 12L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.setRangeDescription("2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=1]");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
//        long long17 = day16.getLastMillisecond();
//        java.util.Calendar calendar18 = null;
//        try {
//            day16.peg(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.setDescription("Time");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day12.next();
        int int23 = day12.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, 0.0d);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str24 = timePeriodValues23.getDescription();
        timePeriodValues23.setRangeDescription("hi!");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day27, (java.lang.Number) 10.0f);
        int int30 = year17.compareTo((java.lang.Object) timePeriodValues23);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str35 = timePeriodValues34.getDescription();
        timePeriodValues34.setDescription("Time");
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        boolean boolean39 = timePeriodValues34.equals((java.lang.Object) day38);
        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day38, (double) 10L);
        boolean boolean43 = timePeriodValue41.equals((java.lang.Object) 0.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str48 = timePeriodValues47.getDescription();
        timePeriodValues47.setDescription("Time");
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        boolean boolean52 = timePeriodValues47.equals((java.lang.Object) day51);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean55 = day51.equals((java.lang.Object) (short) 1);
        int int56 = day51.getMonth();
        org.jfree.data.time.SerialDate serialDate57 = day51.getSerialDate();
        java.util.Date date58 = day51.getStart();
        org.jfree.data.time.SerialDate serialDate59 = day51.getSerialDate();
        boolean boolean60 = timePeriodValue41.equals((java.lang.Object) day51);
        timePeriodValues23.setKey((java.lang.Comparable) day51);
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str66 = timePeriodValues65.getDescription();
        timePeriodValues65.setRangeDescription("hi!");
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        timePeriodValues65.add((org.jfree.data.time.TimePeriod) day69, (java.lang.Number) 10.0f);
        boolean boolean72 = timePeriodValues65.isEmpty();
        boolean boolean73 = timePeriodValues23.equals((java.lang.Object) boolean72);
        boolean boolean74 = timePeriodValues23.isEmpty();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        int int11 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setRangeDescription("hi!");
//        int int7 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str12 = timePeriodValues11.getDescription();
//        timePeriodValues11.setDescription("Time");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
//        int int20 = day15.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) (-1));
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (double) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str32 = timePeriodValues31.getDescription();
//        timePeriodValues31.setDescription("Time");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean36 = timePeriodValues31.equals((java.lang.Object) day35);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean39 = day35.equals((java.lang.Object) (short) 1);
//        int int40 = day35.getMonth();
//        org.jfree.data.time.SerialDate serialDate41 = day35.getSerialDate();
//        java.util.Date date42 = day35.getStart();
//        java.util.Date date43 = day35.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str48 = timePeriodValues47.getDescription();
//        timePeriodValues47.setRangeDescription("hi!");
//        int int51 = timePeriodValues47.getMaxStartIndex();
//        int int52 = day35.compareTo((java.lang.Object) int51);
//        java.lang.String str53 = day35.toString();
//        boolean boolean54 = timePeriodValue27.equals((java.lang.Object) day35);
//        java.lang.String str55 = day35.toString();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "13-June-2019" + "'", str53.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "13-June-2019" + "'", str55.equals("13-June-2019"));
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
        timePeriodValue10.setValue((java.lang.Number) (-1.0d));
        java.lang.Object obj13 = timePeriodValue10.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str18 = timePeriodValues17.getDescription();
        timePeriodValues17.setDescription("Time");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        boolean boolean22 = timePeriodValues17.equals((java.lang.Object) day21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean25 = day21.equals((java.lang.Object) (short) 1);
        int int26 = day21.getMonth();
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        java.util.Date date28 = day21.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str35 = timePeriodValues34.getDescription();
        timePeriodValues34.setDescription("Time");
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        boolean boolean39 = timePeriodValues34.equals((java.lang.Object) day38);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean42 = day38.equals((java.lang.Object) (short) 1);
        int int43 = day38.getMonth();
        org.jfree.data.time.SerialDate serialDate44 = day38.getSerialDate();
        java.util.Date date45 = day38.getStart();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45, timeZone46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date28, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str53 = timePeriodValues52.getDescription();
        timePeriodValues52.setDescription("Time");
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        boolean boolean57 = timePeriodValues52.equals((java.lang.Object) day56);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent59 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean60 = day56.equals((java.lang.Object) (short) 1);
        int int61 = day56.getMonth();
        org.jfree.data.time.SerialDate serialDate62 = day56.getSerialDate();
        java.util.Date date63 = day56.getStart();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date63, timeZone64);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(date28, date63);
        java.util.Date date67 = simpleTimePeriod66.getStart();
        boolean boolean68 = timePeriodValue10.equals((java.lang.Object) simpleTimePeriod66);
        java.util.Date date69 = simpleTimePeriod66.getStart();
        java.util.Date date70 = simpleTimePeriod66.getEnd();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(date70);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue5 = timePeriodValues1.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 'a');
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        java.util.Date date22 = day15.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date7, timeZone23);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day25.getLastMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        boolean boolean33 = year17.equals((java.lang.Object) day25);
        java.lang.Object obj34 = null;
        int int35 = year17.compareTo(obj34);
        int int36 = year17.getYear();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setRangeDescription("TimePeriodValue[13-June-2019,1.0]");
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        java.util.Date date54 = year53.getStart();
        long long55 = year53.getSerialIndex();
        long long56 = year53.getSerialIndex();
        long long57 = year53.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 2019L + "'", long55 == 2019L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 2019L + "'", long57 == 2019L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        int int11 = day7.getYear();
        int int12 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
        int int14 = day7.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day7.previous();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.setDescription("Time");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Time");
        java.lang.String str7 = seriesChangeEvent6.toString();
        java.lang.Object obj8 = seriesChangeEvent6.getSource();
        java.lang.String str9 = seriesChangeEvent6.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Time]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=Time]"));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + "Time" + "'", obj8.equals("Time"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Time]" + "'", str9.equals("org.jfree.data.general.SeriesChangeEvent[source=Time]"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
        java.lang.String str10 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        boolean boolean8 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setDescription("Time");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = timePeriodValues13.equals((java.lang.Object) day17);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 10L);
        java.util.Date date21 = day17.getEnd();
        boolean boolean22 = timePeriodValues3.equals((java.lang.Object) date21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        int int11 = day7.getYear();
        int int12 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "hi!", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day7.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) '#');
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        boolean boolean36 = year34.equals((java.lang.Object) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year34.previous();
        java.util.Date date38 = year34.getStart();
        long long39 = year34.getLastMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setDescription("Time");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str26 = timePeriodValues25.getDescription();
        timePeriodValues25.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timePeriodValues25.addChangeListener(seriesChangeListener29);
        boolean boolean31 = timePeriodValue21.equals((java.lang.Object) timePeriodValues25);
        java.lang.Number number32 = null;
        timePeriodValue21.setValue(number32);
        timePeriodValues3.add(timePeriodValue21);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.Date date15 = day7.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str20 = timePeriodValues19.getDescription();
//        timePeriodValues19.setRangeDescription("hi!");
//        int int23 = timePeriodValues19.getMaxStartIndex();
//        int int24 = day7.compareTo((java.lang.Object) int23);
//        java.lang.String str25 = day7.toString();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
//        long long29 = simpleTimePeriod28.getStartMillis();
//        long long30 = simpleTimePeriod28.getEndMillis();
//        long long31 = simpleTimePeriod28.getStartMillis();
//        int int32 = day7.compareTo((java.lang.Object) long31);
//        int int33 = day7.getDayOfMonth();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 12L + "'", long30 == 12L);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 13 + "'", int33 == 13);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,10.0]");
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        long long18 = year17.getSerialIndex();
        long long19 = year17.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str24 = timePeriodValues23.getDescription();
        timePeriodValues23.setRangeDescription("");
        java.lang.Class<?> wildcardClass27 = timePeriodValues23.getClass();
        java.lang.Comparable comparable28 = timePeriodValues23.getKey();
        boolean boolean29 = timePeriodValues23.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str34 = timePeriodValues33.getDescription();
        timePeriodValues33.setDescription("Time");
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        boolean boolean38 = timePeriodValues33.equals((java.lang.Object) day37);
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day37, (double) 10L);
        java.util.Date date41 = day37.getEnd();
        boolean boolean42 = timePeriodValues23.equals((java.lang.Object) date41);
        java.lang.String str43 = timePeriodValues23.getDescription();
        int int44 = year17.compareTo((java.lang.Object) timePeriodValues23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year17.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (-1.0d) + "'", comparable28.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        java.util.Date date11 = day7.getEnd();
//        org.jfree.data.time.SerialDate serialDate12 = day7.getSerialDate();
//        int int14 = day7.compareTo((java.lang.Object) 0L);
//        java.util.Date date15 = day7.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str20 = timePeriodValues19.getDescription();
//        timePeriodValues19.setDescription("Time");
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean24 = timePeriodValues19.equals((java.lang.Object) day23);
//        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, 0.0d);
//        java.util.Date date27 = day23.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str32 = timePeriodValues31.getDescription();
//        timePeriodValues31.setRangeDescription("");
//        java.lang.Class<?> wildcardClass35 = timePeriodValues31.getClass();
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str40 = timePeriodValues39.getDescription();
//        timePeriodValues39.setDescription("Time");
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        boolean boolean44 = timePeriodValues39.equals((java.lang.Object) day43);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean47 = day43.equals((java.lang.Object) (short) 1);
//        int int48 = day43.getMonth();
//        org.jfree.data.time.SerialDate serialDate49 = day43.getSerialDate();
//        java.util.Date date50 = day43.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50, timeZone51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date50);
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date50, timeZone54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date27, timeZone54);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(date15, date27);
//        long long58 = simpleTimePeriod57.getEndMillis();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560495599999L + "'", long58 == 1560495599999L);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        java.lang.String str34 = year24.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.delete(3, 0);
        int int7 = timePeriodValues3.getItemCount();
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        java.lang.String str13 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Object obj12 = timePeriodValues3.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        int int11 = day7.getMonth();
//        long long12 = day7.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "Time", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        try {
//            org.jfree.data.time.TimePeriodValue timePeriodValue17 = timePeriodValues15.getDataItem(11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str58 = timePeriodValues57.getDescription();
        timePeriodValues57.setDescription("Time");
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        boolean boolean62 = timePeriodValues57.equals((java.lang.Object) day61);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent64 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean65 = day61.equals((java.lang.Object) (short) 1);
        int int66 = day61.getMonth();
        org.jfree.data.time.SerialDate serialDate67 = day61.getSerialDate();
        java.util.Date date68 = day61.getStart();
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date68, timeZone69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date68);
        org.jfree.data.time.TimePeriodValues timePeriodValues75 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str76 = timePeriodValues75.getDescription();
        timePeriodValues75.setDescription("Time");
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
        boolean boolean80 = timePeriodValues75.equals((java.lang.Object) day79);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent82 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean83 = day79.equals((java.lang.Object) (short) 1);
        int int84 = day79.getMonth();
        org.jfree.data.time.SerialDate serialDate85 = day79.getSerialDate();
        java.util.Date date86 = day79.getStart();
        boolean boolean87 = year71.equals((java.lang.Object) day79);
        int int88 = year71.getYear();
        long long89 = year71.getSerialIndex();
        int int90 = year53.compareTo((java.lang.Object) year71);
        org.jfree.data.time.TimePeriodValues timePeriodValues93 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int90, "Value", "TimePeriodValue[2019,0.0]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 6 + "'", int84 == 6);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2019 + "'", int88 == 2019);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 2019L + "'", long89 == 2019L);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = day16.equals((java.lang.Object) day17);
        java.util.Date date19 = day17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long23 = simpleTimePeriod22.getStartMillis();
        long long24 = simpleTimePeriod22.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str29 = timePeriodValues28.getDescription();
        timePeriodValues28.setDescription("Time");
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        boolean boolean33 = timePeriodValues28.equals((java.lang.Object) day32);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean36 = day32.equals((java.lang.Object) (short) 1);
        int int37 = day32.getMonth();
        org.jfree.data.time.SerialDate serialDate38 = day32.getSerialDate();
        java.util.Date date39 = day32.getStart();
        java.util.Date date40 = day32.getEnd();
        int int41 = simpleTimePeriod22.compareTo((java.lang.Object) day32);
        boolean boolean43 = simpleTimePeriod22.equals((java.lang.Object) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str48 = timePeriodValues47.getDescription();
        timePeriodValues47.setRangeDescription("hi!");
        java.lang.String str51 = timePeriodValues47.getDomainDescription();
        int int52 = timePeriodValues47.getMaxEndIndex();
        java.lang.Comparable comparable53 = timePeriodValues47.getKey();
        boolean boolean54 = simpleTimePeriod22.equals((java.lang.Object) timePeriodValues47);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str59 = timePeriodValues58.getDescription();
        timePeriodValues58.setDescription("Time");
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        boolean boolean63 = timePeriodValues58.equals((java.lang.Object) day62);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean66 = day62.equals((java.lang.Object) (short) 1);
        int int67 = day62.getMonth();
        org.jfree.data.time.SerialDate serialDate68 = day62.getSerialDate();
        java.util.Date date69 = day62.getStart();
        java.lang.Class<?> wildcardClass70 = date69.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str75 = timePeriodValues74.getDescription();
        timePeriodValues74.setDescription("Time");
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        boolean boolean79 = timePeriodValues74.equals((java.lang.Object) day78);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent81 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean82 = day78.equals((java.lang.Object) (short) 1);
        int int83 = day78.getMonth();
        org.jfree.data.time.SerialDate serialDate84 = day78.getSerialDate();
        java.util.Date date85 = day78.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date85, timeZone86);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date69, timeZone86);
        boolean boolean89 = simpleTimePeriod22.equals((java.lang.Object) timeZone86);
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date19, timeZone86);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 12L + "'", long24 == 12L);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + (-1.0d) + "'", comparable53.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(false);
        java.lang.String str11 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str15 = timePeriodValues14.getDescription();
//        timePeriodValues14.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timePeriodValues14.addChangeListener(seriesChangeListener18);
//        boolean boolean20 = timePeriodValue10.equals((java.lang.Object) timePeriodValues14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str23 = timePeriodValues22.getDomainDescription();
//        int int24 = timePeriodValues22.getMinStartIndex();
//        timePeriodValues22.setRangeDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues22.addPropertyChangeListener(propertyChangeListener27);
//        java.lang.String str29 = timePeriodValues22.getDomainDescription();
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str34 = timePeriodValues33.getDescription();
//        timePeriodValues33.setDescription("Time");
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        boolean boolean38 = timePeriodValues33.equals((java.lang.Object) day37);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent40 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean41 = day37.equals((java.lang.Object) (short) 1);
//        int int42 = day37.getMonth();
//        org.jfree.data.time.SerialDate serialDate43 = day37.getSerialDate();
//        java.util.Date date44 = day37.getStart();
//        int int45 = day37.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str48 = timePeriodValues47.getDomainDescription();
//        int int49 = timePeriodValues47.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener50 = null;
//        timePeriodValues47.removePropertyChangeListener(propertyChangeListener50);
//        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str56 = timePeriodValues55.getDescription();
//        timePeriodValues55.setDescription("Time");
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        boolean boolean60 = timePeriodValues55.equals((java.lang.Object) day59);
//        org.jfree.data.time.TimePeriodValue timePeriodValue62 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day59, 1.0d);
//        timePeriodValues47.add((org.jfree.data.time.TimePeriod) day59, (java.lang.Number) 0.0f);
//        boolean boolean65 = day37.equals((java.lang.Object) 0.0f);
//        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) 0L);
//        timePeriodValues22.add(timePeriodValue67);
//        boolean boolean69 = timePeriodValues14.equals((java.lang.Object) timePeriodValue67);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 13 + "'", int45 == 13);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Time" + "'", str48.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//        org.junit.Assert.assertNull(str56);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        java.util.Date date22 = day15.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date22, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22);
        int int26 = year25.getYear();
        int int28 = year25.compareTo((java.lang.Object) 3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, 9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=1]");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("TimePeriodValue[13-June-2019,1.0]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException7);
        java.lang.String str9 = seriesException7.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,1.0]" + "'", str9.equals("org.jfree.data.general.SeriesException: TimePeriodValue[13-June-2019,1.0]"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setRangeDescription("hi!");
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        int int14 = timePeriodValues1.getMaxStartIndex();
        int int15 = timePeriodValues1.getMinStartIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str6 = timePeriodValues5.getDescription();
//        timePeriodValues5.setDescription("Time");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean10 = timePeriodValues5.equals((java.lang.Object) day9);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, 1.0d);
//        java.lang.Number number13 = timePeriodValue12.getValue();
//        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue12.getPeriod();
//        java.lang.String str15 = timePeriodValue12.toString();
//        timePeriodValues1.add(timePeriodValue12);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str23 = timePeriodValues22.getDescription();
//        timePeriodValues22.setDescription("Time");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        boolean boolean27 = timePeriodValues22.equals((java.lang.Object) day26);
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 1.0d);
//        java.lang.Number number30 = timePeriodValue29.getValue();
//        org.jfree.data.time.TimePeriod timePeriod31 = timePeriodValue29.getPeriod();
//        java.lang.String str32 = timePeriodValue29.toString();
//        timePeriodValues18.add(timePeriodValue29);
//        java.lang.String str34 = timePeriodValue29.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str39 = timePeriodValues38.getDescription();
//        timePeriodValues38.setDescription("Time");
//        int int42 = timePeriodValues38.getMaxEndIndex();
//        timePeriodValues38.setRangeDescription("2019");
//        boolean boolean45 = timePeriodValue29.equals((java.lang.Object) "2019");
//        boolean boolean46 = timePeriodValue12.equals((java.lang.Object) boolean45);
//        timePeriodValue12.setValue((java.lang.Number) 5);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
//        org.junit.Assert.assertNotNull(timePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str15.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1.0d + "'", number30.equals(1.0d));
//        org.junit.Assert.assertNotNull(timePeriod31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str32.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str34.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        int int11 = day7.getMonth();
//        long long12 = day7.getFirstMillisecond();
//        long long13 = day7.getFirstMillisecond();
//        int int14 = day7.getMonth();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        long long24 = year17.getMiddleMillisecond();
        long long25 = year17.getLastMillisecond();
        int int26 = year17.getYear();
        java.util.Date date27 = year17.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setRangeDescription("");
        java.lang.Class<?> wildcardClass17 = timePeriodValues13.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date32, timeZone36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str42 = timePeriodValues41.getDescription();
        timePeriodValues41.setRangeDescription("");
        java.lang.Class<?> wildcardClass45 = timePeriodValues41.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setDescription("Time");
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        boolean boolean54 = timePeriodValues49.equals((java.lang.Object) day53);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean57 = day53.equals((java.lang.Object) (short) 1);
        int int58 = day53.getMonth();
        org.jfree.data.time.SerialDate serialDate59 = day53.getSerialDate();
        java.util.Date date60 = day53.getStart();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date60, timeZone61);
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str67 = timePeriodValues66.getDescription();
        timePeriodValues66.setRangeDescription("");
        java.lang.Class<?> wildcardClass70 = timePeriodValues66.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str75 = timePeriodValues74.getDescription();
        timePeriodValues74.setDescription("Time");
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        boolean boolean79 = timePeriodValues74.equals((java.lang.Object) day78);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent81 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean82 = day78.equals((java.lang.Object) (short) 1);
        int int83 = day78.getMonth();
        org.jfree.data.time.SerialDate serialDate84 = day78.getSerialDate();
        java.util.Date date85 = day78.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date85, timeZone86);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date85);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date85, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date60, timeZone89);
        timePeriodValues3.setKey((java.lang.Comparable) date60);
        int int93 = timePeriodValues3.getMaxStartIndex();
        int int94 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, 0.0d);
        long long20 = year17.getLastMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
    }
}

