import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = null;
        try {
            timePeriodValues1.add(timePeriodValue4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable throwable2 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setDomainDescription("");
        try {
            java.lang.Number number7 = timePeriodValues3.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues3.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        try {
            java.lang.Number number5 = timePeriodValues1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day7.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues1.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        timePeriodValues1.setDescription("");
        timePeriodValues1.delete(5, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, (int) '4');
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues1.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year34.getLastMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.Date date15 = day7.getEnd();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day7.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day7.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '#' + "'", comparable4.equals('#'));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str28 = timePeriodValues27.getDescription();
        timePeriodValues27.setRangeDescription("");
        int int31 = year17.compareTo((java.lang.Object) "");
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year17.getFirstMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        boolean boolean36 = year34.equals((java.lang.Object) 0.0f);
        java.util.Calendar calendar37 = null;
        try {
            long long38 = year34.getFirstMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        boolean boolean36 = year34.equals((java.lang.Object) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year34.previous();
        java.util.Calendar calendar38 = null;
        try {
            year34.peg(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        int int7 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        try {
            timePeriodValues3.delete((int) (byte) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
        java.util.Calendar calendar16 = null;
        try {
            day7.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
        timePeriodValue10.setValue((java.lang.Number) (short) -1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        boolean boolean7 = timePeriodValues3.isEmpty();
        try {
            timePeriodValues3.update((int) 'a', (java.lang.Number) 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        try {
            java.lang.Number number7 = timePeriodValues1.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setDomainDescription("hi!");
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) (short) -1, 4);
        int int11 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues3.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        try {
            java.lang.Number number7 = timePeriodValues1.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test063");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        int int9 = day7.getYear();
//        long long10 = day7.getLastMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560495599999L + "'", long10 == 1560495599999L);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setDescription("Time");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (double) 10L);
        boolean boolean23 = timePeriodValue21.equals((java.lang.Object) 0.0f);
        timePeriodValues3.add(timePeriodValue21);
        timePeriodValue21.setValue((java.lang.Number) 1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        java.lang.String str35 = year34.toString();
        java.util.Calendar calendar36 = null;
        try {
            long long37 = year34.getMiddleMillisecond(calendar36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 6, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues1.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 12, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = day16.equals((java.lang.Object) day17);
        java.util.Date date19 = day17.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str24 = timePeriodValues23.getDescription();
        timePeriodValues23.setRangeDescription("");
        java.lang.Class<?> wildcardClass27 = timePeriodValues23.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str32 = timePeriodValues31.getDescription();
        timePeriodValues31.setDescription("Time");
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        boolean boolean36 = timePeriodValues31.equals((java.lang.Object) day35);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean39 = day35.equals((java.lang.Object) (short) 1);
        int int40 = day35.getMonth();
        org.jfree.data.time.SerialDate serialDate41 = day35.getSerialDate();
        java.util.Date date42 = day35.getStart();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date42, timeZone43);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date19, date42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(regularTimePeriod44);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Date date11 = day7.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str16 = timePeriodValues15.getDescription();
        timePeriodValues15.setRangeDescription("hi!");
        boolean boolean19 = day7.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "2019", "org.jfree.data.general.SeriesChangeEvent[source=1]");
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) (short) -1, 4);
        int int11 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        try {
            java.lang.Number number9 = timePeriodValues3.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setDescription("Time");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (double) 10L);
        boolean boolean23 = timePeriodValue21.equals((java.lang.Object) 0.0f);
        timePeriodValues3.add(timePeriodValue21);
        try {
            timePeriodValues3.delete((int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.delete((int) (short) 10, 2);
        int int12 = timePeriodValues1.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues5.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues5.getDomainDescription();
        try {
            int int9 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues5);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        java.util.Date date22 = day15.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date22, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str32 = timePeriodValues31.getDescription();
        timePeriodValues31.setRangeDescription("");
        java.lang.Class<?> wildcardClass35 = timePeriodValues31.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str40 = timePeriodValues39.getDescription();
        timePeriodValues39.setDescription("Time");
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        boolean boolean44 = timePeriodValues39.equals((java.lang.Object) day43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean47 = day43.equals((java.lang.Object) (short) 1);
        int int48 = day43.getMonth();
        org.jfree.data.time.SerialDate serialDate49 = day43.getSerialDate();
        java.util.Date date50 = day43.getStart();
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date50, timeZone51);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str57 = timePeriodValues56.getDescription();
        timePeriodValues56.setRangeDescription("");
        java.lang.Class<?> wildcardClass60 = timePeriodValues56.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str65 = timePeriodValues64.getDescription();
        timePeriodValues64.setDescription("Time");
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
        boolean boolean69 = timePeriodValues64.equals((java.lang.Object) day68);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent71 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean72 = day68.equals((java.lang.Object) (short) 1);
        int int73 = day68.getMonth();
        org.jfree.data.time.SerialDate serialDate74 = day68.getSerialDate();
        java.util.Date date75 = day68.getStart();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date75, timeZone76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date75);
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date75, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date50, timeZone79);
        java.lang.Class class82 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 6 + "'", int73 == 6);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(class82);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test079");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        int int9 = day7.getYear();
//        java.util.Date date10 = day7.getEnd();
//        long long11 = day7.getLastMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        java.util.Date date22 = day15.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date22, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22);
        int int26 = year25.getYear();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year25.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        try {
            timePeriodValues3.update((int) (short) 100, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[13-June-2019,1.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        java.util.Calendar calendar18 = null;
        try {
            year17.peg(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1577865599999L, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues3.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setNotify(true);
        try {
            java.lang.Number number10 = timePeriodValues1.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        java.util.Date date54 = year53.getStart();
        java.util.Calendar calendar55 = null;
        try {
            long long56 = year53.getFirstMillisecond(calendar55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date54);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues3.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1577865599999L, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=Time]");
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) (short) -1, 4);
        java.lang.Comparable comparable11 = timePeriodValues10.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (-1.0d) + "'", comparable11.equals((-1.0d)));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (6) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues8.setDomainDescription("");
        timePeriodValues8.setDomainDescription("hi!");
        boolean boolean13 = timePeriodValues8.isEmpty();
        try {
            int int14 = simpleTimePeriod2.compareTo((java.lang.Object) boolean13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.previous();
        java.util.Date date25 = regularTimePeriod24.getStart();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        java.util.Calendar calendar33 = null;
        try {
            long long34 = year24.getFirstMillisecond(calendar33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        int int11 = day7.getMonth();
//        java.lang.String str12 = day7.toString();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day7.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setRangeDescription("hi!");
//        int int7 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str12 = timePeriodValues11.getDescription();
//        timePeriodValues11.setDescription("Time");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
//        int int20 = day15.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) (-1));
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (double) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str32 = timePeriodValues31.getDescription();
//        timePeriodValues31.setDescription("Time");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean36 = timePeriodValues31.equals((java.lang.Object) day35);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean39 = day35.equals((java.lang.Object) (short) 1);
//        int int40 = day35.getMonth();
//        org.jfree.data.time.SerialDate serialDate41 = day35.getSerialDate();
//        java.util.Date date42 = day35.getStart();
//        java.util.Date date43 = day35.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str48 = timePeriodValues47.getDescription();
//        timePeriodValues47.setRangeDescription("hi!");
//        int int51 = timePeriodValues47.getMaxStartIndex();
//        int int52 = day35.compareTo((java.lang.Object) int51);
//        java.lang.String str53 = day35.toString();
//        boolean boolean54 = timePeriodValue27.equals((java.lang.Object) day35);
//        java.util.Calendar calendar55 = null;
//        try {
//            long long56 = day35.getFirstMillisecond(calendar55);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "13-June-2019" + "'", str53.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[13-June-2019,1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=1]");
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException6.getSuppressed();
        timePeriodFormatException4.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        timePeriodValues1.setDescription("");
        timePeriodValues1.setRangeDescription("");
        timePeriodValues1.setDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener8);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setRangeDescription("hi!");
//        int int7 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str12 = timePeriodValues11.getDescription();
//        timePeriodValues11.setDescription("Time");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
//        int int20 = day15.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) (-1));
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (double) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str32 = timePeriodValues31.getDescription();
//        timePeriodValues31.setDescription("Time");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean36 = timePeriodValues31.equals((java.lang.Object) day35);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean39 = day35.equals((java.lang.Object) (short) 1);
//        int int40 = day35.getMonth();
//        org.jfree.data.time.SerialDate serialDate41 = day35.getSerialDate();
//        java.util.Date date42 = day35.getStart();
//        java.util.Date date43 = day35.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str48 = timePeriodValues47.getDescription();
//        timePeriodValues47.setRangeDescription("hi!");
//        int int51 = timePeriodValues47.getMaxStartIndex();
//        int int52 = day35.compareTo((java.lang.Object) int51);
//        java.lang.String str53 = day35.toString();
//        boolean boolean54 = timePeriodValue27.equals((java.lang.Object) day35);
//        java.lang.String str55 = timePeriodValue27.toString();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "13-June-2019" + "'", str53.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str55.equals("TimePeriodValue[13-June-2019,1.0]"));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date14);
        java.util.Calendar calendar55 = null;
        try {
            long long56 = day54.getFirstMillisecond(calendar55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 10.0f);
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        java.util.Date date22 = day15.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date22, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year25.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        timePeriodValues1.setDescription("");
        timePeriodValues1.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod33);
        java.lang.String str35 = timePeriodValues34.getDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(str35);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setDomainDescription("");
        try {
            timePeriodValues3.update(2019, (java.lang.Number) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        int int11 = day7.getMonth();
//        long long12 = day7.getFirstMillisecond();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day7.getFirstMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=1]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setRangeDescription("hi!");
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        int int14 = timePeriodValues1.getMaxStartIndex();
        int int15 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        java.util.Date date22 = day15.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date22, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone26 = null;
        try {
            org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        java.util.Date date54 = year53.getStart();
        java.lang.String str55 = year53.toString();
        long long56 = year53.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year53.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1546329600000L + "'", long56 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + '#' + "'", comparable5.equals('#'));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 0.0f);
        timePeriodValue10.setValue((java.lang.Number) 1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) day17);
//        java.util.Date date19 = day17.getEnd();
//        int int20 = day17.getYear();
//        int int21 = day17.getYear();
//        long long22 = day17.getFirstMillisecond();
//        long long23 = day17.getSerialIndex();
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = day17.getFirstMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 43629L + "'", long23 == 43629L);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        boolean boolean35 = year24.equals((java.lang.Object) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues39.setDomainDescription("");
        int int42 = year24.compareTo((java.lang.Object) timePeriodValues39);
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = null;
        try {
            timePeriodValues39.add(timePeriodValue43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
        try {
            java.lang.Number number11 = timePeriodValues3.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setRangeDescription("hi!");
//        int int7 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str12 = timePeriodValues11.getDescription();
//        timePeriodValues11.setDescription("Time");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
//        int int20 = day15.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) (-1));
//        long long25 = day22.getSerialIndex();
//        java.util.Calendar calendar26 = null;
//        try {
//            long long27 = day22.getFirstMillisecond(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues14.addChangeListener(seriesChangeListener18);
        boolean boolean20 = timePeriodValue10.equals((java.lang.Object) timePeriodValues14);
        try {
            timePeriodValues14.update(0, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, 0.0d);
        java.lang.String str20 = timePeriodValue19.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[2019,0.0]" + "'", str20.equals("TimePeriodValue[2019,0.0]"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day7.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test125");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
//        int int11 = day7.getYear();
//        int int12 = day7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
//        int int14 = day7.getDayOfMonth();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        boolean boolean33 = year17.equals((java.lang.Object) day25);
        long long34 = year17.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        boolean boolean28 = timePeriodValues1.isEmpty();
        timePeriodValues1.setDescription("TimePeriodValue[13-June-2019,1.0]");
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Date date11 = day7.getEnd();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day7.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        boolean boolean7 = simpleTimePeriod2.equals((java.lang.Object) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        timePeriodValues1.setDescription("");
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Date date11 = day7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.previous();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        int int15 = day7.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str18 = timePeriodValues17.getDomainDescription();
//        int int19 = timePeriodValues17.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str26 = timePeriodValues25.getDescription();
//        timePeriodValues25.setDescription("Time");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 0.0f);
//        boolean boolean35 = day7.equals((java.lang.Object) 0.0f);
//        java.util.Calendar calendar36 = null;
//        try {
//            long long37 = day7.getMiddleMillisecond(calendar36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        java.lang.String str33 = timePeriodValues3.getRangeDescription();
        int int34 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        long long11 = day7.getLastMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
//        int int11 = day7.getYear();
//        int int12 = day7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "hi!", "hi!");
//        long long17 = day7.getSerialIndex();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43629L + "'", long17 == 43629L);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, (int) (short) 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, (int) '4');
        try {
            java.lang.Number number11 = timePeriodValues9.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str2 = timePeriodValues1.getDomainDescription();
//        int int3 = timePeriodValues1.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str10 = timePeriodValues9.getDescription();
//        timePeriodValues9.setDescription("Time");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
//        long long19 = day13.getFirstMillisecond();
//        long long20 = day13.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560495599999L + "'", long20 == 1560495599999L);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 2019, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, 0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 100, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        java.lang.String str8 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0d) + "'", comparable7.equals((-1.0d)));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 7, "TimePeriodValue[13-June-2019,1.0]", "hi!");
        timePeriodValues3.setRangeDescription("");
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 100L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long23 = simpleTimePeriod22.getStartMillis();
        java.util.Date date24 = simpleTimePeriod22.getEnd();
        boolean boolean25 = timePeriodValue19.equals((java.lang.Object) date24);
        java.lang.String str26 = timePeriodValue19.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TimePeriodValue[2019,100.0]" + "'", str26.equals("TimePeriodValue[2019,100.0]"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.setDescription("Time");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Time");
        java.lang.Object obj7 = seriesChangeEvent6.getSource();
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + "Time" + "'", obj7.equals("Time"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,0.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.next();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long28 = simpleTimePeriod27.getStartMillis();
        long long29 = simpleTimePeriod27.getEndMillis();
        long long30 = simpleTimePeriod27.getStartMillis();
        int int31 = year17.compareTo((java.lang.Object) long30);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 12L + "'", long29 == 12L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean17 = day13.equals((java.lang.Object) (short) 1);
        int int18 = day13.getMonth();
        org.jfree.data.time.SerialDate serialDate19 = day13.getSerialDate();
        java.util.Date date20 = day13.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str28 = timePeriodValues27.getDescription();
        timePeriodValues27.setDescription("Time");
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        boolean boolean32 = timePeriodValues27.equals((java.lang.Object) day31);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean35 = day31.equals((java.lang.Object) (short) 1);
        int int36 = day31.getMonth();
        org.jfree.data.time.SerialDate serialDate37 = day31.getSerialDate();
        java.util.Date date38 = day31.getStart();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str45 = timePeriodValues44.getDescription();
        timePeriodValues44.setDescription("Time");
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        boolean boolean49 = timePeriodValues44.equals((java.lang.Object) day48);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent51 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean52 = day48.equals((java.lang.Object) (short) 1);
        int int53 = day48.getMonth();
        org.jfree.data.time.SerialDate serialDate54 = day48.getSerialDate();
        java.util.Date date55 = day48.getStart();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date55, timeZone56);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date38, timeZone56);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date20, timeZone56);
        try {
            int int60 = simpleTimePeriod2.compareTo((java.lang.Object) timeZone56);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: sun.util.calendar.ZoneInfo cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone56);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        timePeriodValues1.setDescription("");
        boolean boolean4 = timePeriodValues1.isEmpty();
        try {
            timePeriodValues1.update(10, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.previous();
        int int25 = year17.getYear();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        java.lang.String str35 = year34.toString();
        long long36 = year34.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) day17);
//        long long19 = day16.getSerialIndex();
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = day16.getFirstMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, 8, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.setDescription("Time");
        try {
            timePeriodValues3.update(0, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.setDescription("Time");
        java.lang.Object obj6 = timePeriodValues3.clone();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues3.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day12.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, 0.0d);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year17.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        int int7 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) (-1));
        int int25 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        int int4 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        int int8 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) (short) -1, 4);
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        int int22 = year17.compareTo((java.lang.Object) timePeriodFormatException21);
        long long23 = year17.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 2019L + "'", long23 == 2019L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        int int7 = timePeriodValues3.getMaxStartIndex();
        boolean boolean9 = timePeriodValues3.equals((java.lang.Object) 2);
        boolean boolean10 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        long long22 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.Date date15 = day7.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str20 = timePeriodValues19.getDescription();
//        timePeriodValues19.setDescription("Time");
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean24 = timePeriodValues19.equals((java.lang.Object) day23);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean27 = day23.equals((java.lang.Object) (short) 1);
//        int int28 = day23.getMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day23.getSerialDate();
//        java.util.Date date30 = day23.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date30);
//        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str38 = timePeriodValues37.getDescription();
//        timePeriodValues37.setDescription("Time");
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        boolean boolean42 = timePeriodValues37.equals((java.lang.Object) day41);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean45 = day41.equals((java.lang.Object) (short) 1);
//        int int46 = day41.getMonth();
//        org.jfree.data.time.SerialDate serialDate47 = day41.getSerialDate();
//        java.util.Date date48 = day41.getStart();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
//        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str55 = timePeriodValues54.getDescription();
//        timePeriodValues54.setDescription("Time");
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        boolean boolean59 = timePeriodValues54.equals((java.lang.Object) day58);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean62 = day58.equals((java.lang.Object) (short) 1);
//        int int63 = day58.getMonth();
//        org.jfree.data.time.SerialDate serialDate64 = day58.getSerialDate();
//        java.util.Date date65 = day58.getStart();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date65, timeZone66);
//        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date48, timeZone66);
//        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date30, timeZone66);
//        boolean boolean70 = day7.equals((java.lang.Object) year69);
//        int int71 = day7.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValue timePeriodValue73 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) '#');
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNull(str55);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 6 + "'", int63 == 6);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 13 + "'", int71 == 13);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, (int) '4');
        int int10 = timePeriodValues9.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        java.util.Calendar calendar17 = null;
        try {
            day16.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        long long4 = simpleTimePeriod2.getEndMillis();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str9 = timePeriodValues8.getDescription();
//        timePeriodValues8.setDescription("Time");
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
//        int int17 = day12.getMonth();
//        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
//        java.util.Date date19 = day12.getStart();
//        java.util.Date date20 = day12.getEnd();
//        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
//        long long22 = day12.getLastMillisecond();
//        long long23 = day12.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560495599999L + "'", long22 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560409200000L + "'", long23 == 1560409200000L);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=1]");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=1]"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener11);
        try {
            int int13 = simpleTimePeriod2.compareTo((java.lang.Object) seriesChangeListener11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        java.util.Calendar calendar24 = null;
        try {
            year17.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str2 = timePeriodValues1.getDomainDescription();
//        int int3 = timePeriodValues1.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str10 = timePeriodValues9.getDescription();
//        timePeriodValues9.setDescription("Time");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
//        java.lang.String str19 = day13.toString();
//        java.util.Date date20 = day13.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str25 = timePeriodValues24.getDescription();
//        timePeriodValues24.setDescription("Time");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean29 = timePeriodValues24.equals((java.lang.Object) day28);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean32 = day28.equals((java.lang.Object) (short) 1);
//        int int33 = day28.getMonth();
//        org.jfree.data.time.SerialDate serialDate34 = day28.getSerialDate();
//        java.util.Date date35 = day28.getStart();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35, timeZone36);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35);
//        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str43 = timePeriodValues42.getDescription();
//        timePeriodValues42.setDescription("Time");
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        boolean boolean47 = timePeriodValues42.equals((java.lang.Object) day46);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent49 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean50 = day46.equals((java.lang.Object) (short) 1);
//        int int51 = day46.getMonth();
//        org.jfree.data.time.SerialDate serialDate52 = day46.getSerialDate();
//        java.util.Date date53 = day46.getStart();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date53, timeZone54);
//        org.jfree.data.time.TimePeriodValues timePeriodValues59 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str60 = timePeriodValues59.getDescription();
//        timePeriodValues59.setDescription("Time");
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        boolean boolean64 = timePeriodValues59.equals((java.lang.Object) day63);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent66 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean67 = day63.equals((java.lang.Object) (short) 1);
//        int int68 = day63.getMonth();
//        org.jfree.data.time.SerialDate serialDate69 = day63.getSerialDate();
//        java.util.Date date70 = day63.getStart();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date70, timeZone71);
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date53, timeZone71);
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date35, timeZone71);
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod75 = new org.jfree.data.time.SimpleTimePeriod(date20, date35);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(str43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNull(str60);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 6 + "'", int68 == 6);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 10, "", "org.jfree.data.time.TimePeriodFormatException: hi!");
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        java.util.Date date54 = year53.getStart();
        java.lang.String str55 = year53.toString();
        long long56 = year53.getFirstMillisecond();
        long long57 = year53.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1546329600000L + "'", long56 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str22 = timePeriodValues21.getDescription();
//        timePeriodValues21.setDescription("Time");
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
//        int int30 = day25.getMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
//        java.util.Date date32 = day25.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str39 = timePeriodValues38.getDescription();
//        timePeriodValues38.setDescription("Time");
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
//        int int47 = day42.getMonth();
//        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
//        java.util.Date date49 = day42.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date14);
//        java.util.Date date55 = day54.getStart();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
//        long long57 = day56.getMiddleMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560452399999L + "'", long57 == 1560452399999L);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setRangeDescription("hi!");
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        int int14 = timePeriodValues1.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues1.getDataItem(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.util.Date date11 = day7.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str16 = timePeriodValues15.getDescription();
        timePeriodValues15.setRangeDescription("");
        java.lang.Class<?> wildcardClass19 = timePeriodValues15.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str24 = timePeriodValues23.getDescription();
        timePeriodValues23.setDescription("Time");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        boolean boolean28 = timePeriodValues23.equals((java.lang.Object) day27);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean31 = day27.equals((java.lang.Object) (short) 1);
        int int32 = day27.getMonth();
        org.jfree.data.time.SerialDate serialDate33 = day27.getSerialDate();
        java.util.Date date34 = day27.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date34);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date34, timeZone38);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date11, date34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        java.lang.Object obj8 = timePeriodValues3.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0d) + "'", comparable7.equals((-1.0d)));
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        int int11 = day7.getMonth();
//        long long12 = day7.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "Time", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        int int16 = timePeriodValues15.getMaxMiddleIndex();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=1]");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str6 = timePeriodFormatException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        int int11 = day7.getYear();
        int int12 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "hi!", "hi!");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues16.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        java.util.Date date11 = day7.getEnd();
//        org.jfree.data.time.SerialDate serialDate12 = day7.getSerialDate();
//        int int14 = day7.compareTo((java.lang.Object) 0L);
//        long long15 = day7.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str20 = timePeriodValues19.getDescription();
//        timePeriodValues19.setDescription("Time");
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean24 = timePeriodValues19.equals((java.lang.Object) day23);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean27 = day23.equals((java.lang.Object) (short) 1);
//        int int28 = day23.getMonth();
//        org.jfree.data.time.SerialDate serialDate29 = day23.getSerialDate();
//        java.util.Date date30 = day23.getStart();
//        java.util.Date date31 = day23.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str36 = timePeriodValues35.getDescription();
//        timePeriodValues35.setDescription("Time");
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        boolean boolean40 = timePeriodValues35.equals((java.lang.Object) day39);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean43 = day39.equals((java.lang.Object) (short) 1);
//        int int44 = day39.getMonth();
//        org.jfree.data.time.SerialDate serialDate45 = day39.getSerialDate();
//        java.util.Date date46 = day39.getStart();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date46, timeZone47);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date46);
//        org.jfree.data.time.TimePeriodValues timePeriodValues53 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str54 = timePeriodValues53.getDescription();
//        timePeriodValues53.setDescription("Time");
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        boolean boolean58 = timePeriodValues53.equals((java.lang.Object) day57);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent60 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean61 = day57.equals((java.lang.Object) (short) 1);
//        int int62 = day57.getMonth();
//        org.jfree.data.time.SerialDate serialDate63 = day57.getSerialDate();
//        java.util.Date date64 = day57.getStart();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date64, timeZone65);
//        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str71 = timePeriodValues70.getDescription();
//        timePeriodValues70.setDescription("Time");
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
//        boolean boolean75 = timePeriodValues70.equals((java.lang.Object) day74);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent77 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean78 = day74.equals((java.lang.Object) (short) 1);
//        int int79 = day74.getMonth();
//        org.jfree.data.time.SerialDate serialDate80 = day74.getSerialDate();
//        java.util.Date date81 = day74.getStart();
//        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date81, timeZone82);
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date64, timeZone82);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date46, timeZone82);
//        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date31, timeZone82);
//        boolean boolean87 = day7.equals((java.lang.Object) year86);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertNull(str20);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(str54);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNull(str71);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 6 + "'", int79 == 6);
//        org.junit.Assert.assertNotNull(serialDate80);
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(timeZone82);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues(comparable0, "", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        int int10 = timePeriodValues3.getMinEndIndex();
        int int11 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        java.util.Date date54 = year53.getStart();
        java.lang.String str55 = year53.toString();
        long long56 = year53.getFirstMillisecond();
        java.util.Calendar calendar57 = null;
        try {
            long long58 = year53.getFirstMillisecond(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1546329600000L + "'", long56 == 1546329600000L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        java.util.Date date22 = day15.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date22, timeZone23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str29 = timePeriodValues28.getDescription();
        timePeriodValues28.setDescription("Time");
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        boolean boolean33 = timePeriodValues28.equals((java.lang.Object) day32);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day32, 0.0d);
        java.util.Date date36 = day32.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str41 = timePeriodValues40.getDescription();
        timePeriodValues40.setRangeDescription("");
        java.lang.Class<?> wildcardClass44 = timePeriodValues40.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str49 = timePeriodValues48.getDescription();
        timePeriodValues48.setDescription("Time");
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        boolean boolean53 = timePeriodValues48.equals((java.lang.Object) day52);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean56 = day52.equals((java.lang.Object) (short) 1);
        int int57 = day52.getMonth();
        org.jfree.data.time.SerialDate serialDate58 = day52.getSerialDate();
        java.util.Date date59 = day52.getStart();
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date59, timeZone60);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date59);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date59, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date36, timeZone63);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date22, timeZone63);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod69 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long70 = simpleTimePeriod69.getStartMillis();
        long long71 = simpleTimePeriod69.getEndMillis();
        java.util.Date date72 = simpleTimePeriod69.getStart();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(date22, date72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 12L + "'", long71 == 12L);
        org.junit.Assert.assertNotNull(date72);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        long long54 = year53.getLastMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        boolean boolean57 = year53.equals((java.lang.Object) seriesChangeEvent56);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (short) -1 + "'", obj2.equals((short) -1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues1.getTimePeriod(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str28 = timePeriodValues27.getDescription();
        timePeriodValues27.setRangeDescription("");
        int int31 = year17.compareTo((java.lang.Object) "");
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year17.getLastMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        long long54 = year53.getLastMillisecond();
        long long55 = year53.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1546329600000L + "'", long55 == 1546329600000L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        java.util.Date date22 = day15.getStart();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date22, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year25.getMiddleMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod24);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        int int10 = timePeriodValues3.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues3.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setRangeDescription("hi!");
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        int int14 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.delete(3, 0);
        boolean boolean7 = timePeriodValues3.isEmpty();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues3.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        boolean boolean10 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        java.util.Date date54 = year53.getStart();
        java.lang.String str55 = year53.toString();
        java.util.Calendar calendar56 = null;
        try {
            year53.peg(calendar56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "2019" + "'", str55.equals("2019"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        int int5 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setRangeDescription("");
        java.lang.Class<?> wildcardClass13 = timePeriodValues9.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str18 = timePeriodValues17.getDescription();
        timePeriodValues17.setDescription("Time");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        boolean boolean22 = timePeriodValues17.equals((java.lang.Object) day21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean25 = day21.equals((java.lang.Object) (short) 1);
        int int26 = day21.getMonth();
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        java.util.Date date28 = day21.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date28);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date28, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str38 = timePeriodValues37.getDescription();
        timePeriodValues37.setRangeDescription("");
        java.lang.Class<?> wildcardClass41 = timePeriodValues37.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str46 = timePeriodValues45.getDescription();
        timePeriodValues45.setDescription("Time");
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        boolean boolean50 = timePeriodValues45.equals((java.lang.Object) day49);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent52 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean53 = day49.equals((java.lang.Object) (short) 1);
        int int54 = day49.getMonth();
        org.jfree.data.time.SerialDate serialDate55 = day49.getSerialDate();
        java.util.Date date56 = day49.getStart();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass41, date56, timeZone57);
        org.jfree.data.time.TimePeriodValues timePeriodValues62 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str63 = timePeriodValues62.getDescription();
        timePeriodValues62.setRangeDescription("");
        java.lang.Class<?> wildcardClass66 = timePeriodValues62.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues70 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str71 = timePeriodValues70.getDescription();
        timePeriodValues70.setDescription("Time");
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
        boolean boolean75 = timePeriodValues70.equals((java.lang.Object) day74);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent77 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean78 = day74.equals((java.lang.Object) (short) 1);
        int int79 = day74.getMonth();
        org.jfree.data.time.SerialDate serialDate80 = day74.getSerialDate();
        java.util.Date date81 = day74.getStart();
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date81, timeZone82);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date81);
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass66, date81, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date56, timeZone85);
        boolean boolean88 = timePeriodValues1.equals((java.lang.Object) timeZone85);
        boolean boolean89 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNull(str71);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 6 + "'", int79 == 6);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNull(regularTimePeriod86);
        org.junit.Assert.assertNull(regularTimePeriod87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod33);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener35);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Date date11 = day7.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = day7.getSerialDate();
        int int14 = day7.compareTo((java.lang.Object) 0L);
        java.util.Date date15 = day7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setRangeDescription("");
        java.lang.Class<?> wildcardClass23 = timePeriodValues19.getClass();
        java.lang.Comparable comparable24 = timePeriodValues19.getKey();
        boolean boolean25 = timePeriodValues19.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str30 = timePeriodValues29.getDescription();
        timePeriodValues29.setDescription("Time");
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        boolean boolean34 = timePeriodValues29.equals((java.lang.Object) day33);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (double) 10L);
        java.util.Date date37 = day33.getEnd();
        boolean boolean38 = timePeriodValues19.equals((java.lang.Object) date37);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date15, date37);
        java.util.Date date41 = simpleTimePeriod40.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod40, (double) 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (-1.0d) + "'", comparable24.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date41);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        boolean boolean5 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str5 = timePeriodValues1.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) 10L);
        java.util.Date date17 = day13.getEnd();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (double) 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setRangeDescription("");
        java.lang.Class<?> wildcardClass17 = timePeriodValues13.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date32, timeZone36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str42 = timePeriodValues41.getDescription();
        timePeriodValues41.setRangeDescription("");
        java.lang.Class<?> wildcardClass45 = timePeriodValues41.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setDescription("Time");
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        boolean boolean54 = timePeriodValues49.equals((java.lang.Object) day53);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean57 = day53.equals((java.lang.Object) (short) 1);
        int int58 = day53.getMonth();
        org.jfree.data.time.SerialDate serialDate59 = day53.getSerialDate();
        java.util.Date date60 = day53.getStart();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date60, timeZone61);
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str67 = timePeriodValues66.getDescription();
        timePeriodValues66.setRangeDescription("");
        java.lang.Class<?> wildcardClass70 = timePeriodValues66.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str75 = timePeriodValues74.getDescription();
        timePeriodValues74.setDescription("Time");
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        boolean boolean79 = timePeriodValues74.equals((java.lang.Object) day78);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent81 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean82 = day78.equals((java.lang.Object) (short) 1);
        int int83 = day78.getMonth();
        org.jfree.data.time.SerialDate serialDate84 = day78.getSerialDate();
        java.util.Date date85 = day78.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date85, timeZone86);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date85);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date85, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date60, timeZone89);
        timePeriodValues3.setKey((java.lang.Comparable) date60);
        java.lang.Comparable comparable93 = timePeriodValues3.getKey();
        int int94 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertNotNull(comparable93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + (-1) + "'", int94 == (-1));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) 12L);
        java.util.Calendar calendar27 = null;
        try {
            year17.peg(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        java.util.Date date24 = year17.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year17.previous();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (short) 1 + "'", obj2.equals((short) 1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day7.previous();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        boolean boolean33 = year17.equals((java.lang.Object) day25);
        java.util.Calendar calendar34 = null;
        try {
            year17.peg(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        int int7 = timePeriodValues3.getMaxEndIndex();
        int int8 = timePeriodValues3.getMaxMiddleIndex();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, (-1), 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) -1, 2019, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str26 = timePeriodValues25.getDescription();
        timePeriodValues25.setDescription("Time");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean33 = day29.equals((java.lang.Object) (short) 1);
        int int34 = day29.getMonth();
        org.jfree.data.time.SerialDate serialDate35 = day29.getSerialDate();
        java.util.Date date36 = day29.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean43 = timePeriodValues41.equals((java.lang.Object) 7);
        boolean boolean44 = timePeriodValues41.isEmpty();
        int int45 = year39.compareTo((java.lang.Object) boolean44);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setRangeDescription("");
        int int53 = year39.compareTo((java.lang.Object) "");
        boolean boolean54 = simpleTimePeriod2.equals((java.lang.Object) int53);
        long long55 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 12L + "'", long55 == 12L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "Time");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str6 = timePeriodValues3.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener7);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 2 + "'", comparable4.equals(2));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.util.Date date11 = day7.getEnd();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day7.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + '#' + "'", comparable4.equals('#'));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
        int int2 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setKey((java.lang.Comparable) 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        java.util.Date date9 = day7.getStart();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        boolean boolean33 = year17.equals((java.lang.Object) day25);
        int int34 = year17.getYear();
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year17.getLastMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date49);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str57 = timePeriodValues56.getDescription();
        timePeriodValues56.setDescription("Time");
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        boolean boolean61 = timePeriodValues56.equals((java.lang.Object) day60);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent63 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean64 = day60.equals((java.lang.Object) (short) 1);
        int int65 = day60.getMonth();
        org.jfree.data.time.SerialDate serialDate66 = day60.getSerialDate();
        java.util.Date date67 = day60.getStart();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date67, timeZone68);
        org.jfree.data.time.TimePeriodValues timePeriodValues73 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str74 = timePeriodValues73.getDescription();
        timePeriodValues73.setDescription("Time");
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
        boolean boolean78 = timePeriodValues73.equals((java.lang.Object) day77);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent80 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean81 = day77.equals((java.lang.Object) (short) 1);
        int int82 = day77.getMonth();
        org.jfree.data.time.SerialDate serialDate83 = day77.getSerialDate();
        java.util.Date date84 = day77.getStart();
        java.util.TimeZone timeZone85 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date84, timeZone85);
        org.jfree.data.time.Year year87 = new org.jfree.data.time.Year(date67, timeZone85);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date49, timeZone85);
        org.jfree.data.time.Year year89 = new org.jfree.data.time.Year(date14, timeZone85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = year89.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 6 + "'", int82 == 6);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertNotNull(timeZone85);
        org.junit.Assert.assertNotNull(regularTimePeriod90);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.delete((int) (short) 10, 4);
        int int9 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 7, "TimePeriodValue[13-June-2019,1.0]", "hi!");
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,100.0]");
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        int int11 = day7.getYear();
        int int12 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
        java.util.Date date14 = regularTimePeriod13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod13);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        long long54 = year53.getLastMillisecond();
        int int55 = year53.getYear();
        long long56 = year53.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "Time");
        boolean boolean4 = timePeriodValues3.isEmpty();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1577865599999L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        int int8 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.setDescription("Time");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "Time");
        java.lang.String str7 = seriesChangeEvent6.toString();
        java.lang.String str8 = seriesChangeEvent6.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Time]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=Time]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Time]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=Time]"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean5 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        int int4 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) propertyChangeListener7);
        try {
            timePeriodValues1.delete((int) (byte) 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.lang.Class<?> wildcardClass15 = date14.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setDescription("Time");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        boolean boolean24 = timePeriodValues19.equals((java.lang.Object) day23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean27 = day23.equals((java.lang.Object) (short) 1);
        int int28 = day23.getMonth();
        org.jfree.data.time.SerialDate serialDate29 = day23.getSerialDate();
        java.util.Date date30 = day23.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date14, timeZone31);
        long long34 = year33.getFirstMillisecond();
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year33.getFirstMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.next();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = year17.getLastMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test247");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str22 = timePeriodValues21.getDescription();
//        timePeriodValues21.setDescription("Time");
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
//        int int30 = day25.getMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
//        java.util.Date date32 = day25.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str39 = timePeriodValues38.getDescription();
//        timePeriodValues38.setDescription("Time");
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
//        int int47 = day42.getMonth();
//        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
//        java.util.Date date49 = day42.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date14);
//        java.util.Date date55 = day54.getStart();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
//        long long57 = day56.getLastMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560495599999L + "'", long57 == 1560495599999L);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getYear();
//        int int2 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date14);
        long long55 = year54.getMiddleMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1562097599999L + "'", long55 == 1562097599999L);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
//        int int11 = day7.getYear();
//        int int12 = day7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
//        int int14 = day7.getMonth();
//        long long15 = day7.getSerialIndex();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43629L + "'", long15 == 43629L);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str6 = timePeriodValues5.getDescription();
//        timePeriodValues5.setDescription("Time");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean10 = timePeriodValues5.equals((java.lang.Object) day9);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, 1.0d);
//        java.lang.Number number13 = timePeriodValue12.getValue();
//        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue12.getPeriod();
//        java.lang.String str15 = timePeriodValue12.toString();
//        timePeriodValues1.add(timePeriodValue12);
//        java.lang.Object obj17 = timePeriodValue12.clone();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
//        org.junit.Assert.assertNotNull(timePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str15.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertNotNull(obj17);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date14);
        java.util.Date date55 = day54.getStart();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        java.util.Calendar calendar57 = null;
        try {
            long long58 = day56.getFirstMillisecond(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date55);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(0, (int) '4');
        java.lang.String str10 = timePeriodValues1.getDescription();
        java.lang.String str11 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) 1L);
        boolean boolean9 = timePeriodValues3.getNotify();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test258");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
//        int int11 = day7.getYear();
//        long long12 = day7.getFirstMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("2019");
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        int int6 = timePeriodValues1.getMinEndIndex();
        boolean boolean7 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 0.0d);
        java.lang.Number number11 = timePeriodValue10.getValue();
        java.lang.Object obj12 = null;
        boolean boolean13 = timePeriodValue10.equals(obj12);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues14.addChangeListener(seriesChangeListener18);
        boolean boolean20 = timePeriodValue10.equals((java.lang.Object) timePeriodValues14);
        java.lang.Comparable comparable21 = timePeriodValues14.getKey();
        timePeriodValues14.setDomainDescription("Time");
        int int24 = timePeriodValues14.getMaxEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (-1.0d) + "'", comparable21.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        java.util.Date date11 = day7.getEnd();
//        org.jfree.data.time.SerialDate serialDate12 = day7.getSerialDate();
//        int int14 = day7.compareTo((java.lang.Object) 0L);
//        java.util.Date date15 = day7.getStart();
//        long long16 = day7.getMiddleMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560452399999L + "'", long16 == 1560452399999L);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "Time");
        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timePeriodValues3.clone();
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 2 + "'", comparable4.equals(2));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.delete(3, 0);
        int int7 = timePeriodValues3.getItemCount();
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.delete((int) (short) 10, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str13 = timePeriodValues12.getDescription();
        timePeriodValues12.setDescription("Time");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        boolean boolean17 = timePeriodValues12.equals((java.lang.Object) day16);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean20 = day16.equals((java.lang.Object) (short) 1);
        int int21 = day16.getMonth();
        org.jfree.data.time.SerialDate serialDate22 = day16.getSerialDate();
        java.util.Date date23 = day16.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23, timeZone24);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str30 = timePeriodValues29.getDescription();
        timePeriodValues29.setDescription("Time");
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        boolean boolean34 = timePeriodValues29.equals((java.lang.Object) day33);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean37 = day33.equals((java.lang.Object) (short) 1);
        int int38 = day33.getMonth();
        org.jfree.data.time.SerialDate serialDate39 = day33.getSerialDate();
        java.util.Date date40 = day33.getStart();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date23, timeZone41);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str48 = timePeriodValues47.getDescription();
        timePeriodValues47.setDescription("Time");
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        boolean boolean52 = timePeriodValues47.equals((java.lang.Object) day51);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean55 = day51.equals((java.lang.Object) (short) 1);
        int int56 = day51.getMonth();
        org.jfree.data.time.SerialDate serialDate57 = day51.getSerialDate();
        java.util.Date date58 = day51.getStart();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date58, timeZone59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date58);
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str66 = timePeriodValues65.getDescription();
        timePeriodValues65.setDescription("Time");
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        boolean boolean70 = timePeriodValues65.equals((java.lang.Object) day69);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent72 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean73 = day69.equals((java.lang.Object) (short) 1);
        int int74 = day69.getMonth();
        org.jfree.data.time.SerialDate serialDate75 = day69.getSerialDate();
        java.util.Date date76 = day69.getStart();
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date76, timeZone77);
        org.jfree.data.time.TimePeriodValues timePeriodValues82 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str83 = timePeriodValues82.getDescription();
        timePeriodValues82.setDescription("Time");
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day();
        boolean boolean87 = timePeriodValues82.equals((java.lang.Object) day86);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent89 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean90 = day86.equals((java.lang.Object) (short) 1);
        int int91 = day86.getMonth();
        org.jfree.data.time.SerialDate serialDate92 = day86.getSerialDate();
        java.util.Date date93 = day86.getStart();
        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date93, timeZone94);
        org.jfree.data.time.Year year96 = new org.jfree.data.time.Year(date76, timeZone94);
        org.jfree.data.time.Year year97 = new org.jfree.data.time.Year(date58, timeZone94);
        org.jfree.data.time.Year year98 = new org.jfree.data.time.Year(date23, timeZone94);
        timePeriodValues3.setKey((java.lang.Comparable) date23);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(str66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNull(str83);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 6 + "'", int91 == 6);
        org.junit.Assert.assertNotNull(serialDate92);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertNotNull(timeZone94);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.delete((int) (short) 10, 2);
        int int12 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setRangeDescription("hi!");
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setRangeDescription("hi!");
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        int int14 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues1.getMaxStartIndex();
        try {
            timePeriodValues1.update(13, (java.lang.Number) 1546329600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
        java.lang.Number number11 = timePeriodValue10.getValue();
        java.lang.Object obj12 = timePeriodValue10.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0d + "'", number11.equals(1.0d));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        int int7 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setRangeDescription("2019");
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str58 = timePeriodValues57.getDescription();
        timePeriodValues57.setDescription("Time");
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        boolean boolean62 = timePeriodValues57.equals((java.lang.Object) day61);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent64 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean65 = day61.equals((java.lang.Object) (short) 1);
        int int66 = day61.getMonth();
        org.jfree.data.time.SerialDate serialDate67 = day61.getSerialDate();
        java.util.Date date68 = day61.getStart();
        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date68, timeZone69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date68);
        org.jfree.data.time.TimePeriodValues timePeriodValues75 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str76 = timePeriodValues75.getDescription();
        timePeriodValues75.setDescription("Time");
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
        boolean boolean80 = timePeriodValues75.equals((java.lang.Object) day79);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent82 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean83 = day79.equals((java.lang.Object) (short) 1);
        int int84 = day79.getMonth();
        org.jfree.data.time.SerialDate serialDate85 = day79.getSerialDate();
        java.util.Date date86 = day79.getStart();
        boolean boolean87 = year71.equals((java.lang.Object) day79);
        int int88 = year71.getYear();
        long long89 = year71.getSerialIndex();
        int int90 = year53.compareTo((java.lang.Object) year71);
        org.jfree.data.time.TimePeriodValues timePeriodValues91 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year53);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 6 + "'", int66 == 6);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertNull(str76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 6 + "'", int84 == 6);
        org.junit.Assert.assertNotNull(serialDate85);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2019 + "'", int88 == 2019);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 2019L + "'", long89 == 2019L);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
        timePeriodValue10.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValue10.getPeriod();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timePeriod13);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setRangeDescription("");
        java.lang.Class<?> wildcardClass17 = timePeriodValues13.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date32, timeZone36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str42 = timePeriodValues41.getDescription();
        timePeriodValues41.setRangeDescription("");
        java.lang.Class<?> wildcardClass45 = timePeriodValues41.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setDescription("Time");
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        boolean boolean54 = timePeriodValues49.equals((java.lang.Object) day53);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean57 = day53.equals((java.lang.Object) (short) 1);
        int int58 = day53.getMonth();
        org.jfree.data.time.SerialDate serialDate59 = day53.getSerialDate();
        java.util.Date date60 = day53.getStart();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date60, timeZone61);
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str67 = timePeriodValues66.getDescription();
        timePeriodValues66.setRangeDescription("");
        java.lang.Class<?> wildcardClass70 = timePeriodValues66.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str75 = timePeriodValues74.getDescription();
        timePeriodValues74.setDescription("Time");
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        boolean boolean79 = timePeriodValues74.equals((java.lang.Object) day78);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent81 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean82 = day78.equals((java.lang.Object) (short) 1);
        int int83 = day78.getMonth();
        org.jfree.data.time.SerialDate serialDate84 = day78.getSerialDate();
        java.util.Date date85 = day78.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date85, timeZone86);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date85);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date85, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date60, timeZone89);
        timePeriodValues3.setKey((java.lang.Comparable) date60);
        int int93 = timePeriodValues3.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue95 = timePeriodValues3.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues14.addChangeListener(seriesChangeListener18);
        boolean boolean20 = timePeriodValue10.equals((java.lang.Object) timePeriodValues14);
        java.lang.Comparable comparable21 = timePeriodValues14.getKey();
        timePeriodValues14.setDomainDescription("Time");
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str28 = timePeriodValues27.getDescription();
        timePeriodValues27.setDescription("Time");
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        boolean boolean32 = timePeriodValues27.equals((java.lang.Object) day31);
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day31, (double) 10L);
        boolean boolean36 = timePeriodValue34.equals((java.lang.Object) 0.0f);
        timePeriodValue34.setValue((java.lang.Number) 0.0f);
        boolean boolean39 = timePeriodValues14.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + (-1.0d) + "'", comparable21.equals((-1.0d)));
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("hi!");
        try {
            timePeriodValues1.update((int) (byte) 100, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long25 = simpleTimePeriod24.getStartMillis();
        java.util.Date date26 = simpleTimePeriod24.getEnd();
        boolean boolean27 = simpleTimePeriod2.equals((java.lang.Object) simpleTimePeriod24);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        boolean boolean4 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setRangeDescription("hi!");
        java.lang.String str12 = timePeriodValues8.getDomainDescription();
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) str12);
        int int14 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setDescription("");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        java.lang.Object obj6 = timePeriodValues1.clone();
        boolean boolean7 = timePeriodValues1.getNotify();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        java.util.Date date11 = day7.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
//        long long13 = day7.getLastMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str6 = timePeriodValues5.getDescription();
//        timePeriodValues5.setDescription("Time");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean10 = timePeriodValues5.equals((java.lang.Object) day9);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, 1.0d);
//        java.lang.Number number13 = timePeriodValue12.getValue();
//        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue12.getPeriod();
//        java.lang.String str15 = timePeriodValue12.toString();
//        timePeriodValues1.add(timePeriodValue12);
//        java.lang.String str17 = timePeriodValue12.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str22 = timePeriodValues21.getDescription();
//        timePeriodValues21.setDescription("Time");
//        int int25 = timePeriodValues21.getMaxEndIndex();
//        timePeriodValues21.setRangeDescription("2019");
//        boolean boolean28 = timePeriodValue12.equals((java.lang.Object) "2019");
//        java.lang.Number number29 = timePeriodValue12.getValue();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
//        org.junit.Assert.assertNotNull(timePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str15.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str17.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 1.0d + "'", number29.equals(1.0d));
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        int int11 = day7.getYear();
        int int12 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
        java.util.Calendar calendar14 = null;
        try {
            day7.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        java.lang.String str9 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Time" + "'", str9.equals("Time"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 100L);
        java.lang.Object obj20 = timePeriodValue19.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str25 = timePeriodValues24.getDescription();
        timePeriodValues24.setDescription("Time");
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        boolean boolean29 = timePeriodValues24.equals((java.lang.Object) day28);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean32 = day28.equals((java.lang.Object) (short) 1);
        int int33 = day28.getMonth();
        org.jfree.data.time.SerialDate serialDate34 = day28.getSerialDate();
        java.util.Date date35 = day28.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean42 = timePeriodValues40.equals((java.lang.Object) 7);
        boolean boolean43 = timePeriodValues40.isEmpty();
        int int44 = year38.compareTo((java.lang.Object) boolean43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year38.previous();
        boolean boolean46 = timePeriodValue19.equals((java.lang.Object) year38);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        java.lang.Class<?> wildcardClass2 = seriesChangeEvent1.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean15 = day11.equals((java.lang.Object) (short) 1);
        int int16 = day11.getMonth();
        org.jfree.data.time.SerialDate serialDate17 = day11.getSerialDate();
        java.util.Date date18 = day11.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str25 = timePeriodValues24.getDescription();
        timePeriodValues24.setRangeDescription("");
        java.lang.Class<?> wildcardClass28 = timePeriodValues24.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long32 = simpleTimePeriod31.getStartMillis();
        long long33 = simpleTimePeriod31.getEndMillis();
        java.util.Date date34 = simpleTimePeriod31.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str56 = timePeriodValues55.getDescription();
        timePeriodValues55.setDescription("Time");
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        boolean boolean60 = timePeriodValues55.equals((java.lang.Object) day59);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean63 = day59.equals((java.lang.Object) (short) 1);
        int int64 = day59.getMonth();
        org.jfree.data.time.SerialDate serialDate65 = day59.getSerialDate();
        java.util.Date date66 = day59.getStart();
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date66, timeZone67);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date49, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date34, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date18, timeZone67);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 12L + "'", long33 == 12L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNull(regularTimePeriod71);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=1]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setRangeDescription("hi!");
//        int int7 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str12 = timePeriodValues11.getDescription();
//        timePeriodValues11.setDescription("Time");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
//        int int20 = day15.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) (-1));
//        long long25 = day22.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day22, (double) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str32 = timePeriodValues31.getDescription();
//        timePeriodValues31.setDescription("Time");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean36 = timePeriodValues31.equals((java.lang.Object) day35);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean39 = day35.equals((java.lang.Object) (short) 1);
//        int int40 = day35.getMonth();
//        org.jfree.data.time.SerialDate serialDate41 = day35.getSerialDate();
//        java.util.Date date42 = day35.getStart();
//        java.util.Date date43 = day35.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str48 = timePeriodValues47.getDescription();
//        timePeriodValues47.setRangeDescription("hi!");
//        int int51 = timePeriodValues47.getMaxStartIndex();
//        int int52 = day35.compareTo((java.lang.Object) int51);
//        java.lang.String str53 = day35.toString();
//        boolean boolean54 = timePeriodValue27.equals((java.lang.Object) day35);
//        long long55 = day35.getSerialIndex();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//        org.junit.Assert.assertNull(str32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "13-June-2019" + "'", str53.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 43629L + "'", long55 == 43629L);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) (byte) 0);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("");
        int int22 = year17.compareTo((java.lang.Object) timePeriodFormatException21);
        java.lang.String str23 = timePeriodFormatException21.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str23.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1546329600000L, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        long long34 = year24.getLastMillisecond();
        java.util.Calendar calendar35 = null;
        try {
            long long36 = year24.getFirstMillisecond(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str21 = timePeriodValues20.getDescription();
//        timePeriodValues20.setDescription("Time");
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
//        int int29 = day24.getMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
//        java.util.Date date31 = day24.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str39 = timePeriodValues38.getDescription();
//        timePeriodValues38.setDescription("Time");
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
//        int int47 = day42.getMonth();
//        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
//        java.util.Date date49 = day42.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date14, date49);
//        long long53 = simpleTimePeriod52.getStartMillis();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560409200000L + "'", long53 == 1560409200000L);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        boolean boolean35 = year24.equals((java.lang.Object) 'a');
        long long36 = year24.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str41 = timePeriodValues40.getDescription();
        timePeriodValues40.setDescription("Time");
        boolean boolean44 = year24.equals((java.lang.Object) "Time");
        java.lang.String str45 = year24.toString();
        int int46 = year24.getYear();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 'a');
        long long7 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        java.lang.Class<?> wildcardClass10 = seriesChangeEvent9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        try {
            int int12 = simpleTimePeriod2.compareTo((java.lang.Object) class11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Class cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        java.util.Date date24 = year17.getEnd();
        java.lang.String str25 = year17.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues1.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) (byte) 0);
        java.lang.Object obj20 = timePeriodValue19.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(obj20);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate15);
//        int int18 = day17.getDayOfMonth();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = day16.equals((java.lang.Object) day17);
        java.util.Date date19 = day17.getEnd();
        int int20 = day17.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str25 = timePeriodValues24.getDescription();
        timePeriodValues24.setRangeDescription("hi!");
        java.lang.String str28 = timePeriodValues24.getDomainDescription();
        int int29 = day17.compareTo((java.lang.Object) str28);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setDescription("Time");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = timePeriodValues13.equals((java.lang.Object) day17);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 10L);
        java.util.Date date21 = day17.getEnd();
        boolean boolean22 = timePeriodValues3.equals((java.lang.Object) date21);
        int int23 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        timePeriodValues3.delete(100, 4);
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
//        java.lang.String str11 = day7.toString();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.util.Date date0 = null;
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException2 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass3 = timePeriodFormatException2.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean15 = day11.equals((java.lang.Object) (short) 1);
        int int16 = day11.getMonth();
        org.jfree.data.time.SerialDate serialDate17 = day11.getSerialDate();
        java.util.Date date18 = day11.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        boolean boolean22 = day20.equals((java.lang.Object) day21);
        java.util.Date date23 = day21.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str28 = timePeriodValues27.getDescription();
        timePeriodValues27.setDescription("Time");
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        boolean boolean32 = timePeriodValues27.equals((java.lang.Object) day31);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent34 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean35 = day31.equals((java.lang.Object) (short) 1);
        int int36 = day31.getMonth();
        org.jfree.data.time.SerialDate serialDate37 = day31.getSerialDate();
        java.util.Date date38 = day31.getStart();
        java.util.Date date39 = day31.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str44 = timePeriodValues43.getDescription();
        timePeriodValues43.setDescription("Time");
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        boolean boolean48 = timePeriodValues43.equals((java.lang.Object) day47);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean51 = day47.equals((java.lang.Object) (short) 1);
        int int52 = day47.getMonth();
        org.jfree.data.time.SerialDate serialDate53 = day47.getSerialDate();
        java.util.Date date54 = day47.getStart();
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date54, timeZone55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date54);
        org.jfree.data.time.TimePeriodValues timePeriodValues61 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str62 = timePeriodValues61.getDescription();
        timePeriodValues61.setDescription("Time");
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day();
        boolean boolean66 = timePeriodValues61.equals((java.lang.Object) day65);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent68 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean69 = day65.equals((java.lang.Object) (short) 1);
        int int70 = day65.getMonth();
        org.jfree.data.time.SerialDate serialDate71 = day65.getSerialDate();
        java.util.Date date72 = day65.getStart();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date72, timeZone73);
        org.jfree.data.time.TimePeriodValues timePeriodValues78 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str79 = timePeriodValues78.getDescription();
        timePeriodValues78.setDescription("Time");
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day();
        boolean boolean83 = timePeriodValues78.equals((java.lang.Object) day82);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent85 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean86 = day82.equals((java.lang.Object) (short) 1);
        int int87 = day82.getMonth();
        org.jfree.data.time.SerialDate serialDate88 = day82.getSerialDate();
        java.util.Date date89 = day82.getStart();
        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day(date89, timeZone90);
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date72, timeZone90);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date54, timeZone90);
        org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date39, timeZone90);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass3, date23, timeZone90);
        try {
            org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date0, timeZone90);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 6 + "'", int70 == 6);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
        org.junit.Assert.assertNull(str79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 6 + "'", int87 == 6);
        org.junit.Assert.assertNotNull(serialDate88);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(timeZone90);
        org.junit.Assert.assertNull(regularTimePeriod95);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "13-June-2019");
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str12 = timePeriodValues11.getDescription();
        timePeriodValues11.setDescription("Time");
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
        int int20 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
        java.util.Date date22 = day15.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date22, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str32 = timePeriodValues31.getDescription();
        timePeriodValues31.setRangeDescription("");
        java.lang.Class<?> wildcardClass35 = timePeriodValues31.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str40 = timePeriodValues39.getDescription();
        timePeriodValues39.setDescription("Time");
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        boolean boolean44 = timePeriodValues39.equals((java.lang.Object) day43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean47 = day43.equals((java.lang.Object) (short) 1);
        int int48 = day43.getMonth();
        org.jfree.data.time.SerialDate serialDate49 = day43.getSerialDate();
        java.util.Date date50 = day43.getStart();
        java.util.TimeZone timeZone51 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date50, timeZone51);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str57 = timePeriodValues56.getDescription();
        timePeriodValues56.setRangeDescription("");
        java.lang.Class<?> wildcardClass60 = timePeriodValues56.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str65 = timePeriodValues64.getDescription();
        timePeriodValues64.setDescription("Time");
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
        boolean boolean69 = timePeriodValues64.equals((java.lang.Object) day68);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent71 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean72 = day68.equals((java.lang.Object) (short) 1);
        int int73 = day68.getMonth();
        org.jfree.data.time.SerialDate serialDate74 = day68.getSerialDate();
        java.util.Date date75 = day68.getStart();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date75, timeZone76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date75);
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date75, timeZone79);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass7, date50, timeZone79);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date50);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertNull(str65);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 6 + "'", int73 == 6);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod81);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + (-1L) + "'", comparable11.equals((-1L)));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.lang.Class<?> wildcardClass14 = serialDate13.getClass();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate13);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.Date date15 = day7.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setDescription("Time");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        boolean boolean24 = timePeriodValues19.equals((java.lang.Object) day23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean27 = day23.equals((java.lang.Object) (short) 1);
        int int28 = day23.getMonth();
        org.jfree.data.time.SerialDate serialDate29 = day23.getSerialDate();
        java.util.Date date30 = day23.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str38 = timePeriodValues37.getDescription();
        timePeriodValues37.setDescription("Time");
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        boolean boolean42 = timePeriodValues37.equals((java.lang.Object) day41);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean45 = day41.equals((java.lang.Object) (short) 1);
        int int46 = day41.getMonth();
        org.jfree.data.time.SerialDate serialDate47 = day41.getSerialDate();
        java.util.Date date48 = day41.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date48, timeZone49);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str55 = timePeriodValues54.getDescription();
        timePeriodValues54.setDescription("Time");
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
        boolean boolean59 = timePeriodValues54.equals((java.lang.Object) day58);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean62 = day58.equals((java.lang.Object) (short) 1);
        int int63 = day58.getMonth();
        org.jfree.data.time.SerialDate serialDate64 = day58.getSerialDate();
        java.util.Date date65 = day58.getStart();
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date65, timeZone66);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date48, timeZone66);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date30, timeZone66);
        boolean boolean70 = day7.equals((java.lang.Object) year69);
        java.util.Calendar calendar71 = null;
        try {
            year69.peg(calendar71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 6 + "'", int63 == 6);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        boolean boolean35 = year24.equals((java.lang.Object) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str40 = timePeriodValues39.getDescription();
        timePeriodValues39.setDescription("Time");
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        boolean boolean44 = timePeriodValues39.equals((java.lang.Object) day43);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent46 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean47 = day43.equals((java.lang.Object) (short) 1);
        int int48 = day43.getMonth();
        org.jfree.data.time.SerialDate serialDate49 = day43.getSerialDate();
        java.util.Date date50 = day43.getStart();
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50, timeZone51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date50);
        org.jfree.data.time.TimePeriodValue timePeriodValue55 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year53, (double) (byte) 0);
        boolean boolean56 = year24.equals((java.lang.Object) timePeriodValue55);
        java.util.Date date57 = year24.getEnd();
        long long58 = year24.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues14.addChangeListener(seriesChangeListener18);
        boolean boolean20 = timePeriodValue10.equals((java.lang.Object) timePeriodValues14);
        try {
            org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValues14.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str2 = timePeriodValues1.getDomainDescription();
//        int int3 = timePeriodValues1.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str10 = timePeriodValues9.getDescription();
//        timePeriodValues9.setDescription("Time");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
//        long long19 = day13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day13.previous();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str21 = timePeriodValues20.getDescription();
//        timePeriodValues20.setDescription("Time");
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
//        int int29 = day24.getMonth();
//        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
//        java.util.Date date31 = day24.getStart();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str39 = timePeriodValues38.getDescription();
//        timePeriodValues38.setDescription("Time");
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
//        int int47 = day42.getMonth();
//        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
//        java.util.Date date49 = day42.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date14, date49);
//        java.util.Date date53 = simpleTimePeriod52.getStart();
//        java.util.Date date54 = simpleTimePeriod52.getEnd();
//        long long55 = simpleTimePeriod52.getStartMillis();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560409200000L + "'", long55 == 1560409200000L);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
        java.lang.Number number11 = timePeriodValue10.getValue();
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue10.getPeriod();
        java.lang.Number number13 = timePeriodValue10.getValue();
        java.lang.Number number14 = timePeriodValue10.getValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0d + "'", number11.equals(1.0d));
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0d + "'", number14.equals(1.0d));
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str22 = timePeriodValues21.getDescription();
//        timePeriodValues21.setDescription("Time");
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
//        int int30 = day25.getMonth();
//        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
//        java.util.Date date32 = day25.getStart();
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str39 = timePeriodValues38.getDescription();
//        timePeriodValues38.setDescription("Time");
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
//        int int47 = day42.getMonth();
//        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
//        java.util.Date date49 = day42.getStart();
//        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date14);
//        java.util.Date date55 = day54.getStart();
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
//        long long57 = day56.getFirstMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(str22);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(timeZone50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560409200000L + "'", long57 == 1560409200000L);
//    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str6 = timePeriodValues5.getDescription();
//        timePeriodValues5.setDescription("Time");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean10 = timePeriodValues5.equals((java.lang.Object) day9);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, (double) 10L);
//        int int13 = day9.getMonth();
//        long long14 = day9.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day9, "Time", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day9, (double) 0.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str24 = timePeriodValues23.getDescription();
//        timePeriodValues23.setDescription("Time");
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        boolean boolean28 = timePeriodValues23.equals((java.lang.Object) day27);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean31 = day27.equals((java.lang.Object) (short) 1);
//        int int32 = day27.getMonth();
//        org.jfree.data.time.SerialDate serialDate33 = day27.getSerialDate();
//        java.util.Date date34 = day27.getStart();
//        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date34);
//        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year37, (double) (byte) 0);
//        timePeriodValues1.setKey((java.lang.Comparable) (byte) 0);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(timeZone35);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        boolean boolean28 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str33 = timePeriodValues32.getDescription();
        timePeriodValues32.setDescription("Time");
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        boolean boolean37 = timePeriodValues32.equals((java.lang.Object) day36);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean40 = day36.equals((java.lang.Object) (short) 1);
        int int41 = day36.getMonth();
        org.jfree.data.time.SerialDate serialDate42 = day36.getSerialDate();
        java.util.Date date43 = day36.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean50 = timePeriodValues48.equals((java.lang.Object) 7);
        boolean boolean51 = timePeriodValues48.isEmpty();
        int int52 = year46.compareTo((java.lang.Object) boolean51);
        java.util.Date date53 = year46.getEnd();
        long long54 = year46.getMiddleMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year46, (java.lang.Number) (-1));
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues59 = timePeriodValues1.createCopy(5, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1562097599999L + "'", long54 == 1562097599999L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean17 = day13.equals((java.lang.Object) (short) 1);
        int int18 = day13.getMonth();
        org.jfree.data.time.SerialDate serialDate19 = day13.getSerialDate();
        java.util.Date date20 = day13.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str27 = timePeriodValues26.getDescription();
        timePeriodValues26.setDescription("Time");
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        boolean boolean31 = timePeriodValues26.equals((java.lang.Object) day30);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean34 = day30.equals((java.lang.Object) (short) 1);
        int int35 = day30.getMonth();
        org.jfree.data.time.SerialDate serialDate36 = day30.getSerialDate();
        java.util.Date date37 = day30.getStart();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date20, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date5, timeZone38);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        java.util.Date date54 = year53.getStart();
        long long55 = year53.getLastMillisecond();
        long long56 = year53.getSerialIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 2019L + "'", long56 == 2019L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        java.lang.Number number28 = timePeriodValue14.getValue();
        timePeriodValue14.setValue((java.lang.Number) (short) -1);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(number28);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        timePeriodValues7.setDescription("Time");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        boolean boolean12 = timePeriodValues7.equals((java.lang.Object) day11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day11, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str19 = timePeriodValues18.getDescription();
        timePeriodValues18.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        boolean boolean24 = timePeriodValue14.equals((java.lang.Object) timePeriodValues18);
        java.lang.Number number25 = null;
        timePeriodValue14.setValue(number25);
        timePeriodValues1.add(timePeriodValue14);
        boolean boolean28 = timePeriodValues1.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str33 = timePeriodValues32.getDescription();
        timePeriodValues32.setDescription("Time");
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        boolean boolean37 = timePeriodValues32.equals((java.lang.Object) day36);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean40 = day36.equals((java.lang.Object) (short) 1);
        int int41 = day36.getMonth();
        org.jfree.data.time.SerialDate serialDate42 = day36.getSerialDate();
        java.util.Date date43 = day36.getStart();
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean50 = timePeriodValues48.equals((java.lang.Object) 7);
        boolean boolean51 = timePeriodValues48.isEmpty();
        int int52 = year46.compareTo((java.lang.Object) boolean51);
        java.util.Date date53 = year46.getEnd();
        long long54 = year46.getMiddleMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year46, (java.lang.Number) (-1));
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent57 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        java.lang.Object obj58 = seriesChangeEvent57.getSource();
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1562097599999L + "'", long54 == 1562097599999L);
        org.junit.Assert.assertNotNull(obj58);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=1]");
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException3.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        long long33 = year24.getFirstMillisecond();
        long long34 = year24.getMiddleMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1562097599999L + "'", long34 == 1562097599999L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 100L);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year17.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.lang.Object obj11 = timePeriodValue10.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
        java.lang.Number number11 = timePeriodValue10.getValue();
        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue10.getPeriod();
        java.lang.Number number13 = timePeriodValue10.getValue();
        java.lang.Object obj14 = timePeriodValue10.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0d + "'", number11.equals(1.0d));
        org.junit.Assert.assertNotNull(timePeriod12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        boolean boolean23 = simpleTimePeriod2.equals((java.lang.Object) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str28 = timePeriodValues27.getDescription();
        timePeriodValues27.setRangeDescription("hi!");
        java.lang.String str31 = timePeriodValues27.getDomainDescription();
        int int32 = timePeriodValues27.getMaxEndIndex();
        java.lang.Comparable comparable33 = timePeriodValues27.getKey();
        boolean boolean34 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues27);
        boolean boolean35 = timePeriodValues27.getNotify();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + comparable33 + "' != '" + (-1.0d) + "'", comparable33.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setDescription("Time");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (double) 10L);
        boolean boolean23 = timePeriodValue21.equals((java.lang.Object) 0.0f);
        timePeriodValues3.add(timePeriodValue21);
        int int25 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        int int9 = timePeriodValues3.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues13.fireSeriesChanged();
        int int15 = timePeriodValues13.getItemCount();
        int int16 = timePeriodValues13.getMaxEndIndex();
        boolean boolean17 = timePeriodValues3.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (java.lang.Number) 4);
        int int29 = day25.getYear();
        int int30 = day25.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day25.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day25, "hi!", "hi!");
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day25, (double) (byte) 1);
        timePeriodValues13.add(timePeriodValue36);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setDomainDescription("");
        timePeriodValues3.setDomainDescription("hi!");
        boolean boolean8 = timePeriodValues3.isEmpty();
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        long long14 = day7.getFirstMillisecond();
//        long long15 = day7.getFirstMillisecond();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day7.getFirstMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = day16.equals((java.lang.Object) day17);
        java.util.Date date19 = day17.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setRangeDescription("hi!");
//        int int7 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str12 = timePeriodValues11.getDescription();
//        timePeriodValues11.setDescription("Time");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean16 = timePeriodValues11.equals((java.lang.Object) day15);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean19 = day15.equals((java.lang.Object) (short) 1);
//        int int20 = day15.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day15.getSerialDate();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(serialDate21);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) (-1));
//        long long25 = day22.getSerialIndex();
//        java.util.Calendar calendar26 = null;
//        try {
//            long long27 = day22.getLastMillisecond(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43629L + "'", long25 == 43629L);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        boolean boolean35 = year24.equals((java.lang.Object) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues39.setDomainDescription("");
        int int42 = year24.compareTo((java.lang.Object) timePeriodValues39);
        java.util.Calendar calendar43 = null;
        try {
            long long44 = year24.getFirstMillisecond(calendar43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass4 = timePeriodFormatException3.getClass();
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str2 = timePeriodValues1.getDomainDescription();
//        int int3 = timePeriodValues1.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str10 = timePeriodValues9.getDescription();
//        timePeriodValues9.setDescription("Time");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
//        java.lang.String str19 = day13.toString();
//        java.util.Date date20 = day13.getEnd();
//        java.util.Date date21 = null;
//        try {
//            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date20, date21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (-1), 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "Time");
//        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        java.lang.Object obj8 = timePeriodValues3.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str13 = timePeriodValues12.getDescription();
//        timePeriodValues12.setDescription("Time");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean17 = timePeriodValues12.equals((java.lang.Object) day16);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 10L);
//        boolean boolean21 = timePeriodValue19.equals((java.lang.Object) 0.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str26 = timePeriodValues25.getDescription();
//        timePeriodValues25.setDescription("Time");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean33 = day29.equals((java.lang.Object) (short) 1);
//        int int34 = day29.getMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day29.getSerialDate();
//        java.util.Date date36 = day29.getStart();
//        org.jfree.data.time.SerialDate serialDate37 = day29.getSerialDate();
//        boolean boolean38 = timePeriodValue19.equals((java.lang.Object) day29);
//        java.lang.String str39 = timePeriodValue19.toString();
//        org.jfree.data.time.TimePeriod timePeriod40 = timePeriodValue19.getPeriod();
//        timePeriodValues3.setKey((java.lang.Comparable) timePeriod40);
//        try {
//            timePeriodValues3.update((int) (short) 10, (java.lang.Number) 1562097599999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 2 + "'", comparable4.equals(2));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str39.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod40);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setRangeDescription("");
        java.lang.Class<?> wildcardClass17 = timePeriodValues13.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date32, timeZone36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str42 = timePeriodValues41.getDescription();
        timePeriodValues41.setRangeDescription("");
        java.lang.Class<?> wildcardClass45 = timePeriodValues41.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setDescription("Time");
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        boolean boolean54 = timePeriodValues49.equals((java.lang.Object) day53);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean57 = day53.equals((java.lang.Object) (short) 1);
        int int58 = day53.getMonth();
        org.jfree.data.time.SerialDate serialDate59 = day53.getSerialDate();
        java.util.Date date60 = day53.getStart();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date60, timeZone61);
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str67 = timePeriodValues66.getDescription();
        timePeriodValues66.setRangeDescription("");
        java.lang.Class<?> wildcardClass70 = timePeriodValues66.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str75 = timePeriodValues74.getDescription();
        timePeriodValues74.setDescription("Time");
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        boolean boolean79 = timePeriodValues74.equals((java.lang.Object) day78);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent81 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean82 = day78.equals((java.lang.Object) (short) 1);
        int int83 = day78.getMonth();
        org.jfree.data.time.SerialDate serialDate84 = day78.getSerialDate();
        java.util.Date date85 = day78.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date85, timeZone86);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date85);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date85, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date60, timeZone89);
        timePeriodValues3.setKey((java.lang.Comparable) date60);
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues94 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day93);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day93, (double) 10L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNull(regularTimePeriod91);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        int int35 = year34.getYear();
        int int36 = year34.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year34, (java.lang.Number) (byte) -1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2019 + "'", int36 == 2019);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        boolean boolean33 = year17.equals((java.lang.Object) day25);
        java.lang.Object obj34 = null;
        int int35 = year17.compareTo(obj34);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str40 = timePeriodValues39.getDescription();
        timePeriodValues39.setDescription("Time");
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        boolean boolean44 = timePeriodValues39.equals((java.lang.Object) day43);
        int int45 = day43.getYear();
        java.util.Date date46 = day43.getEnd();
        int int47 = day43.getMonth();
        int int48 = year17.compareTo((java.lang.Object) int47);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str53 = timePeriodValues52.getDescription();
        timePeriodValues52.setRangeDescription("hi!");
        timePeriodValues52.setDomainDescription("hi!");
        java.lang.String str58 = timePeriodValues52.getRangeDescription();
        java.lang.Object obj59 = timePeriodValues52.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener60 = null;
        timePeriodValues52.addChangeListener(seriesChangeListener60);
        boolean boolean62 = timePeriodValues52.getNotify();
        int int63 = year17.compareTo((java.lang.Object) boolean62);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2019 + "'", int45 == 2019);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        timePeriodValues1.setDescription("");
        try {
            timePeriodValues1.update(0, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy(10, 4);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        long long54 = year53.getLastMillisecond();
        java.util.Calendar calendar55 = null;
        try {
            long long56 = year53.getFirstMillisecond(calendar55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
        timePeriodValue16.setValue((java.lang.Number) (-1.0d));
        java.lang.Object obj19 = timePeriodValue16.clone();
        java.lang.Number number20 = timePeriodValue16.getValue();
        timePeriodValues3.add(timePeriodValue16);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.0d) + "'", number20.equals((-1.0d)));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        int int5 = timePeriodValues1.getMinMiddleIndex();
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues1.getMinEndIndex();
        int int10 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        int int4 = timePeriodValues1.getMaxMiddleIndex();
        java.lang.String str5 = timePeriodValues1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str13 = timePeriodValues12.getDescription();
        timePeriodValues12.setDescription("Time");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        boolean boolean17 = timePeriodValues12.equals((java.lang.Object) day16);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 4);
        int int20 = day16.getYear();
        int int21 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day16.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day16, "hi!", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day16.next();
        int int27 = day16.getYear();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) (-1));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 10.0f);
        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate11 = day7.getSerialDate();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.setDescription("Time");
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 0.0f + "'", comparable6.equals(0.0f));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str7 = timePeriodValues6.getDescription();
        timePeriodValues6.setDescription("Time");
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        boolean boolean11 = timePeriodValues6.equals((java.lang.Object) day10);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean14 = day10.equals((java.lang.Object) (short) 1);
        int int15 = day10.getMonth();
        org.jfree.data.time.SerialDate serialDate16 = day10.getSerialDate();
        java.util.Date date17 = day10.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17, timeZone18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str24 = timePeriodValues23.getDescription();
        timePeriodValues23.setDescription("Time");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        boolean boolean28 = timePeriodValues23.equals((java.lang.Object) day27);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean31 = day27.equals((java.lang.Object) (short) 1);
        int int32 = day27.getMonth();
        org.jfree.data.time.SerialDate serialDate33 = day27.getSerialDate();
        java.util.Date date34 = day27.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str42 = timePeriodValues41.getDescription();
        timePeriodValues41.setDescription("Time");
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        boolean boolean46 = timePeriodValues41.equals((java.lang.Object) day45);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean49 = day45.equals((java.lang.Object) (short) 1);
        int int50 = day45.getMonth();
        org.jfree.data.time.SerialDate serialDate51 = day45.getSerialDate();
        java.util.Date date52 = day45.getStart();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52, timeZone53);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str59 = timePeriodValues58.getDescription();
        timePeriodValues58.setDescription("Time");
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        boolean boolean63 = timePeriodValues58.equals((java.lang.Object) day62);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean66 = day62.equals((java.lang.Object) (short) 1);
        int int67 = day62.getMonth();
        org.jfree.data.time.SerialDate serialDate68 = day62.getSerialDate();
        java.util.Date date69 = day62.getStart();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date69, timeZone70);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date52, timeZone70);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date34, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date17, timeZone70);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod74);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.Date date32 = day24.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str37 = timePeriodValues36.getDescription();
        timePeriodValues36.setRangeDescription("hi!");
        int int40 = timePeriodValues36.getMaxStartIndex();
        int int41 = day24.compareTo((java.lang.Object) int40);
        timePeriodValues13.add((org.jfree.data.time.TimePeriod) day24, (double) (-1));
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day24, (double) 7);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener46);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (-1.0d) + "'", comparable9.equals((-1.0d)));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.lang.Object obj9 = timePeriodValues3.clone();
        java.lang.String str10 = timePeriodValues3.getDescription();
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        int int7 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setNotify(false);
        int int10 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setDescription("Time");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean22 = day18.equals((java.lang.Object) (short) 1);
        int int23 = day18.getMonth();
        org.jfree.data.time.SerialDate serialDate24 = day18.getSerialDate();
        java.util.Date date25 = day18.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        boolean boolean29 = day27.equals((java.lang.Object) day28);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day27, (double) (short) 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
        timePeriodValue10.setValue((java.lang.Number) (-1.0d));
        java.lang.Object obj13 = timePeriodValue10.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str18 = timePeriodValues17.getDescription();
        timePeriodValues17.setDescription("Time");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        boolean boolean22 = timePeriodValues17.equals((java.lang.Object) day21);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean25 = day21.equals((java.lang.Object) (short) 1);
        int int26 = day21.getMonth();
        org.jfree.data.time.SerialDate serialDate27 = day21.getSerialDate();
        java.util.Date date28 = day21.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str35 = timePeriodValues34.getDescription();
        timePeriodValues34.setDescription("Time");
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        boolean boolean39 = timePeriodValues34.equals((java.lang.Object) day38);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean42 = day38.equals((java.lang.Object) (short) 1);
        int int43 = day38.getMonth();
        org.jfree.data.time.SerialDate serialDate44 = day38.getSerialDate();
        java.util.Date date45 = day38.getStart();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45, timeZone46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date28, timeZone46);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str53 = timePeriodValues52.getDescription();
        timePeriodValues52.setDescription("Time");
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        boolean boolean57 = timePeriodValues52.equals((java.lang.Object) day56);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent59 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean60 = day56.equals((java.lang.Object) (short) 1);
        int int61 = day56.getMonth();
        org.jfree.data.time.SerialDate serialDate62 = day56.getSerialDate();
        java.util.Date date63 = day56.getStart();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date63, timeZone64);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(date28, date63);
        java.util.Date date67 = simpleTimePeriod66.getStart();
        boolean boolean68 = timePeriodValue10.equals((java.lang.Object) simpleTimePeriod66);
        timePeriodValue10.setValue((java.lang.Number) 10);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        boolean boolean23 = simpleTimePeriod2.equals((java.lang.Object) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues27.delete(3, 0);
        int int31 = timePeriodValues27.getItemCount();
        java.lang.String str32 = timePeriodValues27.getDescription();
        timePeriodValues27.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        try {
            int int35 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues27);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(str32);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Date date11 = day7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day7.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str17 = timePeriodValues16.getDescription();
        timePeriodValues16.setDescription("Time");
        int int20 = timePeriodValues16.getMaxEndIndex();
        timePeriodValues16.setNotify(false);
        int int23 = timePeriodValues16.getMaxEndIndex();
        int int24 = timePeriodValues16.getMaxStartIndex();
        int int25 = day7.compareTo((java.lang.Object) int24);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        int int7 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setRangeDescription("2019");
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean39 = timePeriodValues37.equals((java.lang.Object) 7);
        boolean boolean40 = timePeriodValues37.isEmpty();
        int int41 = year35.compareTo((java.lang.Object) boolean40);
        java.util.Date date42 = year35.getEnd();
        boolean boolean43 = timePeriodValues14.equals((java.lang.Object) year35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year35.next();
        boolean boolean46 = year35.equals((java.lang.Object) 'a');
        long long47 = year35.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str52 = timePeriodValues51.getDescription();
        timePeriodValues51.setDescription("Time");
        boolean boolean55 = year35.equals((java.lang.Object) "Time");
        boolean boolean56 = timePeriodValues3.equals((java.lang.Object) boolean55);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date32, timeZone50);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date14, timeZone50);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date14);
        java.lang.Class<?> wildcardClass55 = day54.getClass();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(wildcardClass55);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[13-June-2019,10.0]");
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        boolean boolean36 = year34.equals((java.lang.Object) 0.0f);
        long long37 = year34.getSerialIndex();
        int int38 = year34.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year34, (java.lang.Number) 0.0f);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMaxMiddleIndex();
        int int6 = timePeriodValues1.getItemCount();
        timePeriodValues1.setNotify(true);
        timePeriodValues1.delete((int) (short) 10, 2);
        int int12 = timePeriodValues1.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue14 = timePeriodValues1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str26 = timePeriodValues25.getDescription();
        timePeriodValues25.setDescription("Time");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean33 = day29.equals((java.lang.Object) (short) 1);
        int int34 = day29.getMonth();
        org.jfree.data.time.SerialDate serialDate35 = day29.getSerialDate();
        java.util.Date date36 = day29.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean43 = timePeriodValues41.equals((java.lang.Object) 7);
        boolean boolean44 = timePeriodValues41.isEmpty();
        int int45 = year39.compareTo((java.lang.Object) boolean44);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setRangeDescription("");
        int int53 = year39.compareTo((java.lang.Object) "");
        boolean boolean54 = simpleTimePeriod2.equals((java.lang.Object) int53);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str59 = timePeriodValues58.getDescription();
        timePeriodValues58.setDescription("Time");
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        boolean boolean63 = timePeriodValues58.equals((java.lang.Object) day62);
        org.jfree.data.time.TimePeriodValue timePeriodValue65 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day62, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str70 = timePeriodValues69.getDescription();
        timePeriodValues69.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener73 = null;
        timePeriodValues69.addChangeListener(seriesChangeListener73);
        boolean boolean75 = timePeriodValue65.equals((java.lang.Object) timePeriodValues69);
        boolean boolean76 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues69);
        timePeriodValues69.delete(6, 1);
        int int80 = timePeriodValues69.getItemCount();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        int int7 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setRangeDescription("2019");
        int int10 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = day16.equals((java.lang.Object) day17);
        java.util.Date date19 = day17.getEnd();
        int int20 = day17.getMonth();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        long long2 = day0.getSerialIndex();
//        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        int int11 = day7.getMonth();
//        long long12 = day7.getFirstMillisecond();
//        java.util.Date date13 = day7.getEnd();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 100L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.previous();
        long long21 = regularTimePeriod20.getMiddleMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1530561599999L + "'", long21 == 1530561599999L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str39 = timePeriodValues38.getDescription();
        timePeriodValues38.setDescription("Time");
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        boolean boolean43 = timePeriodValues38.equals((java.lang.Object) day42);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean46 = day42.equals((java.lang.Object) (short) 1);
        int int47 = day42.getMonth();
        org.jfree.data.time.SerialDate serialDate48 = day42.getSerialDate();
        java.util.Date date49 = day42.getStart();
        java.util.TimeZone timeZone50 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49, timeZone50);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date14, date49);
        java.util.Date date53 = simpleTimePeriod52.getEnd();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date53);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        boolean boolean35 = year24.equals((java.lang.Object) 'a');
        long long36 = year24.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str41 = timePeriodValues40.getDescription();
        timePeriodValues40.setDescription("Time");
        boolean boolean44 = year24.equals((java.lang.Object) "Time");
        java.lang.String str45 = year24.toString();
        java.util.Calendar calendar46 = null;
        try {
            year24.peg(calendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        timePeriodValues1.delete(11, 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        int int22 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate23 = day12.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(serialDate23);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (-1), 0L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, 10L);
        java.lang.Object obj3 = null;
        try {
            int int4 = simpleTimePeriod2.compareTo(obj3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        int int9 = day7.getYear();
        java.lang.Object obj10 = null;
        int int11 = day7.compareTo(obj10);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = day16.equals((java.lang.Object) day17);
        java.util.Date date19 = day17.getEnd();
        int int20 = day17.getYear();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day17.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) day17);
//        java.util.Date date19 = day17.getEnd();
//        int int20 = day17.getYear();
//        int int21 = day17.getYear();
//        long long22 = day17.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 0L);
//        java.util.Calendar calendar25 = null;
//        try {
//            long long26 = day17.getLastMillisecond(calendar25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560409200000L + "'", long22 == 1560409200000L);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,0.0]");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,0.0]" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,0.0]"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        timePeriodValues1.delete((int) (short) 10, 3);
        java.lang.String str9 = timePeriodValues1.getRangeDescription();
        int int10 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        int int8 = timePeriodValues3.getMaxEndIndex();
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setDescription("Time");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = timePeriodValues13.equals((java.lang.Object) day17);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean21 = day17.equals((java.lang.Object) (short) 1);
        int int22 = day17.getMonth();
        org.jfree.data.time.SerialDate serialDate23 = day17.getSerialDate();
        java.util.Date date24 = day17.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean31 = timePeriodValues29.equals((java.lang.Object) 7);
        boolean boolean32 = timePeriodValues29.isEmpty();
        int int33 = year27.compareTo((java.lang.Object) boolean32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year27.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (java.lang.Number) 12L);
        timePeriodValues3.add(timePeriodValue36);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "Time");
        boolean boolean4 = timePeriodValues3.isEmpty();
        timePeriodValues3.delete(2019, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 10.0f);
        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues14.addChangeListener(seriesChangeListener18);
        boolean boolean20 = timePeriodValue10.equals((java.lang.Object) timePeriodValues14);
        java.lang.Object obj21 = timePeriodValues14.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
        timePeriodValue16.setValue((java.lang.Number) (-1.0d));
        java.lang.Object obj19 = timePeriodValue16.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str24 = timePeriodValues23.getDescription();
        timePeriodValues23.setDescription("Time");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        boolean boolean28 = timePeriodValues23.equals((java.lang.Object) day27);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean31 = day27.equals((java.lang.Object) (short) 1);
        int int32 = day27.getMonth();
        org.jfree.data.time.SerialDate serialDate33 = day27.getSerialDate();
        java.util.Date date34 = day27.getStart();
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date34, timeZone35);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str41 = timePeriodValues40.getDescription();
        timePeriodValues40.setDescription("Time");
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        boolean boolean45 = timePeriodValues40.equals((java.lang.Object) day44);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent47 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean48 = day44.equals((java.lang.Object) (short) 1);
        int int49 = day44.getMonth();
        org.jfree.data.time.SerialDate serialDate50 = day44.getSerialDate();
        java.util.Date date51 = day44.getStart();
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date34, timeZone52);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str59 = timePeriodValues58.getDescription();
        timePeriodValues58.setDescription("Time");
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        boolean boolean63 = timePeriodValues58.equals((java.lang.Object) day62);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent65 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean66 = day62.equals((java.lang.Object) (short) 1);
        int int67 = day62.getMonth();
        org.jfree.data.time.SerialDate serialDate68 = day62.getSerialDate();
        java.util.Date date69 = day62.getStart();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date69, timeZone70);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod(date34, date69);
        java.util.Date date73 = simpleTimePeriod72.getStart();
        boolean boolean74 = timePeriodValue16.equals((java.lang.Object) simpleTimePeriod72);
        boolean boolean75 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue16);
        java.util.Date date76 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(date76);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        int int11 = day7.getYear();
        int int12 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "hi!", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day7.next();
        int int18 = day7.getYear();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day7.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.setDescription("Time");
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (int) 'a', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (-1.0d));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str2 = timePeriodValues1.getDomainDescription();
//        int int3 = timePeriodValues1.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str10 = timePeriodValues9.getDescription();
//        timePeriodValues9.setDescription("Time");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
//        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
//        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
//        java.lang.String str19 = day13.toString();
//        java.lang.Class<?> wildcardClass20 = day13.getClass();
//        int int21 = day13.getYear();
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        boolean boolean35 = year24.equals((java.lang.Object) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues39.setDomainDescription("");
        int int42 = year24.compareTo((java.lang.Object) timePeriodValues39);
        int int43 = timePeriodValues39.getMaxEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str13 = timePeriodValues12.getDescription();
        timePeriodValues12.setDescription("Time");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        boolean boolean17 = timePeriodValues12.equals((java.lang.Object) day16);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str24 = timePeriodValues23.getDescription();
        timePeriodValues23.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener27);
        boolean boolean29 = timePeriodValue19.equals((java.lang.Object) timePeriodValues23);
        java.lang.Number number30 = null;
        timePeriodValue19.setValue(number30);
        timePeriodValues1.add(timePeriodValue19);
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.fireSeriesChanged();
        int int5 = timePeriodValues3.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        int int15 = day13.getYear();
        java.util.Date date16 = day13.getEnd();
        int int17 = day13.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day13, (double) 1562097599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int24 = timePeriodValues23.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues23.removePropertyChangeListener(propertyChangeListener25);
        java.lang.Comparable comparable27 = timePeriodValues23.getKey();
        boolean boolean28 = day13.equals((java.lang.Object) timePeriodValues23);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str33 = timePeriodValues32.getDescription();
        timePeriodValues32.setRangeDescription("");
        java.lang.Class<?> wildcardClass36 = timePeriodValues32.getClass();
        java.lang.Comparable comparable37 = timePeriodValues32.getKey();
        boolean boolean38 = timePeriodValues32.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str43 = timePeriodValues42.getDescription();
        timePeriodValues42.setDescription("Time");
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        boolean boolean47 = timePeriodValues42.equals((java.lang.Object) day46);
        org.jfree.data.time.TimePeriodValue timePeriodValue49 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day46, (double) 10L);
        java.util.Date date50 = day46.getEnd();
        boolean boolean51 = timePeriodValues32.equals((java.lang.Object) date50);
        java.lang.String str52 = timePeriodValues32.getDescription();
        boolean boolean53 = day13.equals((java.lang.Object) str52);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (-1.0d) + "'", comparable27.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + (-1.0d) + "'", comparable37.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
//        timePeriodValues3.addChangeListener(seriesChangeListener7);
//        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str15 = timePeriodValues14.getDescription();
//        timePeriodValues14.setDescription("Time");
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
//        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (double) 10L);
//        boolean boolean23 = timePeriodValue21.equals((java.lang.Object) 0.0f);
//        timePeriodValues3.add(timePeriodValue21);
//        java.lang.String str25 = timePeriodValue21.toString();
//        java.lang.Object obj26 = timePeriodValue21.clone();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str25.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(obj26);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        int int7 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        int int12 = timePeriodValues3.getMaxEndIndex();
        int int13 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str6 = timePeriodValues5.getDescription();
//        timePeriodValues5.setDescription("Time");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean10 = timePeriodValues5.equals((java.lang.Object) day9);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, 1.0d);
//        java.lang.Number number13 = timePeriodValue12.getValue();
//        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue12.getPeriod();
//        java.lang.String str15 = timePeriodValue12.toString();
//        timePeriodValues1.add(timePeriodValue12);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day17);
//        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str23 = timePeriodValues22.getDescription();
//        timePeriodValues22.setDescription("Time");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        boolean boolean27 = timePeriodValues22.equals((java.lang.Object) day26);
//        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, 1.0d);
//        java.lang.Number number30 = timePeriodValue29.getValue();
//        org.jfree.data.time.TimePeriod timePeriod31 = timePeriodValue29.getPeriod();
//        java.lang.String str32 = timePeriodValue29.toString();
//        timePeriodValues18.add(timePeriodValue29);
//        java.lang.String str34 = timePeriodValue29.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str39 = timePeriodValues38.getDescription();
//        timePeriodValues38.setDescription("Time");
//        int int42 = timePeriodValues38.getMaxEndIndex();
//        timePeriodValues38.setRangeDescription("2019");
//        boolean boolean45 = timePeriodValue29.equals((java.lang.Object) "2019");
//        boolean boolean46 = timePeriodValue12.equals((java.lang.Object) boolean45);
//        java.lang.Number number47 = timePeriodValue12.getValue();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
//        org.junit.Assert.assertNotNull(timePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str15.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1.0d + "'", number30.equals(1.0d));
//        org.junit.Assert.assertNotNull(timePeriod31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str32.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str34.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertNull(str39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 1.0d + "'", number47.equals(1.0d));
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str6 = timePeriodValues5.getDescription();
//        timePeriodValues5.setDescription("Time");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        boolean boolean10 = timePeriodValues5.equals((java.lang.Object) day9);
//        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day9, 1.0d);
//        java.lang.Number number13 = timePeriodValue12.getValue();
//        org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValue12.getPeriod();
//        java.lang.String str15 = timePeriodValue12.toString();
//        timePeriodValues1.add(timePeriodValue12);
//        java.lang.String str17 = timePeriodValue12.toString();
//        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValue12.getPeriod();
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0d + "'", number13.equals(1.0d));
//        org.junit.Assert.assertNotNull(timePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str15.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str17.equals("TimePeriodValue[13-June-2019,1.0]"));
//        org.junit.Assert.assertNotNull(timePeriod18);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=1]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.setDomainDescription("hi!");
        java.lang.String str9 = timePeriodValues3.getRangeDescription();
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        int int13 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0f, "org.jfree.data.general.SeriesChangeEvent[source=1]", "org.jfree.data.general.SeriesChangeEvent[source=1]");
        timePeriodValues3.delete(3, 0);
        int int7 = timePeriodValues3.getItemCount();
        java.lang.String str8 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        try {
            java.lang.Number number12 = timePeriodValues3.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) day17);
//        int int19 = day17.getDayOfMonth();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        int int9 = day7.getYear();
//        long long10 = day7.getMiddleMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560452399999L + "'", long10 == 1560452399999L);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.delete((int) (short) 10, 4);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str10 = timePeriodValues9.getDescription();
        timePeriodValues9.setDescription("Time");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean14 = timePeriodValues9.equals((java.lang.Object) day13);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, 1.0d);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 0.0f);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues1.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str2 = timePeriodValues1.getDomainDescription();
        int int3 = timePeriodValues1.getMinStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        boolean boolean7 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 13);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        long long24 = year17.getMiddleMillisecond();
        long long25 = year17.getLastMillisecond();
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year17.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1562097599999L + "'", long24 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        boolean boolean33 = year17.equals((java.lang.Object) day25);
        int int34 = year17.getYear();
        long long35 = year17.getSerialIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year17.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str42 = timePeriodValues41.getDescription();
        timePeriodValues41.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
        timePeriodValues41.addChangeListener(seriesChangeListener45);
        timePeriodValues41.setKey((java.lang.Comparable) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str53 = timePeriodValues52.getDescription();
        timePeriodValues52.setDescription("Time");
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        boolean boolean57 = timePeriodValues52.equals((java.lang.Object) day56);
        org.jfree.data.time.TimePeriodValue timePeriodValue59 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day56, (double) 10L);
        boolean boolean61 = timePeriodValue59.equals((java.lang.Object) 0.0f);
        timePeriodValues41.add(timePeriodValue59);
        boolean boolean63 = timePeriodValues41.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener64 = null;
        timePeriodValues41.addChangeListener(seriesChangeListener64);
        boolean boolean66 = year17.equals((java.lang.Object) seriesChangeListener64);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNull(str53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 0.0d);
//        java.util.Date date11 = day7.getEnd();
//        long long12 = day7.getLastMillisecond();
//        int int13 = day7.getMonth();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        long long18 = year17.getSerialIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long22 = simpleTimePeriod21.getStartMillis();
        int int23 = year17.compareTo((java.lang.Object) long22);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year17);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
//        int int11 = day7.getYear();
//        int int12 = day7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "hi!", "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day7.next();
//        int int18 = day7.getYear();
//        long long19 = day7.getFirstMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560409200000L + "'", long19 == 1560409200000L);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        int int11 = day7.getMonth();
//        long long12 = day7.getFirstMillisecond();
//        long long13 = day7.getSerialIndex();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day7.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod33);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod33, (double) 10);
        java.lang.String str37 = timePeriodValue36.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "TimePeriodValue[2020,10.0]" + "'", str37.equals("TimePeriodValue[2020,10.0]"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day7.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(43629L, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, 10L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setRangeDescription("");
        java.lang.Class<?> wildcardClass17 = timePeriodValues13.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date32, timeZone36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str42 = timePeriodValues41.getDescription();
        timePeriodValues41.setRangeDescription("");
        java.lang.Class<?> wildcardClass45 = timePeriodValues41.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setDescription("Time");
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        boolean boolean54 = timePeriodValues49.equals((java.lang.Object) day53);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean57 = day53.equals((java.lang.Object) (short) 1);
        int int58 = day53.getMonth();
        org.jfree.data.time.SerialDate serialDate59 = day53.getSerialDate();
        java.util.Date date60 = day53.getStart();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date60, timeZone61);
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str67 = timePeriodValues66.getDescription();
        timePeriodValues66.setRangeDescription("");
        java.lang.Class<?> wildcardClass70 = timePeriodValues66.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str75 = timePeriodValues74.getDescription();
        timePeriodValues74.setDescription("Time");
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        boolean boolean79 = timePeriodValues74.equals((java.lang.Object) day78);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent81 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean82 = day78.equals((java.lang.Object) (short) 1);
        int int83 = day78.getMonth();
        org.jfree.data.time.SerialDate serialDate84 = day78.getSerialDate();
        java.util.Date date85 = day78.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date85, timeZone86);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date85);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date85, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date60, timeZone89);
        timePeriodValues3.setKey((java.lang.Comparable) date60);
        int int93 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str94 = timePeriodValues3.getRangeDescription();
        int int95 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNull(regularTimePeriod91);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + (-1) + "'", int93 == (-1));
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "hi!" + "'", str94.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-1) + "'", int95 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=Time]");
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
        int int11 = day7.getYear();
        int int12 = day7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "hi!", "hi!");
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) (byte) 1);
        java.lang.Number number19 = timePeriodValue18.getValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0d + "'", number19.equals(1.0d));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        java.lang.String str35 = year34.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        boolean boolean33 = year17.equals((java.lang.Object) day25);
        int int34 = year17.getYear();
        long long35 = year17.getSerialIndex();
        long long36 = year17.getSerialIndex();
        long long37 = year17.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2019L + "'", long35 == 2019L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 2019L + "'", long36 == 2019L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
        java.util.Date date17 = day16.getEnd();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "TimePeriodValue[2020,10.0]");
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Date date11 = day7.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = day7.getSerialDate();
        int int14 = day7.compareTo((java.lang.Object) 0L);
        java.util.Date date15 = day7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setRangeDescription("");
        java.lang.Class<?> wildcardClass23 = timePeriodValues19.getClass();
        java.lang.Comparable comparable24 = timePeriodValues19.getKey();
        boolean boolean25 = timePeriodValues19.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str30 = timePeriodValues29.getDescription();
        timePeriodValues29.setDescription("Time");
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        boolean boolean34 = timePeriodValues29.equals((java.lang.Object) day33);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (double) 10L);
        java.util.Date date37 = day33.getEnd();
        boolean boolean38 = timePeriodValues19.equals((java.lang.Object) date37);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date15, date37);
        org.jfree.data.time.TimePeriodValue timePeriodValue42 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod40, 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (-1.0d) + "'", comparable24.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.lang.Class<?> wildcardClass15 = date14.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setDescription("Time");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        boolean boolean24 = timePeriodValues19.equals((java.lang.Object) day23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean27 = day23.equals((java.lang.Object) (short) 1);
        int int28 = day23.getMonth();
        org.jfree.data.time.SerialDate serialDate29 = day23.getSerialDate();
        java.util.Date date30 = day23.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date14, timeZone31);
        java.util.Date date34 = year33.getEnd();
        int int35 = year33.getYear();
        java.lang.Object obj36 = null;
        int int37 = year33.compareTo(obj36);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener8);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 2, "", "Time");
//        java.lang.Comparable comparable4 = timePeriodValues3.getKey();
//        int int5 = timePeriodValues3.getMaxStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        java.lang.Object obj8 = timePeriodValues3.clone();
//        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str13 = timePeriodValues12.getDescription();
//        timePeriodValues12.setDescription("Time");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean17 = timePeriodValues12.equals((java.lang.Object) day16);
//        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 10L);
//        boolean boolean21 = timePeriodValue19.equals((java.lang.Object) 0.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str26 = timePeriodValues25.getDescription();
//        timePeriodValues25.setDescription("Time");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean33 = day29.equals((java.lang.Object) (short) 1);
//        int int34 = day29.getMonth();
//        org.jfree.data.time.SerialDate serialDate35 = day29.getSerialDate();
//        java.util.Date date36 = day29.getStart();
//        org.jfree.data.time.SerialDate serialDate37 = day29.getSerialDate();
//        boolean boolean38 = timePeriodValue19.equals((java.lang.Object) day29);
//        java.lang.String str39 = timePeriodValue19.toString();
//        org.jfree.data.time.TimePeriod timePeriod40 = timePeriodValue19.getPeriod();
//        timePeriodValues3.setKey((java.lang.Comparable) timePeriod40);
//        int int42 = timePeriodValues3.getItemCount();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 2 + "'", comparable4.equals(2));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str39.equals("TimePeriodValue[13-June-2019,10.0]"));
//        org.junit.Assert.assertNotNull(timePeriod40);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.delete((int) (short) 10, 4);
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        org.jfree.data.time.SerialDate serialDate15 = day7.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate15);
//        long long17 = day16.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.next();
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day16, (double) 0L);
//        java.util.Calendar calendar21 = null;
//        try {
//            day16.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560495599999L + "'", long17 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1.0d + "'", obj2.equals(1.0d));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1.0d + "'", obj3.equals(1.0d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("");
        java.lang.Class<?> wildcardClass7 = timePeriodValues3.getClass();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setDescription("Time");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        boolean boolean18 = timePeriodValues13.equals((java.lang.Object) day17);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day17, (double) 10L);
        java.util.Date date21 = day17.getEnd();
        boolean boolean22 = timePeriodValues3.equals((java.lang.Object) date21);
        java.lang.Comparable comparable23 = timePeriodValues3.getKey();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener24);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (-1.0d) + "'", comparable8.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (-1.0d) + "'", comparable23.equals((-1.0d)));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        int int11 = timePeriodValues3.getMinEndIndex();
        int int12 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (-1.0d));
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 1562097599999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "", "Value");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str26 = timePeriodValues25.getDescription();
        timePeriodValues25.setDescription("Time");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent32 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean33 = day29.equals((java.lang.Object) (short) 1);
        int int34 = day29.getMonth();
        org.jfree.data.time.SerialDate serialDate35 = day29.getSerialDate();
        java.util.Date date36 = day29.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean43 = timePeriodValues41.equals((java.lang.Object) 7);
        boolean boolean44 = timePeriodValues41.isEmpty();
        int int45 = year39.compareTo((java.lang.Object) boolean44);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setRangeDescription("");
        int int53 = year39.compareTo((java.lang.Object) "");
        boolean boolean54 = simpleTimePeriod2.equals((java.lang.Object) int53);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str59 = timePeriodValues58.getDescription();
        timePeriodValues58.setDescription("Time");
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        boolean boolean63 = timePeriodValues58.equals((java.lang.Object) day62);
        org.jfree.data.time.TimePeriodValue timePeriodValue65 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day62, (java.lang.Number) 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues69 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str70 = timePeriodValues69.getDescription();
        timePeriodValues69.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener73 = null;
        timePeriodValues69.addChangeListener(seriesChangeListener73);
        boolean boolean75 = timePeriodValue65.equals((java.lang.Object) timePeriodValues69);
        boolean boolean76 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues69);
        timePeriodValues69.delete(6, 1);
        timePeriodValues69.delete(12, 2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(str70);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.lang.Class<?> wildcardClass15 = date14.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setDescription("Time");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        boolean boolean24 = timePeriodValues19.equals((java.lang.Object) day23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean27 = day23.equals((java.lang.Object) (short) 1);
        int int28 = day23.getMonth();
        org.jfree.data.time.SerialDate serialDate29 = day23.getSerialDate();
        java.util.Date date30 = day23.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date14, timeZone31);
        long long34 = year33.getMiddleMillisecond();
        java.lang.String str35 = year33.toString();
        java.util.Date date36 = year33.getEnd();
        java.util.Calendar calendar37 = null;
        try {
            long long38 = year33.getFirstMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1562097599999L + "'", long34 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNotNull(date36);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        java.lang.Object obj9 = timePeriodValues3.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str14 = timePeriodValues13.getDescription();
        timePeriodValues13.setRangeDescription("");
        java.lang.Class<?> wildcardClass17 = timePeriodValues13.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date32, timeZone36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str42 = timePeriodValues41.getDescription();
        timePeriodValues41.setRangeDescription("");
        java.lang.Class<?> wildcardClass45 = timePeriodValues41.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str50 = timePeriodValues49.getDescription();
        timePeriodValues49.setDescription("Time");
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        boolean boolean54 = timePeriodValues49.equals((java.lang.Object) day53);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean57 = day53.equals((java.lang.Object) (short) 1);
        int int58 = day53.getMonth();
        org.jfree.data.time.SerialDate serialDate59 = day53.getSerialDate();
        java.util.Date date60 = day53.getStart();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date60, timeZone61);
        org.jfree.data.time.TimePeriodValues timePeriodValues66 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str67 = timePeriodValues66.getDescription();
        timePeriodValues66.setRangeDescription("");
        java.lang.Class<?> wildcardClass70 = timePeriodValues66.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str75 = timePeriodValues74.getDescription();
        timePeriodValues74.setDescription("Time");
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day();
        boolean boolean79 = timePeriodValues74.equals((java.lang.Object) day78);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent81 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean82 = day78.equals((java.lang.Object) (short) 1);
        int int83 = day78.getMonth();
        org.jfree.data.time.SerialDate serialDate84 = day78.getSerialDate();
        java.util.Date date85 = day78.getStart();
        java.util.TimeZone timeZone86 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day87 = new org.jfree.data.time.Day(date85, timeZone86);
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date85);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass70, date85, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date60, timeZone89);
        timePeriodValues3.setKey((java.lang.Comparable) date60);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener93 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener93);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertNull(str67);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(str75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(timeZone86);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod90);
        org.junit.Assert.assertNull(regularTimePeriod91);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod24, "TimePeriodValue[13-June-2019,1.0]", "");
        boolean boolean28 = timePeriodValues27.isEmpty();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        boolean boolean36 = year34.equals((java.lang.Object) 0.0f);
        long long37 = year34.getSerialIndex();
        int int38 = year34.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year34, (java.lang.Number) (short) 1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 2019L + "'", long37 == 2019L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.lang.Class<?> wildcardClass15 = date14.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setDescription("Time");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        boolean boolean24 = timePeriodValues19.equals((java.lang.Object) day23);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean27 = day23.equals((java.lang.Object) (short) 1);
        int int28 = day23.getMonth();
        org.jfree.data.time.SerialDate serialDate29 = day23.getSerialDate();
        java.util.Date date30 = day23.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date14, timeZone31);
        long long34 = year33.getMiddleMillisecond();
        java.lang.String str35 = year33.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1562097599999L + "'", long34 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str22 = timePeriodValues21.getDescription();
        timePeriodValues21.setDescription("Time");
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        boolean boolean26 = timePeriodValues21.equals((java.lang.Object) day25);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean29 = day25.equals((java.lang.Object) (short) 1);
        int int30 = day25.getMonth();
        org.jfree.data.time.SerialDate serialDate31 = day25.getSerialDate();
        java.util.Date date32 = day25.getStart();
        boolean boolean33 = year17.equals((java.lang.Object) day25);
        int int34 = year17.getYear();
        long long35 = year17.getMiddleMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1562097599999L + "'", long35 == 1562097599999L);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) day17);
//        long long19 = day16.getSerialIndex();
//        long long20 = day16.getMiddleMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43629L + "'", long19 == 43629L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560452399999L + "'", long20 == 1560452399999L);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues10.setDomainDescription("");
        timePeriodValues10.setDomainDescription("hi!");
        boolean boolean15 = simpleTimePeriod2.equals((java.lang.Object) "hi!");
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, 1.0d);
//        java.lang.Number number11 = timePeriodValue10.getValue();
//        org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValue10.getPeriod();
//        java.lang.String str13 = timePeriodValue10.toString();
//        timePeriodValue10.setValue((java.lang.Number) (-1));
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0d + "'", number11.equals(1.0d));
//        org.junit.Assert.assertNotNull(timePeriod12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "TimePeriodValue[13-June-2019,1.0]" + "'", str13.equals("TimePeriodValue[13-June-2019,1.0]"));
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str11 = timePeriodValues10.getDescription();
        timePeriodValues10.setDescription("Time");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean15 = timePeriodValues10.equals((java.lang.Object) day14);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent17 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean18 = day14.equals((java.lang.Object) (short) 1);
        int int19 = day14.getMonth();
        org.jfree.data.time.SerialDate serialDate20 = day14.getSerialDate();
        java.util.Date date21 = day14.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean28 = timePeriodValues26.equals((java.lang.Object) 7);
        boolean boolean29 = timePeriodValues26.isEmpty();
        int int30 = year24.compareTo((java.lang.Object) boolean29);
        java.util.Date date31 = year24.getEnd();
        boolean boolean32 = timePeriodValues3.equals((java.lang.Object) year24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year24.next();
        java.lang.Class<?> wildcardClass34 = year24.getClass();
        java.lang.String str35 = year24.toString();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.Date date15 = day7.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setRangeDescription("hi!");
        int int23 = timePeriodValues19.getMaxStartIndex();
        int int24 = day7.compareTo((java.lang.Object) int23);
        int int25 = day7.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day7.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean3 = timePeriodValues1.equals((java.lang.Object) 7);
        int int4 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) propertyChangeListener7);
        timePeriodValues1.setKey((java.lang.Comparable) "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        int int11 = day7.getMonth();
//        long long12 = day7.getFirstMillisecond();
//        long long13 = day7.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.previous();
//        java.util.Date date15 = day7.getStart();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        timePeriodValues3.setDomainDescription("");
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=1]"));
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) day17);
//        long long19 = day16.getMiddleMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560452399999L + "'", long19 == 1560452399999L);
//    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
//        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 0.0f);
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str17 = timePeriodValues16.getDescription();
//        timePeriodValues16.setDescription("Time");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        boolean boolean21 = timePeriodValues16.equals((java.lang.Object) day20);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean24 = day20.equals((java.lang.Object) (short) 1);
//        int int25 = day20.getMonth();
//        org.jfree.data.time.SerialDate serialDate26 = day20.getSerialDate();
//        java.util.Date date27 = day20.getStart();
//        org.jfree.data.time.SerialDate serialDate28 = day20.getSerialDate();
//        boolean boolean29 = timePeriodValue10.equals((java.lang.Object) day20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str32 = timePeriodValues31.getDomainDescription();
//        int int33 = timePeriodValues31.getMinStartIndex();
//        timePeriodValues31.setRangeDescription("hi!");
//        java.beans.PropertyChangeListener propertyChangeListener36 = null;
//        timePeriodValues31.addPropertyChangeListener(propertyChangeListener36);
//        boolean boolean38 = day20.equals((java.lang.Object) timePeriodValues31);
//        org.jfree.data.time.TimePeriodValue timePeriodValue40 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day20, 10.0d);
//        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str45 = timePeriodValues44.getDescription();
//        timePeriodValues44.setRangeDescription("hi!");
//        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str52 = timePeriodValues51.getDescription();
//        timePeriodValues51.setDescription("Time");
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        boolean boolean56 = timePeriodValues51.equals((java.lang.Object) day55);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent58 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean59 = day55.equals((java.lang.Object) (short) 1);
//        int int60 = day55.getMonth();
//        org.jfree.data.time.SerialDate serialDate61 = day55.getSerialDate();
//        java.util.Date date62 = day55.getStart();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date62, timeZone63);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date62);
//        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        boolean boolean69 = timePeriodValues67.equals((java.lang.Object) 7);
//        boolean boolean70 = timePeriodValues67.isEmpty();
//        int int71 = year65.compareTo((java.lang.Object) boolean70);
//        java.util.Date date72 = year65.getEnd();
//        boolean boolean73 = timePeriodValues44.equals((java.lang.Object) year65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year65.next();
//        boolean boolean76 = year65.equals((java.lang.Object) 'a');
//        long long77 = year65.getLastMillisecond();
//        boolean boolean78 = timePeriodValue40.equals((java.lang.Object) long77);
//        java.lang.String str79 = timePeriodValue40.toString();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNull(str17);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertNull(str52);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1577865599999L + "'", long77 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "TimePeriodValue[13-June-2019,10.0]" + "'", str79.equals("TimePeriodValue[13-June-2019,10.0]"));
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        int int15 = day7.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str18 = timePeriodValues17.getDomainDescription();
//        int int19 = timePeriodValues17.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str26 = timePeriodValues25.getDescription();
//        timePeriodValues25.setDescription("Time");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 0.0f);
//        boolean boolean35 = day7.equals((java.lang.Object) 0.0f);
//        long long36 = day7.getLastMillisecond();
//        long long37 = day7.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str42 = timePeriodValues41.getDescription();
//        timePeriodValues41.setDescription("Time");
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        boolean boolean46 = timePeriodValues41.equals((java.lang.Object) day45);
//        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day45, 0.0d);
//        boolean boolean49 = day7.equals((java.lang.Object) timePeriodValue48);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560495599999L + "'", long36 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560452399999L + "'", long37 == 1560452399999L);
//        org.junit.Assert.assertNull(str42);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.next();
        long long25 = regularTimePeriod24.getMiddleMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1593676799999L + "'", long25 == 1593676799999L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        int int6 = timePeriodValues1.getMinEndIndex();
        java.lang.String str7 = timePeriodValues1.getDomainDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        boolean boolean5 = timePeriodValues1.isEmpty();
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues1.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Date date11 = day7.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = day7.getSerialDate();
        int int14 = day7.compareTo((java.lang.Object) 0L);
        java.util.Date date15 = day7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setRangeDescription("");
        java.lang.Class<?> wildcardClass23 = timePeriodValues19.getClass();
        java.lang.Comparable comparable24 = timePeriodValues19.getKey();
        boolean boolean25 = timePeriodValues19.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str30 = timePeriodValues29.getDescription();
        timePeriodValues29.setDescription("Time");
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        boolean boolean34 = timePeriodValues29.equals((java.lang.Object) day33);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (double) 10L);
        java.util.Date date37 = day33.getEnd();
        boolean boolean38 = timePeriodValues19.equals((java.lang.Object) date37);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date15, date37);
        java.util.Date date41 = simpleTimePeriod40.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str46 = timePeriodValues45.getDescription();
        boolean boolean47 = simpleTimePeriod40.equals((java.lang.Object) str46);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (-1.0d) + "'", comparable24.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year16, "TimePeriodValue[2019,100.0]", "TimePeriodValue[2020,10.0]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        java.util.Date date14 = day7.getStart();
//        int int15 = day7.getDayOfMonth();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
//        java.lang.String str18 = timePeriodValues17.getDomainDescription();
//        int int19 = timePeriodValues17.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues17.removePropertyChangeListener(propertyChangeListener20);
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str26 = timePeriodValues25.getDescription();
//        timePeriodValues25.setDescription("Time");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean30 = timePeriodValues25.equals((java.lang.Object) day29);
//        org.jfree.data.time.TimePeriodValue timePeriodValue32 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day29, 1.0d);
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) day29, (java.lang.Number) 0.0f);
//        boolean boolean35 = day7.equals((java.lang.Object) 0.0f);
//        org.jfree.data.time.TimePeriodValue timePeriodValue37 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 0L);
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str42 = timePeriodValues41.getDescription();
//        timePeriodValues41.setRangeDescription("hi!");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
//        timePeriodValues41.addChangeListener(seriesChangeListener45);
//        timePeriodValues41.setKey((java.lang.Comparable) (-1L));
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str53 = timePeriodValues52.getDescription();
//        timePeriodValues52.setDescription("Time");
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        boolean boolean57 = timePeriodValues52.equals((java.lang.Object) day56);
//        org.jfree.data.time.TimePeriodValue timePeriodValue59 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day56, (double) 10L);
//        boolean boolean61 = timePeriodValue59.equals((java.lang.Object) 0.0f);
//        timePeriodValues41.add(timePeriodValue59);
//        boolean boolean63 = timePeriodValues41.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener64 = null;
//        timePeriodValues41.addPropertyChangeListener(propertyChangeListener64);
//        boolean boolean66 = timePeriodValue37.equals((java.lang.Object) propertyChangeListener64);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNull(str42);
//        org.junit.Assert.assertNull(str53);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener7);
        timePeriodValues3.setKey((java.lang.Comparable) (-1L));
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str15 = timePeriodValues14.getDescription();
        timePeriodValues14.setDescription("Time");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean19 = timePeriodValues14.equals((java.lang.Object) day18);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day18, (double) 10L);
        boolean boolean23 = timePeriodValue21.equals((java.lang.Object) 0.0f);
        timePeriodValues3.add(timePeriodValue21);
        boolean boolean25 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener26);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener28);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setRangeDescription("hi!");
        int int7 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1]");
        java.lang.Object obj12 = timePeriodValues3.clone();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.next();
        java.lang.Object obj25 = null;
        int int26 = year17.compareTo(obj25);
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year17.getFirstMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Date date11 = day7.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = day7.getSerialDate();
        int int14 = day7.compareTo((java.lang.Object) 0L);
        java.util.Date date15 = day7.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str20 = timePeriodValues19.getDescription();
        timePeriodValues19.setRangeDescription("");
        java.lang.Class<?> wildcardClass23 = timePeriodValues19.getClass();
        java.lang.Comparable comparable24 = timePeriodValues19.getKey();
        boolean boolean25 = timePeriodValues19.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str30 = timePeriodValues29.getDescription();
        timePeriodValues29.setDescription("Time");
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        boolean boolean34 = timePeriodValues29.equals((java.lang.Object) day33);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day33, (double) 10L);
        java.util.Date date37 = day33.getEnd();
        boolean boolean38 = timePeriodValues19.equals((java.lang.Object) date37);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date37);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date15, date37);
        java.util.Date date41 = simpleTimePeriod40.getStart();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (-1.0d) + "'", comparable24.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) 100L);
        long long20 = year17.getLastMillisecond();
        java.util.Date date21 = year17.getStart();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str21 = timePeriodValues20.getDescription();
        timePeriodValues20.setDescription("Time");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        boolean boolean25 = timePeriodValues20.equals((java.lang.Object) day24);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean28 = day24.equals((java.lang.Object) (short) 1);
        int int29 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day24.getSerialDate();
        java.util.Date date31 = day24.getStart();
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date14, timeZone32);
        boolean boolean36 = year34.equals((java.lang.Object) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year34.previous();
        int int38 = year34.getYear();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues3.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (-1.0d) + "'", comparable7.equals((-1.0d)));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 'a');
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 12);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str9 = timePeriodValues8.getDescription();
        timePeriodValues8.setDescription("Time");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        boolean boolean13 = timePeriodValues8.equals((java.lang.Object) day12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean16 = day12.equals((java.lang.Object) (short) 1);
        int int17 = day12.getMonth();
        org.jfree.data.time.SerialDate serialDate18 = day12.getSerialDate();
        java.util.Date date19 = day12.getStart();
        java.util.Date date20 = day12.getEnd();
        int int21 = simpleTimePeriod2.compareTo((java.lang.Object) day12);
        java.util.Date date22 = simpleTimePeriod2.getEnd();
        long long23 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 12L + "'", long4 == 12L);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 12L + "'", long23 == 12L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,100.0]");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: TimePeriodValue[2019,100.0]"));
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0);
//        long long2 = day0.getSerialIndex();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43629L + "'", long2 == 43629L);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        int int5 = timePeriodValues3.getMaxEndIndex();
        int int6 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues3.createCopy(100, (int) (byte) 10);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
//        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
//        int int12 = day7.getMonth();
//        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
//        long long14 = day7.getFirstMillisecond();
//        long long15 = day7.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate16 = day7.getSerialDate();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        java.util.Date date11 = day7.getEnd();
        org.jfree.data.time.SerialDate serialDate12 = day7.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day7.next();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean6 = timePeriodValues3.equals((java.lang.Object) (short) 1);
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy((int) (short) -1, 4);
        timePeriodValues10.setKey((java.lang.Comparable) 3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues10.removeChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 0.0f);
        timePeriodValue10.setValue((java.lang.Number) 0.0f);
        java.lang.Number number15 = timePeriodValue10.getValue();
        java.lang.Number number16 = timePeriodValue10.getValue();
        java.lang.Number number17 = timePeriodValue10.getValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0f + "'", number15.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0f + "'", number16.equals(0.0f));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0f + "'", number17.equals(0.0f));
    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test496");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        timePeriodValues3.setDescription("Time");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
//        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (java.lang.Number) 4);
//        int int11 = day7.getYear();
//        int int12 = day7.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day7.next();
//        int int14 = day7.getMonth();
//        java.lang.String str15 = day7.toString();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, 10L);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException4.getSuppressed();
        try {
            int int7 = simpleTimePeriod2.compareTo((java.lang.Object) throwableArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Ljava.lang.Throwable; cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day7, (double) 10L);
        boolean boolean12 = timePeriodValue10.equals((java.lang.Object) 0.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str17 = timePeriodValues16.getDescription();
        timePeriodValues16.setDescription("Time");
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        boolean boolean21 = timePeriodValues16.equals((java.lang.Object) day20);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean24 = day20.equals((java.lang.Object) (short) 1);
        int int25 = day20.getMonth();
        org.jfree.data.time.SerialDate serialDate26 = day20.getSerialDate();
        java.util.Date date27 = day20.getStart();
        org.jfree.data.time.SerialDate serialDate28 = day20.getSerialDate();
        boolean boolean29 = timePeriodValue10.equals((java.lang.Object) day20);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        java.lang.String str32 = timePeriodValues31.getDomainDescription();
        int int33 = timePeriodValues31.getMinStartIndex();
        timePeriodValues31.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues31.addPropertyChangeListener(propertyChangeListener36);
        boolean boolean38 = day20.equals((java.lang.Object) timePeriodValues31);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = day20.getMiddleMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str29 = timePeriodValues28.getDescription();
        int int30 = timePeriodValues28.getMaxEndIndex();
        int int31 = timePeriodValues28.getMaxEndIndex();
        int int32 = year17.compareTo((java.lang.Object) int31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year17.previous();
        long long34 = regularTimePeriod33.getMiddleMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1530561599999L + "'", long34 == 1530561599999L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1.0d), "hi!", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("Time");
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) day7);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) 1);
        boolean boolean11 = day7.equals((java.lang.Object) (short) 1);
        int int12 = day7.getMonth();
        org.jfree.data.time.SerialDate serialDate13 = day7.getSerialDate();
        java.util.Date date14 = day7.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '#');
        boolean boolean21 = timePeriodValues19.equals((java.lang.Object) 7);
        boolean boolean22 = timePeriodValues19.isEmpty();
        int int23 = year17.compareTo((java.lang.Object) boolean22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year17.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod24, "TimePeriodValue[13-June-2019,1.0]", "");
        java.lang.String str28 = timePeriodValues27.getDescription();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(str28);
    }
}

