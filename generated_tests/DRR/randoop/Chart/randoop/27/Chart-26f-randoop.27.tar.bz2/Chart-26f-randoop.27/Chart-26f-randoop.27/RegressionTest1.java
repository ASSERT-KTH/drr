import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedAreaRenderer7.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator9, false);
        double double12 = stackedAreaRenderer7.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        stackedAreaRenderer13.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator15, false);
        java.awt.Paint paint20 = stackedAreaRenderer13.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer7.setBaseFillPaint(paint20);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint23, stroke24, paint25, stroke26, (float) 1L);
        java.awt.Color color29 = java.awt.Color.white;
        java.awt.Stroke stroke30 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint20, stroke24, (java.awt.Paint) color29, stroke30, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset33 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer37 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset33, categoryAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot38.getDomainAxis();
        java.awt.Paint paint40 = categoryPlot38.getDomainGridlinePaint();
        categoryMarker32.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot38);
        boolean boolean42 = stackedAreaRenderer4.hasListener((java.util.EventListener) categoryPlot38);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12 == 2.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(categoryAxis39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity20 = new org.jfree.chart.entity.TickLabelEntity(shape17, "May", "May");
        boolean boolean21 = org.jfree.chart.util.ShapeUtilities.equal(shape15, shape17);
        dateAxis12.setRightArrow(shape17);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer23 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        stackedAreaRenderer23.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator25, false);
        double double28 = stackedAreaRenderer23.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer29 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator31 = null;
        stackedAreaRenderer29.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator31, false);
        java.awt.Paint paint36 = stackedAreaRenderer29.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer23.setBaseFillPaint(paint36);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D38 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D38.setMaximumBarWidth((double) '#');
        java.awt.Font font42 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D38.setSeriesItemLabelFont((int) (byte) 100, font42);
        java.awt.Stroke stroke45 = stackedBarRenderer3D38.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem47 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape17, paint36, stroke45, (java.awt.Paint) color46);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint50, stroke51, paint52, stroke53, (float) 1L);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone58 = dateAxis57.getTimeZone();
        java.lang.Object obj59 = dateAxis57.clone();
        java.awt.Font font60 = dateAxis57.getTickLabelFont();
        java.lang.String str61 = dateAxis57.getLabelToolTip();
        java.awt.Stroke stroke62 = dateAxis57.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker64 = new org.jfree.chart.plot.ValueMarker((-1.0d), paint36, stroke48, paint52, stroke62, 0.0f);
        polarPlot3.setRadiusGridlineStroke(stroke48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo68 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset69 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        org.jfree.chart.axis.DateAxis dateAxis72 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer73 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot74 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset69, categoryAxis70, (org.jfree.chart.axis.ValueAxis) dateAxis72, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer73);
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = categoryPlot74.getDomainAxis();
        java.awt.Paint paint76 = categoryPlot74.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer77 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator79 = null;
        stackedAreaRenderer77.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator79, false);
        double double82 = stackedAreaRenderer77.getItemLabelAnchorOffset();
        java.awt.Paint paint85 = stackedAreaRenderer77.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot74.setRangeGridlinePaint(paint85);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        java.awt.geom.Rectangle2D rectangle2D89 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor90 = null;
        java.awt.geom.Point2D point2D91 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D89, rectangleAnchor90);
        categoryPlot74.zoomRangeAxes(3.0d, plotRenderingInfo88, point2D91);
        try {
            polarPlot3.zoomRangeAxes((double) 6, (double) (byte) 0, plotRenderingInfo68, point2D91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertNotNull(font60);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNull(categoryAxis75);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 2.0d + "'", double82 == 2.0d);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(point2D91);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType1 = numberAxis3D0.getRangeType();
        java.awt.Font font6 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 2019, (double) 1L, (double) 12, (double) 900000L, font6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            org.jfree.chart.axis.AxisState axisState14 = numberAxis3D0.draw(graphics2D8, (double) 100.0f, rectangle2D10, rectangle2D11, rectangleEdge12, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) -1, (float) (byte) -1, (float) 1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator1 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat2 = standardCategoryToolTipGenerator1.getNumberFormat();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator3 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("ItemLabelAnchor.OUTSIDE8", numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Paint paint17 = xYPlot7.getRangeTickBandPaint();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone21 = dateAxis20.getTimeZone();
        xYPlot7.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) dateAxis20);
        xYPlot7.clearRangeMarkers();
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot7.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 0);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        stackedAreaRenderer6.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator8, false);
        java.awt.Paint paint13 = stackedAreaRenderer6.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer0.setBaseFillPaint(paint13);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedAreaRenderer16.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator18, false);
        java.awt.Paint paint23 = stackedAreaRenderer16.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = stackedAreaRenderer16.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition25);
        java.awt.Stroke stroke27 = stackedAreaRenderer0.getBaseStroke();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        int int3 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj4 = defaultCategoryDataset1.clone();
        boolean boolean5 = blockBorder0.equals((java.lang.Object) defaultCategoryDataset1);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.util.Date date11 = dateAxis9.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.util.Date date15 = dateAxis13.getMinimumDate();
        org.jfree.data.gantt.Task task16 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date11, date15);
        org.jfree.data.time.TimePeriod timePeriod17 = task16.getDuration();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) "Category Plot", (java.lang.Comparable) timePeriod17);
        defaultCategoryDataset1.setValue((java.lang.Number) (-1), (java.lang.Comparable) (short) 10, (java.lang.Comparable) 10);
        defaultCategoryDataset1.addValue((double) (-2208960000000L), (java.lang.Comparable) 1L, (java.lang.Comparable) "Category Plot");
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriod17);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setMaximumBarWidth((double) '#');
        java.awt.Shape shape6 = stackedBarRenderer3D3.getBaseShape();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot13.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis16);
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint22, stroke23, paint24, stroke25, (float) 1L);
        java.awt.Paint paint28 = categoryMarker27.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D7, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.plot.Marker) categoryMarker27, rectangle2D29);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = null;
        stackedAreaRenderer31.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator33, false);
        java.awt.Paint paint38 = stackedAreaRenderer31.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker27.setOutlinePaint(paint38);
        stackedBarRenderer3D0.setBasePaint(paint38);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer41 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator43 = null;
        stackedAreaRenderer41.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator43, false);
        java.awt.Paint paint48 = stackedAreaRenderer41.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean49 = stackedAreaRenderer41.getAutoPopulateSeriesOutlineStroke();
        stackedAreaRenderer41.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = stackedAreaRenderer41.getBaseNegativeItemLabelPosition();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer53 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator55 = null;
        stackedAreaRenderer53.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator55, false);
        double double58 = stackedAreaRenderer53.getItemLabelAnchorOffset();
        java.awt.Paint paint61 = stackedAreaRenderer53.getItemOutlinePaint(0, (int) (short) 100);
        boolean boolean62 = itemLabelPosition52.equals((java.lang.Object) stackedAreaRenderer53);
        stackedBarRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition52);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor64 = itemLabelPosition52.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition52);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.0d + "'", double58 == 2.0d);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor64);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        java.util.Date date6 = dateAxis4.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.util.Date date10 = dateAxis8.getMinimumDate();
        org.jfree.data.gantt.Task task11 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date6, date10);
        boolean boolean12 = gradientPaintTransformType1.equals((java.lang.Object) date6);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        java.util.Date date17 = dateAxis14.getMinimumDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date6, date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Date date20 = dateTickUnit0.addToDate(date17, timeZone19);
        java.lang.Object obj21 = null;
        boolean boolean22 = dateTickUnit0.equals(obj21);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        categoryPlot10.mapDatasetToDomainAxis((int) (byte) 0, (int) '4');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Shape shape34 = stackedBarRenderer3D31.getBaseShape();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer40 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer40);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot41.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        dateAxis44.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis44);
        java.awt.Paint paint50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint50, stroke51, paint52, stroke53, (float) 1L);
        java.awt.Paint paint56 = categoryMarker55.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        stackedBarRenderer3D31.drawRangeMarker(graphics2D35, categoryPlot41, (org.jfree.chart.axis.ValueAxis) dateAxis44, (org.jfree.chart.plot.Marker) categoryMarker55, rectangle2D57);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator61 = null;
        stackedAreaRenderer59.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator61, false);
        java.awt.Paint paint66 = stackedAreaRenderer59.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker55.setOutlinePaint(paint66);
        categoryPlot10.addDomainMarker(categoryMarker55);
        java.awt.Color color69 = java.awt.Color.MAGENTA;
        categoryMarker55.setOutlinePaint((java.awt.Paint) color69);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(color69);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int8 = stackedAreaRenderer0.getPassCount();
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(true, false);
        java.awt.Paint paint13 = stackedAreaRenderer0.getSeriesFillPaint(0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = stackedAreaRenderer0.getToolTipGenerator(100, 13);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        legendTitle1.setHeight((double) ' ');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot15.getDomainAxis();
        java.awt.Paint paint17 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        stackedAreaRenderer18.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator20, false);
        double double23 = stackedAreaRenderer18.getItemLabelAnchorOffset();
        java.awt.Paint paint26 = stackedAreaRenderer18.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot15.setRangeGridlinePaint(paint26);
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint29, stroke30, paint31, stroke32, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryMarker34.getLabelOffset();
        double double37 = rectangleInsets35.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset38 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset38, categoryAxis39, (org.jfree.chart.axis.ValueAxis) dateAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = categoryPlot43.getDomainAxis();
        java.awt.Paint paint45 = categoryPlot43.getDomainGridlinePaint();
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot43.setRangeGridlineStroke(stroke46);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor48 = categoryPlot43.getDomainGridlinePosition();
        boolean boolean49 = rectangleInsets35.equals((java.lang.Object) categoryPlot43);
        categoryPlot15.setAxisOffset(rectangleInsets35);
        legendTitle1.setPadding(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 3.0d + "'", double37 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(categoryAnchor48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        dateAxis13.setVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        double double24 = dateAxis20.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setMaximumBarWidth((double) '#');
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis38);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        java.awt.Paint paint50 = categoryMarker49.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedBarRenderer3D25.drawRangeMarker(graphics2D29, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.plot.Marker) categoryMarker49, rectangle2D51);
        java.awt.Shape shape53 = dateAxis38.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity56 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis20, shape53, "RectangleAnchor.CENTER", "Following");
        dateAxis13.setLeftArrow(shape53);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset60 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number61 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset60);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity64 = new org.jfree.chart.entity.CategoryItemEntity(shape53, "Range[0.0,1.0]", "RectangleAnchor.CENTER", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset60, (java.lang.Comparable) true, (java.lang.Comparable) (-1.0f));
        java.lang.String str65 = categoryItemEntity64.getShapeType();
        categoryItemEntity64.setURLText("TextBlockAnchor.BOTTOM_LEFT");
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNull(number61);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "poly" + "'", str65.equals("poly"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("RectangleAnchor.CENTER");
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.addValue((java.lang.Comparable) 1562097599999L, (java.lang.Number) 10.0f);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D4 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D4.setMaximumBarWidth((double) '#');
        java.awt.Shape shape7 = stackedBarRenderer3D4.getBaseShape();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, categoryAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot14.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        dateAxis17.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis17);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint23, stroke24, paint25, stroke26, (float) 1L);
        java.awt.Paint paint29 = categoryMarker28.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        stackedBarRenderer3D4.drawRangeMarker(graphics2D8, categoryPlot14, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.plot.Marker) categoryMarker28, rectangle2D30);
        categoryPlot14.mapDatasetToDomainAxis((int) (byte) 0, (int) '4');
        boolean boolean35 = defaultKeyedValues0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) 0.0f);
        org.jfree.data.Range range6 = rectangleConstraint5.getHeightRange();
        try {
            org.jfree.chart.util.Size2D size2D7 = flowArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis3D0.setLabelFont(font1);
        float float3 = numberAxis3D0.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        int int20 = xYPlot7.getRangeAxisIndex(valueAxis13);
        xYPlot7.clearAnnotations();
        xYPlot7.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke25 = stackedBarRenderer3D23.lookupSeriesStroke(11);
        xYPlot7.setRangeCrosshairStroke(stroke25);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer31);
        categoryPlot32.setRangeGridlinesVisible(false);
        java.awt.Paint paint35 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryPlot32.setDomainGridlinePaint(paint35);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot32.setDatasetRenderingOrder(datasetRenderingOrder37);
        xYPlot7.setDatasetRenderingOrder(datasetRenderingOrder37);
        boolean boolean40 = xYPlot7.isOutlineVisible();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-435) + "'", int1 == (-435));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor3);
        java.lang.String str5 = rectangleAnchor3.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str5.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        int int18 = xYPlot15.getWeight();
        java.awt.Stroke stroke19 = xYPlot15.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        dateAxis22.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis22);
        xYPlot15.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone30 = dateAxis29.getTimeZone();
        java.lang.Object obj31 = dateAxis29.clone();
        java.awt.Font font32 = dateAxis29.getTickLabelFont();
        java.lang.String str33 = dateAxis29.getLabelToolTip();
        java.awt.Stroke stroke34 = dateAxis29.getTickMarkStroke();
        dateAxis29.setTickMarkInsideLength((float) 6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer37);
        org.jfree.data.Range range39 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis29);
        float float40 = polarPlot3.getForegroundAlpha();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 1.0f + "'", float40 == 1.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        double double17 = dateAxis13.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D18.setMaximumBarWidth((double) '#');
        java.awt.Shape shape21 = stackedBarRenderer3D18.getBaseShape();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer27 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23, categoryAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer27);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot28.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        dateAxis31.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis31);
        java.awt.Paint paint37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint37, stroke38, paint39, stroke40, (float) 1L);
        java.awt.Paint paint43 = categoryMarker42.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        stackedBarRenderer3D18.drawRangeMarker(graphics2D22, categoryPlot28, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.plot.Marker) categoryMarker42, rectangle2D44);
        java.awt.Shape shape46 = dateAxis31.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity49 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis13, shape46, "RectangleAnchor.CENTER", "Following");
        java.awt.Paint paint50 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone55 = dateAxis54.getTimeZone();
        boolean boolean56 = dateAxis54.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset51, valueAxis52, (org.jfree.chart.axis.ValueAxis) dateAxis54, xYItemRenderer57);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent59 = null;
        xYPlot58.markerChanged(markerChangeEvent59);
        int int61 = xYPlot58.getWeight();
        java.awt.Stroke stroke62 = xYPlot58.getRangeCrosshairStroke();
        int int63 = xYPlot58.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("");
        dateAxis65.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent69 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis65);
        int int70 = xYPlot58.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis65);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        java.awt.geom.Point2D point2D74 = null;
        xYPlot58.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo73, point2D74);
        org.jfree.chart.axis.AxisSpace axisSpace76 = xYPlot58.getFixedRangeAxisSpace();
        java.awt.Stroke stroke77 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot58.setRangeGridlineStroke(stroke77);
        java.awt.Paint paint79 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem80 = new org.jfree.chart.LegendItem("", "Category Plot", "", "hi!", shape46, paint50, stroke77, paint79);
        java.awt.Color color81 = java.awt.Color.magenta;
        org.jfree.chart.LegendItem legendItem82 = new org.jfree.chart.LegendItem("hi!", "HorizontalAlignment.RIGHT", "TextAnchor.CENTER", "RectangleAnchor.CENTER", shape46, (java.awt.Paint) color81);
        java.awt.Paint paint83 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.LegendItem legendItem84 = new org.jfree.chart.LegendItem("Following", "Category Plot", "hi!", "0,-1,1,1,-1,1,-1,1", shape46, paint83);
        java.awt.Paint paint85 = legendItem84.getLinePaint();
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertNull(axisSpace76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(paint85);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D0.setSeriesItemLabelFont((int) (byte) 100, font4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        int int16 = xYPlot13.getWeight();
        java.awt.Stroke stroke17 = xYPlot13.getRangeCrosshairStroke();
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot13);
        java.awt.Stroke stroke19 = null;
        try {
            xYPlot13.setRangeZeroBaselineStroke(stroke19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 1, (double) (byte) 100);
        java.awt.Font font3 = intervalMarker2.getLabelFont();
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) '4');
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getSeriesCount();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.util.Date date7 = dateAxis5.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.util.Date date11 = dateAxis9.getMinimumDate();
        org.jfree.data.gantt.Task task12 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date7, date11);
        boolean boolean13 = gradientPaintTransformType2.equals((java.lang.Object) date7);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        java.util.Date date18 = dateAxis15.getMinimumDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date7, date18);
        int int20 = taskSeriesCollection0.getRowIndex((java.lang.Comparable) date18);
        java.util.List list21 = taskSeriesCollection0.getRowKeys();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline4 = dateAxis1.getTimeline();
        dateAxis1.zoomRange((double) (-451), (double) 11);
        dateAxis1.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeline4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = null;
        java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) 'a');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.lang.Object obj4 = dateAxis2.clone();
        java.awt.Font font5 = dateAxis2.getTickLabelFont();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        int int16 = xYPlot13.getWeight();
        java.awt.Stroke stroke17 = xYPlot13.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        xYPlot13.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        xYPlot13.setDomainAxisLocation((int) (short) 1, axisLocation27);
        java.awt.Paint paint29 = xYPlot13.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle35.getLegendItemGraphicAnchor();
        legendTitle33.setLegendItemGraphicLocation(rectangleAnchor36);
        org.jfree.chart.block.BlockBorder blockBorder38 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray40 = legendTitle33.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = legendTitle33.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment31, verticalAlignment41, (double) 0.0f, (double) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = legendTitle48.getLegendItemGraphicAnchor();
        legendTitle46.setLegendItemGraphicLocation(rectangleAnchor49);
        org.jfree.chart.block.BlockBorder blockBorder51 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle46.setFrame((org.jfree.chart.block.BlockFrame) blockBorder51);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray53 = legendTitle46.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = legendTitle46.getVerticalAlignment();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset55 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset55, categoryAxis56, (org.jfree.chart.axis.ValueAxis) dateAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer59);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = categoryPlot60.getDomainAxis();
        java.awt.Paint paint62 = categoryPlot60.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer63 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator65 = null;
        stackedAreaRenderer63.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator65, false);
        double double68 = stackedAreaRenderer63.getItemLabelAnchorOffset();
        java.awt.Paint paint71 = stackedAreaRenderer63.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot60.setRangeGridlinePaint(paint71);
        java.awt.Paint paint74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke75 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint74, stroke75, paint76, stroke77, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = categoryMarker79.getLabelOffset();
        double double82 = rectangleInsets80.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset83 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis84 = null;
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer87 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot88 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset83, categoryAxis84, (org.jfree.chart.axis.ValueAxis) dateAxis86, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer87);
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = categoryPlot88.getDomainAxis();
        java.awt.Paint paint90 = categoryPlot88.getDomainGridlinePaint();
        java.awt.Stroke stroke91 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot88.setRangeGridlineStroke(stroke91);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor93 = categoryPlot88.getDomainGridlinePosition();
        boolean boolean94 = rectangleInsets80.equals((java.lang.Object) categoryPlot88);
        categoryPlot60.setAxisOffset(rectangleInsets80);
        org.jfree.chart.title.TextTitle textTitle96 = new org.jfree.chart.title.TextTitle("RectangleEdge.RIGHT", font5, paint29, rectangleEdge30, horizontalAlignment31, verticalAlignment54, rectangleInsets80);
        java.lang.String str97 = textTitle96.getText();
        java.awt.Paint paint98 = textTitle96.getPaint();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(blockBorder38);
        org.junit.Assert.assertNotNull(legendItemSourceArray40);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(blockBorder51);
        org.junit.Assert.assertNotNull(legendItemSourceArray53);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertNull(categoryAxis61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 2.0d + "'", double68 == 2.0d);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 3.0d + "'", double82 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis89);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(categoryAnchor93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "RectangleEdge.RIGHT" + "'", str97.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(paint98);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        legendTitle1.setID("Category Plot");
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        xYPlot7.setDomainCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot7.setDomainAxisLocation(axisLocation22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot7.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator2);
        boolean boolean4 = ganttRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = ganttRenderer0.getPositiveItemLabelPosition(2, 5);
        java.awt.Paint paint9 = ganttRenderer0.getSeriesPaint((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone4);
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone4;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("Third", timeZone4);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        categoryPlot5.setBackgroundImageAlignment((int) (byte) 100);
        categoryPlot5.setForegroundAlpha(0.5f);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range5 = dateAxis1.getDefaultAutoRange();
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone13);
        int int16 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        xYPlot7.setWeight(0);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        boolean boolean7 = dateAxis5.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        org.jfree.chart.axis.AxisSpace axisSpace12 = null;
        xYPlot9.setFixedRangeAxisSpace(axisSpace12);
        boolean boolean14 = chartRenderingInfo0.equals((java.lang.Object) xYPlot9);
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        boolean boolean8 = categoryPlot5.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot5.getDataset((int) (byte) 1);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(categoryDataset10);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        double double2 = ganttRenderer0.getMaximumBarWidth();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = ganttRenderer0.getGradientPaintTransformer();
        ganttRenderer0.setItemMargin(0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = null;
        try {
            ganttRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultBoxAndWhiskerCategoryDataset0.getGroup();
        try {
            java.lang.Number number4 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((int) (byte) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) '4', (float) '#', (double) (-1L), (float) (-1L), (float) '4');
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        int int11 = xYPlot8.getWeight();
        java.awt.Stroke stroke12 = xYPlot8.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        dateAxis15.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis15);
        xYPlot8.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone23 = dateAxis22.getTimeZone();
        java.lang.Object obj24 = dateAxis22.clone();
        java.awt.Font font25 = dateAxis22.getTickLabelFont();
        java.lang.String str26 = dateAxis22.getLabelToolTip();
        java.awt.Stroke stroke27 = dateAxis22.getTickMarkStroke();
        dateAxis22.setTickMarkInsideLength((float) 6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer30);
        dateAxis22.setVisible(true);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setLabelGap((double) 1577865599999L);
        boolean boolean3 = ringPlot0.getIgnoreZeroValues();
        ringPlot0.setSeparatorsVisible(true);
        double double6 = ringPlot0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        boolean boolean8 = dateAxis6.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, xYItemRenderer9);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        xYPlot10.markerChanged(markerChangeEvent11);
        int int13 = xYPlot10.getWeight();
        java.awt.Stroke stroke14 = xYPlot10.getRangeCrosshairStroke();
        int int15 = xYPlot10.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        dateAxis17.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis17);
        int int22 = xYPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis17);
        xYPlot10.setDomainCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot10.setDomainAxisLocation(axisLocation25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator30 = null;
        stackedAreaRenderer28.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator30, false);
        java.awt.Paint paint35 = stackedAreaRenderer28.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean36 = plotOrientation27.equals((java.lang.Object) 'a');
        java.lang.String str37 = plotOrientation27.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation25, plotOrientation27);
        axisState0.moveCursor((double) 31, rectangleEdge38);
        axisState0.setCursor((double) 3600000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str37.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.setAngleLabelsVisible(false);
        java.awt.Paint paint8 = polarPlot3.getRadiusGridlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(paint8);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.resizeRange(0.05d, 0.0d);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("May", font8);
        dateAxis3.setLabelFont(font8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer17);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        int int21 = xYPlot18.getWeight();
        java.awt.Stroke stroke22 = xYPlot18.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone27 = dateAxis26.getTimeZone();
        boolean boolean28 = dateAxis26.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer29);
        int int31 = xYPlot18.getRangeAxisIndex(valueAxis24);
        xYPlot18.clearAnnotations();
        xYPlot18.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke36 = stackedBarRenderer3D34.lookupSeriesStroke(11);
        xYPlot18.setRangeCrosshairStroke(stroke36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot18.getDomainAxisEdge((int) 'a');
        java.awt.Paint paint40 = xYPlot18.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("Third", font8, paint40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone46 = dateAxis45.getTimeZone();
        boolean boolean47 = dateAxis45.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer48);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        int int52 = xYPlot49.getWeight();
        java.awt.Stroke stroke53 = xYPlot49.getRangeCrosshairStroke();
        int int54 = xYPlot49.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("");
        dateAxis56.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent60 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis56);
        int int61 = xYPlot49.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Point2D point2D65 = null;
        xYPlot49.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo64, point2D65);
        boolean boolean67 = xYPlot49.isDomainGridlinesVisible();
        xYPlot49.clearRangeMarkers();
        org.jfree.chart.JFreeChart jFreeChart70 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", font8, (org.jfree.chart.plot.Plot) xYPlot49, false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener71 = null;
        try {
            jFreeChart70.removeChangeListener(chartChangeListener71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("Following", "", "RectangleAnchor.CENTER", image3, "May", "0,-1,1,1,-1,1,-1,1", "0,-1,1,1,-1,1,-1,1");
        java.awt.Image image8 = projectInfo7.getLogo();
        java.lang.String str9 = projectInfo7.getInfo();
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleAnchor.CENTER" + "'", str9.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        int int1 = groupedStackedBarRenderer0.getPassCount();
        double double2 = groupedStackedBarRenderer0.getBase();
        java.awt.Paint paint3 = groupedStackedBarRenderer0.getBasePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.setAngleLabelsVisible(false);
        polarPlot3.setAngleLabelsVisible(true);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = polarPlot3.getOrientation();
        java.lang.String str11 = plotOrientation10.toString();
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str11.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot7.zoomDomainAxes((double) 10, plotRenderingInfo11, point2D12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot7.getRangeAxisEdge((int) '#');
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone20 = dateAxis19.getTimeZone();
        boolean boolean21 = dateAxis19.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer22);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = null;
        xYPlot23.markerChanged(markerChangeEvent24);
        int int26 = xYPlot23.getWeight();
        java.awt.Stroke stroke27 = xYPlot23.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone32 = dateAxis31.getTimeZone();
        boolean boolean33 = dateAxis31.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer34);
        int int36 = xYPlot23.getRangeAxisIndex(valueAxis29);
        xYPlot23.clearAnnotations();
        xYPlot23.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke41 = stackedBarRenderer3D39.lookupSeriesStroke(11);
        xYPlot23.setRangeCrosshairStroke(stroke41);
        xYPlot7.setDomainCrosshairStroke(stroke41);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        stackedAreaRenderer1.setBaseItemLabelsVisible(false, true);
        java.awt.Paint paint11 = stackedAreaRenderer1.getItemPaint((int) (byte) 10, 0);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        xYPlot19.markerChanged(markerChangeEvent20);
        int int22 = xYPlot19.getWeight();
        java.awt.Stroke stroke23 = xYPlot19.getRangeCrosshairStroke();
        int int24 = xYPlot19.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        dateAxis26.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis26);
        int int31 = xYPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        xYPlot19.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo34, point2D35);
        boolean boolean37 = xYPlot19.isDomainGridlinesVisible();
        java.awt.Stroke stroke38 = xYPlot19.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) 10, paint11, stroke38);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (byte) 0, (double) 1, 3, (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setSectionDepth(0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range1);
        double double3 = range1.getLowerBound();
        boolean boolean6 = range1.intersects((double) '#', 2.0d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke7 = null;
        stackedAreaRenderer0.setSeriesStroke((int) (byte) 1, stroke7);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer9.setSeriesCreateEntities((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        stackedAreaRenderer9.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator15, true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        stackedAreaRenderer9.setBaseItemLabelPaint((java.awt.Paint) color18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = stackedAreaRenderer9.getSeriesURLGenerator(0);
        boolean boolean22 = stackedAreaRenderer0.equals((java.lang.Object) categoryURLGenerator21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedAreaRenderer0.getLegendItems();
        boolean boolean24 = stackedAreaRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge2);
        axisSpace0.add((double) 9999, rectangleEdge2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        int int18 = xYPlot15.getWeight();
        java.awt.Stroke stroke19 = xYPlot15.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone24 = dateAxis23.getTimeZone();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer26);
        int int28 = xYPlot15.getRangeAxisIndex(valueAxis21);
        xYPlot15.clearAnnotations();
        xYPlot15.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke33 = stackedBarRenderer3D31.lookupSeriesStroke(11);
        xYPlot15.setRangeCrosshairStroke(stroke33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot15.getDomainAxisEdge((int) 'a');
        boolean boolean37 = rectangleEdge6.equals((java.lang.Object) 'a');
        axisSpace0.ensureAtLeast(0.0d, rectangleEdge6);
        java.lang.String str39 = axisSpace0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 31, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int8 = stackedAreaRenderer0.getPassCount();
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(true, false);
        stackedAreaRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        java.awt.Paint paint23 = categoryPlot21.getDomainGridlinePaint();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot21.setRangeGridlineStroke(stroke24);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        categoryPlot21.markerChanged(markerChangeEvent26);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent28);
        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) categoryPlot21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        stackedBarRenderer3D32.setNegativeItemLabelPositionFallback(itemLabelPosition33);
        stackedBarRenderer3D32.setIncludeBaseInRange(true);
        categoryPlot21.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D32);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("HorizontalAlignment.RIGHT");
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 1, (double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        stackedAreaRenderer0.drawRangeMarker(graphics2D15, categoryPlot21, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.plot.Marker) intervalMarker42, rectangle2D43);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer46 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator48 = null;
        stackedAreaRenderer46.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator48, false);
        double double51 = stackedAreaRenderer46.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer52 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator54 = null;
        stackedAreaRenderer52.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator54, false);
        java.awt.Paint paint59 = stackedAreaRenderer52.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer46.setBaseFillPaint(paint59);
        java.awt.Paint paint62 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke63 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint64 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke65 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker67 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint62, stroke63, paint64, stroke65, (float) 1L);
        java.awt.Color color68 = java.awt.Color.white;
        java.awt.Stroke stroke69 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker71 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint59, stroke63, (java.awt.Paint) color68, stroke69, 1.0f);
        intervalMarker42.setLabelPaint(paint59);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 2.0d + "'", double51 == 2.0d);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color68);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.gantt.Task task7 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date5, date6);
        java.lang.Comparable[] comparableArray8 = new java.lang.Comparable[] { (short) -1, 900000L, (byte) 10, 1.562097600005E12d, "0,-1,1,1,-1,1,-1,1" };
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        java.util.Date date14 = dateAxis12.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone17 = dateAxis16.getTimeZone();
        java.util.Date date18 = dateAxis16.getMinimumDate();
        org.jfree.data.gantt.Task task19 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date14, date18);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection21 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int22 = taskSeriesCollection21.getSeriesCount();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType23 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone27 = dateAxis26.getTimeZone();
        java.util.Date date28 = dateAxis26.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone31 = dateAxis30.getTimeZone();
        java.util.Date date32 = dateAxis30.getMinimumDate();
        org.jfree.data.gantt.Task task33 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date28, date32);
        boolean boolean34 = gradientPaintTransformType23.equals((java.lang.Object) date28);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone37 = dateAxis36.getTimeZone();
        boolean boolean38 = dateAxis36.isVerticalTickLabels();
        java.util.Date date39 = dateAxis36.getMinimumDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date28, date39);
        int int41 = taskSeriesCollection21.getRowIndex((java.lang.Comparable) date39);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone46 = dateAxis45.getTimeZone();
        java.util.Date date47 = dateAxis45.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone50 = dateAxis49.getTimeZone();
        java.util.Date date51 = dateAxis49.getMinimumDate();
        org.jfree.data.gantt.Task task52 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date47, date51);
        org.jfree.data.time.TimePeriod timePeriod53 = task52.getDuration();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        task52.setDuration((org.jfree.data.time.TimePeriod) year54);
        java.lang.Comparable[] comparableArray56 = new java.lang.Comparable[] { 5, date14, 8, int41, "Category Plot", year54 };
        double[] doubleArray59 = new double[] { 31, 3 };
        double[] doubleArray62 = new double[] { 31, 3 };
        double[] doubleArray65 = new double[] { 31, 3 };
        double[] doubleArray68 = new double[] { 31, 3 };
        double[] doubleArray71 = new double[] { 31, 3 };
        double[][] doubleArray72 = new double[][] { doubleArray59, doubleArray62, doubleArray65, doubleArray68, doubleArray71 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset73 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray8, comparableArray56, doubleArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of column keys does not match the number of columns in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(comparableArray8);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType23);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timePeriod53);
        org.junit.Assert.assertNotNull(comparableArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryPlot5.setDomainGridlinePaint(paint8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        stackedAreaRenderer10.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator12, false);
        java.awt.Paint paint17 = stackedAreaRenderer10.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setMaximumBarWidth((double) '#');
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D19.setSeriesItemLabelFont((int) (byte) 100, font23);
        java.awt.Stroke stroke26 = stackedBarRenderer3D19.lookupSeriesOutlineStroke((int) ' ');
        stackedAreaRenderer10.setSeriesStroke(3, stroke26);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer10);
        try {
            stackedAreaRenderer10.setSeriesVisible((-435), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape1, "May", "May");
        java.lang.String str5 = tickLabelEntity4.getShapeCoords();
        tickLabelEntity4.setURLText("Pie Plot");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0,-1,1,1,-1,1,-1,1" + "'", str5.equals("0,-1,1,1,-1,1,-1,1"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setMaximumBarWidth((double) '#');
        java.awt.Shape shape4 = stackedBarRenderer3D1.getBaseShape();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range6 = stackedBarRenderer3D1.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 7.0d, (org.jfree.data.general.Dataset) defaultCategoryDataset5);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setMaximumBarWidth((double) '#');
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis38);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        java.awt.Paint paint50 = categoryMarker49.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedBarRenderer3D25.drawRangeMarker(graphics2D29, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.plot.Marker) categoryMarker49, rectangle2D51);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer53 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator55 = null;
        stackedAreaRenderer53.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator55, false);
        java.awt.Paint paint60 = stackedAreaRenderer53.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker49.setOutlinePaint(paint60);
        xYPlot7.setDomainGridlinePaint(paint60);
        xYPlot7.clearRangeMarkers(3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false, true);
        stackedAreaRenderer0.setBaseCreateEntities(true, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer15 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, categoryAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot16.getDomainAxis();
        java.awt.Paint paint18 = categoryPlot16.getDomainGridlinePaint();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot16.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        categoryPlot16.markerChanged(markerChangeEvent21);
        categoryPlot16.setAnchorValue((-1.0d), false);
        stackedAreaRenderer0.setPlot(categoryPlot16);
        int int27 = categoryPlot16.getWeight();
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType1 = numberAxis3D0.getRangeType();
        java.lang.Object obj2 = numberAxis3D0.clone();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setMaximumBarWidth((double) '#');
        java.awt.Shape shape6 = stackedBarRenderer3D3.getBaseShape();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot13.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis16);
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint22, stroke23, paint24, stroke25, (float) 1L);
        java.awt.Paint paint28 = categoryMarker27.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D7, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.plot.Marker) categoryMarker27, rectangle2D29);
        java.awt.Paint paint31 = stackedBarRenderer3D3.getBaseItemLabelPaint();
        numberAxis3D0.setAxisLinePaint(paint31);
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection22 = xYPlot7.getDomainMarkers((int) '4', layer21);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation23 = null;
        try {
            boolean boolean24 = xYPlot7.removeAnnotation(xYAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Date date8 = dateAxis6.getMinimumDate();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date4, date8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        java.util.Date date14 = dateAxis12.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone17 = dateAxis16.getTimeZone();
        java.util.Date date18 = dateAxis16.getMinimumDate();
        org.jfree.data.gantt.Task task19 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date14, date18);
        task9.addSubtask(task19);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer26 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer26);
        categoryPlot27.setRangeGridlinesVisible(false);
        boolean boolean30 = stackedBarRenderer3D21.hasListener((java.util.EventListener) categoryPlot27);
        categoryPlot27.clearRangeAxes();
        boolean boolean32 = task9.equals((java.lang.Object) categoryPlot27);
        categoryPlot27.clearRangeMarkers();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        dateAxis35.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent39 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis35);
        java.lang.Object obj40 = axisChangeEvent39.getSource();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        dateAxis42.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent46 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis42);
        org.jfree.chart.JFreeChart jFreeChart47 = null;
        axisChangeEvent46.setChart(jFreeChart47);
        org.jfree.chart.axis.Axis axis49 = axisChangeEvent46.getAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType50 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer52 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator54 = null;
        stackedAreaRenderer52.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator54, false);
        double double57 = stackedAreaRenderer52.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer58 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator60 = null;
        stackedAreaRenderer58.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator60, false);
        java.awt.Paint paint65 = stackedAreaRenderer58.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer52.setBaseFillPaint(paint65);
        java.awt.Paint paint68 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke69 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint70 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke71 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker73 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint68, stroke69, paint70, stroke71, (float) 1L);
        java.awt.Color color74 = java.awt.Color.white;
        java.awt.Stroke stroke75 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker77 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint65, stroke69, (java.awt.Paint) color74, stroke75, 1.0f);
        boolean boolean78 = chartChangeEventType50.equals((java.lang.Object) categoryMarker77);
        axisChangeEvent46.setType(chartChangeEventType50);
        axisChangeEvent39.setType(chartChangeEventType50);
        categoryPlot27.axisChanged(axisChangeEvent39);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(axis49);
        org.junit.Assert.assertNotNull(chartChangeEventType50);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot7.getDomainAxis();
        java.awt.Paint paint9 = categoryPlot7.getDomainGridlinePaint();
        boolean boolean10 = horizontalAlignment1.equals((java.lang.Object) paint9);
        boolean boolean11 = layer0.equals((java.lang.Object) paint9);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setMinimumArcAngleToDraw((double) 2019);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, (java.lang.Comparable) "Following");
        double double9 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset8);
        ringPlot0.setDataset(pieDataset8);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_GREEN;
        xYPlot7.setDomainGridlinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        boolean boolean25 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot7.getOrientation();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot7.rendererChanged(rendererChangeEvent27);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(plotOrientation26);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        int int1 = groupedStackedBarRenderer0.getPassCount();
        double double2 = groupedStackedBarRenderer0.getBase();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity16 = new org.jfree.chart.entity.TickLabelEntity(shape13, "May", "May");
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal(shape11, shape13);
        dateAxis8.setRightArrow(shape13);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        stackedAreaRenderer19.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator21, false);
        double double24 = stackedAreaRenderer19.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        stackedAreaRenderer25.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator27, false);
        java.awt.Paint paint32 = stackedAreaRenderer25.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer19.setBaseFillPaint(paint32);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setMaximumBarWidth((double) '#');
        java.awt.Font font38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D34.setSeriesItemLabelFont((int) (byte) 100, font38);
        java.awt.Stroke stroke41 = stackedBarRenderer3D34.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape13, paint32, stroke41, (java.awt.Paint) color42);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer44 = legendItem43.getFillPaintTransformer();
        groupedStackedBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer44);
        org.jfree.data.KeyToGroupMap keyToGroupMap46 = null;
        try {
            groupedStackedBarRenderer0.setSeriesToGroupMap(keyToGroupMap46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'map' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(gradientPaintTransformer44);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        double double4 = dateAxis2.getLabelAngle();
        dateAxis2.resizeRange((double) (short) -1);
        boolean boolean7 = categoryLabelWidthType0.equals((java.lang.Object) dateAxis2);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean9 = categoryLabelWidthType0.equals((java.lang.Object) textAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setLabelGap((double) 1577865599999L);
        java.lang.String str3 = ringPlot0.getPlotType();
        java.awt.Stroke stroke4 = ringPlot0.getLabelOutlineStroke();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        boolean boolean2 = ringPlot0.getSeparatorsVisible();
        ringPlot0.setLabelGap(7.0d);
        double double5 = ringPlot0.getInteriorGap();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.25d + "'", double5 == 0.25d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int8 = stackedAreaRenderer0.getPassCount();
        boolean boolean9 = stackedAreaRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.LegendItem legendItem12 = stackedAreaRenderer0.getLegendItem(15, 0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItem12);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        double double6 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedAreaRenderer7.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator9, false);
        java.awt.Paint paint14 = stackedAreaRenderer7.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer1.setBaseFillPaint(paint14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint17, stroke18, paint19, stroke20, (float) 1L);
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.Stroke stroke24 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint14, stroke18, (java.awt.Paint) color23, stroke24, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot32.getDomainAxis();
        java.awt.Paint paint34 = categoryPlot32.getDomainGridlinePaint();
        categoryMarker26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot32);
        java.util.List list36 = categoryPlot32.getAnnotations();
        java.awt.Font font37 = categoryPlot32.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(font37);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        java.util.List list2 = null;
        axisState0.setTicks(list2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesCreateEntities((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        stackedAreaRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = stackedAreaRenderer0.getSeriesURLGenerator(0);
        boolean boolean13 = stackedAreaRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        float float2 = dateAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = numberAxis3D0.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        boolean boolean4 = ringPlot0.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        ringPlot0.setCircular(false, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = xYPlot7.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        xYPlot7.setDataset(xYDataset26);
        java.awt.Stroke stroke28 = xYPlot7.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType1 = numberAxis3D0.getRangeType();
        java.awt.Font font6 = null;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 2019, (double) 1L, (double) 12, (double) 900000L, font6);
        java.awt.Graphics2D graphics2D8 = null;
        double double9 = markerAxisBand7.getHeight(graphics2D8);
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        java.lang.Object obj3 = lineAndShapeRenderer0.clone();
        boolean boolean4 = lineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.util.Date date7 = dateAxis5.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.util.Date date11 = dateAxis9.getMinimumDate();
        org.jfree.data.gantt.Task task12 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date7, date11);
        boolean boolean13 = gradientPaintTransformType2.equals((java.lang.Object) date7);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        java.util.Date date18 = dateAxis15.getMinimumDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod(date7, date18);
        ringPlot0.setExplodePercent((java.lang.Comparable) date18, 2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke4 = stackedBarRenderer3D2.lookupSeriesStroke(11);
        stackedBarRenderer3D2.setItemMargin((double) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = stackedBarRenderer3D2.getGradientPaintTransformer();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = stackedBarRenderer3D2.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer15);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        int int19 = xYPlot16.getWeight();
        java.awt.Stroke stroke20 = xYPlot16.getRangeCrosshairStroke();
        int int21 = xYPlot16.getSeriesCount();
        boolean boolean22 = legendItemCollection8.equals((java.lang.Object) int21);
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone29 = dateAxis28.getTimeZone();
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity36 = new org.jfree.chart.entity.TickLabelEntity(shape33, "May", "May");
        boolean boolean37 = org.jfree.chart.util.ShapeUtilities.equal(shape31, shape33);
        dateAxis28.setRightArrow(shape33);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer39 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        stackedAreaRenderer39.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator41, false);
        double double44 = stackedAreaRenderer39.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer45 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = null;
        stackedAreaRenderer45.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator47, false);
        java.awt.Paint paint52 = stackedAreaRenderer45.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer39.setBaseFillPaint(paint52);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D54 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D54.setMaximumBarWidth((double) '#');
        java.awt.Font font58 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D54.setSeriesItemLabelFont((int) (byte) 100, font58);
        java.awt.Stroke stroke61 = stackedBarRenderer3D54.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape33, paint52, stroke61, (java.awt.Paint) color62);
        legendItem63.setSeriesIndex((int) (short) 0);
        java.lang.Comparable comparable66 = legendItem63.getSeriesKey();
        legendItemCollection8.add(legendItem63);
        java.lang.Object obj68 = legendItemCollection8.clone();
        boolean boolean69 = standardGradientPaintTransformer1.equals(obj68);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNull(comparable66);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke7 = null;
        stackedAreaRenderer0.setSeriesStroke((int) (byte) 1, stroke7);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer9.setSeriesCreateEntities((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        stackedAreaRenderer9.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator15, true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        stackedAreaRenderer9.setBaseItemLabelPaint((java.awt.Paint) color18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = stackedAreaRenderer9.getSeriesURLGenerator(0);
        boolean boolean22 = stackedAreaRenderer0.equals((java.lang.Object) categoryURLGenerator21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = stackedAreaRenderer0.getLegendItems();
        java.lang.Object obj24 = stackedAreaRenderer0.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        boolean boolean25 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot7.getOrientation();
        int int27 = xYPlot7.getDatasetCount();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint29 = defaultDrawingSupplier28.getNextPaint();
        xYPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier28);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 10.0f);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone39 = dateAxis38.getTimeZone();
        boolean boolean40 = dateAxis38.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer41);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = null;
        xYPlot42.markerChanged(markerChangeEvent43);
        int int45 = xYPlot42.getWeight();
        java.awt.Stroke stroke46 = xYPlot42.getRangeCrosshairStroke();
        int int47 = xYPlot42.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("");
        dateAxis49.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent53 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis49);
        int int54 = xYPlot42.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis49);
        xYPlot42.setDomainCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset57 = xYPlot42.getDataset();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType58 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer60 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator62 = null;
        stackedAreaRenderer60.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator62, false);
        double double65 = stackedAreaRenderer60.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer66 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator68 = null;
        stackedAreaRenderer66.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator68, false);
        java.awt.Paint paint73 = stackedAreaRenderer66.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer60.setBaseFillPaint(paint73);
        java.awt.Paint paint76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint78 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke79 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker81 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint76, stroke77, paint78, stroke79, (float) 1L);
        java.awt.Color color82 = java.awt.Color.white;
        java.awt.Stroke stroke83 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker85 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint73, stroke77, (java.awt.Paint) color82, stroke83, 1.0f);
        boolean boolean86 = chartChangeEventType58.equals((java.lang.Object) categoryMarker85);
        org.jfree.chart.util.Layer layer87 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot42.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker85, layer87);
        xYPlot7.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) intervalMarker34, layer87);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent90 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker34);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNull(xYDataset57);
        org.junit.Assert.assertNotNull(chartChangeEventType58);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 2.0d + "'", double65 == 2.0d);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(layer87);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot5.markerChanged(markerChangeEvent10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) categoryPlot5);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot5.setDomainAxis(categoryAxis15);
        boolean boolean17 = categoryPlot5.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getDomainMarkers(layer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot5.getDatasetRenderingOrder();
        int int11 = categoryPlot5.getDomainAxisCount();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.text.NumberFormat numberFormat1 = null;
        numberAxis3D0.setNumberFormatOverride(numberFormat1);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        boolean boolean10 = dateAxis8.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, xYItemRenderer11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        xYPlot12.markerChanged(markerChangeEvent13);
        int int15 = xYPlot12.getWeight();
        java.awt.Stroke stroke16 = xYPlot12.getRangeCrosshairStroke();
        int int17 = xYPlot12.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis19);
        int int24 = xYPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        xYPlot12.setDomainCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot12.setDomainAxisLocation(axisLocation27);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer30 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = null;
        stackedAreaRenderer30.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator32, false);
        java.awt.Paint paint37 = stackedAreaRenderer30.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean38 = plotOrientation29.equals((java.lang.Object) 'a');
        java.lang.String str39 = plotOrientation29.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation27, plotOrientation29);
        try {
            double double41 = numberAxis3D0.valueToJava2D((double) 86400000L, rectangle2D4, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str39.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(true, true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYPlot7.setDomainZeroBaselinePaint(paint8);
        xYPlot7.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        xYPlot7.setRangeAxis(9999, valueAxis12);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        dateAxis15.setAutoTickUnitSelection(false, true);
        double double19 = dateAxis15.getLabelAngle();
        int int20 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        dateAxis15.setLabelToolTip("DateTickMarkPosition.END");
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        stackedBarRenderer3D0.setIncludeBaseInRange(true);
        double double5 = stackedBarRenderer3D0.getYOffset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setMaximumBarWidth((double) '#');
        java.awt.Shape shape10 = stackedBarRenderer3D7.getBaseShape();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot17.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        java.awt.Paint paint26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint26, stroke27, paint28, stroke29, (float) 1L);
        java.awt.Paint paint32 = categoryMarker31.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        stackedBarRenderer3D7.drawRangeMarker(graphics2D11, categoryPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.plot.Marker) categoryMarker31, rectangle2D33);
        java.awt.Shape shape35 = dateAxis20.getDownArrow();
        stackedBarRenderer3D0.setSeriesShape(8, shape35);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator38 = stackedBarRenderer3D0.getSeriesToolTipGenerator((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNull(categoryToolTipGenerator38);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint1, stroke2, paint3, stroke4, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryMarker6.getLabelOffset();
        double double9 = rectangleInsets7.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot15.getDomainAxis();
        java.awt.Paint paint17 = categoryPlot15.getDomainGridlinePaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot15.setRangeGridlineStroke(stroke18);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot15.getDomainGridlinePosition();
        boolean boolean21 = rectangleInsets7.equals((java.lang.Object) categoryPlot15);
        double double23 = rectangleInsets7.extendWidth((double) 1900);
        double double25 = rectangleInsets7.calculateRightInset((double) 3);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1906.0d + "'", double23 == 1906.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.0d + "'", double25 == 3.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        double double3 = ringPlot0.getShadowXOffset();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = ringPlot0.getLabelDistributor();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator30 = null;
        stackedAreaRenderer28.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator30, false);
        java.awt.Paint paint35 = stackedAreaRenderer28.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker24.setOutlinePaint(paint35);
        categoryMarker24.setLabel("Following");
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.addBaseTimelineExclusions((long) 8, (long) '#');
        long long4 = segmentedTimeline0.getSegmentSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 900000L + "'", long4 == 900000L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int8 = stackedAreaRenderer0.getPassCount();
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = stackedAreaRenderer0.getToolTipGenerator((int) (byte) 10, 5);
        java.awt.Stroke stroke16 = stackedAreaRenderer0.lookupSeriesOutlineStroke((int) (byte) -1);
        boolean boolean17 = stackedAreaRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNull(categoryToolTipGenerator14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        java.awt.Shape shape28 = dateAxis13.getDownArrow();
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range31);
        double double33 = range31.getLowerBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        dateAxis37.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range41 = dateAxis37.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) 86400000L, range31, lengthConstraintType34, 3.0d, range41, lengthConstraintType42);
        dateAxis13.setDefaultAutoRange(range31);
        java.awt.Shape shape45 = dateAxis13.getLeftArrow();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        categoryPlot10.setWeight(500);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryPlot5.setDomainGridlinePaint(paint8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        stackedAreaRenderer10.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator12, false);
        java.awt.Paint paint17 = stackedAreaRenderer10.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setMaximumBarWidth((double) '#');
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D19.setSeriesItemLabelFont((int) (byte) 100, font23);
        java.awt.Stroke stroke26 = stackedBarRenderer3D19.lookupSeriesOutlineStroke((int) ' ');
        stackedAreaRenderer10.setSeriesStroke(3, stroke26);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer10);
        stackedAreaRenderer10.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, true);
        try {
            org.jfree.chart.LegendItem legendItem35 = stackedAreaRenderer10.getLegendItem((int) (short) 0, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType1 = numberAxis3D0.getRangeType();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range4);
        double double6 = range4.getLowerBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        dateAxis10.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range14 = dateAxis10.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) 86400000L, range4, lengthConstraintType7, 3.0d, range14, lengthConstraintType15);
        boolean boolean17 = rangeType1.equals((java.lang.Object) lengthConstraintType15);
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultCategoryDataset0.getRowKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYPlot7.setDomainZeroBaselinePaint(paint8);
        java.awt.Stroke stroke10 = xYPlot7.getDomainGridlineStroke();
        xYPlot7.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        try {
            defaultKeyedValues0.insertValue((int) (byte) 1, (java.lang.Comparable) 7.0d, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        xYPlot7.setDomainCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        xYPlot7.datasetChanged(datasetChangeEvent22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYPlot7.drawBackgroundImage(graphics2D24, rectangle2D25);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone32 = dateAxis31.getTimeZone();
        boolean boolean33 = dateAxis31.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer34);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent36 = null;
        xYPlot35.markerChanged(markerChangeEvent36);
        int int38 = xYPlot35.getWeight();
        java.awt.Stroke stroke39 = xYPlot35.getRangeCrosshairStroke();
        int int40 = xYPlot35.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        dateAxis42.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent46 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis42);
        int int47 = xYPlot35.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis42);
        xYPlot35.setDomainCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot35.setDomainAxisLocation(axisLocation50);
        xYPlot7.setDomainAxisLocation((int) (short) 10, axisLocation50, true);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        stackedBarRenderer3D0.setIncludeBaseInRange(true);
        double double5 = stackedBarRenderer3D0.getYOffset();
        boolean boolean6 = stackedBarRenderer3D0.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Date date8 = dateAxis6.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        java.util.Date date12 = dateAxis10.getMinimumDate();
        org.jfree.data.gantt.Task task13 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date8, date12);
        boolean boolean14 = gradientPaintTransformType3.equals((java.lang.Object) date8);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D15.setMaximumBarWidth((double) '#');
        java.awt.Shape shape18 = stackedBarRenderer3D15.getBaseShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity21 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) date8, shape18, "ThreadContext", "ThreadContext");
        try {
            java.awt.GradientPaint gradientPaint22 = standardGradientPaintTransformer1.transform(gradientPaint2, shape18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        legendTitle1.setHeight((double) ' ');
        java.awt.Font font10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        legendTitle1.setItemFont(font10);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition1, categoryLabelPosition2, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        xYPlot7.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.awt.Shape shape20 = dateAxis14.getDownArrow();
        boolean boolean21 = dateAxis14.isVisible();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        stackedBarRenderer3D0.setItemMargin((double) 100);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D0.setBaseItemLabelFont(font5, false);
        stackedBarRenderer3D0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean8 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (java.lang.Comparable) (short) 1);
        org.jfree.data.Range range15 = stackedAreaRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        try {
            defaultCategoryDataset11.removeRow(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNull(range15);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range2);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range2, (double) 0, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range6, 0.65d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedHeight();
        boolean boolean10 = textBlockAnchor0.equals((java.lang.Object) rectangleConstraint9);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesCreateEntities((int) (short) 10, (java.lang.Boolean) false, false);
        java.awt.Paint paint6 = stackedAreaRenderer0.getSeriesFillPaint(10);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean6 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Font font8 = stackedAreaRenderer0.getSeriesItemLabelFont(100);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator9 = stackedAreaRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        axisChangeEvent5.setChart(jFreeChart6);
        org.jfree.chart.axis.Axis axis8 = axisChangeEvent5.getAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        stackedAreaRenderer11.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator13, false);
        double double16 = stackedAreaRenderer11.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        stackedAreaRenderer17.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator19, false);
        java.awt.Paint paint24 = stackedAreaRenderer17.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer11.setBaseFillPaint(paint24);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint27, stroke28, paint29, stroke30, (float) 1L);
        java.awt.Color color33 = java.awt.Color.white;
        java.awt.Stroke stroke34 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint24, stroke28, (java.awt.Paint) color33, stroke34, 1.0f);
        boolean boolean37 = chartChangeEventType9.equals((java.lang.Object) categoryMarker36);
        axisChangeEvent5.setType(chartChangeEventType9);
        org.jfree.chart.axis.Axis axis39 = axisChangeEvent5.getAxis();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        dateAxis41.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent45 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis41);
        org.jfree.chart.JFreeChart jFreeChart46 = null;
        axisChangeEvent45.setChart(jFreeChart46);
        org.jfree.chart.JFreeChart jFreeChart48 = axisChangeEvent45.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType49 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        axisChangeEvent45.setType(chartChangeEventType49);
        axisChangeEvent5.setType(chartChangeEventType49);
        boolean boolean53 = chartChangeEventType49.equals((java.lang.Object) 5);
        org.junit.Assert.assertNotNull(axis8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axis39);
        org.junit.Assert.assertNull(jFreeChart48);
        org.junit.Assert.assertNotNull(chartChangeEventType49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 10L);
        blockParams0.setTranslateX((double) (-1.0f));
        boolean boolean5 = blockParams0.getGenerateEntities();
        boolean boolean6 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 500);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.Point point9 = polarPlot3.translateValueThetaRadiusToJava2D(0.0d, 1.0d, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font5, (java.awt.Paint) color6);
        stackedBarRenderer3D0.setSeriesItemLabelFont(9999, font5, false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot15.getDomainAxis();
        java.awt.Paint paint17 = categoryPlot15.getDomainGridlinePaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot15.setRangeGridlineStroke(stroke18);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        categoryPlot15.markerChanged(markerChangeEvent20);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        categoryPlot15.rendererChanged(rendererChangeEvent22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot15.getRenderer();
        boolean boolean25 = categoryPlot15.isDomainGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone30 = dateAxis29.getTimeZone();
        boolean boolean31 = dateAxis29.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer32);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        xYPlot33.markerChanged(markerChangeEvent34);
        int int36 = xYPlot33.getWeight();
        java.awt.Stroke stroke37 = xYPlot33.getRangeCrosshairStroke();
        int int38 = xYPlot33.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        dateAxis40.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent44 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis40);
        int int45 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis40);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection48 = xYPlot33.getDomainMarkers((int) '4', layer47);
        java.util.Collection collection49 = categoryPlot15.getRangeMarkers(layer47);
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(categoryItemRenderer24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertNull(collection49);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity17 = new org.jfree.chart.entity.TickLabelEntity(shape14, "May", "May");
        boolean boolean18 = org.jfree.chart.util.ShapeUtilities.equal(shape12, shape14);
        dateAxis9.setRightArrow(shape14);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = null;
        stackedAreaRenderer20.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator22, false);
        double double25 = stackedAreaRenderer20.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer26 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = null;
        stackedAreaRenderer26.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator28, false);
        java.awt.Paint paint33 = stackedAreaRenderer26.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer20.setBaseFillPaint(paint33);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setMaximumBarWidth((double) '#');
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D35.setSeriesItemLabelFont((int) (byte) 100, font39);
        java.awt.Stroke stroke42 = stackedBarRenderer3D35.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape14, paint33, stroke42, (java.awt.Paint) color43);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint47, stroke48, paint49, stroke50, (float) 1L);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone55 = dateAxis54.getTimeZone();
        java.lang.Object obj56 = dateAxis54.clone();
        java.awt.Font font57 = dateAxis54.getTickLabelFont();
        java.lang.String str58 = dateAxis54.getLabelToolTip();
        java.awt.Stroke stroke59 = dateAxis54.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker61 = new org.jfree.chart.plot.ValueMarker((-1.0d), paint33, stroke45, paint49, stroke59, 0.0f);
        java.awt.Paint paint62 = valueMarker61.getPaint();
        boolean boolean63 = verticalAlignment2.equals((java.lang.Object) paint62);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        int int2 = year0.getYear();
        long long3 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getDomainMarkers(layer8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot5.getDatasetRenderingOrder();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot5.render(graphics2D11, rectangle2D12, 5, plotRenderingInfo14);
        categoryPlot5.clearRangeAxes();
        categoryPlot5.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 2019, (java.lang.Number) 2019);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator2);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        stackedAreaRenderer5.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator7, false);
        double double10 = stackedAreaRenderer5.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        stackedAreaRenderer11.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator13, false);
        java.awt.Paint paint18 = stackedAreaRenderer11.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer5.setBaseFillPaint(paint18);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = null;
        stackedAreaRenderer21.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator23, false);
        java.awt.Paint paint28 = stackedAreaRenderer21.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedAreaRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        stackedAreaRenderer5.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition30);
        ganttRenderer0.setSeriesPositiveItemLabelPosition(9, itemLabelPosition30);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = ganttRenderer0.getSeriesToolTipGenerator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNull(categoryToolTipGenerator34);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesCreateEntities((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        stackedAreaRenderer0.setSeriesToolTipGenerator((int) (short) 0, categoryToolTipGenerator6, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        stackedAreaRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = stackedAreaRenderer0.getSeriesURLGenerator(0);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14, categoryAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot19.getDomainAxis();
        java.awt.Paint paint21 = categoryPlot19.getDomainGridlinePaint();
        boolean boolean22 = categoryPlot19.isRangeCrosshairLockedOnData();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            stackedAreaRenderer0.drawDomainGridline(graphics2D13, categoryPlot19, rectangle2D23, 52.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D0.setSeriesItemLabelFont((int) (byte) 100, font4);
        java.awt.Stroke stroke7 = stackedBarRenderer3D0.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer16);
        categoryPlot17.setRangeGridlinesVisible(false);
        boolean boolean20 = stackedBarRenderer3D11.hasListener((java.util.EventListener) categoryPlot17);
        categoryPlot17.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot17.getRangeAxisEdge((-435));
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        int int28 = defaultCategoryDataset26.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj29 = defaultCategoryDataset26.clone();
        try {
            stackedBarRenderer3D0.drawItem(graphics2D8, categoryItemRendererState9, rectangle2D10, categoryPlot17, categoryAxis24, valueAxis25, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset26, (int) (short) -1, 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.setAngleLabelsVisible(false);
        polarPlot3.setAngleLabelsVisible(true);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        polarPlot3.setRenderer(polarItemRenderer10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getDomainMarkers(layer8);
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        int int13 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj14 = defaultCategoryDataset11.clone();
        boolean boolean15 = blockBorder10.equals((java.lang.Object) defaultCategoryDataset11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot5.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone21 = dateAxis20.getTimeZone();
        boolean boolean22 = dateAxis20.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer23);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        int int27 = xYPlot24.getWeight();
        java.awt.Stroke stroke28 = xYPlot24.getRangeCrosshairStroke();
        int int29 = xYPlot24.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        dateAxis31.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent35 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis31);
        int int36 = xYPlot24.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis31);
        xYPlot24.setDomainCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset39 = xYPlot24.getDataset();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer42 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = null;
        stackedAreaRenderer42.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator44, false);
        double double47 = stackedAreaRenderer42.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer48 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = null;
        stackedAreaRenderer48.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator50, false);
        java.awt.Paint paint55 = stackedAreaRenderer48.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer42.setBaseFillPaint(paint55);
        java.awt.Paint paint58 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint60 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke61 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint58, stroke59, paint60, stroke61, (float) 1L);
        java.awt.Color color64 = java.awt.Color.white;
        java.awt.Stroke stroke65 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker67 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint55, stroke59, (java.awt.Paint) color64, stroke65, 1.0f);
        boolean boolean68 = chartChangeEventType40.equals((java.lang.Object) categoryMarker67);
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot24.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker67, layer69);
        java.util.Collection collection71 = categoryPlot5.getDomainMarkers(layer69);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNull(xYDataset39);
        org.junit.Assert.assertNotNull(chartChangeEventType40);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertNull(collection71);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setLabelGap((double) 1577865599999L);
        java.lang.String str3 = ringPlot0.getPlotType();
        java.awt.Stroke stroke4 = ringPlot0.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Pie Plot" + "'", str3.equals("Pie Plot"));
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) (-1), (java.lang.Comparable) 100);
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue((java.lang.Comparable) 0.05d, (java.lang.Comparable) 52.0d);
        try {
            java.lang.Number number9 = defaultBoxAndWhiskerCategoryDataset0.getValue((int) 'a', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        int int2 = defaultKeyedValues0.getIndex((java.lang.Comparable) (byte) 1);
        defaultKeyedValues0.removeValue((java.lang.Comparable) 3);
        defaultKeyedValues0.addValue((java.lang.Comparable) 3600000L, (java.lang.Number) 52.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        int int1 = groupedStackedBarRenderer0.getPassCount();
        groupedStackedBarRenderer0.setBaseCreateEntities(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone13);
        int int16 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        boolean boolean17 = xYPlot7.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false, true);
        stackedAreaRenderer0.setBaseCreateEntities(true, false);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        dateAxis21.setAutoTickUnitSelection(false, true);
        double double25 = dateAxis21.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D26.setMaximumBarWidth((double) '#');
        java.awt.Shape shape29 = stackedBarRenderer3D26.getBaseShape();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer35 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, categoryAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = categoryPlot36.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        dateAxis39.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent43 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis39);
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint45, stroke46, paint47, stroke48, (float) 1L);
        java.awt.Paint paint51 = categoryMarker50.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        stackedBarRenderer3D26.drawRangeMarker(graphics2D30, categoryPlot36, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.plot.Marker) categoryMarker50, rectangle2D52);
        java.awt.Shape shape54 = dateAxis39.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity57 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis21, shape54, "RectangleAnchor.CENTER", "Following");
        java.awt.Paint paint58 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone63 = dateAxis62.getTimeZone();
        boolean boolean64 = dateAxis62.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = null;
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot(xYDataset59, valueAxis60, (org.jfree.chart.axis.ValueAxis) dateAxis62, xYItemRenderer65);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent67 = null;
        xYPlot66.markerChanged(markerChangeEvent67);
        int int69 = xYPlot66.getWeight();
        java.awt.Stroke stroke70 = xYPlot66.getRangeCrosshairStroke();
        int int71 = xYPlot66.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis73 = new org.jfree.chart.axis.DateAxis("");
        dateAxis73.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent77 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis73);
        int int78 = xYPlot66.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis73);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        java.awt.geom.Point2D point2D82 = null;
        xYPlot66.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo81, point2D82);
        org.jfree.chart.axis.AxisSpace axisSpace84 = xYPlot66.getFixedRangeAxisSpace();
        java.awt.Stroke stroke85 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot66.setRangeGridlineStroke(stroke85);
        java.awt.Paint paint87 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem("", "Category Plot", "", "hi!", shape54, paint58, stroke85, paint87);
        java.awt.Color color89 = java.awt.Color.magenta;
        org.jfree.chart.LegendItem legendItem90 = new org.jfree.chart.LegendItem("hi!", "HorizontalAlignment.RIGHT", "TextAnchor.CENTER", "RectangleAnchor.CENTER", shape54, (java.awt.Paint) color89);
        stackedAreaRenderer0.setSeriesShape((int) (short) 10, shape54, false);
        java.awt.Paint paint94 = stackedAreaRenderer0.getSeriesFillPaint(6);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(categoryAxis37);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNull(axisSpace84);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNull(paint94);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean8 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.lang.Object obj9 = stackedAreaRenderer0.clone();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke12 = stackedBarRenderer3D10.lookupSeriesStroke(11);
        int int13 = stackedBarRenderer3D10.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = stackedBarRenderer3D10.getBasePositiveItemLabelPosition();
        stackedAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition14, true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("ItemLabelAnchor.OUTSIDE8", graphics2D1, (float) (short) 1, 100.0f, (double) 900000L, (float) 7, 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Image image4 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo8 = new org.jfree.chart.ui.ProjectInfo("Following", "", "RectangleAnchor.CENTER", image4, "May", "0,-1,1,1,-1,1,-1,1", "0,-1,1,1,-1,1,-1,1");
        java.lang.String str9 = projectInfo8.getCopyright();
        boolean boolean10 = strokeList0.equals((java.lang.Object) str9);
        java.lang.Object obj11 = strokeList0.clone();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        java.util.Date date16 = dateAxis13.getMinimumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = null;
        dateAxis13.setTickUnit(dateTickUnit17);
        boolean boolean19 = strokeList0.equals((java.lang.Object) dateTickUnit17);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "May" + "'", str9.equals("May"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        boolean boolean13 = xYPlot7.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        xYPlot7.setRenderer(11, xYItemRenderer15, false);
        xYPlot7.setDomainCrosshairValue((double) 1.0f);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        dateAxis5.setAutoTickUnitSelection(false, true);
        double double9 = dateAxis5.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D10.setMaximumBarWidth((double) '#');
        java.awt.Shape shape13 = stackedBarRenderer3D10.getBaseShape();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot20.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint29, stroke30, paint31, stroke32, (float) 1L);
        java.awt.Paint paint35 = categoryMarker34.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D10.drawRangeMarker(graphics2D14, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.plot.Marker) categoryMarker34, rectangle2D36);
        java.awt.Shape shape38 = dateAxis23.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis5, shape38, "RectangleAnchor.CENTER", "Following");
        java.awt.Paint paint42 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone47 = dateAxis46.getTimeZone();
        boolean boolean48 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset43, valueAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, xYItemRenderer49);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent51 = null;
        xYPlot50.markerChanged(markerChangeEvent51);
        int int53 = xYPlot50.getWeight();
        java.awt.Stroke stroke54 = xYPlot50.getRangeCrosshairStroke();
        int int55 = xYPlot50.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("");
        dateAxis57.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent61 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis57);
        int int62 = xYPlot50.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        xYPlot50.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo65, point2D66);
        org.jfree.chart.axis.AxisSpace axisSpace68 = xYPlot50.getFixedRangeAxisSpace();
        java.awt.Stroke stroke69 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot50.setRangeGridlineStroke(stroke69);
        java.awt.Paint paint71 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("", "Category Plot", "", "hi!", shape38, paint42, stroke69, paint71);
        java.awt.Stroke stroke73 = legendItem72.getLineStroke();
        legendItem72.setSeriesKey((java.lang.Comparable) 0.05d);
        boolean boolean76 = legendItem72.isShapeOutlineVisible();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNull(axisSpace68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        java.lang.Object obj3 = lineAndShapeRenderer0.clone();
        lineAndShapeRenderer0.setBaseShapesVisible(false);
        try {
            lineAndShapeRenderer0.setSeriesShapesVisible((-435), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        paintList0.setPaint((int) (byte) 100, (java.awt.Paint) color2);
        java.awt.Paint paint5 = paintList0.getPaint((int) (byte) -1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        dateAxis1.setLabelURL("");
        float float7 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setRange(4.0d, (double) 11);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        java.lang.Object obj3 = lineAndShapeRenderer0.clone();
        lineAndShapeRenderer0.setBaseShapesVisible(false);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesShapesFilled(500);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range5 = stackedBarRenderer3D0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = stackedBarRenderer3D0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(drawingSupplier6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot5.markerChanged(markerChangeEvent10);
        categoryPlot5.setAnchorValue((-1.0d), false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot5.getDatasetRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("");
        dateAxis17.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis17);
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        axisChangeEvent21.setChart(jFreeChart22);
        org.jfree.chart.axis.Axis axis24 = axisChangeEvent21.getAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer27 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = null;
        stackedAreaRenderer27.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator29, false);
        double double32 = stackedAreaRenderer27.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator35 = null;
        stackedAreaRenderer33.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator35, false);
        java.awt.Paint paint40 = stackedAreaRenderer33.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer27.setBaseFillPaint(paint40);
        java.awt.Paint paint43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint43, stroke44, paint45, stroke46, (float) 1L);
        java.awt.Color color49 = java.awt.Color.white;
        java.awt.Stroke stroke50 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint40, stroke44, (java.awt.Paint) color49, stroke50, 1.0f);
        boolean boolean53 = chartChangeEventType25.equals((java.lang.Object) categoryMarker52);
        axisChangeEvent21.setType(chartChangeEventType25);
        org.jfree.chart.axis.Axis axis55 = axisChangeEvent21.getAxis();
        categoryPlot5.axisChanged(axisChangeEvent21);
        categoryPlot5.configureRangeAxes();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(axis24);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.0d + "'", double32 == 2.0d);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(axis55);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        axisChangeEvent5.setChart(jFreeChart6);
        org.jfree.chart.axis.Axis axis8 = axisChangeEvent5.getAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        stackedAreaRenderer11.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator13, false);
        double double16 = stackedAreaRenderer11.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        stackedAreaRenderer17.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator19, false);
        java.awt.Paint paint24 = stackedAreaRenderer17.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer11.setBaseFillPaint(paint24);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint27, stroke28, paint29, stroke30, (float) 1L);
        java.awt.Color color33 = java.awt.Color.white;
        java.awt.Stroke stroke34 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint24, stroke28, (java.awt.Paint) color33, stroke34, 1.0f);
        boolean boolean37 = chartChangeEventType9.equals((java.lang.Object) categoryMarker36);
        axisChangeEvent5.setType(chartChangeEventType9);
        org.jfree.chart.axis.Axis axis39 = axisChangeEvent5.getAxis();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("");
        dateAxis41.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent45 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis41);
        org.jfree.chart.JFreeChart jFreeChart46 = null;
        axisChangeEvent45.setChart(jFreeChart46);
        org.jfree.chart.JFreeChart jFreeChart48 = axisChangeEvent45.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType49 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        axisChangeEvent45.setType(chartChangeEventType49);
        axisChangeEvent5.setType(chartChangeEventType49);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType52 = axisChangeEvent5.getType();
        org.junit.Assert.assertNotNull(axis8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axis39);
        org.junit.Assert.assertNull(jFreeChart48);
        org.junit.Assert.assertNotNull(chartChangeEventType49);
        org.junit.Assert.assertNotNull(chartChangeEventType52);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedAreaRenderer8.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator10, false);
        double double13 = stackedAreaRenderer8.getItemLabelAnchorOffset();
        java.awt.Paint paint16 = stackedAreaRenderer8.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot5.setRangeGridlinePaint(paint16);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryMarker24.getLabelOffset();
        double double27 = rectangleInsets25.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer32 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, categoryAxis29, (org.jfree.chart.axis.ValueAxis) dateAxis31, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot33.getDomainAxis();
        java.awt.Paint paint35 = categoryPlot33.getDomainGridlinePaint();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot33.setRangeGridlineStroke(stroke36);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor38 = categoryPlot33.getDomainGridlinePosition();
        boolean boolean39 = rectangleInsets25.equals((java.lang.Object) categoryPlot33);
        categoryPlot5.setAxisOffset(rectangleInsets25);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = categoryPlot5.getRenderer();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(categoryAnchor38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(categoryItemRenderer41);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        stackedBarRenderer3D0.setItemMargin((double) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = stackedBarRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = stackedBarRenderer3D0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer13);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        int int17 = xYPlot14.getWeight();
        java.awt.Stroke stroke18 = xYPlot14.getRangeCrosshairStroke();
        int int19 = xYPlot14.getSeriesCount();
        boolean boolean20 = legendItemCollection6.equals((java.lang.Object) int19);
        java.awt.Color color24 = java.awt.Color.getHSBColor((float) 1577865599999L, (float) 9999, (float) 10);
        boolean boolean25 = legendItemCollection6.equals((java.lang.Object) 1577865599999L);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge2);
        axisSpace0.add((double) 9999, rectangleEdge2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        int int18 = xYPlot15.getWeight();
        java.awt.Stroke stroke19 = xYPlot15.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone24 = dateAxis23.getTimeZone();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer26);
        int int28 = xYPlot15.getRangeAxisIndex(valueAxis21);
        xYPlot15.clearAnnotations();
        xYPlot15.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke33 = stackedBarRenderer3D31.lookupSeriesStroke(11);
        xYPlot15.setRangeCrosshairStroke(stroke33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot15.getDomainAxisEdge((int) 'a');
        boolean boolean37 = rectangleEdge6.equals((java.lang.Object) 'a');
        axisSpace0.ensureAtLeast(0.0d, rectangleEdge6);
        boolean boolean39 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        int int1 = groupedStackedBarRenderer0.getPassCount();
        double double2 = groupedStackedBarRenderer0.getBase();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity16 = new org.jfree.chart.entity.TickLabelEntity(shape13, "May", "May");
        boolean boolean17 = org.jfree.chart.util.ShapeUtilities.equal(shape11, shape13);
        dateAxis8.setRightArrow(shape13);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        stackedAreaRenderer19.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator21, false);
        double double24 = stackedAreaRenderer19.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        stackedAreaRenderer25.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator27, false);
        java.awt.Paint paint32 = stackedAreaRenderer25.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer19.setBaseFillPaint(paint32);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setMaximumBarWidth((double) '#');
        java.awt.Font font38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D34.setSeriesItemLabelFont((int) (byte) 100, font38);
        java.awt.Stroke stroke41 = stackedBarRenderer3D34.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape13, paint32, stroke41, (java.awt.Paint) color42);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer44 = legendItem43.getFillPaintTransformer();
        groupedStackedBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer44);
        boolean boolean46 = groupedStackedBarRenderer0.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(gradientPaintTransformer44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("RangeType.FULL");
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        double double6 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedAreaRenderer7.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator9, false);
        java.awt.Paint paint14 = stackedAreaRenderer7.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer1.setBaseFillPaint(paint14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint17, stroke18, paint19, stroke20, (float) 1L);
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.Stroke stroke24 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint14, stroke18, (java.awt.Paint) color23, stroke24, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot32.getDomainAxis();
        java.awt.Paint paint34 = categoryPlot32.getDomainGridlinePaint();
        categoryMarker26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot32);
        java.util.List list36 = categoryPlot32.getAnnotations();
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        boolean boolean41 = categoryPlot32.render(graphics2D37, rectangle2D38, 15, plotRenderingInfo40);
        boolean boolean42 = categoryPlot32.isDomainZoomable();
        org.jfree.chart.util.SortOrder sortOrder43 = categoryPlot32.getColumnRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis45 = categoryPlot32.getRangeAxis(0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(sortOrder43);
        org.junit.Assert.assertNotNull(valueAxis45);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Shape shape2 = null;
        lineAndShapeRenderer0.setSeriesShape((int) '#', shape2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int8 = stackedAreaRenderer0.getPassCount();
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(true, false);
        stackedAreaRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset16, categoryAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot21.getDomainAxis();
        java.awt.Paint paint23 = categoryPlot21.getDomainGridlinePaint();
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot21.setRangeGridlineStroke(stroke24);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        categoryPlot21.markerChanged(markerChangeEvent26);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot21.rendererChanged(rendererChangeEvent28);
        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) categoryPlot21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = null;
        stackedBarRenderer3D32.setNegativeItemLabelPositionFallback(itemLabelPosition33);
        stackedBarRenderer3D32.setIncludeBaseInRange(true);
        categoryPlot21.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D32);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("HorizontalAlignment.RIGHT");
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 1, (double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        stackedAreaRenderer0.drawRangeMarker(graphics2D15, categoryPlot21, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.plot.Marker) intervalMarker42, rectangle2D43);
        java.lang.Object obj45 = intervalMarker42.clone();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 52.0d);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setMaximumBarWidth((double) '#');
        java.awt.Shape shape6 = stackedBarRenderer3D3.getBaseShape();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset7 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range8 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        org.jfree.data.Range range9 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset7);
        stackedBarRenderer3D2.setSeriesCreateEntities(7, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        double double2 = ganttRenderer0.getMaximumBarWidth();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = ganttRenderer0.getGradientPaintTransformer();
        ganttRenderer0.setSeriesItemLabelsVisible(7, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("PlotOrientation.VERTICAL", "Pie Plot", "0,-1,1,1,-1,1,-1,1", image3, "DateTickMarkPosition.END", "Range[0.0,1.0]", "RectangleAnchor.CENTER");
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Date date8 = dateAxis6.getMinimumDate();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date4, date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.previous();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Color color6 = java.awt.Color.GRAY;
        float[] floatArray10 = new float[] { 3, (-1.0f), 100L };
        float[] floatArray11 = color6.getColorComponents(floatArray10);
        float[] floatArray12 = java.awt.Color.RGBtoHSB((int) '4', (int) '4', 1, floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB(15, 6, 31, floatArray12);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getSeriesCount();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getSerialIndex();
        int int4 = year2.getYear();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke7 = stackedBarRenderer3D5.lookupSeriesStroke(11);
        int int8 = stackedBarRenderer3D5.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = stackedBarRenderer3D5.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = itemLabelPosition9.getItemLabelAnchor();
        boolean boolean11 = year2.equals((java.lang.Object) itemLabelAnchor10);
        java.lang.Comparable comparable12 = null;
        try {
            java.lang.Number number13 = taskSeriesCollection0.getValue((java.lang.Comparable) boolean11, comparable12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("PlotOrientation.HORIZONTAL", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color1 = color0.darker();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        double double2 = ringPlot0.getLabelLinkMargin();
        double double4 = ringPlot0.getExplodePercent((java.lang.Comparable) 2019);
        java.awt.Paint paint5 = ringPlot0.getLabelBackgroundPaint();
        java.awt.Paint paint7 = ringPlot0.getSectionOutlinePaint((java.lang.Comparable) (-451));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        categoryPlot5.clearRangeAxes();
        org.junit.Assert.assertNull(categoryAxis6);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Date date8 = dateAxis6.getMinimumDate();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date4, date8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        java.util.Date date14 = dateAxis12.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone17 = dateAxis16.getTimeZone();
        java.util.Date date18 = dateAxis16.getMinimumDate();
        org.jfree.data.gantt.Task task19 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date14, date18);
        task9.addSubtask(task19);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer26 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, categoryAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer26);
        categoryPlot27.setRangeGridlinesVisible(false);
        boolean boolean30 = stackedBarRenderer3D21.hasListener((java.util.EventListener) categoryPlot27);
        categoryPlot27.clearRangeAxes();
        boolean boolean32 = task9.equals((java.lang.Object) categoryPlot27);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone36 = dateAxis35.getTimeZone();
        java.util.Date date37 = dateAxis35.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone40 = dateAxis39.getTimeZone();
        java.util.Date date41 = dateAxis39.getMinimumDate();
        org.jfree.data.gantt.Task task42 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date37, date41);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone46 = dateAxis45.getTimeZone();
        java.util.Date date47 = dateAxis45.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone50 = dateAxis49.getTimeZone();
        java.util.Date date51 = dateAxis49.getMinimumDate();
        org.jfree.data.gantt.Task task52 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date47, date51);
        task42.addSubtask(task52);
        task9.removeSubtask(task52);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(date51);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation25 = null;
        try {
            xYPlot7.addAnnotation(xYAnnotation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.setRangeCrosshairVisible(false);
        categoryPlot6.mapDatasetToRangeAxis(3, 0);
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint16, stroke17, paint18, stroke19, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryMarker21.getLabelOffset();
        double double24 = rectangleInsets22.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer29 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot30.getDomainAxis();
        java.awt.Paint paint32 = categoryPlot30.getDomainGridlinePaint();
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot30.setRangeGridlineStroke(stroke33);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot30.getDomainGridlinePosition();
        boolean boolean36 = rectangleInsets22.equals((java.lang.Object) categoryPlot30);
        categoryPlot6.setAxisOffset(rectangleInsets22);
        categoryPlot6.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedAreaRenderer8.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator10, false);
        java.awt.Paint paint15 = stackedAreaRenderer8.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int16 = stackedAreaRenderer8.getPassCount();
        stackedAreaRenderer8.setBaseSeriesVisibleInLegend(true, false);
        stackedAreaRenderer8.setBaseSeriesVisible(false, false);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot29.getDomainAxis();
        java.awt.Paint paint31 = categoryPlot29.getDomainGridlinePaint();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot29.setRangeGridlineStroke(stroke32);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        categoryPlot29.markerChanged(markerChangeEvent34);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent36 = null;
        categoryPlot29.rendererChanged(rendererChangeEvent36);
        java.lang.Object obj38 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) categoryPlot29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = null;
        stackedBarRenderer3D40.setNegativeItemLabelPositionFallback(itemLabelPosition41);
        stackedBarRenderer3D40.setIncludeBaseInRange(true);
        categoryPlot29.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D40);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("HorizontalAlignment.RIGHT");
        org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker((double) (byte) 1, (double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedAreaRenderer8.drawRangeMarker(graphics2D23, categoryPlot29, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.plot.Marker) intervalMarker50, rectangle2D51);
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker50);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        double double2 = ringPlot0.getLabelLinkMargin();
        double double4 = ringPlot0.getExplodePercent((java.lang.Comparable) 2019);
        boolean boolean5 = ringPlot0.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        double double8 = legendTitle1.getContentXOffset();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = legendTitle1.getMargin();
        org.jfree.chart.event.TitleChangeListener titleChangeListener10 = null;
        legendTitle1.addChangeListener(titleChangeListener10);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        double double3 = dateAxis1.getLabelAngle();
        java.lang.String str4 = dateAxis1.getLabelToolTip();
        dateAxis1.setTickMarkOutsideLength(10.0f);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer13);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        int int17 = xYPlot14.getWeight();
        java.awt.Stroke stroke18 = xYPlot14.getRangeCrosshairStroke();
        int int19 = xYPlot14.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        dateAxis21.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis21);
        int int26 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint28, stroke29, paint30, stroke31, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryMarker33.getLabelOffset();
        dateAxis21.setTickLabelInsets(rectangleInsets34);
        dateAxis1.setTickLabelInsets(rectangleInsets34);
        dateAxis1.setAutoRangeMinimumSize((double) 10.0f);
        dateAxis1.setRange((double) 2, (double) 255);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        int int20 = xYPlot7.getRangeAxisIndex(valueAxis13);
        xYPlot7.clearAnnotations();
        xYPlot7.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke25 = stackedBarRenderer3D23.lookupSeriesStroke(11);
        xYPlot7.setRangeCrosshairStroke(stroke25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot7.getDomainAxisEdge((int) 'a');
        xYPlot7.configureRangeAxes();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        minMaxCategoryRenderer0.setDrawLines(true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        java.lang.Object obj3 = lineAndShapeRenderer0.clone();
        lineAndShapeRenderer0.setBaseShapesVisible(false);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = lineAndShapeRenderer0.getLegendItems();
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.data.general.DatasetGroup datasetGroup8 = categoryPlot5.getDatasetGroup();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(datasetGroup8);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = null;
        stackedAreaRenderer20.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator22, false);
        double double25 = stackedAreaRenderer20.getItemLabelAnchorOffset();
        java.awt.Paint paint28 = stackedAreaRenderer20.getItemOutlinePaint(0, (int) (short) 100);
        java.awt.Paint paint30 = stackedAreaRenderer20.getSeriesFillPaint((int) '4');
        boolean boolean31 = stackedAreaRenderer20.getAutoPopulateSeriesOutlinePaint();
        boolean boolean32 = xYPlot7.equals((java.lang.Object) boolean31);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer7);
        boolean boolean9 = dateAxis4.isVisible();
        java.awt.Paint paint10 = dateAxis4.getLabelPaint();
        org.jfree.data.KeyedObject keyedObject11 = new org.jfree.data.KeyedObject((java.lang.Comparable) dateTickUnit0, (java.lang.Object) paint10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setMaximumBarWidth((double) '#');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D15.setMaximumBarWidth((double) '#');
        java.awt.Shape shape18 = stackedBarRenderer3D15.getBaseShape();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset20, categoryAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot25.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        dateAxis28.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent32 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis28);
        java.awt.Paint paint34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint34, stroke35, paint36, stroke37, (float) 1L);
        java.awt.Paint paint40 = categoryMarker39.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        stackedBarRenderer3D15.drawRangeMarker(graphics2D19, categoryPlot25, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.plot.Marker) categoryMarker39, rectangle2D41);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer43 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator45 = null;
        stackedAreaRenderer43.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator45, false);
        java.awt.Paint paint50 = stackedAreaRenderer43.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker39.setOutlinePaint(paint50);
        stackedBarRenderer3D12.setBasePaint(paint50);
        int int53 = dateTickUnit0.compareTo((java.lang.Object) stackedBarRenderer3D12);
        java.util.Date date55 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.Date date56 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.gantt.Task task57 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date55, date56);
        java.util.Date date58 = dateTickUnit0.rollDate(date55);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date58);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        double double8 = legendTitle1.getContentXOffset();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer15);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        int int19 = xYPlot16.getWeight();
        java.awt.Stroke stroke20 = xYPlot16.getRangeCrosshairStroke();
        int int21 = xYPlot16.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        int int28 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot16.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo31, point2D32);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setMaximumBarWidth((double) '#');
        java.awt.Shape shape37 = stackedBarRenderer3D34.getBaseShape();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer43 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer43);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot44.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        dateAxis47.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent51 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis47);
        java.awt.Paint paint53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint53, stroke54, paint55, stroke56, (float) 1L);
        java.awt.Paint paint59 = categoryMarker58.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        stackedBarRenderer3D34.drawRangeMarker(graphics2D38, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.plot.Marker) categoryMarker58, rectangle2D60);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer62 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator64 = null;
        stackedAreaRenderer62.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator64, false);
        java.awt.Paint paint69 = stackedAreaRenderer62.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker58.setOutlinePaint(paint69);
        xYPlot16.setDomainGridlinePaint(paint69);
        java.awt.Paint paint72 = xYPlot16.getRangeGridlinePaint();
        legendTitle1.setItemPaint(paint72);
        java.awt.Graphics2D graphics2D74 = null;
        java.awt.geom.Rectangle2D rectangle2D75 = null;
        try {
            legendTitle1.draw(graphics2D74, rectangle2D75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(paint72);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYPlot7.setDomainZeroBaselinePaint(paint8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        int int11 = xYPlot7.indexOf(xYDataset10);
        java.lang.Object obj12 = null;
        boolean boolean13 = xYPlot7.equals(obj12);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot();
        double double2 = ringPlot1.getSectionDepth();
        double double3 = ringPlot1.getLabelLinkMargin();
        boolean boolean4 = color0.equals((java.lang.Object) double3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        stackedAreaRenderer6.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator8, false);
        java.awt.Paint paint13 = stackedAreaRenderer6.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer0.setBaseFillPaint(paint13);
        boolean boolean15 = stackedAreaRenderer0.getBaseSeriesVisible();
        java.awt.Color color17 = java.awt.Color.green;
        stackedAreaRenderer0.setSeriesItemLabelPaint(11, (java.awt.Paint) color17);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("SortOrder.ASCENDING");
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("DateTickMarkPosition.END");
        try {
            org.jfree.data.gantt.Task task3 = taskSeries1.get(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer14);
        boolean boolean16 = dateAxis11.isVisible();
        java.awt.Paint paint17 = dateAxis11.getLabelPaint();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot5.getDomainAxis(5);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryAxis20);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        double double2 = axisState0.getCursor();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        double double6 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedAreaRenderer7.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator9, false);
        java.awt.Paint paint14 = stackedAreaRenderer7.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer1.setBaseFillPaint(paint14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint17, stroke18, paint19, stroke20, (float) 1L);
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.Stroke stroke24 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint14, stroke18, (java.awt.Paint) color23, stroke24, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot32.getDomainAxis();
        java.awt.Paint paint34 = categoryPlot32.getDomainGridlinePaint();
        categoryMarker26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot32);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType36 = categoryMarker26.getLabelOffsetType();
        java.awt.Paint paint37 = null;
        try {
            categoryMarker26.setLabelPaint(paint37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(lengthAdjustmentType36);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "May", "May");
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape8, shape10);
        dateAxis5.setRightArrow(shape10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedAreaRenderer16.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator18, false);
        double double21 = stackedAreaRenderer16.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedAreaRenderer22.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator24, false);
        java.awt.Paint paint29 = stackedAreaRenderer22.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer16.setBaseFillPaint(paint29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D31.setSeriesItemLabelFont((int) (byte) 100, font35);
        java.awt.Stroke stroke38 = stackedBarRenderer3D31.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape10, paint29, stroke38, (java.awt.Paint) color39);
        java.awt.Stroke stroke41 = legendItem40.getLineStroke();
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "May", "May");
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape8, shape10);
        dateAxis5.setRightArrow(shape10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedAreaRenderer16.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator18, false);
        double double21 = stackedAreaRenderer16.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedAreaRenderer22.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator24, false);
        java.awt.Paint paint29 = stackedAreaRenderer22.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer16.setBaseFillPaint(paint29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D31.setSeriesItemLabelFont((int) (byte) 100, font35);
        java.awt.Stroke stroke38 = stackedBarRenderer3D31.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape10, paint29, stroke38, (java.awt.Paint) color39);
        legendItem40.setSeriesIndex((int) (short) 0);
        boolean boolean44 = legendItem40.equals((java.lang.Object) 10.0d);
        java.lang.String str45 = legendItem40.getLabel();
        legendItem40.setSeriesIndex((-451));
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "0,-1,1,1,-1,1,-1,1" + "'", str45.equals("0,-1,1,1,-1,1,-1,1"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.setRangeCrosshairVisible(false);
        categoryPlot6.mapDatasetToRangeAxis(3, 0);
        java.awt.Paint paint16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint16, stroke17, paint18, stroke19, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryMarker21.getLabelOffset();
        double double24 = rectangleInsets22.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset25 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer29 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer29);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot30.getDomainAxis();
        java.awt.Paint paint32 = categoryPlot30.getDomainGridlinePaint();
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot30.setRangeGridlineStroke(stroke33);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor35 = categoryPlot30.getDomainGridlinePosition();
        boolean boolean36 = rectangleInsets22.equals((java.lang.Object) categoryPlot30);
        categoryPlot6.setAxisOffset(rectangleInsets22);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot6.getDomainAxisForDataset(2019);
        categoryPlot6.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.0d + "'", double24 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(categoryAnchor35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryAxis39);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryPlot5.setDomainGridlinePaint(paint8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot5.setDatasetRenderingOrder(datasetRenderingOrder10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot5.getRangeAxisLocation((int) (byte) 0);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultBoxAndWhiskerCategoryDataset0.getGroup();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.util.Date date7 = dateAxis5.getMinimumDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
        java.lang.Number number10 = defaultBoxAndWhiskerCategoryDataset0.getQ3Value((java.lang.Comparable) date7, (java.lang.Comparable) 2.0f);
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        int int11 = xYPlot8.getWeight();
        java.awt.Stroke stroke12 = xYPlot8.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        dateAxis15.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis15);
        xYPlot8.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone23 = dateAxis22.getTimeZone();
        java.lang.Object obj24 = dateAxis22.clone();
        java.awt.Font font25 = dateAxis22.getTickLabelFont();
        java.lang.String str26 = dateAxis22.getLabelToolTip();
        java.awt.Stroke stroke27 = dateAxis22.getTickMarkStroke();
        dateAxis22.setTickMarkInsideLength((float) 6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot31.setDataset(xYDataset32);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultBoxAndWhiskerCategoryDataset0.getGroup();
        org.jfree.data.Range range3 = defaultBoxAndWhiskerCategoryDataset0.getRangeBounds(false);
        java.util.Date date4 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.List list6 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((java.lang.Comparable) date4, (java.lang.Comparable) 10.0d);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection7 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int8 = taskSeriesCollection7.getSeriesCount();
        java.util.List list9 = taskSeriesCollection7.getRowKeys();
        try {
            defaultBoxAndWhiskerCategoryDataset0.add(list9, (java.lang.Comparable) 255, (java.lang.Comparable) "poly");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (Infinity) <= upper (-Infinity).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNull(list6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getMargin();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot3.getDomainAxis(6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        dateAxis8.setAutoTickUnitSelection(false, true);
        double double12 = dateAxis8.getLabelAngle();
        boolean boolean14 = dateAxis8.isHiddenValue((long) 3);
        xYPlot3.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) dateAxis8);
        boolean boolean16 = rectangleInsets2.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNull(valueAxis5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int8 = stackedAreaRenderer0.getPassCount();
        boolean boolean9 = stackedAreaRenderer0.getRenderAsPercentages();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        java.lang.Object obj14 = dateAxis12.clone();
        java.awt.Font font15 = dateAxis12.getTickLabelFont();
        stackedAreaRenderer0.setSeriesItemLabelFont(15, font15, false);
        stackedAreaRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Paint paint22 = stackedAreaRenderer0.getItemFillPaint(7, 7);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getDomainMarkers(layer8);
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        int int13 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj14 = defaultCategoryDataset11.clone();
        boolean boolean15 = blockBorder10.equals((java.lang.Object) defaultCategoryDataset11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot5.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        java.awt.Paint paint17 = categoryPlot5.getDomainGridlinePaint();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) (short) 1);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset3);
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        categoryPlot10.mapDatasetToDomainAxis((int) (byte) 0, (int) '4');
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = categoryPlot10.getRangeMarkers((int) (short) 10, layer32);
        int int34 = categoryPlot10.getDatasetCount();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setLabelGap((double) 1577865599999L);
        boolean boolean3 = ringPlot0.getIgnoreZeroValues();
        ringPlot0.setShadowYOffset(0.0d);
        java.awt.Stroke stroke6 = ringPlot0.getSeparatorStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        double double2 = ringPlot0.getInnerSeparatorExtension();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = ringPlot0.getLabelGenerator();
        double double4 = ringPlot0.getStartAngle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 90.0d + "'", double4 == 90.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setBaseLinesVisible(false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        double double3 = stackedBarRenderer3D0.getItemMargin();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke12 = stackedBarRenderer3D10.lookupSeriesStroke(11);
        stackedBarRenderer3D10.setItemMargin((double) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = stackedBarRenderer3D10.getGradientPaintTransformer();
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D10);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot5.getRangeAxisLocation(9999);
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        xYPlot7.setDomainCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot7.setDomainAxisLocation(axisLocation22);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        stackedAreaRenderer25.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator27, false);
        java.awt.Paint paint32 = stackedAreaRenderer25.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean33 = plotOrientation24.equals((java.lang.Object) 'a');
        java.lang.String str34 = plotOrientation24.toString();
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation22, plotOrientation24);
        java.lang.String str36 = axisLocation22.toString();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str34.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str36.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.setAngleLabelsVisible(false);
        java.awt.Paint paint8 = polarPlot3.getRadiusGridlinePaint();
        java.awt.Paint paint9 = polarPlot3.getRadiusGridlinePaint();
        java.awt.Stroke stroke10 = polarPlot3.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        java.lang.String str1 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AreaRendererEndType.TRUNCATE" + "'", str1.equals("AreaRendererEndType.TRUNCATE"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        int int20 = xYPlot7.getRangeAxisIndex(valueAxis13);
        xYPlot7.clearAnnotations();
        xYPlot7.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke25 = stackedBarRenderer3D23.lookupSeriesStroke(11);
        xYPlot7.setRangeCrosshairStroke(stroke25);
        xYPlot7.clearRangeAxes();
        java.awt.Paint paint28 = xYPlot7.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.resizeRange(0.05d, 0.0d);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("May", font8);
        dateAxis3.setLabelFont(font8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer17);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        int int21 = xYPlot18.getWeight();
        java.awt.Stroke stroke22 = xYPlot18.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone27 = dateAxis26.getTimeZone();
        boolean boolean28 = dateAxis26.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer29);
        int int31 = xYPlot18.getRangeAxisIndex(valueAxis24);
        xYPlot18.clearAnnotations();
        xYPlot18.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke36 = stackedBarRenderer3D34.lookupSeriesStroke(11);
        xYPlot18.setRangeCrosshairStroke(stroke36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot18.getDomainAxisEdge((int) 'a');
        java.awt.Paint paint40 = xYPlot18.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("Third", font8, paint40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone46 = dateAxis45.getTimeZone();
        boolean boolean47 = dateAxis45.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer48);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        int int52 = xYPlot49.getWeight();
        java.awt.Stroke stroke53 = xYPlot49.getRangeCrosshairStroke();
        int int54 = xYPlot49.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("");
        dateAxis56.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent60 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis56);
        int int61 = xYPlot49.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Point2D point2D65 = null;
        xYPlot49.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo64, point2D65);
        boolean boolean67 = xYPlot49.isDomainGridlinesVisible();
        xYPlot49.clearRangeMarkers();
        org.jfree.chart.JFreeChart jFreeChart70 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", font8, (org.jfree.chart.plot.Plot) xYPlot49, false);
        java.awt.Graphics2D graphics2D71 = null;
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = null;
        java.awt.geom.Point2D point2D75 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D73, rectangleAnchor74);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo76 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection77 = chartRenderingInfo76.getEntityCollection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo78 = new org.jfree.chart.ChartRenderingInfo(entityCollection77);
        java.lang.Object obj79 = chartRenderingInfo78.clone();
        try {
            jFreeChart70.draw(graphics2D71, rectangle2D72, point2D75, chartRenderingInfo78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(point2D75);
        org.junit.Assert.assertNotNull(entityCollection77);
        org.junit.Assert.assertNotNull(obj79);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 1562097599999L, (double) (short) 0, 10.0d, 0.05d);
        double double6 = rectangleInsets5.getBottom();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 10.0f);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer3 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double4 = ganttRenderer3.getEndPercent();
        double double5 = ganttRenderer3.getMaximumBarWidth();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = ganttRenderer3.getGradientPaintTransformer();
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer6);
        java.lang.Object obj8 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.65d + "'", double4 == 0.65d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYPlot7.setDomainZeroBaselinePaint(paint8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        int int11 = xYPlot7.indexOf(xYDataset10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        xYPlot7.setOutlinePaint(paint12);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        boolean boolean1 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        java.awt.Color color7 = java.awt.Color.yellow;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedAreaRenderer8.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator10, false);
        java.awt.Paint paint15 = stackedAreaRenderer8.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int16 = stackedAreaRenderer8.getPassCount();
        stackedAreaRenderer8.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator22 = stackedAreaRenderer8.getToolTipGenerator((int) (byte) 10, 5);
        java.awt.Stroke stroke24 = stackedAreaRenderer8.lookupSeriesOutlineStroke((int) (byte) -1);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setMaximumBarWidth((double) '#');
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis38);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        java.awt.Paint paint50 = categoryMarker49.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedBarRenderer3D25.drawRangeMarker(graphics2D29, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.plot.Marker) categoryMarker49, rectangle2D51);
        java.awt.Paint paint53 = stackedBarRenderer3D25.getBaseItemLabelPaint();
        try {
            org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem(attributedString0, "", "PlotOrientation.VERTICAL", "AxisLocation.BOTTOM_OR_LEFT", shape5, (java.awt.Paint) color7, stroke24, paint53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNull(categoryToolTipGenerator22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint1, stroke2, paint3, stroke4, (float) 1L);
        java.awt.Paint paint7 = categoryMarker6.getLabelPaint();
        java.lang.Comparable comparable8 = categoryMarker6.getKey();
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str10 = textAnchor9.toString();
        categoryMarker6.setLabelTextAnchor(textAnchor9);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        stackedAreaRenderer13.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator15, false);
        double double18 = stackedAreaRenderer13.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        stackedAreaRenderer19.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator21, false);
        java.awt.Paint paint26 = stackedAreaRenderer19.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer13.setBaseFillPaint(paint26);
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint29, stroke30, paint31, stroke32, (float) 1L);
        java.awt.Color color35 = java.awt.Color.white;
        java.awt.Stroke stroke36 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint26, stroke30, (java.awt.Paint) color35, stroke36, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer43 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer43);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot44.getDomainAxis();
        java.awt.Paint paint46 = categoryPlot44.getDomainGridlinePaint();
        categoryMarker38.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot44);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType48 = categoryMarker38.getLabelOffsetType();
        categoryMarker6.setLabelOffsetType(lengthAdjustmentType48);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "RectangleAnchor.CENTER" + "'", comparable8.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.CENTER" + "'", str10.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(lengthAdjustmentType48);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        int int20 = xYPlot7.getRangeAxisIndex(valueAxis13);
        xYPlot7.clearAnnotations();
        xYPlot7.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace23 = xYPlot7.getFixedDomainAxisSpace();
        java.awt.Paint paint24 = xYPlot7.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        double double3 = dateAxis1.getLabelAngle();
        java.lang.String str4 = dateAxis1.getLabelToolTip();
        try {
            dateAxis1.setAutoRangeMinimumSize((-1.0d), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint1, stroke2, paint3, stroke4, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryMarker6.getLabelOffset();
        double double9 = rectangleInsets7.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot15.getDomainAxis();
        java.awt.Paint paint17 = categoryPlot15.getDomainGridlinePaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot15.setRangeGridlineStroke(stroke18);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot15.getDomainGridlinePosition();
        boolean boolean21 = rectangleInsets7.equals((java.lang.Object) categoryPlot15);
        double double23 = rectangleInsets7.calculateLeftOutset((double) 0.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 3.0d + "'", double23 == 3.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str5 = spreadsheetDate4.getDescription();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str12 = spreadsheetDate11.getDescription();
        boolean boolean13 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int14 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str17 = spreadsheetDate16.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str20 = spreadsheetDate19.getDescription();
        boolean boolean21 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str24 = spreadsheetDate23.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str27 = spreadsheetDate26.getDescription();
        boolean boolean28 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str31 = spreadsheetDate30.getDescription();
        boolean boolean33 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate30, 0);
        boolean boolean35 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate30, 0);
        int int36 = spreadsheetDate4.getMonth();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getStartValue((int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        defaultKeyedValues0.clear();
        defaultKeyedValues0.insertValue((int) (byte) 0, (java.lang.Comparable) 90.0d, (java.lang.Number) 1546329600000L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        stackedBarRenderer3D0.setItemMargin((double) 100);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D0.setBaseItemLabelFont(font5, false);
        stackedBarRenderer3D0.setBase((double) 10L);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        int int20 = xYPlot7.getRangeAxisIndex(valueAxis13);
        xYPlot7.clearAnnotations();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        java.util.List list24 = null;
        xYPlot7.drawDomainTickBands(graphics2D22, rectangle2D23, list24);
        xYPlot7.configureDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone33 = dateAxis32.getTimeZone();
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity40 = new org.jfree.chart.entity.TickLabelEntity(shape37, "May", "May");
        boolean boolean41 = org.jfree.chart.util.ShapeUtilities.equal(shape35, shape37);
        dateAxis32.setRightArrow(shape37);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer43 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator45 = null;
        stackedAreaRenderer43.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator45, false);
        double double48 = stackedAreaRenderer43.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer49 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator51 = null;
        stackedAreaRenderer49.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator51, false);
        java.awt.Paint paint56 = stackedAreaRenderer49.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer43.setBaseFillPaint(paint56);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D58 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D58.setMaximumBarWidth((double) '#');
        java.awt.Font font62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D58.setSeriesItemLabelFont((int) (byte) 100, font62);
        java.awt.Stroke stroke65 = stackedBarRenderer3D58.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color66 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape37, paint56, stroke65, (java.awt.Paint) color66);
        xYPlot7.setOutlinePaint((java.awt.Paint) color66);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(color66);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        double double3 = dateAxis1.getLabelAngle();
        java.lang.String str4 = dateAxis1.getLabelToolTip();
        dateAxis1.setTickMarkOutsideLength(10.0f);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer13);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        int int17 = xYPlot14.getWeight();
        java.awt.Stroke stroke18 = xYPlot14.getRangeCrosshairStroke();
        int int19 = xYPlot14.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        dateAxis21.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent25 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis21);
        int int26 = xYPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis21);
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint28, stroke29, paint30, stroke31, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryMarker33.getLabelOffset();
        dateAxis21.setTickLabelInsets(rectangleInsets34);
        dateAxis1.setTickLabelInsets(rectangleInsets34);
        double double38 = rectangleInsets34.calculateLeftInset(4.0d);
        double double40 = rectangleInsets34.calculateRightOutset((double) 100);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.0d + "'", double38 == 3.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 3.0d + "'", double40 == 3.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle1.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        categoryPlot10.mapDatasetToDomainAxis((int) (byte) 0, (int) '4');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Shape shape34 = stackedBarRenderer3D31.getBaseShape();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer40 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer40);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot41.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        dateAxis44.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis44);
        java.awt.Paint paint50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint50, stroke51, paint52, stroke53, (float) 1L);
        java.awt.Paint paint56 = categoryMarker55.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        stackedBarRenderer3D31.drawRangeMarker(graphics2D35, categoryPlot41, (org.jfree.chart.axis.ValueAxis) dateAxis44, (org.jfree.chart.plot.Marker) categoryMarker55, rectangle2D57);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator61 = null;
        stackedAreaRenderer59.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator61, false);
        java.awt.Paint paint66 = stackedAreaRenderer59.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker55.setOutlinePaint(paint66);
        categoryPlot10.addDomainMarker(categoryMarker55);
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = categoryPlot10.getDomainAxis();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNull(categoryAxis69);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone8 = dateAxis7.getTimeZone();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity15 = new org.jfree.chart.entity.TickLabelEntity(shape12, "May", "May");
        boolean boolean16 = org.jfree.chart.util.ShapeUtilities.equal(shape10, shape12);
        dateAxis7.setRightArrow(shape12);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer18 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        stackedAreaRenderer18.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator20, false);
        double double23 = stackedAreaRenderer18.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer24 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        stackedAreaRenderer24.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator26, false);
        java.awt.Paint paint31 = stackedAreaRenderer24.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer18.setBaseFillPaint(paint31);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D33.setMaximumBarWidth((double) '#');
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D33.setSeriesItemLabelFont((int) (byte) 100, font37);
        java.awt.Stroke stroke40 = stackedBarRenderer3D33.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape12, paint31, stroke40, (java.awt.Paint) color41);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker50 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint45, stroke46, paint47, stroke48, (float) 1L);
        org.jfree.chart.axis.DateAxis dateAxis52 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone53 = dateAxis52.getTimeZone();
        java.lang.Object obj54 = dateAxis52.clone();
        java.awt.Font font55 = dateAxis52.getTickLabelFont();
        java.lang.String str56 = dateAxis52.getLabelToolTip();
        java.awt.Stroke stroke57 = dateAxis52.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((-1.0d), paint31, stroke43, paint47, stroke57, 0.0f);
        minMaxCategoryRenderer0.setGroupStroke(stroke43);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 2.0d + "'", double23 == 2.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNull(str56);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        int int3 = stackedBarRenderer3D0.getRowCount();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone8 = dateAxis7.getTimeZone();
        boolean boolean9 = dateAxis7.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot11.markerChanged(markerChangeEvent12);
        int int14 = xYPlot11.getWeight();
        java.awt.Stroke stroke15 = xYPlot11.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone20 = dateAxis19.getTimeZone();
        boolean boolean21 = dateAxis19.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer22);
        int int24 = xYPlot11.getRangeAxisIndex(valueAxis17);
        xYPlot11.clearAnnotations();
        xYPlot11.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke29 = stackedBarRenderer3D27.lookupSeriesStroke(11);
        xYPlot11.setRangeCrosshairStroke(stroke29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot11.setDomainZeroBaselineStroke(stroke31);
        stackedBarRenderer3D0.setBaseStroke(stroke31);
        java.awt.Paint paint35 = null;
        stackedBarRenderer3D0.setSeriesItemLabelPaint(5, paint35);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = stackedBarRenderer3D0.getPlot();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(categoryPlot37);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.util.List list1 = taskSeriesCollection0.getColumnKeys();
        java.lang.Comparable comparable2 = null;
        try {
            java.lang.Number number4 = taskSeriesCollection0.getPercentComplete(comparable2, (java.lang.Comparable) 0.25d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str5 = spreadsheetDate4.getDescription();
        boolean boolean6 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str9 = spreadsheetDate8.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str12 = spreadsheetDate11.getDescription();
        boolean boolean13 = spreadsheetDate8.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int14 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str17 = spreadsheetDate16.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str20 = spreadsheetDate19.getDescription();
        boolean boolean21 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str24 = spreadsheetDate23.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str27 = spreadsheetDate26.getDescription();
        boolean boolean28 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str31 = spreadsheetDate30.getDescription();
        boolean boolean33 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate30, 0);
        boolean boolean35 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate30, 0);
        java.awt.Color color37 = java.awt.Color.GRAY;
        float[] floatArray41 = new float[] { 3, (-1.0f), 100L };
        float[] floatArray42 = color37.getColorComponents(floatArray41);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color37, stroke43);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Font font46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis3D45.setLabelFont(font46);
        boolean boolean48 = valueMarker44.equals((java.lang.Object) font46);
        try {
            int int49 = spreadsheetDate4.compareTo((java.lang.Object) font46);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.awt.Font cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        stackedAreaRenderer6.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator8, false);
        java.awt.Paint paint13 = stackedAreaRenderer6.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer0.setBaseFillPaint(paint13);
        java.awt.Color color17 = java.awt.Color.cyan;
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color17, stroke22);
        int int26 = color17.getAlpha();
        stackedAreaRenderer0.setSeriesOutlinePaint(3, (java.awt.Paint) color17, false);
        java.awt.Paint paint30 = null;
        try {
            stackedAreaRenderer0.setSeriesFillPaint((-451), paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 255 + "'", int26 == 255);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        dateAxis2.resizeRange(0.05d, 0.0d);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("May", font7);
        dateAxis2.setLabelFont(font7);
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("ThreadContext", font7);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean8 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedAreaRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        stackedAreaRenderer12.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator14, false);
        double double17 = stackedAreaRenderer12.getItemLabelAnchorOffset();
        java.awt.Paint paint20 = stackedAreaRenderer12.getItemOutlinePaint(0, (int) (short) 100);
        boolean boolean21 = itemLabelPosition11.equals((java.lang.Object) stackedAreaRenderer12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = stackedAreaRenderer12.getSeriesURLGenerator(9);
        stackedAreaRenderer12.setSeriesCreateEntities(8, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryURLGenerator23);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getIncompletePaint();
        java.awt.Stroke stroke3 = ganttRenderer0.getSeriesStroke(0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone13);
        int int16 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        dateAxis15.setVisible(false);
        boolean boolean19 = dateAxis15.isAxisLineVisible();
        java.awt.Shape shape20 = dateAxis15.getRightArrow();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultBoxAndWhiskerCategoryDataset0.getGroup();
        int int2 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem3 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str7 = spreadsheetDate6.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str10 = spreadsheetDate9.getDescription();
        boolean boolean11 = spreadsheetDate6.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str14 = spreadsheetDate13.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str17 = spreadsheetDate16.getDescription();
        boolean boolean18 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str21 = spreadsheetDate20.getDescription();
        boolean boolean23 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate20, 0);
        try {
            defaultBoxAndWhiskerCategoryDataset0.add(boxAndWhiskerItem3, (java.lang.Comparable) "ItemLabelAnchor.OUTSIDE8", (java.lang.Comparable) spreadsheetDate20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setLabelGap((double) 1577865599999L);
        ringPlot0.setShadowYOffset((double) (-451));
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = ringPlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        try {
            int int5 = taskSeriesCollection0.getSubIntervalCount((java.lang.Comparable) 1900, (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setMaximumBarWidth((double) '#');
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis38);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        java.awt.Paint paint50 = categoryMarker49.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedBarRenderer3D25.drawRangeMarker(graphics2D29, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.plot.Marker) categoryMarker49, rectangle2D51);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer53 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator55 = null;
        stackedAreaRenderer53.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator55, false);
        java.awt.Paint paint60 = stackedAreaRenderer53.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker49.setOutlinePaint(paint60);
        xYPlot7.setDomainGridlinePaint(paint60);
        java.awt.Paint paint63 = xYPlot7.getRangeGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = null;
        java.awt.geom.Point2D point2D69 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D67, rectangleAnchor68);
        xYPlot7.zoomRangeAxes((double) 8, (double) 11, plotRenderingInfo66, point2D69);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(point2D69);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator2);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        stackedAreaRenderer5.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator7, false);
        double double10 = stackedAreaRenderer5.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        stackedAreaRenderer11.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator13, false);
        java.awt.Paint paint18 = stackedAreaRenderer11.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer5.setBaseFillPaint(paint18);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer21 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator23 = null;
        stackedAreaRenderer21.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator23, false);
        java.awt.Paint paint28 = stackedAreaRenderer21.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = stackedAreaRenderer21.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        stackedAreaRenderer5.setSeriesNegativeItemLabelPosition((int) (byte) 1, itemLabelPosition30);
        ganttRenderer0.setSeriesPositiveItemLabelPosition(9, itemLabelPosition30);
        double double33 = itemLabelPosition30.getAngle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        dateAxis5.setAutoTickUnitSelection(false, true);
        double double9 = dateAxis5.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D10.setMaximumBarWidth((double) '#');
        java.awt.Shape shape13 = stackedBarRenderer3D10.getBaseShape();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot20.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint29, stroke30, paint31, stroke32, (float) 1L);
        java.awt.Paint paint35 = categoryMarker34.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D10.drawRangeMarker(graphics2D14, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.plot.Marker) categoryMarker34, rectangle2D36);
        java.awt.Shape shape38 = dateAxis23.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis5, shape38, "RectangleAnchor.CENTER", "Following");
        java.awt.Paint paint42 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone47 = dateAxis46.getTimeZone();
        boolean boolean48 = dateAxis46.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset43, valueAxis44, (org.jfree.chart.axis.ValueAxis) dateAxis46, xYItemRenderer49);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent51 = null;
        xYPlot50.markerChanged(markerChangeEvent51);
        int int53 = xYPlot50.getWeight();
        java.awt.Stroke stroke54 = xYPlot50.getRangeCrosshairStroke();
        int int55 = xYPlot50.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("");
        dateAxis57.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent61 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis57);
        int int62 = xYPlot50.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        xYPlot50.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo65, point2D66);
        org.jfree.chart.axis.AxisSpace axisSpace68 = xYPlot50.getFixedRangeAxisSpace();
        java.awt.Stroke stroke69 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot50.setRangeGridlineStroke(stroke69);
        java.awt.Paint paint71 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("", "Category Plot", "", "hi!", shape38, paint42, stroke69, paint71);
        legendItem72.setDatasetIndex((-451));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNull(axisSpace68);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        boolean boolean6 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Font font8 = stackedAreaRenderer0.getSeriesItemLabelFont(11);
        java.awt.Paint paint11 = stackedAreaRenderer0.getItemLabelPaint(7, 15);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        double double1 = ringPlot0.getSectionDepth();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        ringPlot0.setSeparatorPaint(paint3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2d + "'", double1 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.addBaseTimelineExclusions((long) 8, (long) '#');
        java.util.Date date4 = null;
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment5 = segmentedTimeline0.getSegment(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryPlot5.setDomainGridlinePaint(paint8);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        stackedAreaRenderer10.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator12, false);
        java.awt.Paint paint17 = stackedAreaRenderer10.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D19.setMaximumBarWidth((double) '#');
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D19.setSeriesItemLabelFont((int) (byte) 100, font23);
        java.awt.Stroke stroke26 = stackedBarRenderer3D19.lookupSeriesOutlineStroke((int) ' ');
        stackedAreaRenderer10.setSeriesStroke(3, stroke26);
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer10);
        java.awt.Font font32 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("", font32, (java.awt.Paint) color33);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("HorizontalAlignment.RIGHT", font32);
        stackedAreaRenderer10.setSeriesItemLabelFont(3, font32);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType37 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        java.lang.Object obj38 = null;
        boolean boolean39 = areaRendererEndType37.equals(obj38);
        stackedAreaRenderer10.setEndType(areaRendererEndType37);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(areaRendererEndType37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.gantt.TaskSeries taskSeries1 = new org.jfree.data.gantt.TaskSeries("DateTickMarkPosition.END");
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        java.util.Date date6 = dateAxis4.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.util.Date date10 = dateAxis8.getMinimumDate();
        org.jfree.data.gantt.Task task11 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date6, date10);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        java.util.Date date16 = dateAxis14.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone19 = dateAxis18.getTimeZone();
        java.util.Date date20 = dateAxis18.getMinimumDate();
        org.jfree.data.gantt.Task task21 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date16, date20);
        task11.addSubtask(task21);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer28);
        categoryPlot29.setRangeGridlinesVisible(false);
        boolean boolean32 = stackedBarRenderer3D23.hasListener((java.util.EventListener) categoryPlot29);
        categoryPlot29.clearRangeAxes();
        boolean boolean34 = task11.equals((java.lang.Object) categoryPlot29);
        taskSeries1.remove(task11);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        java.util.Date date6 = dateAxis4.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.util.Date date10 = dateAxis8.getMinimumDate();
        org.jfree.data.gantt.Task task11 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date6, date10);
        boolean boolean12 = gradientPaintTransformType1.equals((java.lang.Object) date6);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        java.util.Date date17 = dateAxis14.getMinimumDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date6, date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Date date20 = dateTickUnit0.addToDate(date17, timeZone19);
        int int21 = dateTickUnit0.getCount();
        java.lang.String str22 = dateTickUnit0.toString();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str22.equals("DateTickUnit[DAY, 1]"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.MinMaxCategoryRenderer minMaxCategoryRenderer0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = categoryItemRendererState3.getInfo();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.lang.Object obj11 = dateAxis9.clone();
        java.awt.Font font12 = dateAxis9.getTickLabelFont();
        java.lang.String str13 = dateAxis9.getLabelToolTip();
        java.awt.Stroke stroke14 = dateAxis9.getTickMarkStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D15.setMaximumBarWidth((double) '#');
        java.awt.Shape shape18 = stackedBarRenderer3D15.getBaseShape();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset19 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range20 = stackedBarRenderer3D15.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset19);
        try {
            minMaxCategoryRenderer0.drawItem(graphics2D1, categoryItemRendererState3, rectangle2D5, categoryPlot6, categoryAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset19, (int) (byte) 1, (int) (byte) 100, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(plotRenderingInfo4);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType4 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone8 = dateAxis7.getTimeZone();
        java.util.Date date9 = dateAxis7.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        java.util.Date date13 = dateAxis11.getMinimumDate();
        org.jfree.data.gantt.Task task14 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date9, date13);
        boolean boolean15 = gradientPaintTransformType4.equals((java.lang.Object) date9);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D16.setMaximumBarWidth((double) '#');
        java.awt.Shape shape19 = stackedBarRenderer3D16.getBaseShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) date9, shape19, "ThreadContext", "ThreadContext");
        java.awt.Color color23 = java.awt.Color.gray;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("ItemLabelAnchor.OUTSIDE8", "Pie Plot", "ItemLabelAnchor.OUTSIDE8", "Following", shape19, (java.awt.Paint) color23);
        org.junit.Assert.assertNotNull(gradientPaintTransformType4);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot5.markerChanged(markerChangeEvent10);
        categoryPlot5.setAnchorValue((-1.0d), false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = categoryPlot5.getDatasetRenderingOrder();
        float float16 = categoryPlot5.getBackgroundAlpha();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setLabelGap((double) 1577865599999L);
        ringPlot0.setCircular(false, false);
        ringPlot0.setCircular(false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("May");
        java.awt.Font font2 = textFragment1.getFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("AxisLocation.BOTTOM_OR_LEFT", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = stackedAreaRenderer1.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(itemLabelPosition2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1900, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        java.util.Date date5 = dateAxis3.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone8 = dateAxis7.getTimeZone();
        java.util.Date date9 = dateAxis7.getMinimumDate();
        org.jfree.data.gantt.Task task10 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date5, date9);
        boolean boolean11 = gradientPaintTransformType0.equals((java.lang.Object) date5);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D12 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D12.setMaximumBarWidth((double) '#');
        java.awt.Shape shape15 = stackedBarRenderer3D12.getBaseShape();
        org.jfree.chart.entity.CategoryLabelEntity categoryLabelEntity18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable) date5, shape15, "ThreadContext", "ThreadContext");
        java.lang.String str19 = categoryLabelEntity18.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "CategoryLabelEntity: category=Wed Dec 31 16:00:00 PST 1969, tooltip=ThreadContext, url=ThreadContext" + "'", str19.equals("CategoryLabelEntity: category=Wed Dec 31 16:00:00 PST 1969, tooltip=ThreadContext, url=ThreadContext"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        double double6 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedAreaRenderer7.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator9, false);
        java.awt.Paint paint14 = stackedAreaRenderer7.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer1.setBaseFillPaint(paint14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint17, stroke18, paint19, stroke20, (float) 1L);
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.Stroke stroke24 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint14, stroke18, (java.awt.Paint) color23, stroke24, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot32.getDomainAxis();
        java.awt.Paint paint34 = categoryPlot32.getDomainGridlinePaint();
        categoryMarker26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot32);
        java.util.List list36 = categoryPlot32.getAnnotations();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone41 = dateAxis40.getTimeZone();
        boolean boolean42 = dateAxis40.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis40, xYItemRenderer43);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer45 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = null;
        stackedAreaRenderer45.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator47, false);
        double double50 = stackedAreaRenderer45.getItemLabelAnchorOffset();
        java.awt.Paint paint53 = stackedAreaRenderer45.getItemOutlinePaint(0, (int) (short) 100);
        xYPlot44.setOutlinePaint(paint53);
        categoryPlot32.setRangeCrosshairPaint(paint53);
        org.jfree.chart.axis.AxisSpace axisSpace56 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace57 = new org.jfree.chart.axis.AxisSpace();
        axisSpace56.ensureAtLeast(axisSpace57);
        categoryPlot32.setFixedRangeAxisSpace(axisSpace56);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        boolean boolean8 = dateAxis3.isVisible();
        java.util.Date date9 = dateAxis3.getMinimumDate();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getLength();
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double3 = range2.getLength();
        double double5 = range2.constrain(0.0d);
        org.jfree.data.Range range6 = org.jfree.data.Range.combine(range0, range2);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        boolean boolean3 = lineAndShapeRenderer0.getBaseLinesVisible();
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(2019, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setSeriesShapesFilled((int) (byte) 0, (java.lang.Boolean) true);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = textTitle0.getFont();
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        double double5 = dateAxis1.getLabelAngle();
        java.lang.Object obj6 = dateAxis1.clone();
        dateAxis1.setLabelAngle((double) 1900);
        java.lang.Object obj9 = dateAxis1.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator30 = null;
        stackedAreaRenderer28.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator30, false);
        java.awt.Paint paint35 = stackedAreaRenderer28.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker24.setOutlinePaint(paint35);
        java.awt.Paint paint37 = null;
        categoryMarker24.setOutlinePaint(paint37);
        java.awt.Paint paint39 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryMarker24.setLabelPaint(paint39);
        categoryMarker24.setDrawAsLine(false);
        java.lang.Class<?> wildcardClass43 = categoryMarker24.getClass();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint1, stroke2, paint3, stroke4, (float) 1L);
        java.awt.Paint paint7 = categoryMarker6.getLabelPaint();
        java.lang.Comparable comparable8 = categoryMarker6.getKey();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke11 = stackedBarRenderer3D9.lookupSeriesStroke(11);
        categoryMarker6.setOutlineStroke(stroke11);
        java.awt.Font font13 = categoryMarker6.getLabelFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + "RectangleAnchor.CENTER" + "'", comparable8.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        double double8 = legendTitle1.getContentXOffset();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer15);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        int int19 = xYPlot16.getWeight();
        java.awt.Stroke stroke20 = xYPlot16.getRangeCrosshairStroke();
        int int21 = xYPlot16.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        int int28 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot16.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo31, point2D32);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D34.setMaximumBarWidth((double) '#');
        java.awt.Shape shape37 = stackedBarRenderer3D34.getBaseShape();
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset39 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer43 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset39, categoryAxis40, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer43);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = categoryPlot44.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        dateAxis47.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent51 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis47);
        java.awt.Paint paint53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint55 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint53, stroke54, paint55, stroke56, (float) 1L);
        java.awt.Paint paint59 = categoryMarker58.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        stackedBarRenderer3D34.drawRangeMarker(graphics2D38, categoryPlot44, (org.jfree.chart.axis.ValueAxis) dateAxis47, (org.jfree.chart.plot.Marker) categoryMarker58, rectangle2D60);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer62 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator64 = null;
        stackedAreaRenderer62.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator64, false);
        java.awt.Paint paint69 = stackedAreaRenderer62.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker58.setOutlinePaint(paint69);
        xYPlot16.setDomainGridlinePaint(paint69);
        java.awt.Paint paint72 = xYPlot16.getRangeGridlinePaint();
        legendTitle1.setItemPaint(paint72);
        org.jfree.chart.block.BlockContainer blockContainer74 = legendTitle1.getItemContainer();
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNull(categoryAxis45);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(blockContainer74);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        xYPlot7.setDomainCrosshairVisible(false);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        xYPlot7.setDataset(xYDataset22);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        java.util.Date date4 = dateAxis1.getMinimumDate();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType5 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.util.Date date10 = dateAxis8.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        java.util.Date date14 = dateAxis12.getMinimumDate();
        org.jfree.data.gantt.Task task15 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date10, date14);
        boolean boolean16 = gradientPaintTransformType5.equals((java.lang.Object) date10);
        dateAxis1.setMaximumDate(date10);
        org.jfree.data.Range range19 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range19);
        org.jfree.data.Range range23 = org.jfree.data.Range.shift(range19, (double) 0, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint(range23, 0.65d);
        dateAxis1.setRangeWithMargins(range23, false, true);
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range31);
        double double33 = range31.getLowerBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        dateAxis37.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range41 = dateAxis37.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) 86400000L, range31, lengthConstraintType34, 3.0d, range41, lengthConstraintType42);
        dateAxis1.setRange(range41, true, false);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(gradientPaintTransformType5);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedAreaRenderer8.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator10, false);
        double double13 = stackedAreaRenderer8.getItemLabelAnchorOffset();
        java.awt.Paint paint16 = stackedAreaRenderer8.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot5.setRangeGridlinePaint(paint16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot5.getDomainAxisEdge(5);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot5.getRangeAxis();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(valueAxis20);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        dateAxis13.setVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        double double24 = dateAxis20.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setMaximumBarWidth((double) '#');
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis38);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        java.awt.Paint paint50 = categoryMarker49.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedBarRenderer3D25.drawRangeMarker(graphics2D29, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.plot.Marker) categoryMarker49, rectangle2D51);
        java.awt.Shape shape53 = dateAxis38.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity56 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis20, shape53, "RectangleAnchor.CENTER", "Following");
        dateAxis13.setLeftArrow(shape53);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset60 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number61 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset60);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity64 = new org.jfree.chart.entity.CategoryItemEntity(shape53, "Range[0.0,1.0]", "RectangleAnchor.CENTER", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset60, (java.lang.Comparable) true, (java.lang.Comparable) (-1.0f));
        java.lang.String str65 = categoryItemEntity64.getShapeType();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection66 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int67 = taskSeriesCollection66.getSeriesCount();
        java.util.List list68 = taskSeriesCollection66.getRowKeys();
        java.util.List list69 = taskSeriesCollection66.getColumnKeys();
        categoryItemEntity64.setDataset((org.jfree.data.category.CategoryDataset) taskSeriesCollection66);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNull(number61);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "poly" + "'", str65.equals("poly"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(list68);
        org.junit.Assert.assertNotNull(list69);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj3 = defaultCategoryDataset0.clone();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Category Plot");
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.lang.Object obj4 = dateAxis2.clone();
        java.awt.Font font5 = dateAxis2.getTickLabelFont();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        int int16 = xYPlot13.getWeight();
        java.awt.Stroke stroke17 = xYPlot13.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        xYPlot13.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        xYPlot13.setDomainAxisLocation((int) (short) 1, axisLocation27);
        java.awt.Paint paint29 = xYPlot13.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle35.getLegendItemGraphicAnchor();
        legendTitle33.setLegendItemGraphicLocation(rectangleAnchor36);
        org.jfree.chart.block.BlockBorder blockBorder38 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray40 = legendTitle33.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = legendTitle33.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment31, verticalAlignment41, (double) 0.0f, (double) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = legendTitle48.getLegendItemGraphicAnchor();
        legendTitle46.setLegendItemGraphicLocation(rectangleAnchor49);
        org.jfree.chart.block.BlockBorder blockBorder51 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle46.setFrame((org.jfree.chart.block.BlockFrame) blockBorder51);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray53 = legendTitle46.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = legendTitle46.getVerticalAlignment();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset55 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset55, categoryAxis56, (org.jfree.chart.axis.ValueAxis) dateAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer59);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = categoryPlot60.getDomainAxis();
        java.awt.Paint paint62 = categoryPlot60.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer63 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator65 = null;
        stackedAreaRenderer63.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator65, false);
        double double68 = stackedAreaRenderer63.getItemLabelAnchorOffset();
        java.awt.Paint paint71 = stackedAreaRenderer63.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot60.setRangeGridlinePaint(paint71);
        java.awt.Paint paint74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke75 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint74, stroke75, paint76, stroke77, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = categoryMarker79.getLabelOffset();
        double double82 = rectangleInsets80.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset83 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis84 = null;
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer87 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot88 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset83, categoryAxis84, (org.jfree.chart.axis.ValueAxis) dateAxis86, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer87);
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = categoryPlot88.getDomainAxis();
        java.awt.Paint paint90 = categoryPlot88.getDomainGridlinePaint();
        java.awt.Stroke stroke91 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot88.setRangeGridlineStroke(stroke91);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor93 = categoryPlot88.getDomainGridlinePosition();
        boolean boolean94 = rectangleInsets80.equals((java.lang.Object) categoryPlot88);
        categoryPlot60.setAxisOffset(rectangleInsets80);
        org.jfree.chart.title.TextTitle textTitle96 = new org.jfree.chart.title.TextTitle("RectangleEdge.RIGHT", font5, paint29, rectangleEdge30, horizontalAlignment31, verticalAlignment54, rectangleInsets80);
        java.awt.Graphics2D graphics2D97 = null;
        java.awt.geom.Rectangle2D rectangle2D98 = null;
        textTitle96.draw(graphics2D97, rectangle2D98);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(blockBorder38);
        org.junit.Assert.assertNotNull(legendItemSourceArray40);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(blockBorder51);
        org.junit.Assert.assertNotNull(legendItemSourceArray53);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertNull(categoryAxis61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 2.0d + "'", double68 == 2.0d);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 3.0d + "'", double82 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis89);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(categoryAnchor93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }
}

