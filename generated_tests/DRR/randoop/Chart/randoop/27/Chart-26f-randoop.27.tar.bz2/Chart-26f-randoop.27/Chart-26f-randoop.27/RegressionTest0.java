import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 'a', (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (97.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = null;
        java.awt.Paint paint9 = null;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Paint paint14 = null;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "", true, shape5, false, paint7, false, paint9, stroke10, true, shape12, stroke13, paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            legendTitle1.setMargin(rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Color color0 = java.awt.Color.GRAY;
        float[] floatArray3 = new float[] { (byte) 1, 100L };
        try {
            float[] floatArray4 = color0.getComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicAnchor();
        java.lang.String str3 = rectangleAnchor2.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleAnchor.CENTER" + "'", str3.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "hi!", keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        try {
            legendTitle1.setLegendItemGraphicEdge(rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "May" + "'", str1.equals("May"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle4.getLegendItemGraphicAnchor();
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 100.0d, (double) 0.0f, rectangleAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        double double6 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        java.awt.Paint paint9 = stackedAreaRenderer1.getItemOutlinePaint(0, (int) (short) 100);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        stackedAreaRenderer11.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator13, false);
        java.awt.Paint paint18 = stackedAreaRenderer11.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "May", paint9, stroke10, paint18, stroke19, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        try {
            stackedAreaRenderer0.setSeriesItemLabelGenerator((int) (short) -1, categoryItemLabelGenerator9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.awt.Stroke stroke2 = null;
        try {
            dateAxis1.setAxisLineStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        try {
            xYPlot7.zoomRangeAxes((double) (short) 100, 2.0d, plotRenderingInfo12, point2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (2.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 10, (float) 100L, 100.0d, (float) 100, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot9.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        try {
            ganttRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot9, categoryAxis11, valueAxis12, categoryDataset13, 0, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 100, textBlock1, textBlockAnchor2, textAnchor3, (double) (-2208960000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Stroke stroke0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        dateAxis1.setLabelURL("");
        java.util.Date date7 = null;
        java.util.Date date8 = null;
        try {
            dateAxis1.setRange(date7, date8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("May", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape1, "May", "May");
        java.awt.Shape shape5 = null;
        try {
            tickLabelEntity4.setArea(shape5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, 0.0d, (double) 0.0f, (double) ' ', 1.0d, font5);
        java.awt.Graphics2D graphics2D7 = null;
        double double8 = markerAxisBand6.getHeight(graphics2D7);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke11, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot7.getDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = null;
        try {
            xYPlot7.setDatasetRenderingOrder(datasetRenderingOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.util.Date date0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            org.jfree.chart.axis.DateTick dateTick5 = new org.jfree.chart.axis.DateTick(date0, "", textAnchor2, textAnchor3, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("May", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeGridlinePaint();
        java.awt.Paint paint9 = null;
        try {
            xYPlot7.setRangeGridlinePaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        xYPlot7.drawAnnotations(graphics2D20, rectangle2D21, plotRenderingInfo22);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("RectangleAnchor.CENTER", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CrosshairState crosshairState21 = null;
        boolean boolean22 = xYPlot7.render(graphics2D17, rectangle2D18, (int) '#', plotRenderingInfo20, crosshairState21);
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint25, stroke26, paint27, stroke28, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryMarker30.getLabelOffset();
        org.jfree.chart.util.Layer layer32 = null;
        try {
            xYPlot7.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) categoryMarker30, layer32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        boolean boolean1 = stackedBarRenderer3D0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int8 = stackedAreaRenderer0.getPassCount();
        stackedAreaRenderer0.setBaseSeriesVisibleInLegend(true, false);
        boolean boolean12 = stackedAreaRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        java.lang.Object obj3 = dateAxis1.clone();
        java.awt.Font font4 = dateAxis1.getTickLabelFont();
        java.lang.String str5 = dateAxis1.getLabelToolTip();
        dateAxis1.setAutoRangeMinimumSize((double) 5, true);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        stackedAreaRenderer0.setSeriesCreateEntities((int) (short) 10, (java.lang.Boolean) false, false);
        org.jfree.chart.LegendItem legendItem7 = stackedAreaRenderer0.getLegendItem((int) (short) 1, (int) '#');
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 10, 0.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.chart.axis.DateTickUnit.YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Color color0 = java.awt.Color.white;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) color0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        boolean boolean7 = dateAxis5.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis5, xYItemRenderer8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot9.markerChanged(markerChangeEvent10);
        int int12 = xYPlot9.getWeight();
        java.awt.Stroke stroke13 = xYPlot9.getRangeCrosshairStroke();
        stackedAreaRenderer1.setBaseStroke(stroke13);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            categoryPlot5.handleClick(0, (int) (byte) 100, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        java.util.Locale locale1 = null;
//        java.lang.Class class2 = null;
//        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
//        java.util.ResourceBundle.Control control4 = null;
//        try {
//            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("May", locale1, classLoader3, control4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader3);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            categoryPlot5.draw(graphics2D8, rectangle2D9, point2D10, plotState11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis7);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone4);
        dateAxis1.setStandardTickUnits(tickUnitSource5);
        dateAxis1.setFixedAutoRange((double) 100.0f);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double12 = dateAxis1.java2DToValue(0.0d, rectangle2D10, rectangleEdge11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            xYPlot7.drawBackground(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray8 = legendTitle1.getSources();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        try {
            legendTitle1.setHorizontalAlignment(horizontalAlignment9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
        org.junit.Assert.assertNotNull(legendItemSourceArray8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Paint paint0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        boolean boolean2 = stackedBarRenderer3D1.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        boolean boolean3 = dateAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone4);
        dateAxis1.setStandardTickUnits(tickUnitSource5);
        dateAxis1.setFixedAutoRange((double) 100.0f);
        try {
            dateAxis1.setAutoRangeMinimumSize((double) (short) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D0.setSeriesItemLabelFont((int) (byte) 100, font4);
        java.awt.Stroke stroke7 = stackedBarRenderer3D0.lookupSeriesOutlineStroke((int) ' ');
        stackedBarRenderer3D0.setDrawBarOutline(false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.awt.Font font20 = null;
        try {
            dateAxis14.setTickLabelFont(font20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Following" + "'", str1.equals("Following"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint1, stroke2, paint3, stroke4, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryMarker6.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets7.createInsetRectangle(rectangle2D8, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D0.setSeriesItemLabelFont((int) (byte) 100, font4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        int int16 = xYPlot13.getWeight();
        java.awt.Stroke stroke17 = xYPlot13.getRangeCrosshairStroke();
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot13);
        try {
            java.awt.Paint paint20 = xYPlot13.getQuadrantPaint(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        xYPlot7.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation20 = null;
        try {
            boolean boolean21 = xYPlot7.removeAnnotation(xYAnnotation20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.renderer.OutlierListCollection outlierListCollection0 = new org.jfree.chart.renderer.OutlierListCollection();
        outlierListCollection0.setLowFarOut(false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("hi!");
        float float2 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke7 = null;
        stackedAreaRenderer0.setSeriesStroke((int) (byte) 1, stroke7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = null;
        stackedAreaRenderer0.setSeriesNegativeItemLabelPosition(9999, itemLabelPosition10, true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        ganttRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator2);
        ganttRenderer0.setStartPercent(0.05d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double[] doubleArray6 = new double[] { 1L, 7, (short) 100, 10, 0.0d, (byte) 10 };
        double[] doubleArray13 = new double[] { 1L, 7, (short) 100, 10, 0.0d, (byte) 10 };
        double[] doubleArray20 = new double[] { 1L, 7, (short) 100, 10, 0.0d, (byte) 10 };
        double[][] doubleArray21 = new double[][] { doubleArray6, doubleArray13, doubleArray20 };
        double[] doubleArray28 = new double[] { 0.0d, '4', (short) 10, ' ', 10, (byte) -1 };
        double[][] doubleArray29 = new double[][] { doubleArray28 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset30 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray21, doubleArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Shape shape0 = null;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        java.awt.Paint paint8 = stackedAreaRenderer1.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape0, paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        double double6 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedAreaRenderer7.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator9, false);
        java.awt.Paint paint14 = stackedAreaRenderer7.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer1.setBaseFillPaint(paint14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint17, stroke18, paint19, stroke20, (float) 1L);
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.Stroke stroke24 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint14, stroke18, (java.awt.Paint) color23, stroke24, 1.0f);
        int int27 = color23.getBlue();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 255 + "'", int27 == 255);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bottom' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        try {
            dateAxis3.setRangeWithMargins((double) (short) 10, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape1, "May", "May");
        java.lang.String str5 = tickLabelEntity4.getShapeCoords();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity10 = new org.jfree.chart.entity.TickLabelEntity(shape7, "May", "May");
        tickLabelEntity4.setArea(shape7);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0,-1,1,1,-1,1,-1,1" + "'", str5.equals("0,-1,1,1,-1,1,-1,1"));
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("May", font1);
        java.awt.Paint paint3 = textFragment2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        int int6 = categoryPlot5.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint1, stroke2, paint3, stroke4, (float) 1L);
        java.awt.Paint paint7 = categoryMarker6.getLabelPaint();
        java.awt.Font font8 = null;
        try {
            categoryMarker6.setLabelFont(font8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("RectangleAnchor.CENTER", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot5.markerChanged(markerChangeEvent10);
        categoryPlot5.setRangeCrosshairValue((double) 15);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot5.setDataset((int) ' ', categoryDataset15);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false, true);
        stackedAreaRenderer0.setBaseCreateEntities(true, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        stackedAreaRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator11, false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        dateAxis3.setLabel("");
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-451) + "'", int1 == (-451));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        xYPlot7.clearDomainMarkers();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Color color0 = java.awt.Color.yellow;
        java.awt.Color color1 = java.awt.Color.GRAY;
        float[] floatArray5 = new float[] { 3, (-1.0f), 100L };
        float[] floatArray6 = color1.getColorComponents(floatArray5);
        try {
            float[] floatArray7 = color0.getRGBComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Color color1 = java.awt.Color.getColor("0,-1,1,1,-1,1,-1,1");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        int int20 = xYPlot7.getRangeAxisIndex(valueAxis13);
        xYPlot7.clearAnnotations();
        xYPlot7.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        xYPlot7.setRangeAxisLocation((int) (short) 1, axisLocation24);
        java.lang.Object obj26 = xYPlot7.clone();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        java.text.NumberFormat numberFormat1 = intervalCategoryToolTipGenerator0.getNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) 0.65d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Paint paint17 = xYPlot7.getRangeTickBandPaint();
        java.awt.Paint paint18 = null;
        try {
            xYPlot7.setRangeCrosshairPaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        boolean boolean8 = dateAxis3.isVisible();
        org.jfree.chart.axis.Timeline timeline9 = null;
        dateAxis3.setTimeline(timeline9);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        categoryPlot9.setRangeGridlinesVisible(false);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryPlot9.setDomainGridlinePaint(paint12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setAutoTickUnitSelection(false, true);
        dateAxis16.setLabelURL("");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, (java.lang.Comparable) "Following");
        try {
            groupedStackedBarRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D3, categoryPlot9, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset22, (int) (short) 1, 5, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(pieDataset25);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        boolean boolean25 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot7.getOrientation();
        java.lang.String str27 = plotOrientation26.toString();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "PlotOrientation.VERTICAL" + "'", str27.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            categoryPlot6.handleClick(0, (int) (byte) 10, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        stackedBarRenderer3D0.setItemMargin((double) 100);
        double double5 = stackedBarRenderer3D0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        boolean boolean8 = dateAxis3.isVisible();
        float float9 = dateAxis3.getTickMarkOutsideLength();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge12);
        try {
            double double14 = dateAxis3.valueToJava2D((double) (short) 0, rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "May", "May");
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape8, shape10);
        dateAxis5.setRightArrow(shape10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedAreaRenderer16.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator18, false);
        double double21 = stackedAreaRenderer16.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedAreaRenderer22.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator24, false);
        java.awt.Paint paint29 = stackedAreaRenderer22.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer16.setBaseFillPaint(paint29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D31.setSeriesItemLabelFont((int) (byte) 100, font35);
        java.awt.Stroke stroke38 = stackedBarRenderer3D31.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape10, paint29, stroke38, (java.awt.Paint) color39);
        legendItem40.setSeriesIndex((int) (short) 0);
        java.lang.Comparable comparable43 = legendItem40.getSeriesKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, (java.lang.Comparable) "Following");
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, true);
        legendItem40.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(10);
        java.lang.String str54 = spreadsheetDate53.getDescription();
        try {
            defaultCategoryDataset44.incrementValue((double) 1, (java.lang.Comparable) str54, (java.lang.Comparable) 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(comparable43);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNull(str54);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = legendTitle1.getVerticalAlignment();
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle1.removeChangeListener(titleChangeListener3);
        org.junit.Assert.assertNotNull(verticalAlignment2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = org.jfree.chart.axis.DateTickUnit.SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        java.lang.Object obj13 = xYPlot7.clone();
        xYPlot7.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        legendTitle1.setNotify(false);
        legendTitle1.setMargin((double) 10L, (double) 1, (double) (-1), (double) 0L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape11, "May", "May");
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.equal(shape9, shape11);
        dateAxis6.setRightArrow(shape11);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        stackedAreaRenderer17.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator19, false);
        double double22 = stackedAreaRenderer17.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer23 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        stackedAreaRenderer23.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator25, false);
        java.awt.Paint paint30 = stackedAreaRenderer23.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer17.setBaseFillPaint(paint30);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setMaximumBarWidth((double) '#');
        java.awt.Font font36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D32.setSeriesItemLabelFont((int) (byte) 100, font36);
        java.awt.Stroke stroke39 = stackedBarRenderer3D32.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape11, paint30, stroke39, (java.awt.Paint) color40);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone52 = dateAxis51.getTimeZone();
        java.lang.Object obj53 = dateAxis51.clone();
        java.awt.Font font54 = dateAxis51.getTickLabelFont();
        java.lang.String str55 = dateAxis51.getLabelToolTip();
        java.awt.Stroke stroke56 = dateAxis51.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((-1.0d), paint30, stroke42, paint46, stroke56, 0.0f);
        java.io.ObjectOutputStream objectOutputStream59 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke56, objectOutputStream59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle2.getLegendItemGraphicLocation();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        centerArrangement0.add((org.jfree.chart.block.Block) legendTitle2, (java.lang.Object) 10);
        legendTitle2.setWidth((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            polarPlot3.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        xYPlot7.setDomainCrosshairVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        try {
            xYPlot7.zoomRangeAxes((double) 10L, (double) 1L, plotRenderingInfo24, point2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        java.lang.String str8 = categoryPlot5.getPlotType();
        boolean boolean9 = categoryPlot5.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        java.awt.Paint paint8 = stackedAreaRenderer0.getItemOutlinePaint(0, (int) (short) 100);
        boolean boolean9 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int0 = org.jfree.chart.axis.DateTickUnit.DAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleAnchor.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint1, stroke2, paint3, stroke4, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryMarker6.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets7.createAdjustedRectangle(rectangle2D8, lengthAdjustmentType9, lengthAdjustmentType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false, true);
        java.awt.Paint paint10 = stackedAreaRenderer0.getItemPaint((int) (byte) 10, 0);
        java.lang.Boolean boolean12 = stackedAreaRenderer0.getSeriesVisibleInLegend(9999);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot5.markerChanged(markerChangeEvent10);
        categoryPlot5.setAnchorValue((-1.0d), false);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = null;
        try {
            categoryPlot5.setOrientation(plotOrientation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        int int11 = xYPlot8.getWeight();
        java.awt.Stroke stroke12 = xYPlot8.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        dateAxis15.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis15);
        xYPlot8.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone23 = dateAxis22.getTimeZone();
        java.lang.Object obj24 = dateAxis22.clone();
        java.awt.Font font25 = dateAxis22.getTickLabelFont();
        java.lang.String str26 = dateAxis22.getLabelToolTip();
        java.awt.Stroke stroke27 = dateAxis22.getTickMarkStroke();
        dateAxis22.setTickMarkInsideLength((float) 6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer30);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        try {
            xYPlot31.setDomainAxisLocation(axisLocation32, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot5.getDomainGridlinePosition();
        categoryPlot5.clearRangeMarkers();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(categoryAnchor10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(7, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.END;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.END" + "'", str1.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        dateAxis5.setAutoTickUnitSelection(false, true);
        double double9 = dateAxis5.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D10.setMaximumBarWidth((double) '#');
        java.awt.Shape shape13 = stackedBarRenderer3D10.getBaseShape();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset15, categoryAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot20.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint31 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint29, stroke30, paint31, stroke32, (float) 1L);
        java.awt.Paint paint35 = categoryMarker34.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        stackedBarRenderer3D10.drawRangeMarker(graphics2D14, categoryPlot20, (org.jfree.chart.axis.ValueAxis) dateAxis23, (org.jfree.chart.plot.Marker) categoryMarker34, rectangle2D36);
        java.awt.Shape shape38 = dateAxis23.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity41 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis5, shape38, "RectangleAnchor.CENTER", "Following");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer46 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, categoryAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer46);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot47.getDomainAxis();
        java.awt.Paint paint49 = categoryPlot47.getDomainGridlinePaint();
        try {
            org.jfree.chart.LegendItem legendItem50 = new org.jfree.chart.LegendItem(attributedString0, "", "TextAnchor.CENTER", "0,-1,1,1,-1,1,-1,1", shape38, paint49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.setRangeCrosshairVisible(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            categoryPlot6.addAnnotation(categoryAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        int int3 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj4 = defaultCategoryDataset1.clone();
        boolean boolean5 = blockBorder0.equals((java.lang.Object) defaultCategoryDataset1);
        defaultCategoryDataset1.validateObject();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100.0f, 0.05d, (double) 3, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        double double3 = dateAxis1.getLabelAngle();
        java.lang.String str4 = dateAxis1.getLabelToolTip();
        dateAxis1.setLowerMargin((double) (byte) 10);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape8, "RectangleAnchor.CENTER", "0,-1,1,1,-1,1,-1,1");
        dateAxis1.setDownArrow(shape8);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setMaximumBarWidth((double) '#');
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis38);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        java.awt.Paint paint50 = categoryMarker49.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedBarRenderer3D25.drawRangeMarker(graphics2D29, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.plot.Marker) categoryMarker49, rectangle2D51);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer53 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator55 = null;
        stackedAreaRenderer53.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator55, false);
        java.awt.Paint paint60 = stackedAreaRenderer53.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker49.setOutlinePaint(paint60);
        xYPlot7.setDomainGridlinePaint(paint60);
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        try {
            xYPlot7.setRangeAxis((-451), valueAxis64, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("May", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            float float5 = textFragment2.calculateBaselineOffset(graphics2D3, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        objectList1.clear();
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = legendTitle2.getMargin();
        boolean boolean4 = sortOrder0.equals((java.lang.Object) legendTitle2);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        java.awt.Paint paint2 = ganttRenderer0.getCompletePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        java.lang.Object obj1 = standardCategoryURLGenerator0.clone();
        java.lang.Object obj2 = standardCategoryURLGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        int int20 = xYPlot7.getRangeAxisIndex(valueAxis13);
        xYPlot7.clearAnnotations();
        xYPlot7.clearDomainMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace23 = xYPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder24 = null;
        try {
            xYPlot7.setSeriesRenderingOrder(seriesRenderingOrder24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNull(axisSpace23);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 100L, (double) 1L, false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("PlotOrientation.VERTICAL", graphics2D1, (double) 8, (float) (byte) 0, (float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Point2D point2D10 = null;
        org.jfree.chart.plot.PlotState plotState11 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            xYPlot7.draw(graphics2D8, rectangle2D9, point2D10, plotState11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.setAngleLabelsVisible(false);
        java.awt.Paint paint8 = polarPlot3.getRadiusGridlinePaint();
        try {
            polarPlot3.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        boolean boolean4 = dateAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        java.lang.Class class1 = null;
//        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
//        org.junit.Assert.assertNotNull(uRL2);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        stackedBarRenderer3D0.setItemMargin((double) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = stackedBarRenderer3D0.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer12);
        categoryPlot13.setRangeGridlinesVisible(false);
        boolean boolean16 = stackedBarRenderer3D7.hasListener((java.util.EventListener) categoryPlot13);
        categoryPlot13.setRangeCrosshairVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone22 = dateAxis21.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone22);
        boolean boolean25 = dateAxis24.isAutoRange();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            stackedBarRenderer3D0.drawRangeGridline(graphics2D6, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis24, rectangle2D26, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        xYPlot7.clearRangeMarkers((int) (short) 100);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) (short) 1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        defaultCategoryDataset0.removeChangeListener(datasetChangeListener4);
        try {
            defaultCategoryDataset0.removeRow((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNotNull(pieDataset3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Date date8 = dateAxis6.getMinimumDate();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date4, date8);
        task9.setPercentComplete((java.lang.Double) 2.0d);
        try {
            org.jfree.data.gantt.Task task13 = task9.getSubtask(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "May", "May");
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape8, shape10);
        dateAxis5.setRightArrow(shape10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedAreaRenderer16.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator18, false);
        double double21 = stackedAreaRenderer16.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedAreaRenderer22.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator24, false);
        java.awt.Paint paint29 = stackedAreaRenderer22.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer16.setBaseFillPaint(paint29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D31.setSeriesItemLabelFont((int) (byte) 100, font35);
        java.awt.Stroke stroke38 = stackedBarRenderer3D31.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape10, paint29, stroke38, (java.awt.Paint) color39);
        legendItem40.setSeriesIndex((int) (short) 0);
        java.lang.Comparable comparable43 = legendItem40.getSeriesKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, (java.lang.Comparable) "Following");
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, true);
        legendItem40.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset44);
        java.awt.Paint paint51 = legendItem40.getLinePaint();
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(comparable43);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge1);
        try {
            double double3 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        stackedBarRenderer3D0.setItemMargin((double) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = stackedBarRenderer3D0.getGradientPaintTransformer();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = stackedBarRenderer3D0.getLegendItems();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot15.getDomainAxis();
        java.awt.Paint paint17 = categoryPlot15.getDomainGridlinePaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot15.setRangeGridlineStroke(stroke18);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = null;
        categoryPlot15.markerChanged(markerChangeEvent20);
        categoryPlot15.setAnchorValue((-1.0d), false);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone30 = dateAxis29.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource31 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone30);
        dateAxis27.setStandardTickUnits(tickUnitSource31);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset33 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number34 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset33);
        try {
            stackedBarRenderer3D0.drawItem(graphics2D7, categoryItemRendererState8, rectangle2D9, categoryPlot15, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset33, 0, 3, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(tickUnitSource31);
        org.junit.Assert.assertNull(number34);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot5.markerChanged(markerChangeEvent10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot5.getRenderer();
        java.awt.Paint paint15 = categoryPlot5.getDomainGridlinePaint();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Date date8 = dateAxis6.getMinimumDate();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date4, date8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        java.util.Date date14 = dateAxis12.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone17 = dateAxis16.getTimeZone();
        java.util.Date date18 = dateAxis16.getMinimumDate();
        org.jfree.data.gantt.Task task19 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date14, date18);
        task9.addSubtask(task19);
        int int21 = task19.getSubtaskCount();
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        boolean boolean23 = task19.equals((java.lang.Object) font22);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 9999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) (-1));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMedianValue((int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.setRangeCrosshairVisible(false);
        categoryPlot6.mapDatasetToRangeAxis(3, 0);
        int int15 = categoryPlot6.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot6.setDomainAxis((int) '#', categoryAxis17, true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer15);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        int int19 = xYPlot16.getWeight();
        java.awt.Stroke stroke20 = xYPlot16.getRangeCrosshairStroke();
        int int21 = xYPlot16.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        int int28 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis23);
        int int29 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis23);
        java.awt.Color color31 = java.awt.Color.cyan;
        java.awt.Paint paint33 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint33, stroke34, paint35, stroke36, (float) 1L);
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color31, stroke36);
        xYPlot7.setRangeCrosshairPaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.setRangeCrosshairVisible(false);
        categoryPlot6.mapDatasetToRangeAxis(3, 0);
        int int15 = categoryPlot6.getRangeAxisCount();
        boolean boolean16 = categoryPlot6.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 10.0f);
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer3 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double4 = ganttRenderer3.getEndPercent();
        double double5 = ganttRenderer3.getMaximumBarWidth();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = ganttRenderer3.getGradientPaintTransformer();
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer6);
        intervalMarker2.setStartValue(2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.65d + "'", double4 == 0.65d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        java.lang.Object obj2 = defaultKeyedValues0.clone();
        try {
            defaultKeyedValues0.insertValue(8, (java.lang.Comparable) 10.0f, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        double double6 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedAreaRenderer7.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator9, false);
        java.awt.Paint paint14 = stackedAreaRenderer7.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer1.setBaseFillPaint(paint14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint17, stroke18, paint19, stroke20, (float) 1L);
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.Stroke stroke24 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint14, stroke18, (java.awt.Paint) color23, stroke24, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot32.getDomainAxis();
        java.awt.Paint paint34 = categoryPlot32.getDomainGridlinePaint();
        categoryMarker26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot32);
        java.util.List list36 = categoryPlot32.getAnnotations();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone41 = dateAxis40.getTimeZone();
        boolean boolean42 = dateAxis40.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, (org.jfree.chart.axis.ValueAxis) dateAxis40, xYItemRenderer43);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer45 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = null;
        stackedAreaRenderer45.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator47, false);
        double double50 = stackedAreaRenderer45.getItemLabelAnchorOffset();
        java.awt.Paint paint53 = stackedAreaRenderer45.getItemOutlinePaint(0, (int) (short) 100);
        xYPlot44.setOutlinePaint(paint53);
        categoryPlot32.setRangeCrosshairPaint(paint53);
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        try {
            categoryPlot32.drawBackground(graphics2D56, rectangle2D57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        double double2 = ganttRenderer0.getMaximumBarWidth();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = ganttRenderer0.getGradientPaintTransformer();
        ganttRenderer0.setItemMargin(0.0d);
        java.awt.Paint paint7 = ganttRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Color color10 = java.awt.Color.getColor("0,-1,1,1,-1,1,-1,1", 10);
        ganttRenderer0.setIncompletePaint((java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        boolean boolean25 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot7.getOrientation();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        xYPlot7.setDataset(xYDataset27);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(plotOrientation26);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        java.lang.Boolean boolean9 = stackedAreaRenderer0.getSeriesVisible((int) '4');
        stackedAreaRenderer0.setBaseSeriesVisible(false, false);
        stackedAreaRenderer0.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicAnchor();
        boolean boolean4 = rectangleAnchor2.equals((java.lang.Object) 1.0d);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str7 = textAnchor6.toString();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor5, textAnchor6, (double) 1, categoryLabelWidthType9, (float) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.CENTER" + "'", str7.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot(xYDataset6, valueAxis7, polarItemRenderer8);
        polarPlot9.removeCornerTextItem("");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        axisSpace15.ensureAtLeast(axisSpace16);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace18 = dateAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) polarPlot9, rectangle2D12, rectangleEdge13, axisSpace15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        xYPlot7.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot7.setDomainAxisLocation((int) (short) 1, axisLocation21);
        java.awt.Paint paint23 = xYPlot7.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        dateAxis25.resizeRange(0.05d, 0.0d);
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone34 = dateAxis33.getTimeZone();
        boolean boolean35 = dateAxis33.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset30, valueAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, xYItemRenderer36);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent38 = null;
        xYPlot37.markerChanged(markerChangeEvent38);
        int int40 = xYPlot37.getWeight();
        java.awt.Stroke stroke41 = xYPlot37.getRangeCrosshairStroke();
        int int42 = xYPlot37.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        dateAxis44.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis44);
        int int49 = xYPlot37.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        xYPlot37.setDomainCrosshairVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot37.setDomainAxisLocation(axisLocation52);
        xYPlot7.setDomainAxisLocation(axisLocation52, false);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(axisLocation52);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Color color1 = java.awt.Color.cyan;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint3, stroke4, paint5, stroke6, (float) 1L);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color1, stroke6);
        float[] floatArray10 = null;
        float[] floatArray11 = color1.getRGBColorComponents(floatArray10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        double double2 = ganttRenderer0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer3 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        stackedAreaRenderer3.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator5, false);
        double double8 = stackedAreaRenderer3.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        stackedAreaRenderer9.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator11, false);
        java.awt.Paint paint16 = stackedAreaRenderer9.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer3.setBaseFillPaint(paint16);
        boolean boolean18 = ganttRenderer0.equals((java.lang.Object) paint16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        categoryPlot5.markerChanged(markerChangeEvent10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot5.getRenderer();
        categoryPlot5.mapDatasetToRangeAxis(13, 2);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(categoryItemRenderer14);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        int int3 = java.awt.Color.HSBtoRGB((float) 'a', 0.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.awt.Paint paint2 = dateAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint1, stroke2, paint3, stroke4, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryMarker6.getLabelOffset();
        double double9 = rectangleInsets7.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset10 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset10, categoryAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer14);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot15.getDomainAxis();
        java.awt.Paint paint17 = categoryPlot15.getDomainGridlinePaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot15.setRangeGridlineStroke(stroke18);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot15.getDomainGridlinePosition();
        boolean boolean21 = rectangleInsets7.equals((java.lang.Object) categoryPlot15);
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        org.jfree.chart.LegendItemSource legendItemSource24 = null;
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle(legendItemSource24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = legendTitle25.getLegendItemGraphicAnchor();
        legendTitle23.setLegendItemGraphicLocation(rectangleAnchor26);
        org.jfree.chart.block.BlockBorder blockBorder28 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle23.setFrame((org.jfree.chart.block.BlockFrame) blockBorder28);
        legendTitle23.setHeight((double) ' ');
        boolean boolean32 = rectangleInsets7.equals((java.lang.Object) legendTitle23);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(blockBorder28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.setRangeCrosshairVisible(false);
        categoryPlot6.mapDatasetToRangeAxis(3, 0);
        int int15 = categoryPlot6.getRangeAxisCount();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            categoryPlot6.drawBackground(graphics2D16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        double double3 = dateAxis1.getLabelAngle();
        java.lang.String str4 = dateAxis1.getLabelToolTip();
        dateAxis1.setLowerMargin((double) (byte) 10);
        dateAxis1.setFixedAutoRange((double) 100);
        boolean boolean9 = dateAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Shape shape17 = null;
        try {
            dateAxis13.setLeftArrow(shape17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setMaximumBarWidth((double) '#');
        java.awt.Shape shape6 = stackedBarRenderer3D3.getBaseShape();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot13.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis16);
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint22, stroke23, paint24, stroke25, (float) 1L);
        java.awt.Paint paint28 = categoryMarker27.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D7, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.plot.Marker) categoryMarker27, rectangle2D29);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = null;
        stackedAreaRenderer31.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator33, false);
        java.awt.Paint paint38 = stackedAreaRenderer31.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker27.setOutlinePaint(paint38);
        java.awt.Paint paint40 = null;
        categoryMarker27.setOutlinePaint(paint40);
        java.awt.Paint paint42 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryMarker27.setLabelPaint(paint42);
        objectList1.set(15, (java.lang.Object) categoryMarker27);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1577865599999L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) 0.0f);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        java.lang.String str4 = rectangleConstraint2.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]" + "'", str4.equals("RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        java.lang.String str5 = rectangleEdge4.toString();
        try {
            java.util.List list6 = numberAxis3D0.refreshTicks(graphics2D1, axisState2, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleEdge.RIGHT" + "'", str5.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        xYPlot7.setDomainCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent22 = null;
        xYPlot7.datasetChanged(datasetChangeEvent22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = null;
        java.awt.Font font29 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis24, 0.0d, (double) 0.0f, (double) ' ', 1.0d, font29);
        xYPlot7.setNoDataMessageFont(font29);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = null;
        try {
            defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        xYPlot8.markerChanged(markerChangeEvent9);
        int int11 = xYPlot8.getWeight();
        java.awt.Stroke stroke12 = xYPlot8.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        dateAxis15.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis15);
        xYPlot8.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis15);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone23 = dateAxis22.getTimeZone();
        java.lang.Object obj24 = dateAxis22.clone();
        java.awt.Font font25 = dateAxis22.getTickLabelFont();
        java.lang.String str26 = dateAxis22.getLabelToolTip();
        java.awt.Stroke stroke27 = dateAxis22.getTickMarkStroke();
        dateAxis22.setTickMarkInsideLength((float) 6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.axis.ValueAxis) dateAxis22, xYItemRenderer30);
        java.awt.Stroke stroke32 = dateAxis15.getTickMarkStroke();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(9, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem3 = defaultBoxAndWhiskerCategoryDataset0.getItem((-451), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -451");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot5.setRangeGridlineStroke(stroke8);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke12 = stackedBarRenderer3D10.lookupSeriesStroke(11);
        stackedBarRenderer3D10.setItemMargin((double) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = stackedBarRenderer3D10.getGradientPaintTransformer();
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D10);
        categoryPlot5.configureDomainAxes();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CrosshairState crosshairState21 = null;
        boolean boolean22 = xYPlot7.render(graphics2D17, rectangle2D18, (int) '#', plotRenderingInfo20, crosshairState21);
        double double23 = xYPlot7.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.clearRangeAxes();
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis13 = categoryPlot6.getRangeAxisForDataset((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        java.lang.Object obj13 = xYPlot7.clone();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray15 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer14 };
        xYPlot7.setRenderers(xYItemRendererArray15);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(xYItemRendererArray15);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        boolean boolean25 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone30 = dateAxis29.getTimeZone();
        boolean boolean31 = dateAxis29.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer32);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent34 = null;
        xYPlot33.markerChanged(markerChangeEvent34);
        int int36 = xYPlot33.getWeight();
        java.awt.Stroke stroke37 = xYPlot33.getRangeCrosshairStroke();
        int int38 = xYPlot33.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("");
        dateAxis40.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent44 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis40);
        int int45 = xYPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis40);
        java.awt.Paint paint47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint47, stroke48, paint49, stroke50, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryMarker52.getLabelOffset();
        dateAxis40.setTickLabelInsets(rectangleInsets53);
        xYPlot7.setAxisOffset(rectangleInsets53);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleInsets53);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Third" + "'", str1.equals("Third"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        int int2 = defaultKeyedValues0.getIndex((java.lang.Comparable) (byte) 1);
        defaultKeyedValues0.removeValue((java.lang.Comparable) 3);
        try {
            defaultKeyedValues0.insertValue((-1), (java.lang.Comparable) 0.0f, (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Date date8 = dateAxis6.getMinimumDate();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date4, date8);
        task9.setPercentComplete((java.lang.Double) 2.0d);
        java.lang.Double double12 = task9.getPercentComplete();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.0d + "'", double12.equals(2.0d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        java.awt.Paint paint8 = stackedAreaRenderer1.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int9 = stackedAreaRenderer1.getPassCount();
        boolean boolean10 = stackedAreaRenderer1.getRenderAsPercentages();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        java.awt.Font font16 = dateAxis13.getTickLabelFont();
        stackedAreaRenderer1.setSeriesItemLabelFont(15, font16, false);
        java.awt.Paint paint19 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer21 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock22 = org.jfree.chart.text.TextUtilities.createTextBlock("0,-1,1,1,-1,1,-1,1", font16, paint19, 2.0f, textMeasurer21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean8 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedAreaRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        stackedAreaRenderer12.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator14, false);
        double double17 = stackedAreaRenderer12.getItemLabelAnchorOffset();
        java.awt.Paint paint20 = stackedAreaRenderer12.getItemOutlinePaint(0, (int) (short) 100);
        boolean boolean21 = itemLabelPosition11.equals((java.lang.Object) stackedAreaRenderer12);
        stackedAreaRenderer12.setSeriesVisibleInLegend(15, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean6 = textAnchor4.equals((java.lang.Object) "RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]");
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str9 = textAnchor8.toString();
        try {
            java.awt.Shape shape10 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.CENTER", graphics2D1, 0.0f, (float) 'a', textAnchor4, 0.0d, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.CENTER" + "'", str9.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle2.getLegendItemGraphicLocation();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        centerArrangement0.add((org.jfree.chart.block.Block) legendTitle2, (java.lang.Object) 10);
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = legendTitle10.getLegendItemGraphicAnchor();
        legendTitle8.setLegendItemGraphicLocation(rectangleAnchor11);
        org.jfree.chart.block.BlockBorder blockBorder13 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle8.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone19 = dateAxis18.getTimeZone();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer21);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent23 = null;
        xYPlot22.markerChanged(markerChangeEvent23);
        int int25 = xYPlot22.getWeight();
        java.awt.Stroke stroke26 = xYPlot22.getRangeCrosshairStroke();
        centerArrangement0.add((org.jfree.chart.block.Block) legendTitle8, (java.lang.Object) stroke26);
        legendTitle8.setMargin((double) (short) 1, 3.0d, (double) ' ', (double) 255);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(blockBorder13);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("Following", "", "RectangleAnchor.CENTER", image3, "May", "0,-1,1,1,-1,1,-1,1", "0,-1,1,1,-1,1,-1,1");
        java.lang.String str8 = projectInfo7.getCopyright();
        java.awt.Image image9 = null;
        projectInfo7.setLogo(image9);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "May" + "'", str8.equals("May"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot5.getDomainMarkers(layer8);
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        int int13 = defaultCategoryDataset11.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj14 = defaultCategoryDataset11.clone();
        boolean boolean15 = blockBorder10.equals((java.lang.Object) defaultCategoryDataset11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot5.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        int int18 = defaultCategoryDataset11.getColumnIndex((java.lang.Comparable) 5);
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.removeCornerTextItem("Following");
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        boolean boolean4 = dateAxis2.isVerticalTickLabels();
        java.util.Date date5 = dateAxis2.getMinimumDate();
        java.util.TimeZone timeZone6 = null;
        try {
            java.util.Date date7 = dateTickUnit0.rollDate(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 1.0f, (double) 900000L, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYPlot7.setDomainZeroBaselinePaint(paint8);
        xYPlot7.setDomainGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        xYPlot7.zoomRangeAxes((double) (short) 100, plotRenderingInfo13, point2D14);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        java.lang.Boolean boolean9 = stackedAreaRenderer0.getSeriesVisible((int) '4');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = stackedAreaRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        int int1 = defaultKeyedValues0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) 0.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0f, jFreeChart3, chartChangeEventType4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = chartChangeEvent5.getType();
        org.junit.Assert.assertNull(chartChangeEventType6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.clearRangeAxes();
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot6.getColumnRenderingOrder();
        float float13 = categoryPlot6.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.clear();
        java.lang.Object obj2 = defaultKeyedValues0.clone();
        int int3 = defaultKeyedValues0.getItemCount();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.data.RangeType rangeType1 = numberAxis3D0.getRangeType();
        java.lang.String str2 = rangeType1.toString();
        org.junit.Assert.assertNotNull(rangeType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RangeType.FULL" + "'", str2.equals("RangeType.FULL"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int8 = stackedAreaRenderer0.getPassCount();
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        stackedAreaRenderer0.setSeriesURLGenerator(3, (org.jfree.chart.urls.CategoryURLGenerator) standardCategoryURLGenerator10, false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.resizeRange(0.05d, 0.0d);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        dateAxis14.setDownArrow(shape19);
        boolean boolean21 = standardCategoryURLGenerator10.equals((java.lang.Object) dateAxis14);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT" + "'", str1.equals("TextBlockAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke2 = stackedBarRenderer3D0.lookupSeriesStroke(11);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset4, categoryAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot9.getDomainAxis();
        java.awt.Paint paint11 = categoryPlot9.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        stackedAreaRenderer12.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator14, false);
        double double17 = stackedAreaRenderer12.getItemLabelAnchorOffset();
        java.awt.Paint paint20 = stackedAreaRenderer12.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot9.setRangeGridlinePaint(paint20);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot9.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone25 = dateAxis24.getTimeZone();
        java.lang.Object obj26 = dateAxis24.clone();
        java.awt.Font font27 = dateAxis24.getTickLabelFont();
        java.lang.String str28 = dateAxis24.getLabelToolTip();
        java.awt.Stroke stroke29 = dateAxis24.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        try {
            stackedBarRenderer3D0.drawRangeGridline(graphics2D3, categoryPlot9, (org.jfree.chart.axis.ValueAxis) dateAxis24, rectangle2D30, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = axisSpace0.expand(rectangle2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = legendTitle2.getLegendItemGraphicLocation();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(10);
        centerArrangement0.add((org.jfree.chart.block.Block) legendTitle2, (java.lang.Object) 10);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        dateAxis9.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis9);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        axisChangeEvent13.setChart(jFreeChart14);
        org.jfree.chart.axis.Axis axis16 = axisChangeEvent13.getAxis();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer19 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        stackedAreaRenderer19.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator21, false);
        double double24 = stackedAreaRenderer19.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer25 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        stackedAreaRenderer25.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator27, false);
        java.awt.Paint paint32 = stackedAreaRenderer25.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer19.setBaseFillPaint(paint32);
        java.awt.Paint paint35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint35, stroke36, paint37, stroke38, (float) 1L);
        java.awt.Color color41 = java.awt.Color.white;
        java.awt.Stroke stroke42 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint32, stroke36, (java.awt.Paint) color41, stroke42, 1.0f);
        boolean boolean45 = chartChangeEventType17.equals((java.lang.Object) categoryMarker44);
        axisChangeEvent13.setType(chartChangeEventType17);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) centerArrangement0, jFreeChart7, chartChangeEventType17);
        centerArrangement0.clear();
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(axis16);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.0d + "'", double24 == 2.0d);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setLabelToolTip("HorizontalAlignment.RIGHT");
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = null;
        numberAxis3D0.setMarkerBand(markerAxisBand1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean4 = numberAxis3D0.equals((java.lang.Object) chartChangeEventType3);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        int int20 = xYPlot7.getRangeAxisIndex(valueAxis13);
        xYPlot7.clearAnnotations();
        xYPlot7.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke25 = stackedBarRenderer3D23.lookupSeriesStroke(11);
        xYPlot7.setRangeCrosshairStroke(stroke25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot7.getDomainAxisEdge((int) 'a');
        java.awt.Paint paint29 = xYPlot7.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (short) 100, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.05).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot6.getDomainMarkers(layer10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent12);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("May", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("Following", "", "RectangleAnchor.CENTER", image3, "May", "0,-1,1,1,-1,1,-1,1", "0,-1,1,1,-1,1,-1,1");
        java.lang.String str8 = projectInfo7.getCopyright();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        stackedAreaRenderer10.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator12, false);
        double double15 = stackedAreaRenderer10.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedAreaRenderer16.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator18, false);
        java.awt.Paint paint23 = stackedAreaRenderer16.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer10.setBaseFillPaint(paint23);
        java.awt.Paint paint26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint26, stroke27, paint28, stroke29, (float) 1L);
        java.awt.Color color32 = java.awt.Color.white;
        java.awt.Stroke stroke33 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint23, stroke27, (java.awt.Paint) color32, stroke33, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer40 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer40);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot41.getDomainAxis();
        java.awt.Paint paint43 = categoryPlot41.getDomainGridlinePaint();
        categoryMarker35.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot41);
        java.util.List list45 = categoryPlot41.getAnnotations();
        projectInfo7.setContributors(list45);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "May" + "'", str8.equals("May"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(list45);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(1, 31);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range5 = dateAxis1.getDefaultAutoRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range5);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        boolean boolean2 = unitType0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        java.awt.Shape shape28 = dateAxis13.getDownArrow();
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range31);
        double double33 = range31.getLowerBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType34 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        dateAxis37.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range41 = dateAxis37.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType42 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) 86400000L, range31, lengthConstraintType34, 3.0d, range41, lengthConstraintType42);
        dateAxis13.setDefaultAutoRange(range31);
        boolean boolean47 = range31.intersects(0.0d, (double) (byte) 1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType34);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(lengthConstraintType42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint21, stroke22, paint23, stroke24, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryMarker26.getLabelOffset();
        dateAxis14.setTickLabelInsets(rectangleInsets27);
        double double30 = rectangleInsets27.calculateLeftOutset((double) 2019L);
        double double32 = rectangleInsets27.trimWidth((double) 13);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30 == 3.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 7.0d + "'", double32 == 7.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        boolean boolean3 = dateAxis1.isVerticalTickLabels();
        java.util.Date date4 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        dateAxis1.setTickUnit(dateTickUnit5);
        dateAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        int int2 = year0.getYear();
        long long3 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeVisible(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape1, "RectangleAnchor.CENTER", "0,-1,1,1,-1,1,-1,1");
        java.lang.Object obj5 = chartEntity4.clone();
        chartEntity4.setToolTipText("Category Plot");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) 0.0f);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.data.Range range4 = rectangleConstraint2.getHeightRange();
        double double5 = rectangleConstraint2.getHeight();
        double double6 = rectangleConstraint2.getHeight();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        xYPlot7.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot7.setDomainAxisLocation((int) (short) 1, axisLocation21);
        java.awt.Paint paint23 = xYPlot7.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot7.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "", image3, "Following", "TextAnchor.CENTER", "hi!");
        projectInfo7.setInfo("RectangleAnchor.CENTER");
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((-1.0d), (double) 255, 0.0d, (double) 9);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.setAngleLabelsVisible(false);
        java.awt.Paint paint8 = polarPlot3.getRadiusGridlinePaint();
        java.awt.Paint paint9 = polarPlot3.getRadiusGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        polarPlot13.removeCornerTextItem("");
        polarPlot13.setAngleLabelsVisible(false);
        java.awt.Paint paint18 = polarPlot13.getRadiusGridlinePaint();
        java.awt.Paint paint19 = polarPlot13.getRadiusGridlinePaint();
        polarPlot3.setAngleLabelPaint(paint19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        polarPlot3.setDataset(xYDataset21);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (double) '#');
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range5 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setAutoRangeMinimumSize((double) 1577865599999L);
        dateAxis1.setAutoRangeMinimumSize((double) 11);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        double double2 = ganttRenderer0.getMaximumBarWidth();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = null;
        ganttRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double[] doubleArray4 = new double[] { 900000L, 13, 1900, 0.65d };
        double[] doubleArray9 = new double[] { 900000L, 13, 1900, 0.65d };
        double[] doubleArray14 = new double[] { 900000L, 13, 1900, 0.65d };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        double[][] doubleArray16 = null;
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset17 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray15, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.clearRangeAxes();
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot6.getColumnRenderingOrder();
        java.lang.String str13 = sortOrder12.toString();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "SortOrder.ASCENDING" + "'", str13.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke7 = null;
        stackedAreaRenderer0.setSeriesStroke((int) (byte) 1, stroke7);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer10 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        stackedAreaRenderer10.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator12, false);
        java.awt.Paint paint17 = stackedAreaRenderer10.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer10.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        stackedAreaRenderer0.setSeriesPositiveItemLabelPosition(1900, itemLabelPosition19, true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        dateAxis13.setVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        double double24 = dateAxis20.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setMaximumBarWidth((double) '#');
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis38);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        java.awt.Paint paint50 = categoryMarker49.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedBarRenderer3D25.drawRangeMarker(graphics2D29, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.plot.Marker) categoryMarker49, rectangle2D51);
        java.awt.Shape shape53 = dateAxis38.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity56 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis20, shape53, "RectangleAnchor.CENTER", "Following");
        dateAxis13.setLeftArrow(shape53);
        org.jfree.data.Range range58 = dateAxis13.getRange();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(range58);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range2);
        double double4 = range2.getLowerBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        dateAxis8.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range12 = dateAxis8.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 86400000L, range2, lengthConstraintType5, 3.0d, range12, lengthConstraintType13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint14.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone13);
        int int16 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        boolean boolean17 = xYPlot7.isDomainZoomable();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint1, stroke2, paint3, stroke4, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryMarker6.getLabelOffset();
        categoryMarker6.setKey((java.lang.Comparable) 100.0d);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RangeType.FULL");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RangeType.FULL, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double[] doubleArray2 = new double[] { 100.0d, 7 };
        double[] doubleArray5 = new double[] { 100.0d, 7 };
        double[][] doubleArray6 = new double[][] { doubleArray2, doubleArray5 };
        double[] doubleArray12 = new double[] { ' ', 2.0f, 2.0f, ' ', 0 };
        double[] doubleArray18 = new double[] { ' ', 2.0f, 2.0f, ' ', 0 };
        double[] doubleArray24 = new double[] { ' ', 2.0f, 2.0f, ' ', 0 };
        double[] doubleArray30 = new double[] { ' ', 2.0f, 2.0f, ' ', 0 };
        double[][] doubleArray31 = new double[][] { doubleArray12, doubleArray18, doubleArray24, doubleArray30 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset32 = new org.jfree.data.category.DefaultIntervalCategoryDataset(doubleArray6, doubleArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        int int1 = paintList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "May", "May");
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape8, shape10);
        dateAxis5.setRightArrow(shape10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedAreaRenderer16.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator18, false);
        double double21 = stackedAreaRenderer16.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedAreaRenderer22.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator24, false);
        java.awt.Paint paint29 = stackedAreaRenderer22.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer16.setBaseFillPaint(paint29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D31.setSeriesItemLabelFont((int) (byte) 100, font35);
        java.awt.Stroke stroke38 = stackedBarRenderer3D31.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape10, paint29, stroke38, (java.awt.Paint) color39);
        legendItem40.setSeriesIndex((int) (short) 0);
        boolean boolean43 = legendItem40.isShapeVisible();
        java.awt.Paint paint44 = legendItem40.getLinePaint();
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity14 = new org.jfree.chart.entity.TickLabelEntity(shape11, "May", "May");
        boolean boolean15 = org.jfree.chart.util.ShapeUtilities.equal(shape9, shape11);
        dateAxis6.setRightArrow(shape11);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        stackedAreaRenderer17.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator19, false);
        double double22 = stackedAreaRenderer17.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer23 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator25 = null;
        stackedAreaRenderer23.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator25, false);
        java.awt.Paint paint30 = stackedAreaRenderer23.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer17.setBaseFillPaint(paint30);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D32.setMaximumBarWidth((double) '#');
        java.awt.Font font36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D32.setSeriesItemLabelFont((int) (byte) 100, font36);
        java.awt.Stroke stroke39 = stackedBarRenderer3D32.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape11, paint30, stroke39, (java.awt.Paint) color40);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone52 = dateAxis51.getTimeZone();
        java.lang.Object obj53 = dateAxis51.clone();
        java.awt.Font font54 = dateAxis51.getTickLabelFont();
        java.lang.String str55 = dateAxis51.getLabelToolTip();
        java.awt.Stroke stroke56 = dateAxis51.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((-1.0d), paint30, stroke42, paint46, stroke56, 0.0f);
        valueMarker58.setValue((double) 2019L);
        valueMarker58.setValue((double) (-451));
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNull(str55);
        org.junit.Assert.assertNotNull(stroke56);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        int int3 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj4 = defaultCategoryDataset1.clone();
        boolean boolean5 = blockBorder0.equals((java.lang.Object) defaultCategoryDataset1);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.util.Date date11 = dateAxis9.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.util.Date date15 = dateAxis13.getMinimumDate();
        org.jfree.data.gantt.Task task16 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date11, date15);
        org.jfree.data.time.TimePeriod timePeriod17 = task16.getDuration();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) "Category Plot", (java.lang.Comparable) timePeriod17);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriod17);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.RELATIVE;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) unitType1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        dateAxis1.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis1);
        boolean boolean6 = dateAxis1.isAutoRange();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D7.setMaximumBarWidth((double) '#');
        java.awt.Shape shape10 = stackedBarRenderer3D7.getBaseShape();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot17.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        java.awt.Paint paint26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint26, stroke27, paint28, stroke29, (float) 1L);
        java.awt.Paint paint32 = categoryMarker31.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        stackedBarRenderer3D7.drawRangeMarker(graphics2D11, categoryPlot17, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.plot.Marker) categoryMarker31, rectangle2D33);
        java.awt.Shape shape35 = dateAxis20.getDownArrow();
        dateAxis1.setDownArrow(shape35);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str5 = textAnchor4.toString();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("May", graphics2D1, (float) (byte) 10, (float) 100, textAnchor4, 0.0d, (float) 7, (float) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.CENTER" + "'", str5.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        dateAxis13.setFixedAutoRange((double) 15);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color4 = java.awt.Color.GRAY;
        float[] floatArray8 = new float[] { 3, (-1.0f), 100L };
        float[] floatArray9 = color4.getColorComponents(floatArray8);
        float[] floatArray10 = java.awt.Color.RGBtoHSB((int) '4', (int) '4', 1, floatArray9);
        try {
            float[] floatArray11 = color0.getRGBComponents(floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = spreadsheetDate2.getPreviousDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D1.setMaximumBarWidth((double) '#');
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D1.setSeriesItemLabelFont((int) (byte) 100, font5);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedAreaRenderer8.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator10, false);
        double double13 = stackedAreaRenderer8.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer14 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        stackedAreaRenderer14.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator16, false);
        java.awt.Paint paint21 = stackedAreaRenderer14.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer8.setBaseFillPaint(paint21);
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint24, stroke25, paint26, stroke27, (float) 1L);
        java.awt.Color color30 = java.awt.Color.white;
        java.awt.Stroke stroke31 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint21, stroke25, (java.awt.Paint) color30, stroke31, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset34 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer38 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot39.getDomainAxis();
        java.awt.Paint paint41 = categoryPlot39.getDomainGridlinePaint();
        categoryMarker33.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot39);
        java.util.List list43 = categoryPlot39.getAnnotations();
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone48 = dateAxis47.getTimeZone();
        boolean boolean49 = dateAxis47.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = null;
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot(xYDataset44, valueAxis45, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer50);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer52 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator54 = null;
        stackedAreaRenderer52.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator54, false);
        double double57 = stackedAreaRenderer52.getItemLabelAnchorOffset();
        java.awt.Paint paint60 = stackedAreaRenderer52.getItemOutlinePaint(0, (int) (short) 100);
        xYPlot51.setOutlinePaint(paint60);
        categoryPlot39.setRangeCrosshairPaint(paint60);
        org.jfree.chart.text.TextMeasurer textMeasurer64 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock65 = org.jfree.chart.text.TextUtilities.createTextBlock("RangeType.FULL", font5, paint60, (float) (byte) 100, textMeasurer64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(categoryAxis40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.0d + "'", double57 == 2.0d);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone4);
        dateAxis1.setStandardTickUnits(tickUnitSource5);
        dateAxis1.setFixedAutoRange((double) 100.0f);
        java.text.DateFormat dateFormat9 = null;
        dateAxis1.setDateFormatOverride(dateFormat9);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        java.awt.Paint paint8 = xYPlot7.getRangeGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        boolean boolean14 = dateAxis12.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer15);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = null;
        xYPlot16.markerChanged(markerChangeEvent17);
        int int19 = xYPlot16.getWeight();
        java.awt.Stroke stroke20 = xYPlot16.getRangeCrosshairStroke();
        int int21 = xYPlot16.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        dateAxis23.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis23);
        int int28 = xYPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis23);
        int int29 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        try {
            xYPlot7.zoomRangeAxes((double) '4', (double) 31, plotRenderingInfo32, point2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (52.0) <= upper (31.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(point2D35);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        java.awt.Font font7 = categoryPlot5.getNoDataMessageFont();
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.setAngleLabelsVisible(false);
        java.awt.Paint paint8 = polarPlot3.getRadiusGridlinePaint();
        java.awt.Paint paint9 = polarPlot3.getRadiusGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot(xYDataset10, valueAxis11, polarItemRenderer12);
        polarPlot13.removeCornerTextItem("");
        polarPlot13.setAngleLabelsVisible(false);
        java.awt.Paint paint18 = polarPlot13.getRadiusGridlinePaint();
        java.awt.Paint paint19 = polarPlot13.getRadiusGridlinePaint();
        polarPlot3.setAngleLabelPaint(paint19);
        try {
            double double21 = polarPlot3.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        double double3 = dateAxis1.getLabelAngle();
        dateAxis1.resizeRange((double) (short) -1);
        java.awt.Paint paint6 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 1.0f, 2.0d, (-2208960000000L), 1562097599999L };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0f, 2.0d, (-2208960000000L), 1562097599999L };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 1.0f, 2.0d, (-2208960000000L), 1562097599999L };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 1.0f, 2.0d, (-2208960000000L), 1562097599999L };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray6, numberArray11, numberArray16, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("0,-1,1,1,-1,1,-1,1", "", numberArray22);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        ringPlot0.setLabelGap((double) 1577865599999L);
        boolean boolean3 = ringPlot0.getIgnoreZeroValues();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.lang.Object obj7 = dateAxis5.clone();
        java.awt.Font font8 = dateAxis5.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        java.util.Date date12 = dateAxis10.getMinimumDate();
        org.jfree.chart.axis.Timeline timeline13 = dateAxis10.getTimeline();
        dateAxis5.setTimeline(timeline13);
        boolean boolean15 = ringPlot0.equals((java.lang.Object) dateAxis5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeline13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge2);
        axisSpace0.add((double) 9999, rectangleEdge2);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = axisSpace0.expand(rectangle2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        int int3 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj4 = defaultCategoryDataset1.clone();
        boolean boolean5 = blockBorder0.equals((java.lang.Object) defaultCategoryDataset1);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.util.Date date11 = dateAxis9.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.util.Date date15 = dateAxis13.getMinimumDate();
        org.jfree.data.gantt.Task task16 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date11, date15);
        org.jfree.data.time.TimePeriod timePeriod17 = task16.getDuration();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) "Category Plot", (java.lang.Comparable) timePeriod17);
        org.jfree.data.general.PieDataset pieDataset20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, (java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriod17);
        org.junit.Assert.assertNotNull(pieDataset20);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues2 = new org.jfree.data.DefaultKeyedValues();
        int int4 = defaultKeyedValues2.getIndex((java.lang.Comparable) (byte) 1);
        int int5 = defaultKeyedValues2.getItemCount();
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues2.sortByKeys(sortOrder6);
        int int8 = objectList1.indexOf((java.lang.Object) defaultKeyedValues2);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        dateAxis10.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis10);
        boolean boolean15 = dateAxis10.isAutoRange();
        int int16 = objectList1.indexOf((java.lang.Object) dateAxis10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone16 = dateAxis15.getTimeZone();
        boolean boolean17 = dateAxis15.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer18);
        int int20 = xYPlot7.getRangeAxisIndex(valueAxis13);
        xYPlot7.clearAnnotations();
        xYPlot7.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke25 = stackedBarRenderer3D23.lookupSeriesStroke(11);
        xYPlot7.setRangeCrosshairStroke(stroke25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot7.getDomainAxisEdge((int) 'a');
        java.awt.Stroke stroke29 = xYPlot7.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot5.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot5.getDomainAxis();
        int int8 = categoryPlot5.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        java.awt.Paint paint8 = stackedAreaRenderer0.getItemOutlinePaint(0, (int) (short) 100);
        java.awt.Paint paint10 = stackedAreaRenderer0.getSeriesFillPaint((int) '4');
        java.awt.Font font12 = stackedAreaRenderer0.getSeriesItemLabelFont(100);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(font12);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = categoryPlot5.getDomainAxis();
        java.awt.Paint paint7 = categoryPlot5.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer8 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        stackedAreaRenderer8.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator10, false);
        double double13 = stackedAreaRenderer8.getItemLabelAnchorOffset();
        java.awt.Paint paint16 = stackedAreaRenderer8.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot5.setRangeGridlinePaint(paint16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = null;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        categoryPlot5.zoomRangeAxes(3.0d, plotRenderingInfo19, point2D22);
        int int24 = categoryPlot5.getWeight();
        org.junit.Assert.assertNull(categoryAxis6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        boolean boolean25 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot7.getOrientation();
        boolean boolean27 = xYPlot7.isRangeCrosshairVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        xYPlot7.rendererChanged(rendererChangeEvent28);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection22 = xYPlot7.getDomainMarkers((int) '4', layer21);
        java.awt.Stroke stroke23 = xYPlot7.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setMax((double) 9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor4);
        org.jfree.chart.block.BlockBorder blockBorder6 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle1.setFrame((org.jfree.chart.block.BlockFrame) blockBorder6);
        legendTitle1.setHeight((double) ' ');
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = legendTitle1.getVerticalAlignment();
        legendTitle1.setPadding((double) (-1), 0.25d, (double) 2019L, (double) 15);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(blockBorder6);
        org.junit.Assert.assertNotNull(verticalAlignment10);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean8 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset11 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number12 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.data.general.PieDataset pieDataset14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11, (java.lang.Comparable) (short) 1);
        org.jfree.data.Range range15 = stackedAreaRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset11);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator17 = stackedAreaRenderer0.getSeriesToolTipGenerator(1900);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(pieDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(categoryToolTipGenerator17);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape6, "May", "May");
        boolean boolean10 = org.jfree.chart.util.ShapeUtilities.equal(shape4, shape6);
        dateAxis1.setRightArrow(shape6);
        dateAxis1.setAutoRangeMinimumSize((double) 100L, false);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE8" + "'", str1.equals("ItemLabelAnchor.OUTSIDE8"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.resizeRange(0.05d, 0.0d);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("May", font8);
        dateAxis3.setLabelFont(font8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer17);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        int int21 = xYPlot18.getWeight();
        java.awt.Stroke stroke22 = xYPlot18.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone27 = dateAxis26.getTimeZone();
        boolean boolean28 = dateAxis26.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer29);
        int int31 = xYPlot18.getRangeAxisIndex(valueAxis24);
        xYPlot18.clearAnnotations();
        xYPlot18.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke36 = stackedBarRenderer3D34.lookupSeriesStroke(11);
        xYPlot18.setRangeCrosshairStroke(stroke36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot18.getDomainAxisEdge((int) 'a');
        java.awt.Paint paint40 = xYPlot18.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("Third", font8, paint40);
        java.awt.Color color44 = java.awt.Color.getColor("", (int) 'a');
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("DateTickMarkPosition.END", font8, (java.awt.Paint) color44, (float) 6);
        java.lang.String str47 = textFragment46.getText();
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "DateTickMarkPosition.END" + "'", str47.equals("DateTickMarkPosition.END"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        double double5 = stackedAreaRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer6 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        stackedAreaRenderer6.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator8, false);
        java.awt.Paint paint13 = stackedAreaRenderer6.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer0.setBaseFillPaint(paint13);
        java.awt.Color color17 = java.awt.Color.cyan;
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (short) 100, (java.awt.Paint) color17, stroke22);
        int int26 = color17.getAlpha();
        stackedAreaRenderer0.setSeriesOutlinePaint(3, (java.awt.Paint) color17, false);
        int int29 = stackedAreaRenderer0.getColumnCount();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 255 + "'", int26 == 255);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = stackedBarRenderer3D0.getSeriesURLGenerator(0);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer12);
        categoryPlot13.setRangeGridlinesVisible(false);
        boolean boolean16 = stackedBarRenderer3D7.hasListener((java.util.EventListener) categoryPlot13);
        categoryPlot13.setRangeCrosshairVisible(false);
        boolean boolean19 = categoryPlot13.isRangeGridlinesVisible();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            stackedBarRenderer3D0.drawDomainGridline(graphics2D6, categoryPlot13, rectangle2D20, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity17 = new org.jfree.chart.entity.TickLabelEntity(shape14, "May", "May");
        boolean boolean18 = org.jfree.chart.util.ShapeUtilities.equal(shape12, shape14);
        dateAxis9.setRightArrow(shape14);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer20 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = null;
        stackedAreaRenderer20.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator22, false);
        double double25 = stackedAreaRenderer20.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer26 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = null;
        stackedAreaRenderer26.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator28, false);
        java.awt.Paint paint33 = stackedAreaRenderer26.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer20.setBaseFillPaint(paint33);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D35.setMaximumBarWidth((double) '#');
        java.awt.Font font39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D35.setSeriesItemLabelFont((int) (byte) 100, font39);
        java.awt.Stroke stroke42 = stackedBarRenderer3D35.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape14, paint33, stroke42, (java.awt.Paint) color43);
        polarPlot3.setAngleGridlineStroke(stroke42);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        java.lang.String str8 = categoryPlot5.getPlotType();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot5.setDomainAxis(categoryAxis9);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.lang.Object obj4 = dateAxis2.clone();
        java.awt.Font font5 = dateAxis2.getTickLabelFont();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        int int16 = xYPlot13.getWeight();
        java.awt.Stroke stroke17 = xYPlot13.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        xYPlot13.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        xYPlot13.setDomainAxisLocation((int) (short) 1, axisLocation27);
        java.awt.Paint paint29 = xYPlot13.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle35.getLegendItemGraphicAnchor();
        legendTitle33.setLegendItemGraphicLocation(rectangleAnchor36);
        org.jfree.chart.block.BlockBorder blockBorder38 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray40 = legendTitle33.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = legendTitle33.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment31, verticalAlignment41, (double) 0.0f, (double) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = legendTitle48.getLegendItemGraphicAnchor();
        legendTitle46.setLegendItemGraphicLocation(rectangleAnchor49);
        org.jfree.chart.block.BlockBorder blockBorder51 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle46.setFrame((org.jfree.chart.block.BlockFrame) blockBorder51);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray53 = legendTitle46.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = legendTitle46.getVerticalAlignment();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset55 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset55, categoryAxis56, (org.jfree.chart.axis.ValueAxis) dateAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer59);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = categoryPlot60.getDomainAxis();
        java.awt.Paint paint62 = categoryPlot60.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer63 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator65 = null;
        stackedAreaRenderer63.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator65, false);
        double double68 = stackedAreaRenderer63.getItemLabelAnchorOffset();
        java.awt.Paint paint71 = stackedAreaRenderer63.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot60.setRangeGridlinePaint(paint71);
        java.awt.Paint paint74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke75 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint74, stroke75, paint76, stroke77, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = categoryMarker79.getLabelOffset();
        double double82 = rectangleInsets80.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset83 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis84 = null;
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer87 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot88 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset83, categoryAxis84, (org.jfree.chart.axis.ValueAxis) dateAxis86, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer87);
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = categoryPlot88.getDomainAxis();
        java.awt.Paint paint90 = categoryPlot88.getDomainGridlinePaint();
        java.awt.Stroke stroke91 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot88.setRangeGridlineStroke(stroke91);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor93 = categoryPlot88.getDomainGridlinePosition();
        boolean boolean94 = rectangleInsets80.equals((java.lang.Object) categoryPlot88);
        categoryPlot60.setAxisOffset(rectangleInsets80);
        org.jfree.chart.title.TextTitle textTitle96 = new org.jfree.chart.title.TextTitle("RectangleEdge.RIGHT", font5, paint29, rectangleEdge30, horizontalAlignment31, verticalAlignment54, rectangleInsets80);
        java.awt.Font font97 = textTitle96.getFont();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(blockBorder38);
        org.junit.Assert.assertNotNull(legendItemSourceArray40);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(blockBorder51);
        org.junit.Assert.assertNotNull(legendItemSourceArray53);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertNull(categoryAxis61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 2.0d + "'", double68 == 2.0d);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 3.0d + "'", double82 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis89);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(categoryAnchor93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(font97);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimePeriod timePeriod1 = null;
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("RangeType.FULL", timePeriod1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        stackedAreaRenderer1.setBaseSeriesVisibleInLegend(false, true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = legendTitle1.getMargin();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets2.createOutsetRectangle(rectangle2D3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 1, false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        java.util.Date date3 = dateAxis1.getMinimumDate();
        java.awt.Paint paint4 = dateAxis1.getTickMarkPaint();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        java.awt.Paint paint8 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryPlot5.setDomainGridlinePaint(paint8);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        categoryPlot5.setDatasetRenderingOrder(datasetRenderingOrder10);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D13 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke15 = stackedBarRenderer3D13.lookupSeriesStroke(11);
        stackedBarRenderer3D13.setItemMargin((double) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = stackedBarRenderer3D13.getGradientPaintTransformer();
        categoryPlot5.setRenderer(3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedBarRenderer3D13);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(gradientPaintTransformer18);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.chart.block.BlockBorder blockBorder1 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        int int4 = defaultCategoryDataset2.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj5 = defaultCategoryDataset2.clone();
        boolean boolean6 = blockBorder1.equals((java.lang.Object) defaultCategoryDataset2);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        java.util.Date date12 = dateAxis10.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        java.util.Date date16 = dateAxis14.getMinimumDate();
        org.jfree.data.gantt.Task task17 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date12, date16);
        org.jfree.data.time.TimePeriod timePeriod18 = task17.getDuration();
        defaultCategoryDataset2.removeValue((java.lang.Comparable) "Category Plot", (java.lang.Comparable) timePeriod18);
        try {
            java.lang.Number number22 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) "Category Plot", (java.lang.Comparable) "SortOrder.ASCENDING", (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timePeriod18);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Range[0.0,1.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.Range range2 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = new org.jfree.chart.block.RectangleConstraint((double) 1.0f, range2);
        double double4 = range2.getLowerBound();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        dateAxis8.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range12 = dateAxis8.getDefaultAutoRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 86400000L, range2, lengthConstraintType5, 3.0d, range12, lengthConstraintType13);
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double16 = range15.getLength();
        org.jfree.data.Range range17 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range18 = org.jfree.data.Range.combine(range15, range17);
        java.lang.String str19 = range17.toString();
        boolean boolean20 = lengthConstraintType5.equals((java.lang.Object) range17);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[0.0,1.0]" + "'", str19.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.awt.Paint paint0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 31, (double) 0);
        double double3 = barRenderer3D2.getLowerClip();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D2.getBaseURLGenerator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setMaximumBarWidth((double) '#');
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis38);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        java.awt.Paint paint50 = categoryMarker49.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedBarRenderer3D25.drawRangeMarker(graphics2D29, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.plot.Marker) categoryMarker49, rectangle2D51);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer53 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator55 = null;
        stackedAreaRenderer53.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator55, false);
        java.awt.Paint paint60 = stackedAreaRenderer53.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker49.setOutlinePaint(paint60);
        xYPlot7.setDomainGridlinePaint(paint60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        java.awt.geom.Point2D point2D66 = null;
        try {
            xYPlot7.zoomRangeAxes((double) 255, (double) 10, plotRenderingInfo65, point2D66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (255.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint60);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        xYPlot7.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.Plot plot20 = xYPlot7.getParent();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(plot20);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', (double) 0.0f);
        org.jfree.data.Range range3 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = xYPlot7.getFixedRangeAxisSpace();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot7.setRangeGridlineStroke(stroke26);
        java.awt.Paint paint28 = null;
        try {
            xYPlot7.setDomainCrosshairPaint(paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        int int8 = stackedAreaRenderer0.getPassCount();
        boolean boolean9 = stackedAreaRenderer0.getRenderAsPercentages();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        java.lang.Object obj14 = dateAxis12.clone();
        java.awt.Font font15 = dateAxis12.getTickLabelFont();
        stackedAreaRenderer0.setSeriesItemLabelFont(15, font15, false);
        stackedAreaRenderer0.setAutoPopulateSeriesStroke(true);
        org.jfree.chart.LegendItem legendItem22 = stackedAreaRenderer0.getLegendItem(0, (int) (byte) 10);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer28 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24, categoryAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = categoryPlot29.getFixedDomainAxisSpace();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        float[] floatArray32 = null;
        float[] floatArray33 = color31.getColorComponents(floatArray32);
        categoryPlot29.setRangeGridlinePaint((java.awt.Paint) color31);
        org.jfree.chart.util.SortOrder sortOrder35 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot29.setRowRenderingOrder(sortOrder35);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        java.awt.Paint paint39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint41 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint39, stroke40, paint41, stroke42, (float) 1L);
        java.awt.Paint paint45 = categoryMarker44.getLabelPaint();
        java.lang.Comparable comparable46 = categoryMarker44.getKey();
        org.jfree.chart.text.TextAnchor textAnchor47 = org.jfree.chart.text.TextAnchor.CENTER;
        java.lang.String str48 = textAnchor47.toString();
        categoryMarker44.setLabelTextAnchor(textAnchor47);
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        try {
            stackedAreaRenderer0.drawDomainMarker(graphics2D23, categoryPlot29, categoryAxis37, categoryMarker44, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(legendItem22);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + "RectangleAnchor.CENTER" + "'", comparable46.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(textAnchor47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "TextAnchor.CENTER" + "'", str48.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Font font4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D0.setSeriesItemLabelFont((int) (byte) 100, font4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        int int16 = xYPlot13.getWeight();
        java.awt.Stroke stroke17 = xYPlot13.getRangeCrosshairStroke();
        stackedBarRenderer3D0.addChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot13);
        int int19 = stackedBarRenderer3D0.getPassCount();
        java.awt.Paint paint22 = stackedBarRenderer3D0.getItemFillPaint(3, (int) '4');
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        int int18 = xYPlot15.getWeight();
        java.awt.Stroke stroke19 = xYPlot15.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        dateAxis22.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis22);
        xYPlot15.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone30 = dateAxis29.getTimeZone();
        java.lang.Object obj31 = dateAxis29.clone();
        java.awt.Font font32 = dateAxis29.getTickLabelFont();
        java.lang.String str33 = dateAxis29.getLabelToolTip();
        java.awt.Stroke stroke34 = dateAxis29.getTickMarkStroke();
        dateAxis29.setTickMarkInsideLength((float) 6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer37);
        org.jfree.data.Range range39 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis29);
        java.awt.Paint paint40 = polarPlot3.getRadiusGridlinePaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge2);
        axisSpace0.add((double) 9999, rectangleEdge2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        int int18 = xYPlot15.getWeight();
        java.awt.Stroke stroke19 = xYPlot15.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone24 = dateAxis23.getTimeZone();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer26);
        int int28 = xYPlot15.getRangeAxisIndex(valueAxis21);
        xYPlot15.clearAnnotations();
        xYPlot15.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke33 = stackedBarRenderer3D31.lookupSeriesStroke(11);
        xYPlot15.setRangeCrosshairStroke(stroke33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot15.getDomainAxisEdge((int) 'a');
        boolean boolean37 = rectangleEdge6.equals((java.lang.Object) 'a');
        axisSpace0.ensureAtLeast(0.0d, rectangleEdge6);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone44 = dateAxis43.getTimeZone();
        boolean boolean45 = dateAxis43.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset40, valueAxis41, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer46);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        xYPlot47.markerChanged(markerChangeEvent48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Point2D point2D52 = null;
        xYPlot47.zoomDomainAxes((double) 10, plotRenderingInfo51, point2D52);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = xYPlot47.getRangeAxisEdge((int) '#');
        try {
            java.awt.geom.Rectangle2D rectangle2D56 = axisSpace0.reserved(rectangle2D39, rectangleEdge55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleEdge55);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Date date8 = dateAxis6.getMinimumDate();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date4, date8);
        org.jfree.data.time.TimePeriod timePeriod10 = task9.getDuration();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        task9.setDuration((org.jfree.data.time.TimePeriod) year11);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D3.setMaximumBarWidth((double) '#');
        java.awt.Shape shape6 = stackedBarRenderer3D3.getBaseShape();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer12 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot13.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("");
        dateAxis16.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent20 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis16);
        java.awt.Paint paint22 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint22, stroke23, paint24, stroke25, (float) 1L);
        java.awt.Paint paint28 = categoryMarker27.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D7, categoryPlot13, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.plot.Marker) categoryMarker27, rectangle2D29);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator33 = null;
        stackedAreaRenderer31.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator33, false);
        java.awt.Paint paint38 = stackedAreaRenderer31.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker27.setOutlinePaint(paint38);
        stackedBarRenderer3D0.setBasePaint(paint38);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer41 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator43 = null;
        stackedAreaRenderer41.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator43, false);
        java.awt.Paint paint48 = stackedAreaRenderer41.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean49 = stackedAreaRenderer41.getAutoPopulateSeriesOutlineStroke();
        stackedAreaRenderer41.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = stackedAreaRenderer41.getBaseNegativeItemLabelPosition();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer53 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator55 = null;
        stackedAreaRenderer53.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator55, false);
        double double58 = stackedAreaRenderer53.getItemLabelAnchorOffset();
        java.awt.Paint paint61 = stackedAreaRenderer53.getItemOutlinePaint(0, (int) (short) 100);
        boolean boolean62 = itemLabelPosition52.equals((java.lang.Object) stackedAreaRenderer53);
        stackedBarRenderer3D0.setPositiveItemLabelPositionFallback(itemLabelPosition52);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer64 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator66 = null;
        stackedAreaRenderer64.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator66, false);
        java.awt.Paint paint71 = stackedAreaRenderer64.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean72 = stackedAreaRenderer64.getAutoPopulateSeriesOutlineStroke();
        stackedAreaRenderer64.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition75 = stackedAreaRenderer64.getBaseNegativeItemLabelPosition();
        stackedBarRenderer3D0.setBaseNegativeItemLabelPosition(itemLabelPosition75);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition52);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.0d + "'", double58 == 2.0d);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition75);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        boolean boolean13 = xYPlot7.isRangeZoomable();
        xYPlot7.zoom((double) 2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot5.getFixedDomainAxisSpace();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        float[] floatArray8 = null;
        float[] floatArray9 = color7.getColorComponents(floatArray8);
        categoryPlot5.setRangeGridlinePaint((java.awt.Paint) color7);
        int int11 = color7.getAlpha();
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.lang.Comparable comparable0 = null;
        java.lang.Object obj1 = null;
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject(comparable0, obj1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, (java.lang.Comparable) (short) 1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener7 = null;
        defaultCategoryDataset3.removeChangeListener(datasetChangeListener7);
        keyedObject2.setObject((java.lang.Object) datasetChangeListener7);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("");
        dateAxis19.setAutoTickUnitSelection(false, true);
        double double23 = dateAxis19.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D24.setMaximumBarWidth((double) '#');
        java.awt.Shape shape27 = stackedBarRenderer3D24.getBaseShape();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset29 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer33 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset29, categoryAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer33);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = categoryPlot34.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        dateAxis37.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent41 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis37);
        java.awt.Paint paint43 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint43, stroke44, paint45, stroke46, (float) 1L);
        java.awt.Paint paint49 = categoryMarker48.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        stackedBarRenderer3D24.drawRangeMarker(graphics2D28, categoryPlot34, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.plot.Marker) categoryMarker48, rectangle2D50);
        java.awt.Shape shape52 = dateAxis37.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity55 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis19, shape52, "RectangleAnchor.CENTER", "Following");
        java.awt.Paint paint56 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.axis.DateAxis dateAxis60 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone61 = dateAxis60.getTimeZone();
        boolean boolean62 = dateAxis60.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset57, valueAxis58, (org.jfree.chart.axis.ValueAxis) dateAxis60, xYItemRenderer63);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent65 = null;
        xYPlot64.markerChanged(markerChangeEvent65);
        int int67 = xYPlot64.getWeight();
        java.awt.Stroke stroke68 = xYPlot64.getRangeCrosshairStroke();
        int int69 = xYPlot64.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis71 = new org.jfree.chart.axis.DateAxis("");
        dateAxis71.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent75 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis71);
        int int76 = xYPlot64.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis71);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        java.awt.geom.Point2D point2D80 = null;
        xYPlot64.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo79, point2D80);
        org.jfree.chart.axis.AxisSpace axisSpace82 = xYPlot64.getFixedRangeAxisSpace();
        java.awt.Stroke stroke83 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot64.setRangeGridlineStroke(stroke83);
        java.awt.Paint paint85 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem86 = new org.jfree.chart.LegendItem("", "Category Plot", "", "hi!", shape52, paint56, stroke83, paint85);
        java.awt.Color color87 = java.awt.Color.magenta;
        org.jfree.chart.LegendItem legendItem88 = new org.jfree.chart.LegendItem("hi!", "HorizontalAlignment.RIGHT", "TextAnchor.CENTER", "RectangleAnchor.CENTER", shape52, (java.awt.Paint) color87);
        boolean boolean89 = keyedObject2.equals((java.lang.Object) "HorizontalAlignment.RIGHT");
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNull(categoryAxis35);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertNull(axisSpace82);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(color87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.lang.Object obj15 = dateAxis13.clone();
        xYPlot7.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13);
        dateAxis13.setVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        double double24 = dateAxis20.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D25.setMaximumBarWidth((double) '#');
        java.awt.Shape shape28 = stackedBarRenderer3D25.getBaseShape();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset30 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer34 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset30, categoryAxis31, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer34);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot35.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("");
        dateAxis38.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis38);
        java.awt.Paint paint44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker49 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint44, stroke45, paint46, stroke47, (float) 1L);
        java.awt.Paint paint50 = categoryMarker49.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        stackedBarRenderer3D25.drawRangeMarker(graphics2D29, categoryPlot35, (org.jfree.chart.axis.ValueAxis) dateAxis38, (org.jfree.chart.plot.Marker) categoryMarker49, rectangle2D51);
        java.awt.Shape shape53 = dateAxis38.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity56 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis20, shape53, "RectangleAnchor.CENTER", "Following");
        dateAxis13.setLeftArrow(shape53);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset60 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number61 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset60);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity64 = new org.jfree.chart.entity.CategoryItemEntity(shape53, "Range[0.0,1.0]", "RectangleAnchor.CENTER", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset60, (java.lang.Comparable) true, (java.lang.Comparable) (-1.0f));
        org.jfree.data.xy.XYDataset xYDataset65 = null;
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.chart.axis.DateAxis dateAxis68 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone69 = dateAxis68.getTimeZone();
        boolean boolean70 = dateAxis68.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot(xYDataset65, valueAxis66, (org.jfree.chart.axis.ValueAxis) dateAxis68, xYItemRenderer71);
        java.awt.Paint paint73 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYPlot72.setDomainZeroBaselinePaint(paint73);
        org.jfree.data.xy.XYDataset xYDataset75 = null;
        int int76 = xYPlot72.indexOf(xYDataset75);
        boolean boolean77 = defaultCategoryDataset60.hasListener((java.util.EventListener) xYPlot72);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNull(number61);
        org.junit.Assert.assertNotNull(timeZone69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(paint73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        int int3 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) (short) 1);
        java.lang.Object obj4 = defaultCategoryDataset1.clone();
        boolean boolean5 = blockBorder0.equals((java.lang.Object) defaultCategoryDataset1);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.util.Date date11 = dateAxis9.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        java.util.Date date15 = dateAxis13.getMinimumDate();
        org.jfree.data.gantt.Task task16 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date11, date15);
        org.jfree.data.time.TimePeriod timePeriod17 = task16.getDuration();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) "Category Plot", (java.lang.Comparable) timePeriod17);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, false);
        java.lang.Comparable comparable22 = null;
        try {
            java.lang.Number number23 = defaultCategoryDataset1.getValue((java.lang.Comparable) 2, comparable22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timePeriod17);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "May", "May");
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape8, shape10);
        dateAxis5.setRightArrow(shape10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedAreaRenderer16.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator18, false);
        double double21 = stackedAreaRenderer16.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedAreaRenderer22.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator24, false);
        java.awt.Paint paint29 = stackedAreaRenderer22.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer16.setBaseFillPaint(paint29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D31.setSeriesItemLabelFont((int) (byte) 100, font35);
        java.awt.Stroke stroke38 = stackedBarRenderer3D31.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape10, paint29, stroke38, (java.awt.Paint) color39);
        legendItem40.setSeriesIndex((int) (short) 0);
        java.lang.Comparable comparable43 = legendItem40.getSeriesKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, (java.lang.Comparable) "Following");
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, true);
        legendItem40.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset44);
        boolean boolean51 = legendItem40.isShapeVisible();
        int int52 = legendItem40.getSeriesIndex();
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(comparable43);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.lang.Object obj4 = dateAxis2.clone();
        java.awt.Font font5 = dateAxis2.getTickLabelFont();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        int int16 = xYPlot13.getWeight();
        java.awt.Stroke stroke17 = xYPlot13.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        xYPlot13.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        xYPlot13.setDomainAxisLocation((int) (short) 1, axisLocation27);
        java.awt.Paint paint29 = xYPlot13.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle35.getLegendItemGraphicAnchor();
        legendTitle33.setLegendItemGraphicLocation(rectangleAnchor36);
        org.jfree.chart.block.BlockBorder blockBorder38 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray40 = legendTitle33.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = legendTitle33.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment31, verticalAlignment41, (double) 0.0f, (double) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = legendTitle48.getLegendItemGraphicAnchor();
        legendTitle46.setLegendItemGraphicLocation(rectangleAnchor49);
        org.jfree.chart.block.BlockBorder blockBorder51 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle46.setFrame((org.jfree.chart.block.BlockFrame) blockBorder51);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray53 = legendTitle46.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = legendTitle46.getVerticalAlignment();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset55 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset55, categoryAxis56, (org.jfree.chart.axis.ValueAxis) dateAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer59);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = categoryPlot60.getDomainAxis();
        java.awt.Paint paint62 = categoryPlot60.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer63 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator65 = null;
        stackedAreaRenderer63.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator65, false);
        double double68 = stackedAreaRenderer63.getItemLabelAnchorOffset();
        java.awt.Paint paint71 = stackedAreaRenderer63.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot60.setRangeGridlinePaint(paint71);
        java.awt.Paint paint74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke75 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint74, stroke75, paint76, stroke77, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = categoryMarker79.getLabelOffset();
        double double82 = rectangleInsets80.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset83 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis84 = null;
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer87 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot88 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset83, categoryAxis84, (org.jfree.chart.axis.ValueAxis) dateAxis86, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer87);
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = categoryPlot88.getDomainAxis();
        java.awt.Paint paint90 = categoryPlot88.getDomainGridlinePaint();
        java.awt.Stroke stroke91 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot88.setRangeGridlineStroke(stroke91);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor93 = categoryPlot88.getDomainGridlinePosition();
        boolean boolean94 = rectangleInsets80.equals((java.lang.Object) categoryPlot88);
        categoryPlot60.setAxisOffset(rectangleInsets80);
        org.jfree.chart.title.TextTitle textTitle96 = new org.jfree.chart.title.TextTitle("RectangleEdge.RIGHT", font5, paint29, rectangleEdge30, horizontalAlignment31, verticalAlignment54, rectangleInsets80);
        double double98 = rectangleInsets80.extendHeight((double) 1562097599999L);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(blockBorder38);
        org.junit.Assert.assertNotNull(legendItemSourceArray40);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(blockBorder51);
        org.junit.Assert.assertNotNull(legendItemSourceArray53);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertNull(categoryAxis61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 2.0d + "'", double68 == 2.0d);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 3.0d + "'", double82 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis89);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(categoryAnchor93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 1.562097600005E12d + "'", double98 == 1.562097600005E12d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        dateAxis3.resizeRange(0.05d, 0.0d);
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("May", font8);
        dateAxis3.setLabelFont(font8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer17);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent19 = null;
        xYPlot18.markerChanged(markerChangeEvent19);
        int int21 = xYPlot18.getWeight();
        java.awt.Stroke stroke22 = xYPlot18.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone27 = dateAxis26.getTimeZone();
        boolean boolean28 = dateAxis26.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, (org.jfree.chart.axis.ValueAxis) dateAxis26, xYItemRenderer29);
        int int31 = xYPlot18.getRangeAxisIndex(valueAxis24);
        xYPlot18.clearAnnotations();
        xYPlot18.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D34 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke36 = stackedBarRenderer3D34.lookupSeriesStroke(11);
        xYPlot18.setRangeCrosshairStroke(stroke36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot18.getDomainAxisEdge((int) 'a');
        java.awt.Paint paint40 = xYPlot18.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine41 = new org.jfree.chart.text.TextLine("Third", font8, paint40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone46 = dateAxis45.getTimeZone();
        boolean boolean47 = dateAxis45.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer48);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        int int52 = xYPlot49.getWeight();
        java.awt.Stroke stroke53 = xYPlot49.getRangeCrosshairStroke();
        int int54 = xYPlot49.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("");
        dateAxis56.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent60 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis56);
        int int61 = xYPlot49.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis56);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Point2D point2D65 = null;
        xYPlot49.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo64, point2D65);
        boolean boolean67 = xYPlot49.isDomainGridlinesVisible();
        xYPlot49.clearRangeMarkers();
        org.jfree.chart.JFreeChart jFreeChart70 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", font8, (org.jfree.chart.plot.Plot) xYPlot49, false);
        java.awt.Graphics2D graphics2D71 = null;
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = null;
        java.awt.geom.Point2D point2D75 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D73, rectangleAnchor74);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo76 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection77 = chartRenderingInfo76.getEntityCollection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo78 = new org.jfree.chart.ChartRenderingInfo(entityCollection77);
        try {
            jFreeChart70.draw(graphics2D71, rectangle2D72, point2D75, chartRenderingInfo78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(point2D75);
        org.junit.Assert.assertNotNull(entityCollection77);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        java.awt.Shape shape3 = stackedBarRenderer3D0.getBaseShape();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        dateAxis13.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint19, stroke20, paint21, stroke22, (float) 1L);
        java.awt.Paint paint25 = categoryMarker24.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        stackedBarRenderer3D0.drawRangeMarker(graphics2D4, categoryPlot10, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.plot.Marker) categoryMarker24, rectangle2D26);
        categoryPlot10.mapDatasetToDomainAxis((int) (byte) 0, (int) '4');
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Shape shape34 = stackedBarRenderer3D31.getBaseShape();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset36 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer40 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset36, categoryAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer40);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot41.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("");
        dateAxis44.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent48 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis44);
        java.awt.Paint paint50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint50, stroke51, paint52, stroke53, (float) 1L);
        java.awt.Paint paint56 = categoryMarker55.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        stackedBarRenderer3D31.drawRangeMarker(graphics2D35, categoryPlot41, (org.jfree.chart.axis.ValueAxis) dateAxis44, (org.jfree.chart.plot.Marker) categoryMarker55, rectangle2D57);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator61 = null;
        stackedAreaRenderer59.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator61, false);
        java.awt.Paint paint66 = stackedAreaRenderer59.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        categoryMarker55.setOutlinePaint(paint66);
        categoryPlot10.addDomainMarker(categoryMarker55);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset71 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.DateAxis dateAxis74 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer75 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset71, categoryAxis72, (org.jfree.chart.axis.ValueAxis) dateAxis74, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer75);
        org.jfree.chart.axis.CategoryAxis categoryAxis77 = categoryPlot76.getDomainAxis();
        java.awt.Paint paint78 = categoryPlot76.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer79 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator81 = null;
        stackedAreaRenderer79.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator81, false);
        double double84 = stackedAreaRenderer79.getItemLabelAnchorOffset();
        java.awt.Paint paint87 = stackedAreaRenderer79.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot76.setRangeGridlinePaint(paint87);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo90 = null;
        java.awt.geom.Rectangle2D rectangle2D91 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor92 = null;
        java.awt.geom.Point2D point2D93 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D91, rectangleAnchor92);
        categoryPlot76.zoomRangeAxes(3.0d, plotRenderingInfo90, point2D93);
        categoryPlot10.zoomDomainAxes((double) 1562097599999L, plotRenderingInfo70, point2D93);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNull(categoryAxis42);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNull(categoryAxis77);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 2.0d + "'", double84 == 2.0d);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(point2D93);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        dateAxis2.resizeRange(0.05d, 0.0d);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("May", font7);
        dateAxis2.setLabelFont(font7);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        boolean boolean15 = dateAxis13.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer16);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = null;
        xYPlot17.markerChanged(markerChangeEvent18);
        int int20 = xYPlot17.getWeight();
        java.awt.Stroke stroke21 = xYPlot17.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone26 = dateAxis25.getTimeZone();
        boolean boolean27 = dateAxis25.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer28);
        int int30 = xYPlot17.getRangeAxisIndex(valueAxis23);
        xYPlot17.clearAnnotations();
        xYPlot17.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke35 = stackedBarRenderer3D33.lookupSeriesStroke(11);
        xYPlot17.setRangeCrosshairStroke(stroke35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot17.getDomainAxisEdge((int) 'a');
        java.awt.Paint paint39 = xYPlot17.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine40 = new org.jfree.chart.text.TextLine("Third", font7, paint39);
        org.jfree.chart.text.TextFragment textFragment41 = textLine40.getFirstTextFragment();
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment44 = new org.jfree.chart.text.TextFragment("May", font43);
        textLine40.addFragment(textFragment44);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(textFragment41);
        org.junit.Assert.assertNotNull(font43);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX(0.25d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer14);
        boolean boolean16 = dateAxis11.isVisible();
        java.awt.Paint paint17 = dateAxis11.getLabelPaint();
        categoryPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis11);
        boolean boolean19 = categoryPlot5.isDomainGridlinesVisible();
        categoryPlot5.setAnchorValue((double) 2.0f);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        stackedAreaRenderer1.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        double double6 = stackedAreaRenderer1.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        stackedAreaRenderer7.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator9, false);
        java.awt.Paint paint14 = stackedAreaRenderer7.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer1.setBaseFillPaint(paint14);
        java.awt.Paint paint17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint17, stroke18, paint19, stroke20, (float) 1L);
        java.awt.Color color23 = java.awt.Color.white;
        java.awt.Stroke stroke24 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint14, stroke18, (java.awt.Paint) color23, stroke24, 1.0f);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer31 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset27, categoryAxis28, (org.jfree.chart.axis.ValueAxis) dateAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot32.getDomainAxis();
        java.awt.Paint paint34 = categoryPlot32.getDomainGridlinePaint();
        categoryMarker26.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot32);
        java.util.List list36 = categoryPlot32.getAnnotations();
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        boolean boolean41 = categoryPlot32.render(graphics2D37, rectangle2D38, 15, plotRenderingInfo40);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = categoryPlot32.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(legendItemCollection42);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        stackedAreaRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator2, false);
        java.awt.Paint paint7 = stackedAreaRenderer0.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        boolean boolean8 = stackedAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        stackedAreaRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = null;
        try {
            stackedAreaRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.setAngleLabelsVisible(false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        java.lang.Object obj11 = dateAxis9.clone();
        java.awt.Font font12 = dateAxis9.getTickLabelFont();
        polarPlot3.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        polarPlot3.setAngleLabelPaint((java.awt.Paint) color14);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge2);
        axisSpace0.add((double) 9999, rectangleEdge2);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean7 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        int int18 = xYPlot15.getWeight();
        java.awt.Stroke stroke19 = xYPlot15.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone24 = dateAxis23.getTimeZone();
        boolean boolean25 = dateAxis23.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, (org.jfree.chart.axis.ValueAxis) dateAxis23, xYItemRenderer26);
        int int28 = xYPlot15.getRangeAxisIndex(valueAxis21);
        xYPlot15.clearAnnotations();
        xYPlot15.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke33 = stackedBarRenderer3D31.lookupSeriesStroke(11);
        xYPlot15.setRangeCrosshairStroke(stroke33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot15.getDomainAxisEdge((int) 'a');
        boolean boolean37 = rectangleEdge6.equals((java.lang.Object) 'a');
        axisSpace0.ensureAtLeast(0.0d, rectangleEdge6);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean41 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone46 = dateAxis45.getTimeZone();
        boolean boolean47 = dateAxis45.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer48);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent50 = null;
        xYPlot49.markerChanged(markerChangeEvent50);
        int int52 = xYPlot49.getWeight();
        java.awt.Stroke stroke53 = xYPlot49.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone58 = dateAxis57.getTimeZone();
        boolean boolean59 = dateAxis57.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot(xYDataset54, valueAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis57, xYItemRenderer60);
        int int62 = xYPlot49.getRangeAxisIndex(valueAxis55);
        xYPlot49.clearAnnotations();
        xYPlot49.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D65 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke67 = stackedBarRenderer3D65.lookupSeriesStroke(11);
        xYPlot49.setRangeCrosshairStroke(stroke67);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = xYPlot49.getDomainAxisEdge((int) 'a');
        boolean boolean71 = rectangleEdge40.equals((java.lang.Object) 'a');
        try {
            java.awt.geom.Rectangle2D rectangle2D72 = axisSpace0.reserved(rectangle2D39, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        boolean boolean6 = polarPlot3.isDomainZoomable();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        dateAxis8.setAutoTickUnitSelection(false, true);
        org.jfree.data.Range range12 = dateAxis8.getDefaultAutoRange();
        polarPlot3.setAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Stroke stroke14 = null;
        polarPlot3.setAngleGridlineStroke(stroke14);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (short) 10, (int) (byte) 0, 9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D0.setMaximumBarWidth((double) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer7 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, categoryAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer7);
        int int9 = defaultCategoryDataset3.getRowCount();
        org.jfree.data.Range range10 = stackedBarRenderer3D0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        int int1 = taskSeriesCollection0.getSeriesCount();
        java.util.List list2 = taskSeriesCollection0.getRowKeys();
        try {
            java.lang.Comparable comparable4 = taskSeriesCollection0.getRowKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "May", "May");
        boolean boolean14 = org.jfree.chart.util.ShapeUtilities.equal(shape8, shape10);
        dateAxis5.setRightArrow(shape10);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer16 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = null;
        stackedAreaRenderer16.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator18, false);
        double double21 = stackedAreaRenderer16.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer22 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        stackedAreaRenderer22.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator24, false);
        java.awt.Paint paint29 = stackedAreaRenderer22.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer16.setBaseFillPaint(paint29);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D31 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D31.setMaximumBarWidth((double) '#');
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D31.setSeriesItemLabelFont((int) (byte) 100, font35);
        java.awt.Stroke stroke38 = stackedBarRenderer3D31.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape10, paint29, stroke38, (java.awt.Paint) color39);
        legendItem40.setSeriesIndex((int) (short) 0);
        java.lang.Comparable comparable43 = legendItem40.getSeriesKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number45 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, (java.lang.Comparable) "Following");
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, true);
        legendItem40.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset44);
        int int51 = defaultCategoryDataset44.getRowCount();
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(comparable43);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.util.Date date4 = dateAxis2.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        java.util.Date date8 = dateAxis6.getMinimumDate();
        org.jfree.data.gantt.Task task9 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date4, date8);
        task9.setPercentComplete((java.lang.Double) 2.0d);
        org.jfree.data.gantt.Task task12 = null;
        task9.removeSubtask(task12);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        java.awt.Paint paint2 = stackedBarRenderer3D1.getBaseItemLabelPaint();
        double double3 = stackedBarRenderer3D1.getXOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("HorizontalAlignment.RIGHT", font2);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        dateAxis9.resizeRange(0.05d, 0.0d);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("May", font14);
        dateAxis9.setLabelFont(font14);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone21 = dateAxis20.getTimeZone();
        boolean boolean22 = dateAxis20.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis20, xYItemRenderer23);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        xYPlot24.markerChanged(markerChangeEvent25);
        int int27 = xYPlot24.getWeight();
        java.awt.Stroke stroke28 = xYPlot24.getRangeCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone33 = dateAxis32.getTimeZone();
        boolean boolean34 = dateAxis32.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, (org.jfree.chart.axis.ValueAxis) dateAxis32, xYItemRenderer35);
        int int37 = xYPlot24.getRangeAxisIndex(valueAxis30);
        xYPlot24.clearAnnotations();
        xYPlot24.clearDomainMarkers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        java.awt.Stroke stroke42 = stackedBarRenderer3D40.lookupSeriesStroke(11);
        xYPlot24.setRangeCrosshairStroke(stroke42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = xYPlot24.getDomainAxisEdge((int) 'a');
        java.awt.Paint paint46 = xYPlot24.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine47 = new org.jfree.chart.text.TextLine("Third", font14, paint46);
        java.awt.Color color50 = java.awt.Color.getColor("", (int) 'a');
        org.jfree.chart.text.TextFragment textFragment52 = new org.jfree.chart.text.TextFragment("DateTickMarkPosition.END", font14, (java.awt.Paint) color50, (float) 6);
        textLine5.addFragment(textFragment52);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(color50);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1562097599999L, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires end >= start.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        int int7 = defaultCategoryDataset1.getRowCount();
        boolean boolean8 = unitType0.equals((java.lang.Object) defaultCategoryDataset1);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, (java.lang.Comparable) (short) 1);
        try {
            defaultCategoryDataset0.removeColumn(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number1);
        org.junit.Assert.assertNotNull(pieDataset3);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        boolean boolean3 = dateAxis1.isPositiveArrowVisible();
        boolean boolean4 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        double double3 = dateAxis1.getLabelAngle();
        java.lang.String str4 = dateAxis1.getLabelToolTip();
        org.jfree.data.Range range5 = dateAxis1.getRange();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        java.lang.Object obj4 = dateAxis2.clone();
        java.awt.Font font5 = dateAxis2.getTickLabelFont();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone10 = dateAxis9.getTimeZone();
        boolean boolean11 = dateAxis9.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis9, xYItemRenderer12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot13.markerChanged(markerChangeEvent14);
        int int16 = xYPlot13.getWeight();
        java.awt.Stroke stroke17 = xYPlot13.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("");
        dateAxis20.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis20);
        xYPlot13.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        xYPlot13.setDomainAxisLocation((int) (short) 1, axisLocation27);
        java.awt.Paint paint29 = xYPlot13.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.LegendItemSource legendItemSource32 = null;
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle(legendItemSource32);
        org.jfree.chart.LegendItemSource legendItemSource34 = null;
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle(legendItemSource34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = legendTitle35.getLegendItemGraphicAnchor();
        legendTitle33.setLegendItemGraphicLocation(rectangleAnchor36);
        org.jfree.chart.block.BlockBorder blockBorder38 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle33.setFrame((org.jfree.chart.block.BlockFrame) blockBorder38);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray40 = legendTitle33.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment41 = legendTitle33.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement44 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment31, verticalAlignment41, (double) 0.0f, (double) (byte) 10);
        org.jfree.chart.LegendItemSource legendItemSource45 = null;
        org.jfree.chart.title.LegendTitle legendTitle46 = new org.jfree.chart.title.LegendTitle(legendItemSource45);
        org.jfree.chart.LegendItemSource legendItemSource47 = null;
        org.jfree.chart.title.LegendTitle legendTitle48 = new org.jfree.chart.title.LegendTitle(legendItemSource47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = legendTitle48.getLegendItemGraphicAnchor();
        legendTitle46.setLegendItemGraphicLocation(rectangleAnchor49);
        org.jfree.chart.block.BlockBorder blockBorder51 = org.jfree.chart.block.BlockBorder.NONE;
        legendTitle46.setFrame((org.jfree.chart.block.BlockFrame) blockBorder51);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray53 = legendTitle46.getSources();
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = legendTitle46.getVerticalAlignment();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset55 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer59 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset55, categoryAxis56, (org.jfree.chart.axis.ValueAxis) dateAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer59);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = categoryPlot60.getDomainAxis();
        java.awt.Paint paint62 = categoryPlot60.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer63 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator65 = null;
        stackedAreaRenderer63.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator65, false);
        double double68 = stackedAreaRenderer63.getItemLabelAnchorOffset();
        java.awt.Paint paint71 = stackedAreaRenderer63.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot60.setRangeGridlinePaint(paint71);
        java.awt.Paint paint74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke75 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint74, stroke75, paint76, stroke77, (float) 1L);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = categoryMarker79.getLabelOffset();
        double double82 = rectangleInsets80.calculateTopOutset((double) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset83 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis84 = null;
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer87 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot88 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset83, categoryAxis84, (org.jfree.chart.axis.ValueAxis) dateAxis86, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer87);
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = categoryPlot88.getDomainAxis();
        java.awt.Paint paint90 = categoryPlot88.getDomainGridlinePaint();
        java.awt.Stroke stroke91 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot88.setRangeGridlineStroke(stroke91);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor93 = categoryPlot88.getDomainGridlinePosition();
        boolean boolean94 = rectangleInsets80.equals((java.lang.Object) categoryPlot88);
        categoryPlot60.setAxisOffset(rectangleInsets80);
        org.jfree.chart.title.TextTitle textTitle96 = new org.jfree.chart.title.TextTitle("RectangleEdge.RIGHT", font5, paint29, rectangleEdge30, horizontalAlignment31, verticalAlignment54, rectangleInsets80);
        boolean boolean97 = textTitle96.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(blockBorder38);
        org.junit.Assert.assertNotNull(legendItemSourceArray40);
        org.junit.Assert.assertNotNull(verticalAlignment41);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(blockBorder51);
        org.junit.Assert.assertNotNull(legendItemSourceArray53);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertNull(categoryAxis61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 2.0d + "'", double68 == 2.0d);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 3.0d + "'", double82 == 3.0d);
        org.junit.Assert.assertNull(categoryAxis89);
        org.junit.Assert.assertNotNull(paint90);
        org.junit.Assert.assertNotNull(stroke91);
        org.junit.Assert.assertNotNull(categoryAnchor93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis("RectangleAnchor.CENTER", timeZone13);
        int int16 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        boolean boolean17 = dateAxis15.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.lang.Number number3 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) (-1), (java.lang.Comparable) 100);
        java.util.List list4 = defaultBoxAndWhiskerCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        xYPlot7.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        xYPlot7.setDomainAxisLocation((int) (short) 1, axisLocation21);
        java.awt.Paint paint23 = xYPlot7.getRangeGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis("");
        dateAxis25.resizeRange(0.05d, 0.0d);
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis25);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone37 = dateAxis36.getTimeZone();
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) 1L);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity44 = new org.jfree.chart.entity.TickLabelEntity(shape41, "May", "May");
        boolean boolean45 = org.jfree.chart.util.ShapeUtilities.equal(shape39, shape41);
        dateAxis36.setRightArrow(shape41);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer47 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator49 = null;
        stackedAreaRenderer47.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator49, false);
        double double52 = stackedAreaRenderer47.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer53 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator55 = null;
        stackedAreaRenderer53.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator55, false);
        java.awt.Paint paint60 = stackedAreaRenderer53.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer47.setBaseFillPaint(paint60);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D62 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D62.setMaximumBarWidth((double) '#');
        java.awt.Font font66 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        stackedBarRenderer3D62.setSeriesItemLabelFont((int) (byte) 100, font66);
        java.awt.Stroke stroke69 = stackedBarRenderer3D62.lookupSeriesOutlineStroke((int) ' ');
        java.awt.Color color70 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.LegendItem legendItem71 = new org.jfree.chart.LegendItem("0,-1,1,1,-1,1,-1,1", "", "hi!", "hi!", shape41, paint60, stroke69, (java.awt.Paint) color70);
        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint74 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke75 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint76 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke77 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint74, stroke75, paint76, stroke77, (float) 1L);
        org.jfree.chart.axis.DateAxis dateAxis81 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone82 = dateAxis81.getTimeZone();
        java.lang.Object obj83 = dateAxis81.clone();
        java.awt.Font font84 = dateAxis81.getTickLabelFont();
        java.lang.String str85 = dateAxis81.getLabelToolTip();
        java.awt.Stroke stroke86 = dateAxis81.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker88 = new org.jfree.chart.plot.ValueMarker((-1.0d), paint60, stroke72, paint76, stroke86, 0.0f);
        valueMarker88.setValue((double) 2019L);
        org.jfree.chart.util.Layer layer91 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot7.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker88, layer91);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 2.0d + "'", double52 == 2.0d);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNotNull(obj83);
        org.junit.Assert.assertNotNull(font84);
        org.junit.Assert.assertNull(str85);
        org.junit.Assert.assertNotNull(stroke86);
        org.junit.Assert.assertNotNull(layer91);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        java.awt.Stroke stroke6 = polarPlot3.getAngleGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        boolean boolean13 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        xYPlot15.markerChanged(markerChangeEvent16);
        int int18 = xYPlot15.getWeight();
        java.awt.Stroke stroke19 = xYPlot15.getRangeCrosshairStroke();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("");
        dateAxis22.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis22);
        xYPlot15.setDomainAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) dateAxis22);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone30 = dateAxis29.getTimeZone();
        java.lang.Object obj31 = dateAxis29.clone();
        java.awt.Font font32 = dateAxis29.getTickLabelFont();
        java.lang.String str33 = dateAxis29.getLabelToolTip();
        java.awt.Stroke stroke34 = dateAxis29.getTickMarkStroke();
        dateAxis29.setTickMarkInsideLength((float) 6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis22, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer37);
        org.jfree.data.Range range39 = polarPlot3.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis29);
        boolean boolean40 = polarPlot3.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 100);
        org.jfree.data.DefaultKeyedValues defaultKeyedValues2 = new org.jfree.data.DefaultKeyedValues();
        int int4 = defaultKeyedValues2.getIndex((java.lang.Comparable) (byte) 1);
        int int5 = defaultKeyedValues2.getItemCount();
        org.jfree.chart.util.SortOrder sortOrder6 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues2.sortByKeys(sortOrder6);
        int int8 = objectList1.indexOf((java.lang.Object) defaultKeyedValues2);
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator10 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        java.lang.Object obj11 = standardCategoryURLGenerator10.clone();
        objectList1.set(4, (java.lang.Object) standardCategoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        double double2 = ganttRenderer0.getMaximumBarWidth();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = ganttRenderer0.getGradientPaintTransformer();
        ganttRenderer0.setItemMargin(0.0d);
        java.awt.Paint paint8 = ganttRenderer0.getItemOutlinePaint(0, 11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone4);
        dateAxis1.setStandardTickUnits(tickUnitSource5);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone11 = dateAxis10.getTimeZone();
        boolean boolean12 = dateAxis10.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset7, valueAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis10, xYItemRenderer13);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        xYPlot14.markerChanged(markerChangeEvent15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace17);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis("");
        dateAxis24.setAutoTickUnitSelection(false, true);
        double double28 = dateAxis24.getLabelAngle();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D29 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        stackedBarRenderer3D29.setMaximumBarWidth((double) '#');
        java.awt.Shape shape32 = stackedBarRenderer3D29.getBaseShape();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset34 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer38 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset34, categoryAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer38);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot39.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis42 = new org.jfree.chart.axis.DateAxis("");
        dateAxis42.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent46 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis42);
        java.awt.Paint paint48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker53 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint48, stroke49, paint50, stroke51, (float) 1L);
        java.awt.Paint paint54 = categoryMarker53.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        stackedBarRenderer3D29.drawRangeMarker(graphics2D33, categoryPlot39, (org.jfree.chart.axis.ValueAxis) dateAxis42, (org.jfree.chart.plot.Marker) categoryMarker53, rectangle2D55);
        java.awt.Shape shape57 = dateAxis42.getDownArrow();
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity60 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) dateAxis24, shape57, "RectangleAnchor.CENTER", "Following");
        java.awt.Paint paint61 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone66 = dateAxis65.getTimeZone();
        boolean boolean67 = dateAxis65.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset62, valueAxis63, (org.jfree.chart.axis.ValueAxis) dateAxis65, xYItemRenderer68);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent70 = null;
        xYPlot69.markerChanged(markerChangeEvent70);
        int int72 = xYPlot69.getWeight();
        java.awt.Stroke stroke73 = xYPlot69.getRangeCrosshairStroke();
        int int74 = xYPlot69.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis76 = new org.jfree.chart.axis.DateAxis("");
        dateAxis76.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent80 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis76);
        int int81 = xYPlot69.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis76);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo84 = null;
        java.awt.geom.Point2D point2D85 = null;
        xYPlot69.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo84, point2D85);
        org.jfree.chart.axis.AxisSpace axisSpace87 = xYPlot69.getFixedRangeAxisSpace();
        java.awt.Stroke stroke88 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot69.setRangeGridlineStroke(stroke88);
        java.awt.Paint paint90 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem91 = new org.jfree.chart.LegendItem("", "Category Plot", "", "hi!", shape57, paint61, stroke88, paint90);
        xYPlot14.setOutlinePaint(paint90);
        org.jfree.chart.event.PlotChangeListener plotChangeListener93 = null;
        xYPlot14.addChangeListener(plotChangeListener93);
        dateAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot14);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(categoryAxis40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1) + "'", int81 == (-1));
        org.junit.Assert.assertNull(axisSpace87);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(paint90);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer4 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer4);
        categoryPlot5.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot5.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        boolean boolean6 = dateAxis4.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer7);
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        xYPlot8.setDomainZeroBaselinePaint(paint9);
        boolean boolean11 = textAnchor0.equals((java.lang.Object) xYPlot8);
        java.awt.Paint paint12 = xYPlot8.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer9 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, categoryAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot10.getDomainAxis();
        java.awt.Paint paint12 = categoryPlot10.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer13 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        stackedAreaRenderer13.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator15, false);
        double double18 = stackedAreaRenderer13.getItemLabelAnchorOffset();
        java.awt.Paint paint21 = stackedAreaRenderer13.getItemOutlinePaint(0, (int) (short) 100);
        categoryPlot10.setRangeGridlinePaint(paint21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        categoryPlot10.zoomRangeAxes(3.0d, plotRenderingInfo24, point2D27);
        org.jfree.chart.plot.PlotState plotState29 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            waferMapPlot2.draw(graphics2D3, rectangle2D4, point2D27, plotState29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        boolean boolean13 = xYPlot7.isRangeZoomable();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = xYPlot7.getLegendItems();
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER");
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer2 = null;
        org.jfree.chart.plot.PolarPlot polarPlot3 = new org.jfree.chart.plot.PolarPlot(xYDataset0, valueAxis1, polarItemRenderer2);
        polarPlot3.removeCornerTextItem("");
        polarPlot3.setAngleLabelsVisible(false);
        polarPlot3.setAngleLabelsVisible(true);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer11 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        stackedAreaRenderer11.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator13, false);
        double double16 = stackedAreaRenderer11.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        stackedAreaRenderer17.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator19, false);
        java.awt.Paint paint24 = stackedAreaRenderer17.getItemOutlinePaint((int) (byte) 10, (int) 'a');
        stackedAreaRenderer11.setBaseFillPaint(paint24);
        java.awt.Paint paint27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        java.awt.Paint paint29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "RectangleAnchor.CENTER", paint27, stroke28, paint29, stroke30, (float) 1L);
        java.awt.Color color33 = java.awt.Color.white;
        java.awt.Stroke stroke34 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-2208960000000L), paint24, stroke28, (java.awt.Paint) color33, stroke34, 1.0f);
        polarPlot3.setAngleGridlineStroke(stroke28);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        try {
            java.awt.Point point41 = polarPlot3.translateValueThetaRadiusToJava2D((double) 255, 0.0d, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = defaultBoxAndWhiskerCategoryDataset0.getGroup();
        int int2 = defaultBoxAndWhiskerCategoryDataset0.getRowCount();
        try {
            java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMeanValue(5, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(datasetGroup1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone4 = dateAxis3.getTimeZone();
        boolean boolean5 = dateAxis3.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis3, xYItemRenderer6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        xYPlot7.markerChanged(markerChangeEvent8);
        int int10 = xYPlot7.getWeight();
        java.awt.Stroke stroke11 = xYPlot7.getRangeCrosshairStroke();
        int int12 = xYPlot7.getSeriesCount();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        dateAxis14.setAutoTickUnitSelection(false, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis14);
        int int19 = xYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        xYPlot7.zoomDomainAxes(0.0d, (double) (-2208960000000L), plotRenderingInfo22, point2D23);
        boolean boolean25 = xYPlot7.isDomainGridlinesVisible();
        java.awt.Stroke stroke26 = xYPlot7.getDomainZeroBaselineStroke();
        xYPlot7.mapDatasetToRangeAxis(13, (int) '4');
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone32 = dateAxis31.getTimeZone();
        double double33 = dateAxis31.getLabelAngle();
        java.lang.String str34 = dateAxis31.getLabelToolTip();
        dateAxis31.setTickMarkOutsideLength(10.0f);
        xYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY((double) 1900);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = null;
        numberAxis3D0.setMarkerBand(markerAxisBand1);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
        numberAxis3D0.setTickUnit(numberTickUnit4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer5 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) stackedAreaRenderer5);
        categoryPlot6.setRangeGridlinesVisible(false);
        boolean boolean9 = stackedBarRenderer3D0.hasListener((java.util.EventListener) categoryPlot6);
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            categoryPlot6.handleClick((int) '4', (int) (short) 10, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone5 = dateAxis4.getTimeZone();
        java.util.Date date6 = dateAxis4.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.util.Date date10 = dateAxis8.getMinimumDate();
        org.jfree.data.gantt.Task task11 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date6, date10);
        boolean boolean12 = gradientPaintTransformType1.equals((java.lang.Object) date6);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone15 = dateAxis14.getTimeZone();
        boolean boolean16 = dateAxis14.isVerticalTickLabels();
        java.util.Date date17 = dateAxis14.getMinimumDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date6, date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.util.Date date20 = dateTickUnit0.addToDate(date17, timeZone19);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        int int2 = defaultKeyedValues0.getIndex((java.lang.Comparable) (byte) 1);
        defaultKeyedValues0.removeValue((java.lang.Comparable) 3);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType5 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        java.util.Date date10 = dateAxis8.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone13 = dateAxis12.getTimeZone();
        java.util.Date date14 = dateAxis12.getMinimumDate();
        org.jfree.data.gantt.Task task15 = new org.jfree.data.gantt.Task("0,-1,1,1,-1,1,-1,1", date10, date14);
        boolean boolean16 = gradientPaintTransformType5.equals((java.lang.Object) date10);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("");
        java.util.TimeZone timeZone19 = dateAxis18.getTimeZone();
        boolean boolean20 = dateAxis18.isVerticalTickLabels();
        java.util.Date date21 = dateAxis18.getMinimumDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date10, date21);
        defaultKeyedValues0.setValue((java.lang.Comparable) date10, (java.lang.Number) 255);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(gradientPaintTransformType5);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = null;
        stackedBarRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition1);
        stackedBarRenderer3D0.setIncludeBaseInRange(true);
        double double5 = stackedBarRenderer3D0.getYOffset();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = stackedBarRenderer3D0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertNull(itemLabelPosition6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
        int int2 = stackedBarRenderer3D1.getRowCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}

