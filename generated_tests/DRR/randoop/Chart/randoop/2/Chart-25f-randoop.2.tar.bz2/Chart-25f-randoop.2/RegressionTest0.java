import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("hi!", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 100L, (float) 1L, (float) (byte) 0);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            rectangleInsets0.trim(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str1.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = java.awt.Color.RED;
        java.lang.String str6 = color5.toString();
        java.awt.Stroke stroke7 = null;
        java.awt.Font font9 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color10 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("", font9, (java.awt.Paint) color10);
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem(attributedString0, "", "TextBlockAnchor.CENTER_LEFT", "TextBlockAnchor.CENTER_LEFT", shape4, (java.awt.Paint) color5, stroke7, (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str6.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        float[] floatArray4 = new float[] { (byte) -1, 100, (-20561) };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.awt.GradientPaint gradientPaint1 = null;
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        try {
            java.awt.GradientPaint gradientPaint3 = standardGradientPaintTransformer0.transform(gradientPaint1, shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        boolean boolean3 = textLine1.equals((java.lang.Object) font2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = null;
        try {
            textLine1.draw(graphics2D4, (float) (short) 10, 100.0f, textAnchor7, 0.0f, (float) (short) 10, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        try {
            java.lang.String str3 = standardCategorySeriesLabelGenerator0.generateLabel(categoryDataset1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = null;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) 0.0f, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = rectangleInsets0.createInsetRectangle(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = java.awt.Color.orange;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=255,g=0,b=0]", "", "", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) (byte) 0, (float) 10, (double) (short) 0, (-1.0f), (float) 1);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, (double) (byte) 100, categoryLabelWidthType4, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 'a', (double) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("TextBlockAnchor.CENTER_LEFT", font1, plot2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", graphics2D1, 0.0f, (float) ' ', textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 0.0f, (double) 1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        try {
            java.awt.GradientPaint gradientPaint4 = standardGradientPaintTransformer0.transform(gradientPaint2, shape3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("TextBlockAnchor.CENTER_LEFT", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (-1L), (double) (-20561));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-1.0) <= upper (-20561.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge1);
        try {
            double double3 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleAnchor.RIGHT", graphics2D1, (float) 1L, 0.0f, textAnchor4, (double) (byte) 0, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        java.lang.String str5 = basicProjectInfo4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textLine2.calculateDimensions(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 0.5f, (double) 100.0f, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("NO_CHANGE");
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.Paint paint1 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.Object obj1 = null;
        boolean boolean2 = axisLocation0.equals(obj1);
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 10);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        keyedObjects2D0.removeObject(comparable1, (java.lang.Comparable) 0.05d);
        try {
            java.lang.Comparable comparable5 = keyedObjects2D0.getRowKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (short) 10);
        double double3 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createOutsetRectangle(rectangle2D4, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ThreadContext");
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        keyedObjects2D0.removeObject(comparable1, (java.lang.Comparable) 0.05d);
        try {
            keyedObjects2D0.removeColumn((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean2 = axisSpace0.equals((java.lang.Object) shapeArray1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        axisSpace0.add((double) 10, rectangleEdge5);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = axisSpace0.expand(rectangle2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shapeArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Paint paint5 = textFragment3.getPaint();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke7 = lineBorder6.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets8.getRight();
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder(paint5, stroke7, rectangleInsets8);
        java.awt.Stroke stroke11 = lineBorder10.getStroke();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            lineBorder10.draw(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getRGB();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, 100, (int) (byte) 1);
        java.lang.String str6 = chartProgressEvent5.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-20561) + "'", int1 == (-20561));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=java.awt.Color[r=255,g=175,b=175]]" + "'", str6.equals("org.jfree.chart.event.ChartProgressEvent[source=java.awt.Color[r=255,g=175,b=175]]"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        keyedObjects2D0.removeObject(comparable1, (java.lang.Comparable) 0.05d);
        try {
            keyedObjects2D0.removeRow((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        try {
            keyedObjects2D0.removeColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) 1L);
        columnArrangement4.clear();
        boolean boolean7 = columnArrangement4.equals((java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("ThreadContext", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setURLText("RectangleAnchor.RIGHT");
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Color color0 = java.awt.Color.gray;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        java.awt.color.ColorSpace colorSpace3 = null;
        float[] floatArray10 = new float[] { 100, (short) 100, 0.0f, 1, 2, 10.0f };
        try {
            float[] floatArray11 = color0.getColorComponents(colorSpace3, floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str3 = lengthAdjustmentType2.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NO_CHANGE" + "'", str3.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            textFragment3.draw(graphics2D4, (float) (byte) 10, (float) 2, textAnchor7, (float) 10, (-1.0f), (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        java.lang.Object obj1 = null;
        boolean boolean2 = gradientPaintTransformType0.equals(obj1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Color color0 = java.awt.Color.RED;
        java.lang.String str1 = color0.toString();
        int int2 = color0.getBlue();
        java.awt.Color color3 = java.awt.Color.gray;
        float[] floatArray4 = null;
        float[] floatArray5 = color3.getRGBColorComponents(floatArray4);
        try {
            float[] floatArray6 = color0.getRGBComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str1.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("LengthConstraintType.NONE", graphics2D1, 1.0E-8d, (float) (byte) 1, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (short) 100, (double) (-1));
        flowArrangement10.clear();
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement10, dataset12, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer14.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = null;
        try {
            org.jfree.chart.util.Size2D size2D22 = flowArrangement4.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer14, graphics2D20, rectangleConstraint21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.setVersion("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean15 = basicProjectInfo13.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        org.jfree.chart.ui.Library[] libraryArray17 = basicProjectInfo13.getLibraries();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(libraryArray17);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            java.awt.Color color1 = java.awt.Color.decode("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ThreadContext\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.setVersion("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean15 = basicProjectInfo13.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        java.lang.String str17 = basicProjectInfo13.getName();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ThreadContext", graphics2D1, (float) 100, 0.0f, (double) 1, 0.0f, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=255,g=0,b=0]", graphics2D1, (float) 128, 0.0f, (double) 10, (float) 10, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Paint paint5 = textFragment3.getPaint();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(paint5);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleAnchor.RIGHT", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double[] doubleArray5 = new double[] { ' ', 15, (byte) 0 };
        double[] doubleArray9 = new double[] { ' ', 15, (byte) 0 };
        double[][] doubleArray10 = new double[][] { doubleArray5, doubleArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("org.jfree.chart.event.ChartProgressEvent[source=java.awt.Color[r=255,g=175,b=175]]", "rect", doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 8, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D4.removeColumn((java.lang.Comparable) numberTickUnit6);
        int int8 = numberTickUnit6.getMinorTickCount();
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] { 10L, "", 0.5f, 1.0E-8d, int8, 128 };
        java.lang.Comparable[] comparableArray17 = new java.lang.Comparable[] { (short) 10, 100.0d, (-1L), 1.0f, (byte) 1, (byte) -1 };
        double[] doubleArray23 = new double[] { 1.0f, (byte) 100, (byte) 10, 0.0f, (-1.0f) };
        double[] doubleArray29 = new double[] { 1.0f, (byte) 100, (byte) 10, 0.0f, (-1.0f) };
        double[] doubleArray35 = new double[] { 1.0f, (byte) 100, (byte) 10, 0.0f, (-1.0f) };
        double[] doubleArray41 = new double[] { 1.0f, (byte) 100, (byte) 10, 0.0f, (-1.0f) };
        double[] doubleArray47 = new double[] { 1.0f, (byte) 100, (byte) 10, 0.0f, (-1.0f) };
        double[][] doubleArray48 = new double[][] { doubleArray23, doubleArray29, doubleArray35, doubleArray41, doubleArray47 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray10, comparableArray17, doubleArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(comparableArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getRGB();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, 100, (int) (byte) 1);
        org.jfree.chart.JFreeChart jFreeChart6 = chartProgressEvent5.getChart();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        chartProgressEvent5.setChart(jFreeChart7);
        chartProgressEvent5.setPercent((-20561));
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-20561) + "'", int1 == (-20561));
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (double) (byte) 100, (float) (byte) 100, (float) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("{0}", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        java.awt.Paint paint6 = null;
        try {
            valueMarker4.setLabelPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock3, textBlockAnchor4, textAnchor5, (double) (short) 1);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor5, (double) 100, categoryLabelWidthType9, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(categoryLabelWidthType9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (short) 10);
        double double3 = rectangleInsets0.getLeft();
        double double5 = rectangleInsets0.trimWidth(0.0d);
        double double7 = rectangleInsets0.calculateLeftOutset((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = shapeList0.equals((java.lang.Object) "hi!");
        java.awt.Shape shape4 = shapeList0.getShape((int) '4');
        java.awt.Shape shape6 = shapeList0.getShape((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNull(shape6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Paint paint5 = textFragment3.getPaint();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke7 = lineBorder6.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets8.getRight();
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder(paint5, stroke7, rectangleInsets8);
        java.awt.Stroke stroke11 = lineBorder10.getStroke();
        java.awt.Stroke stroke12 = lineBorder10.getStroke();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            lineBorder10.draw(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            double double5 = numberAxis0.valueToJava2D((double) (byte) -1, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor7, (double) '4', (double) (byte) 100);
        java.awt.Color color12 = java.awt.Color.MAGENTA;
        java.awt.Font font15 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color16 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("", font15, (java.awt.Paint) color16);
        java.lang.String str18 = textFragment17.getText();
        java.awt.Paint paint19 = textFragment17.getPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (-20561), (float) (byte) 100);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke28 = lineBorder27.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color26, stroke28);
        java.awt.Paint paint30 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem(attributedString0, "rect", "java.awt.Color[r=255,g=0,b=0]", "NO_CHANGE", true, shape10, false, (java.awt.Paint) color12, true, paint19, stroke20, true, shape24, stroke28, paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-20561));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        java.util.List list5 = null;
        axisState4.setTicks(list5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (short) 100, (double) (-1));
        flowArrangement11.clear();
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11, dataset13, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer15.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer15.setHeight((double) (byte) 1);
        java.util.List list23 = legendItemBlockContainer15.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendItemBlockContainer15.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets25.calculateTopOutset((double) (short) 10);
        double double28 = rectangleInsets25.getLeft();
        double double30 = rectangleInsets25.trimWidth(0.0d);
        legendItemBlockContainer15.setMargin(rectangleInsets25);
        java.awt.geom.Rectangle2D rectangle2D32 = legendItemBlockContainer15.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            java.util.List list34 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D32, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.lang.Class<?> wildcardClass3 = itemLabelAnchor2.getClass();
        try {
            java.util.EventListener[] eventListenerArray4 = valueMarker1.getListeners((java.lang.Class) wildcardClass3);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.labels.ItemLabelAnchor; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 10.0f);
        double double4 = range2.constrain((double) 100);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range2, (double) (byte) 10, false);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range2, (double) '#');
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = null;
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, 0.0d, (float) 1, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment6, (double) (short) 100, (double) (-1));
        flowArrangement9.clear();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement9, dataset11, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer13.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer13.setHeight((double) (byte) 1);
        java.util.List list21 = legendItemBlockContainer13.getBlocks();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = null;
        try {
            org.jfree.chart.util.Size2D size2D24 = flowArrangement4.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer13, graphics2D22, rectangleConstraint23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 8, (float) 10L, (float) (-1L));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 10.0f);
        try {
            numberAxis0.setRange(range6, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (byte) 100, (float) 10);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) -1, (double) 100L);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0d) + "'", number3.equals((-1.0d)));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions1, categoryLabelPosition2);
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj6 = objectList4.get(15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor9 = categoryLabelPosition8.getRotationAnchor();
        objectList4.set(0, (java.lang.Object) categoryLabelPosition8);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition2, categoryLabelPosition8, categoryLabelPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "", jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent4.setChart(jFreeChart5);
        org.jfree.chart.JFreeChart jFreeChart7 = chartChangeEvent4.getChart();
        org.junit.Assert.assertNull(jFreeChart7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray6 = new float[] { 1, 1, '#', (-1L) };
        try {
            float[] floatArray7 = color0.getComponents(colorSpace1, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.setVersion("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean15 = basicProjectInfo13.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo13);
        java.lang.String str17 = basicProjectInfo4.getCopyright();
        boolean boolean19 = basicProjectInfo4.equals((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.ui.Contributor contributor3 = new org.jfree.chart.ui.Contributor("", "");
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "", jFreeChart4);
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        chartChangeEvent5.setChart(jFreeChart6);
        boolean boolean8 = verticalAlignment0.equals((java.lang.Object) jFreeChart6);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.KeyedObjects2D keyedObjects2D1 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D1.removeColumn((java.lang.Comparable) numberTickUnit3);
        try {
            org.jfree.chart.axis.TickUnit tickUnit5 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 100, (double) 10L, (double) 0L, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getBarWidth();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        java.awt.Stroke stroke5 = null;
        java.awt.Color color6 = java.awt.Color.pink;
        int int7 = color6.getRGB();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent11 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color6, jFreeChart8, 100, (int) (byte) 1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener13 = null;
        boolean boolean14 = numberAxis12.hasListener(eventListener13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis12.setTickLabelPaint((java.awt.Paint) color15);
        java.lang.String str17 = numberAxis12.getLabelToolTip();
        java.awt.Stroke stroke18 = numberAxis12.getTickMarkStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), (java.awt.Paint) color2, stroke5, (java.awt.Paint) color6, stroke18, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-20561) + "'", int7 == (-20561));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("rect", graphics2D1, (float) 15, (float) 0L, (double) (short) -1, (float) (short) 10, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Paint paint0 = null;
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color3);
        java.lang.String str5 = textFragment4.getText();
        java.awt.Paint paint6 = textFragment4.getPaint();
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke8 = lineBorder7.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double10 = rectangleInsets9.getRight();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder(paint6, stroke8, rectangleInsets9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, (double) (short) 100, (double) (-1));
        flowArrangement16.clear();
        org.jfree.data.general.Dataset dataset18 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement16, dataset18, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer20.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer20.setHeight((double) (byte) 1);
        java.util.List list28 = legendItemBlockContainer20.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendItemBlockContainer20.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets30.calculateTopOutset((double) (short) 10);
        double double33 = rectangleInsets30.getLeft();
        double double35 = rectangleInsets30.trimWidth(0.0d);
        legendItemBlockContainer20.setMargin(rectangleInsets30);
        try {
            org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder(paint0, stroke8, rectangleInsets30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("org.jfree.chart.event.ChartProgressEvent[source=java.awt.Color[r=255,g=175,b=175]]", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        boolean boolean2 = standardGradientPaintTransformer0.equals((java.lang.Object) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge3);
        axisSpace0.add((double) 100.0f, rectangleEdge4);
        java.lang.Object obj6 = axisSpace0.clone();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        basicProjectInfo4.setVersion("0");
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        java.awt.Paint paint5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        boolean boolean6 = horizontalAlignment0.equals((java.lang.Object) paint5);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.NEGATIVE" + "'", str1.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getTop();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        java.awt.Color color3 = color2.darker();
        try {
            org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=java.awt.Color[r=255,g=175,b=175]]", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ThreadContext", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        java.util.List list16 = legendItemBlockContainer8.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendItemBlockContainer8.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateTopOutset((double) (short) 10);
        double double21 = rectangleInsets18.getLeft();
        double double23 = rectangleInsets18.trimWidth(0.0d);
        legendItemBlockContainer8.setMargin(rectangleInsets18);
        java.awt.geom.Rectangle2D rectangle2D25 = legendItemBlockContainer8.getBounds();
        legendItemBlockContainer8.setMargin((double) (byte) 100, (double) (short) 10, 10.0d, (double) (-1L));
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        boolean boolean2 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) paintArray1);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) '#');
        boolean boolean5 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) 100);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        java.lang.Object obj4 = null;
        keyedObjects2D0.addObject(obj4, (java.lang.Comparable) 8, (java.lang.Comparable) "ThreadContext");
        int int9 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 8);
        java.util.List list10 = keyedObjects2D0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("PlotOrientation.HORIZONTAL");
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color3);
        org.jfree.chart.plot.Plot plot5 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("rect", font2, plot5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock1, textBlockAnchor2, textAnchor3, (double) (short) 1);
        java.lang.String str6 = categoryTick5.getText();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 10.0f);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, 0.0d, true);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range3, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = rectangleConstraint13.calculateConstrainedSize(size2D14);
        try {
            org.jfree.chart.util.Size2D size2D16 = rectangleConstraint10.calculateConstrainedSize(size2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(size2D15);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        java.awt.Shape shape8 = numberAxis0.getDownArrow();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment12, (double) (short) 100, (double) (-1));
        flowArrangement15.clear();
        org.jfree.data.general.Dataset dataset17 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement15, dataset17, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer19.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer19.setHeight((double) (byte) 1);
        java.util.List list27 = legendItemBlockContainer19.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = legendItemBlockContainer19.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double31 = rectangleInsets29.calculateTopOutset((double) (short) 10);
        double double32 = rectangleInsets29.getLeft();
        double double34 = rectangleInsets29.trimWidth(0.0d);
        legendItemBlockContainer19.setMargin(rectangleInsets29);
        java.awt.geom.Rectangle2D rectangle2D36 = legendItemBlockContainer19.getBounds();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment41, verticalAlignment42, (double) (short) 100, (double) (-1));
        flowArrangement45.clear();
        org.jfree.data.general.Dataset dataset47 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer49 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement45, dataset47, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer49.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer49.setHeight((double) (byte) 1);
        java.util.List list57 = legendItemBlockContainer49.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendItemBlockContainer49.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double61 = rectangleInsets59.calculateTopOutset((double) (short) 10);
        double double62 = rectangleInsets59.getLeft();
        double double64 = rectangleInsets59.trimWidth(0.0d);
        legendItemBlockContainer49.setMargin(rectangleInsets59);
        java.awt.geom.Rectangle2D rectangle2D66 = legendItemBlockContainer49.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double68 = numberAxis37.valueToJava2D((double) 1.0f, rectangle2D66, rectangleEdge67);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions69 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition70 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions71 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions69, categoryLabelPosition70);
        org.jfree.chart.axis.AxisSpace axisSpace72 = new org.jfree.chart.axis.AxisSpace();
        double double73 = axisSpace72.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge75);
        axisSpace72.add((double) 100.0f, rectangleEdge76);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition78 = categoryLabelPositions69.getLabelPosition(rectangleEdge76);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo79 = null;
        try {
            org.jfree.chart.axis.AxisState axisState80 = numberAxis0.draw(graphics2D9, 0.0d, rectangle2D36, rectangle2D66, rectangleEdge76, plotRenderingInfo79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions69);
        org.junit.Assert.assertNotNull(categoryLabelPositions71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(categoryLabelPosition78);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleAnchor0.equals(obj1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType6 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor3, textAnchor4, (double) 10L, categoryLabelWidthType6, (float) 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(categoryLabelWidthType6);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor5, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape8, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.Axis axis12 = axisLabelEntity11.getAxis();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(axis12);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        try {
            numberAxis0.setAutoRangeMinimumSize((double) (-1.0f), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Font font1 = null;
        java.awt.Color color2 = java.awt.Color.RED;
        java.lang.String str3 = color2.toString();
        int int4 = color2.getBlue();
        try {
            org.jfree.chart.text.TextBlock textBlock5 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.chart.event.ChartProgressEvent[source=java.awt.Color[r=255,g=175,b=175]]", font1, (java.awt.Paint) color2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str3.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 0L);
        double double4 = rectangleInsets0.calculateLeftInset((double) 500);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape9, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color22);
        java.awt.Shape shape24 = legendItem23.getLine();
        java.awt.Shape shape25 = legendItem23.getShape();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape25);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape9, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color22);
        java.awt.Paint paint24 = legendItem23.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        boolean boolean3 = borderArrangement0.equals((java.lang.Object) standardGradientPaintTransformer1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        java.lang.String str4 = legendItemEntity1.getShapeType();
        double[] doubleArray13 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray14);
        boolean boolean16 = legendItemEntity1.equals((java.lang.Object) categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset15);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 15.0d + "'", number17.equals(15.0d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        java.lang.String str2 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RangeType.FULL" + "'", str2.equals("RangeType.FULL"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray8 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray9);
        try {
            java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryLabelPosition4.getRotationAnchor();
        objectList0.set(0, (java.lang.Object) categoryLabelPosition4);
        java.lang.Object obj7 = objectList0.clone();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        valueMarker4.setAlpha(0.5f);
        double double8 = valueMarker4.getValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        valueMarker4.notifyListeners(markerChangeEvent9);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener11 = null;
        valueMarker4.removeChangeListener(markerChangeListener11);
        java.awt.Paint paint13 = valueMarker4.getPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        org.jfree.chart.util.BooleanList booleanList16 = new org.jfree.chart.util.BooleanList();
        boolean boolean17 = legendItemBlockContainer8.equals((java.lang.Object) booleanList16);
        java.lang.Object obj18 = booleanList16.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        org.jfree.chart.util.BooleanList booleanList16 = new org.jfree.chart.util.BooleanList();
        boolean boolean17 = legendItemBlockContainer8.equals((java.lang.Object) booleanList16);
        legendItemBlockContainer8.setWidth((double) (short) 1);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.lang.Class<?> wildcardClass2 = itemLabelAnchor1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("{0}", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(inputStream3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        boolean boolean2 = shapeList0.equals((java.lang.Object) "hi!");
        java.awt.Shape shape4 = shapeList0.getShape((int) '4');
        java.lang.Object obj5 = shapeList0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        boolean boolean2 = numberAxis0.isPositiveArrowVisible();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color7 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("", font6, (java.awt.Paint) color7);
        java.lang.String str9 = textFragment8.getText();
        java.awt.Paint paint10 = textFragment8.getPaint();
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke12 = lineBorder11.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder(paint10, stroke12, rectangleInsets13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) (short) 100, (double) (-1));
        flowArrangement20.clear();
        org.jfree.data.general.Dataset dataset22 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement20, dataset22, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer24.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer24.setHeight((double) (byte) 1);
        java.util.List list32 = legendItemBlockContainer24.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendItemBlockContainer24.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double36 = rectangleInsets34.calculateTopOutset((double) (short) 10);
        double double37 = rectangleInsets34.getLeft();
        double double39 = rectangleInsets34.trimWidth(0.0d);
        legendItemBlockContainer24.setMargin(rectangleInsets34);
        java.awt.geom.Rectangle2D rectangle2D41 = legendItemBlockContainer24.getBounds();
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets13.createInsetRectangle(rectangle2D41);
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity44 = new org.jfree.chart.entity.LegendItemEntity(shape43);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity47 = new org.jfree.chart.entity.TickLabelEntity(shape43, "ThreadContext", "ThreadContext");
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic49 = new org.jfree.chart.title.LegendGraphic(shape43, (java.awt.Paint) color48);
        java.awt.Paint paint50 = legendGraphic49.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder51 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke52 = lineBorder51.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = lineBorder51.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        numberAxis54.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment58 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment59 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement62 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment58, verticalAlignment59, (double) (short) 100, (double) (-1));
        flowArrangement62.clear();
        org.jfree.data.general.Dataset dataset64 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer66 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement62, dataset64, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer66.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer66.setHeight((double) (byte) 1);
        java.util.List list74 = legendItemBlockContainer66.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = legendItemBlockContainer66.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double78 = rectangleInsets76.calculateTopOutset((double) (short) 10);
        double double79 = rectangleInsets76.getLeft();
        double double81 = rectangleInsets76.trimWidth(0.0d);
        legendItemBlockContainer66.setMargin(rectangleInsets76);
        java.awt.geom.Rectangle2D rectangle2D83 = legendItemBlockContainer66.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double85 = numberAxis54.valueToJava2D((double) 1.0f, rectangle2D83, rectangleEdge84);
        java.awt.geom.Rectangle2D rectangle2D88 = rectangleInsets53.createOutsetRectangle(rectangle2D83, false, false);
        legendGraphic49.setLine((java.awt.Shape) rectangle2D88);
        org.jfree.chart.util.RectangleEdge rectangleEdge90 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo91 = null;
        try {
            org.jfree.chart.axis.AxisState axisState92 = numberAxis0.draw(graphics2D3, (double) 0.95f, rectangle2D42, rectangle2D88, rectangleEdge90, plotRenderingInfo91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(horizontalAlignment58);
        org.junit.Assert.assertNotNull(list74);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D88);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue(500, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleAnchor.RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        numberAxis0.setLabelToolTip("");
        numberAxis0.setLabelToolTip("rect");
        numberAxis0.setFixedDimension((double) 15);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = lineBorder14.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment21, verticalAlignment22, (double) (short) 100, (double) (-1));
        flowArrangement25.clear();
        org.jfree.data.general.Dataset dataset27 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, dataset27, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer29.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer29.setHeight((double) (byte) 1);
        java.util.List list37 = legendItemBlockContainer29.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendItemBlockContainer29.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double41 = rectangleInsets39.calculateTopOutset((double) (short) 10);
        double double42 = rectangleInsets39.getLeft();
        double double44 = rectangleInsets39.trimWidth(0.0d);
        legendItemBlockContainer29.setMargin(rectangleInsets39);
        java.awt.geom.Rectangle2D rectangle2D46 = legendItemBlockContainer29.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double48 = numberAxis17.valueToJava2D((double) 1.0f, rectangle2D46, rectangleEdge47);
        java.awt.geom.Rectangle2D rectangle2D51 = rectangleInsets16.createOutsetRectangle(rectangle2D46, false, false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement56 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment52, verticalAlignment53, (double) (short) 100, (double) (-1));
        flowArrangement56.clear();
        org.jfree.data.general.Dataset dataset58 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer60 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement56, dataset58, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer60.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer60.setHeight((double) (byte) 1);
        java.util.List list68 = legendItemBlockContainer60.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = legendItemBlockContainer60.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double72 = rectangleInsets70.calculateTopOutset((double) (short) 10);
        double double73 = rectangleInsets70.getLeft();
        double double75 = rectangleInsets70.trimWidth(0.0d);
        legendItemBlockContainer60.setMargin(rectangleInsets70);
        java.awt.geom.Rectangle2D rectangle2D77 = legendItemBlockContainer60.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge78);
        boolean boolean80 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge78);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo81 = null;
        try {
            org.jfree.chart.axis.AxisState axisState82 = numberAxis0.draw(graphics2D12, (double) 0L, rectangle2D51, rectangle2D77, rectangleEdge78, plotRenderingInfo81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNotNull(list68);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertNotNull(rectangleEdge79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean6 = textFragment3.equals((java.lang.Object) font5);
        java.lang.String str7 = textFragment3.getText();
        java.awt.Graphics2D graphics2D8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textFragment3.calculateDimensions(graphics2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        float float5 = textFragment3.getBaselineOffset();
        java.awt.Font font6 = textFragment3.getFont();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            float float9 = textFragment3.calculateBaselineOffset(graphics2D7, textAnchor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        boolean boolean2 = numberAxis0.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        boolean boolean5 = numberAxis0.isTickMarksVisible();
        boolean boolean6 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        try {
            java.lang.Comparable comparable4 = defaultStatisticalCategoryDataset0.getColumnKey(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("ThreadContext");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean8 = textFragment5.equals((java.lang.Object) font7);
        textLine1.removeFragment(textFragment5);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("RangeType.NEGATIVE");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint5.toFixedWidth((double) 10);
        try {
            org.jfree.chart.util.Size2D size2D8 = labelBlock1.arrange(graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement14 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment10, verticalAlignment11, (double) (short) 100, (double) (-1));
        flowArrangement14.clear();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer18 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement14, dataset16, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer18.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer18.setHeight((double) (byte) 1);
        java.util.List list26 = legendItemBlockContainer18.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = legendItemBlockContainer18.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateTopOutset((double) (short) 10);
        double double31 = rectangleInsets28.getLeft();
        double double33 = rectangleInsets28.trimWidth(0.0d);
        legendItemBlockContainer18.setMargin(rectangleInsets28);
        java.awt.geom.Rectangle2D rectangle2D35 = legendItemBlockContainer18.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double37 = numberAxis6.valueToJava2D((double) 1.0f, rectangle2D35, rectangleEdge36);
        numberAxis6.setLowerMargin((double) 8);
        boolean boolean40 = valueMarker4.equals((java.lang.Object) 8);
        java.awt.Color color41 = java.awt.Color.RED;
        java.lang.String str42 = color41.toString();
        int int43 = color41.getBlue();
        valueMarker4.setPaint((java.awt.Paint) color41);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str42.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=255,g=0,b=0]", "", "", "{0}");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getLibraries();
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        org.jfree.data.general.Dataset dataset14 = legendItemBlockContainer8.getDataset();
        java.lang.String str15 = legendItemBlockContainer8.getURLText();
        java.util.List list16 = legendItemBlockContainer8.getBlocks();
        try {
            java.util.Collection collection17 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list16);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(dataset14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) 1L);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 1L, dataset5);
        org.jfree.data.general.Dataset dataset7 = datasetChangeEvent6.getDataset();
        java.lang.Object obj8 = datasetChangeEvent6.getSource();
        org.jfree.data.general.Dataset dataset9 = datasetChangeEvent6.getDataset();
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + 1L + "'", obj8.equals(1L));
        org.junit.Assert.assertNull(dataset9);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int3 = java.awt.Color.HSBtoRGB(1.0f, (float) 15, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = legendTitle3.getPosition();
        axisState0.moveCursor((double) ' ', rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape9, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color22);
        java.awt.color.ColorSpace colorSpace24 = null;
        float[] floatArray25 = null;
        try {
            float[] floatArray26 = color22.getColorComponents(colorSpace24, floatArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor5, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape8, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        java.lang.String str12 = axisLabelEntity11.getShapeCoords();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "44,96,52,96,52,104,44,104,44,96,44,96" + "'", str12.equals("44,96,52,96,52,104,44,104,44,96,44,96"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener8 = null;
        boolean boolean9 = numberAxis7.hasListener(eventListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis7.setTickLabelPaint((java.awt.Paint) color10);
        java.awt.Font font14 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine15 = new org.jfree.chart.text.TextLine("", font14);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("rect", font14);
        numberAxis7.setTickLabelFont(font14);
        boolean boolean18 = basicProjectInfo4.equals((java.lang.Object) font14);
        basicProjectInfo4.setVersion("");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedWidth(10.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = rectangleConstraint2.calculateConstrainedSize(size2D3);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint2.getWidthConstraintType();
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = rectangleConstraint2.calculateConstrainedSize(size2D3);
        double double5 = size2D4.height;
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 1L, (double) 1);
        java.awt.Font font4 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("", font4);
        boolean boolean6 = meanAndStandardDeviation2.equals((java.lang.Object) textLine5);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        java.lang.String str4 = legendItemEntity1.getShapeType();
        double[] doubleArray13 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray14);
        boolean boolean16 = legendItemEntity1.equals((java.lang.Object) categoryDataset15);
        legendItemEntity1.setSeriesKey((java.lang.Comparable) ' ');
        org.jfree.data.general.Dataset dataset19 = null;
        legendItemEntity1.setDataset(dataset19);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleAnchor.RIGHT", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        boolean boolean7 = legendGraphic6.isShapeOutlineVisible();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendGraphic6.setShapeAnchor(rectangleAnchor8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke12 = lineBorder11.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = lineBorder11.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment19, (double) (short) 100, (double) (-1));
        flowArrangement22.clear();
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22, dataset24, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer26.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer26.setHeight((double) (byte) 1);
        java.util.List list34 = legendItemBlockContainer26.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendItemBlockContainer26.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateTopOutset((double) (short) 10);
        double double39 = rectangleInsets36.getLeft();
        double double41 = rectangleInsets36.trimWidth(0.0d);
        legendItemBlockContainer26.setMargin(rectangleInsets36);
        java.awt.geom.Rectangle2D rectangle2D43 = legendItemBlockContainer26.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double45 = numberAxis14.valueToJava2D((double) 1.0f, rectangle2D43, rectangleEdge44);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets13.createOutsetRectangle(rectangle2D43, false, false);
        org.jfree.chart.util.BooleanList booleanList49 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        numberAxis50.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment55 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement58 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment54, verticalAlignment55, (double) (short) 100, (double) (-1));
        flowArrangement58.clear();
        org.jfree.data.general.Dataset dataset60 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer62 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement58, dataset60, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer62.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer62.setHeight((double) (byte) 1);
        java.util.List list70 = legendItemBlockContainer62.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = legendItemBlockContainer62.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double74 = rectangleInsets72.calculateTopOutset((double) (short) 10);
        double double75 = rectangleInsets72.getLeft();
        double double77 = rectangleInsets72.trimWidth(0.0d);
        legendItemBlockContainer62.setMargin(rectangleInsets72);
        java.awt.geom.Rectangle2D rectangle2D79 = legendItemBlockContainer62.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double81 = numberAxis50.valueToJava2D((double) 1.0f, rectangle2D79, rectangleEdge80);
        boolean boolean82 = numberAxis50.isVerticalTickLabels();
        boolean boolean83 = booleanList49.equals((java.lang.Object) numberAxis50);
        try {
            java.lang.Object obj84 = legendGraphic6.draw(graphics2D10, rectangle2D43, (java.lang.Object) numberAxis50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
        org.junit.Assert.assertNotNull(list70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("java.awt.Color[r=255,g=0,b=0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = rectangleConstraint5.calculateConstrainedSize(size2D6);
        java.lang.String str8 = rectangleConstraint5.toString();
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle1.arrange(graphics2D2, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]" + "'", str8.equals("RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        try {
            valueMarker4.setAlpha((float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "TextBlockAnchor.CENTER_LEFT");
        try {
            java.lang.Comparable comparable4 = defaultStatisticalCategoryDataset0.getRowKey((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        java.util.List list5 = null;
        axisState4.setTicks(list5);
        java.awt.Font font8 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color9 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("", font8, (java.awt.Paint) color9);
        java.lang.String str11 = textFragment10.getText();
        java.awt.Paint paint12 = textFragment10.getPaint();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke14 = lineBorder13.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getRight();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder(paint12, stroke14, rectangleInsets15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment19, (double) (short) 100, (double) (-1));
        flowArrangement22.clear();
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22, dataset24, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer26.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer26.setHeight((double) (byte) 1);
        java.util.List list34 = legendItemBlockContainer26.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendItemBlockContainer26.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateTopOutset((double) (short) 10);
        double double39 = rectangleInsets36.getLeft();
        double double41 = rectangleInsets36.trimWidth(0.0d);
        legendItemBlockContainer26.setMargin(rectangleInsets36);
        java.awt.geom.Rectangle2D rectangle2D43 = legendItemBlockContainer26.getBounds();
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets15.createInsetRectangle(rectangle2D43);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.LEFT;
        try {
            java.util.List list46 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D44, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (-1));
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) standardGradientPaintTransformer1);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = categoryLabelPositions4.getLabelPosition(rectangleEdge5);
        boolean boolean7 = standardGradientPaintTransformer1.equals((java.lang.Object) categoryLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNull(categoryLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = standardGradientPaintTransformer2.getType();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer4 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType3);
        boolean boolean5 = tickUnits0.equals((java.lang.Object) gradientPaintTransformType3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = null;
        numberAxis0.setMarkerBand(markerAxisBand1);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener5 = null;
        boolean boolean6 = numberAxis4.hasListener(eventListener5);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, rectangleAnchor9, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity15 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis4, shape12, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D16 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D16.removeColumn((java.lang.Comparable) numberTickUnit18);
        numberAxis4.setTickUnit(numberTickUnit18);
        numberAxis4.setTickLabelsVisible(false);
        java.awt.Font font25 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color26 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("", font25, (java.awt.Paint) color26);
        java.lang.String str28 = textFragment27.getText();
        java.awt.Paint paint29 = textFragment27.getPaint();
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke31 = lineBorder30.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double33 = rectangleInsets32.getRight();
        org.jfree.chart.block.LineBorder lineBorder34 = new org.jfree.chart.block.LineBorder(paint29, stroke31, rectangleInsets32);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment36 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement39 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment35, verticalAlignment36, (double) (short) 100, (double) (-1));
        flowArrangement39.clear();
        org.jfree.data.general.Dataset dataset41 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer43 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement39, dataset41, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer43.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer43.setHeight((double) (byte) 1);
        java.util.List list51 = legendItemBlockContainer43.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = legendItemBlockContainer43.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double55 = rectangleInsets53.calculateTopOutset((double) (short) 10);
        double double56 = rectangleInsets53.getLeft();
        double double58 = rectangleInsets53.trimWidth(0.0d);
        legendItemBlockContainer43.setMargin(rectangleInsets53);
        java.awt.geom.Rectangle2D rectangle2D60 = legendItemBlockContainer43.getBounds();
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets32.createInsetRectangle(rectangle2D60);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions62 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition64 = categoryLabelPositions62.getLabelPosition(rectangleEdge63);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition66 = categoryLabelPositions62.getLabelPosition(rectangleEdge65);
        double double67 = numberAxis4.valueToJava2D((double) (-16777216), rectangle2D60, rectangleEdge65);
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge68);
        double double70 = numberAxis0.valueToJava2D((double) 128, rectangle2D60, rectangleEdge69);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(categoryLabelPositions62);
        org.junit.Assert.assertNull(categoryLabelPosition64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertNotNull(categoryLabelPosition66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        int int4 = chartColor3.getBlue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) (short) 100, (double) (-1));
        flowArrangement8.clear();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, dataset10, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer12.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer12.setHeight((double) (byte) 1);
        java.util.List list20 = legendItemBlockContainer12.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendItemBlockContainer12.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.calculateTopOutset((double) (short) 10);
        double double25 = rectangleInsets22.getLeft();
        double double27 = rectangleInsets22.trimWidth(0.0d);
        legendItemBlockContainer12.setMargin(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D29 = legendItemBlockContainer12.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double31 = numberAxis0.valueToJava2D((double) 1.0f, rectangle2D29, rectangleEdge30);
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis0.setStandardTickUnits(tickUnitSource32);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource32);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick6 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock2, textBlockAnchor3, textAnchor4, (double) (short) 1);
        org.jfree.chart.text.TextBlock textBlock8 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick12 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock8, textBlockAnchor9, textAnchor10, (double) (short) 1);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick15 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (byte) 10, textBlock2, textBlockAnchor9, textAnchor13, (double) (-20561));
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) textBlockAnchor9, jFreeChart16, (int) (byte) 1, 0);
        int int20 = chartProgressEvent19.getPercent();
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = categoryLabelPositions5.getLabelPosition(rectangleEdge6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = categoryLabelPositions5.getLabelPosition(rectangleEdge8);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge8);
        java.util.List list11 = axisCollection0.getAxesAtRight();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNull(categoryLabelPosition7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryLabelPosition9);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (short) 1, (java.lang.Number) (-1L), (java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) 10);
        java.lang.Number number10 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0.0f, (java.lang.Comparable) (-16777216));
        try {
            org.jfree.data.Range range12 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = categoryLabelPositions0.getLabelPosition(rectangleEdge3);
        double double5 = categoryLabelPosition4.getAngle();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNull(categoryLabelPosition2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryLabelPosition4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.7853981633974483d) + "'", double5 == (-0.7853981633974483d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 10.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, 0.0d, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(range2, (double) ' ');
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        numberAxis4.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) (short) 100, (double) (-1));
        flowArrangement12.clear();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12, dataset14, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer16.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer16.setHeight((double) (byte) 1);
        java.util.List list24 = legendItemBlockContainer16.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendItemBlockContainer16.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double28 = rectangleInsets26.calculateTopOutset((double) (short) 10);
        double double29 = rectangleInsets26.getLeft();
        double double31 = rectangleInsets26.trimWidth(0.0d);
        legendItemBlockContainer16.setMargin(rectangleInsets26);
        java.awt.geom.Rectangle2D rectangle2D33 = legendItemBlockContainer16.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double35 = numberAxis4.valueToJava2D((double) 1.0f, rectangle2D33, rectangleEdge34);
        java.awt.Paint paint36 = null;
        java.awt.Stroke stroke37 = null;
        java.awt.Paint paint38 = null;
        try {
            org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem(attributedString0, "", "", "LengthConstraintType.NONE", (java.awt.Shape) rectangle2D33, paint36, stroke37, paint38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor2, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape0, "", "NO_CHANGE");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.lang.Class<?> wildcardClass3 = itemLabelAnchor2.getClass();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.lang.Class<?> wildcardClass5 = itemLabelAnchor4.getClass();
        java.lang.Object obj6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RangeType.NEGATIVE", (java.lang.Class) wildcardClass3, (java.lang.Class) wildcardClass5);
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNotNull(inputStream7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("Layer.FOREGROUND", graphics2D1, 0.0f, (float) 15, 1.0d, (float) ' ', 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        numberAxis0.resizeRange((double) (byte) 0);
        numberAxis0.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str20 = layer19.toString();
        java.util.Collection collection21 = categoryPlot11.getRangeMarkers(10, layer19);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Layer.FOREGROUND" + "'", str20.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.awt.Color color1 = java.awt.Color.gray;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getRGBColorComponents(floatArray2);
        boolean boolean4 = lengthConstraintType0.equals((java.lang.Object) floatArray2);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        org.jfree.chart.util.BooleanList booleanList16 = new org.jfree.chart.util.BooleanList();
        boolean boolean17 = legendItemBlockContainer8.equals((java.lang.Object) booleanList16);
        legendItemBlockContainer8.setURLText("");
        java.util.List list20 = legendItemBlockContainer8.getBlocks();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.setName("");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.lang.Class<?> wildcardClass8 = itemLabelAnchor7.getClass();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        java.lang.Class<?> wildcardClass10 = itemLabelAnchor9.getClass();
        java.lang.Object obj11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RangeType.NEGATIVE", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass10);
        try {
            java.util.EventListener[] eventListenerArray12 = valueMarker4.getListeners((java.lang.Class) wildcardClass8);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.labels.ItemLabelAnchor; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color12 = java.awt.Color.lightGray;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("MAJOR", "Layer.FOREGROUND", "", "LengthConstraintType.NONE", shape4, (java.awt.Paint) color10, stroke11, (java.awt.Paint) color12);
        java.lang.String str14 = legendItem13.getLabel();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "MAJOR" + "'", str14.equals("MAJOR"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity2 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape1, (double) 'a', (float) (byte) 10, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick6 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock2, textBlockAnchor3, textAnchor4, (double) (short) 1);
        org.jfree.chart.text.TextBlock textBlock8 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick12 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock8, textBlockAnchor9, textAnchor10, (double) (short) 1);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick15 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (byte) 10, textBlock2, textBlockAnchor9, textAnchor13, (double) (-20561));
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlock textBlock20 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick24 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock20, textBlockAnchor21, textAnchor22, (double) (short) 1);
        textBlock2.draw(graphics2D16, (float) 100, (float) 1L, textBlockAnchor21, (float) (-1L), 10.0f, 1.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertNotNull(textAnchor22);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Paint paint5 = textFragment3.getPaint();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke7 = lineBorder6.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets8.getRight();
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder(paint5, stroke7, rectangleInsets8);
        java.awt.Stroke stroke11 = lineBorder10.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = lineBorder10.getInsets();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        valueMarker4.setAlpha(0.5f);
        double double8 = valueMarker4.getValue();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            valueMarker4.setLabelOffset(rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener7 = null;
        boolean boolean8 = numberAxis6.hasListener(eventListener7);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor11, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity17 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis6, shape14, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D18 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D18.removeColumn((java.lang.Comparable) numberTickUnit20);
        numberAxis6.setTickUnit(numberTickUnit20);
        defaultStatisticalCategoryDataset0.add(100.0d, (double) 10.0f, (java.lang.Comparable) 1.0f, (java.lang.Comparable) numberTickUnit20);
        int int24 = numberTickUnit20.getMinorTickCount();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int3 = java.awt.Color.HSBtoRGB((float) 8, (float) (-1L), (float) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = categoryLabelPositions0.getLabelPosition(rectangleEdge1);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = categoryLabelPositions0.getLabelPosition(rectangleEdge3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = categoryLabelPosition4.getCategoryAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNull(categoryLabelPosition2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(categoryLabelPosition4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor5, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape8, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener13 = null;
        boolean boolean14 = numberAxis12.hasListener(eventListener13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis12.setTickLabelPaint((java.awt.Paint) color15);
        boolean boolean17 = numberAxis12.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis12.setMarkerBand(markerAxisBand18);
        java.awt.Shape shape20 = numberAxis12.getDownArrow();
        axisLabelEntity11.setArea(shape20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment2 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment3 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment2, verticalAlignment3, (double) (short) 100, (double) (-1));
        flowArrangement6.clear();
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        boolean boolean9 = flowArrangement6.equals((java.lang.Object) textAnchor8);
        boolean boolean10 = rangeType0.equals((java.lang.Object) textAnchor8);
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
        org.junit.Assert.assertNotNull(horizontalAlignment2);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = null;
        axisState0.setTicks(list1);
        axisState0.cursorDown((double) 0.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("java.awt.Color[r=255,g=0,b=0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot18 = categoryPlot11.getParent();
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray32 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[][] numberArray33 = new java.lang.Number[][] { numberArray24, numberArray28, numberArray32 };
        org.jfree.data.category.CategoryDataset categoryDataset34 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextBlockAnchor.CENTER_LEFT", "hi!", numberArray33);
        categoryPlot11.setDataset(categoryDataset34);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double40 = defaultStatisticalCategoryDataset38.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean43 = numberAxis42.isTickLabelsVisible();
        boolean boolean44 = numberAxis42.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat45 = null;
        numberAxis42.setNumberFormatOverride(numberFormat45);
        boolean boolean47 = numberAxis42.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset38, categoryAxis41, (org.jfree.chart.axis.ValueAxis) numberAxis42, categoryItemRenderer48);
        java.awt.Color color51 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder52 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke53 = lineBorder52.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color51, stroke53);
        java.awt.Paint paint55 = valueMarker54.getLabelPaint();
        valueMarker54.setAlpha(0.5f);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str59 = layer58.toString();
        categoryPlot49.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker54, layer58);
        try {
            categoryPlot11.addDomainMarker((int) '#', categoryMarker37, layer58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray32);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(categoryDataset34);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Layer.FOREGROUND" + "'", str59.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        valueMarker4.setAlpha(0.5f);
        double double8 = valueMarker4.getValue();
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font10);
        valueMarker4.setLabelFont(font10);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        valueMarker4.notifyListeners(markerChangeEvent13);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        boolean boolean2 = rectangleAnchor0.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray3 = legendTitle1.getSources();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity9 = new org.jfree.chart.entity.TickLabelEntity(shape5, "ThreadContext", "ThreadContext");
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color10);
        java.awt.Paint paint12 = legendGraphic11.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke14 = lineBorder13.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder13.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment20, verticalAlignment21, (double) (short) 100, (double) (-1));
        flowArrangement24.clear();
        org.jfree.data.general.Dataset dataset26 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer28 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement24, dataset26, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer28.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer28.setHeight((double) (byte) 1);
        java.util.List list36 = legendItemBlockContainer28.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendItemBlockContainer28.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double40 = rectangleInsets38.calculateTopOutset((double) (short) 10);
        double double41 = rectangleInsets38.getLeft();
        double double43 = rectangleInsets38.trimWidth(0.0d);
        legendItemBlockContainer28.setMargin(rectangleInsets38);
        java.awt.geom.Rectangle2D rectangle2D45 = legendItemBlockContainer28.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double47 = numberAxis16.valueToJava2D((double) 1.0f, rectangle2D45, rectangleEdge46);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets15.createOutsetRectangle(rectangle2D45, false, false);
        legendGraphic11.setLine((java.awt.Shape) rectangle2D50);
        try {
            legendTitle1.draw(graphics2D4, rectangle2D50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(legendItemSourceArray3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Color color13 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke15);
        java.awt.Paint paint17 = valueMarker16.getLabelPaint();
        valueMarker16.setAlpha(0.5f);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str21 = layer20.toString();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        int int24 = categoryPlot11.getDomainAxisIndex(categoryAxis23);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Layer.FOREGROUND" + "'", str21.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 10.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, 0.0d, true);
        boolean boolean7 = range5.contains((double) (short) 10);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 1L, (float) 100L, textAnchor4, (double) (-1L), textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=255,g=0,b=0]", "", "", "{0}");
        java.lang.String str5 = basicProjectInfo4.getCopyright();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextBlock textBlock3 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock3, textBlockAnchor4, textAnchor5, (double) (short) 1);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor5, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "0");
        java.awt.Color color6 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke8 = lineBorder7.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke8);
        java.awt.Paint paint10 = valueMarker9.getLabelPaint();
        valueMarker9.setAlpha(0.5f);
        double double13 = valueMarker9.getValue();
        java.awt.Font font15 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("", font15);
        valueMarker9.setLabelFont(font15);
        boolean boolean18 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) font15);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape17);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape17, "ThreadContext", "ThreadContext");
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic23 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color22);
        java.awt.Paint paint24 = legendGraphic23.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder25 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke26 = lineBorder25.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = lineBorder25.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment32 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment33 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement36 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment32, verticalAlignment33, (double) (short) 100, (double) (-1));
        flowArrangement36.clear();
        org.jfree.data.general.Dataset dataset38 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer40 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement36, dataset38, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer40.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer40.setHeight((double) (byte) 1);
        java.util.List list48 = legendItemBlockContainer40.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = legendItemBlockContainer40.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double52 = rectangleInsets50.calculateTopOutset((double) (short) 10);
        double double53 = rectangleInsets50.getLeft();
        double double55 = rectangleInsets50.trimWidth(0.0d);
        legendItemBlockContainer40.setMargin(rectangleInsets50);
        java.awt.geom.Rectangle2D rectangle2D57 = legendItemBlockContainer40.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double59 = numberAxis28.valueToJava2D((double) 1.0f, rectangle2D57, rectangleEdge58);
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets27.createOutsetRectangle(rectangle2D57, false, false);
        legendGraphic23.setLine((java.awt.Shape) rectangle2D62);
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener65 = null;
        boolean boolean66 = numberAxis64.hasListener(eventListener65);
        java.awt.Color color67 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis64.setTickLabelPaint((java.awt.Paint) color67);
        try {
            java.lang.Object obj69 = legendItemBlockContainer8.draw(graphics2D16, rectangle2D62, (java.lang.Object) color67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(horizontalAlignment32);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(color67);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
        double double1 = itemLabelPosition0.getAngle();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot11.getLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            categoryPlot11.addAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.text.AttributedString attributedString0 = null;
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font5, (java.awt.Paint) color6);
        java.lang.String str8 = textFragment7.getText();
        java.awt.Paint paint9 = textFragment7.getPaint();
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke11 = lineBorder10.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets12.getRight();
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder(paint9, stroke11, rectangleInsets12);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets12.createInsetRectangle(rectangle2D40);
        java.awt.Color color42 = java.awt.Color.orange;
        java.awt.Font font44 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color45 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("", font44, (java.awt.Paint) color45);
        java.lang.String str47 = textFragment46.getText();
        java.awt.Paint paint48 = textFragment46.getPaint();
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke50 = lineBorder49.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double52 = rectangleInsets51.getRight();
        org.jfree.chart.block.LineBorder lineBorder53 = new org.jfree.chart.block.LineBorder(paint48, stroke50, rectangleInsets51);
        java.awt.Stroke stroke54 = lineBorder53.getStroke();
        java.awt.Color color55 = java.awt.Color.RED;
        try {
            org.jfree.chart.LegendItem legendItem56 = new org.jfree.chart.LegendItem(attributedString0, "org.jfree.chart.event.ChartProgressEvent[source=java.awt.Color[r=255,g=175,b=175]]", "RangeType.NEGATIVE", "hi!", (java.awt.Shape) rectangle2D41, (java.awt.Paint) color42, stroke54, (java.awt.Paint) color55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color55);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color3);
        java.lang.String str5 = textFragment4.getText();
        float float6 = textFragment4.getBaselineOffset();
        java.lang.Class<?> wildcardClass7 = textFragment4.getClass();
        java.io.InputStream inputStream8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass7);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(inputStream8);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        java.awt.Stroke stroke6 = numberAxis0.getTickMarkStroke();
        double double7 = numberAxis0.getLabelAngle();
        boolean boolean8 = numberAxis0.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.jfree.chart.block.BorderArrangement borderArrangement3 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean5 = borderArrangement3.equals((java.lang.Object) "rect");
        double[] doubleArray16 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray17 = new double[][] { doubleArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "hi!", doubleArray17);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer21 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement3, (org.jfree.data.general.Dataset) categoryDataset19, (java.lang.Comparable) 1.0f);
        keyedObjects0.setObject((java.lang.Comparable) 0L, (java.lang.Object) 1.0f);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(categoryDataset19);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        java.awt.Shape shape6 = numberAxis0.getUpArrow();
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        try {
            barRenderer0.setSeriesItemLabelGenerator((int) (byte) -1, categoryItemLabelGenerator3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = null;
        axisState0.setTicks(list1);
        double double3 = axisState0.getCursor();
        axisState0.setMax((double) (-1));
        axisState0.setMax(100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        boolean boolean3 = verticalAlignment1.equals((java.lang.Object) 0L);
        org.jfree.chart.block.ColumnArrangement columnArrangement6 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) -1, (double) (short) 0);
        columnArrangement6.clear();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (short) 10);
        double double3 = rectangleInsets0.getLeft();
        double double5 = rectangleInsets0.trimWidth(0.0d);
        java.awt.Color color6 = java.awt.Color.RED;
        java.lang.String str7 = color6.toString();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener11 = null;
        boolean boolean12 = numberAxis10.hasListener(eventListener11);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, rectangleAnchor15, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity21 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis10, shape18, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D22 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D22.removeColumn((java.lang.Comparable) numberTickUnit24);
        numberAxis10.setTickUnit(numberTickUnit24);
        numberAxis10.setTickLabelsVisible(false);
        java.awt.Font font31 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color32 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("", font31, (java.awt.Paint) color32);
        java.lang.String str34 = textFragment33.getText();
        java.awt.Paint paint35 = textFragment33.getPaint();
        org.jfree.chart.block.LineBorder lineBorder36 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke37 = lineBorder36.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets38.getRight();
        org.jfree.chart.block.LineBorder lineBorder40 = new org.jfree.chart.block.LineBorder(paint35, stroke37, rectangleInsets38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment41, verticalAlignment42, (double) (short) 100, (double) (-1));
        flowArrangement45.clear();
        org.jfree.data.general.Dataset dataset47 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer49 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement45, dataset47, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer49.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer49.setHeight((double) (byte) 1);
        java.util.List list57 = legendItemBlockContainer49.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendItemBlockContainer49.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double61 = rectangleInsets59.calculateTopOutset((double) (short) 10);
        double double62 = rectangleInsets59.getLeft();
        double double64 = rectangleInsets59.trimWidth(0.0d);
        legendItemBlockContainer49.setMargin(rectangleInsets59);
        java.awt.geom.Rectangle2D rectangle2D66 = legendItemBlockContainer49.getBounds();
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets38.createInsetRectangle(rectangle2D66);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions68 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition70 = categoryLabelPositions68.getLabelPosition(rectangleEdge69);
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition72 = categoryLabelPositions68.getLabelPosition(rectangleEdge71);
        double double73 = numberAxis10.valueToJava2D((double) (-16777216), rectangle2D66, rectangleEdge71);
        try {
            blockBorder8.draw(graphics2D9, rectangle2D66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str7.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(categoryLabelPositions68);
        org.junit.Assert.assertNull(categoryLabelPosition70);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertNotNull(categoryLabelPosition72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        java.lang.String str7 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-20561), (double) 0.5f, (int) (short) 1, (java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) standardGradientPaintTransformer1);
        java.lang.Object obj4 = standardGradientPaintTransformer1.clone();
        java.lang.Object obj5 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.05d, (double) 100L, (int) '4', (java.lang.Comparable) 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("RangeType.NEGATIVE", 15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 10.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, 0.0d, true);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range2, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder9.getInsets();
        boolean boolean12 = range2.equals((java.lang.Object) lineBorder9);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range2, 0.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range2, 3.0d);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = rectangleConstraint17.getWidthConstraintType();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(lengthConstraintType18);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        int int3 = java.awt.Color.HSBtoRGB((float) 1, 0.0f, (float) 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2) + "'", int3 == (-2));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean6 = textFragment3.equals((java.lang.Object) font5);
        java.lang.String str7 = textFragment3.getText();
        float float8 = textFragment3.getBaselineOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation20);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = numberAxis22.hasListener(eventListener23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis22.setTickLabelPaint((java.awt.Paint) color25);
        boolean boolean27 = numberAxis22.isAxisLineVisible();
        boolean boolean28 = axisLocation19.equals((java.lang.Object) numberAxis22);
        categoryPlot11.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis22, false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean13 = basicProjectInfo11.equals((java.lang.Object) (short) -1);
        basicProjectInfo11.setVersion("java.awt.Color[r=255,g=0,b=0]");
        boolean boolean16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) color3, (java.lang.Object) "java.awt.Color[r=255,g=0,b=0]");
        barRenderer0.setSeriesPaint((int) (byte) 100, (java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) (short) 100, (double) (-1));
        flowArrangement8.clear();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, dataset10, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer12.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer12.setHeight((double) (byte) 1);
        java.util.List list20 = legendItemBlockContainer12.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendItemBlockContainer12.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.calculateTopOutset((double) (short) 10);
        double double25 = rectangleInsets22.getLeft();
        double double27 = rectangleInsets22.trimWidth(0.0d);
        legendItemBlockContainer12.setMargin(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D29 = legendItemBlockContainer12.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double31 = numberAxis0.valueToJava2D((double) 1.0f, rectangle2D29, rectangleEdge30);
        numberAxis0.setLowerMargin((double) 8);
        boolean boolean34 = numberAxis0.getAutoRangeStickyZero();
        double double35 = numberAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 8.0d + "'", double35 == 8.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { "RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]", 0.95f, 0L, false, Double.NaN };
        java.lang.Comparable[] comparableArray11 = new java.lang.Comparable[] { (byte) -1, "hi!", (byte) 100, (byte) -1, 10 };
        double[] doubleArray12 = new double[] {};
        double[] doubleArray13 = new double[] {};
        double[] doubleArray14 = new double[] {};
        double[] doubleArray15 = new double[] {};
        double[][] doubleArray16 = new double[][] { doubleArray12, doubleArray13, doubleArray14, doubleArray15 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray5, comparableArray11, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Duplicate items in 'columnKeys'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(comparableArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (short) 100, (double) (-1));
        flowArrangement5.clear();
        org.jfree.data.general.Dataset dataset7 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5, dataset7, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer9.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer9.setHeight((double) (byte) 1);
        org.jfree.chart.util.BooleanList booleanList17 = new org.jfree.chart.util.BooleanList();
        boolean boolean18 = legendItemBlockContainer9.equals((java.lang.Object) booleanList17);
        boolean boolean19 = itemLabelAnchor0.equals((java.lang.Object) booleanList17);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape9, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color22);
        org.jfree.data.general.Dataset dataset24 = legendItem23.getDataset();
        java.lang.Comparable comparable25 = legendItem23.getSeriesKey();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(dataset24);
        org.junit.Assert.assertNull(comparable25);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        boolean boolean2 = numberAxis0.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat3 = null;
        numberAxis0.setNumberFormatOverride(numberFormat3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double8 = defaultStatisticalCategoryDataset6.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean11 = numberAxis10.isTickLabelsVisible();
        boolean boolean12 = numberAxis10.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat13 = null;
        numberAxis10.setNumberFormatOverride(numberFormat13);
        boolean boolean15 = numberAxis10.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset6, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer16);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str20 = layer19.toString();
        java.util.Collection collection21 = categoryPlot17.getDomainMarkers(0, layer19);
        categoryPlot17.clearRangeAxes();
        categoryPlot17.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint25 = categoryPlot17.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot17.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot17.getRangeAxisEdge();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity30 = new org.jfree.chart.entity.LegendItemEntity(shape29);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity33 = new org.jfree.chart.entity.TickLabelEntity(shape29, "ThreadContext", "ThreadContext");
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic35 = new org.jfree.chart.title.LegendGraphic(shape29, (java.awt.Paint) color34);
        java.awt.Paint paint36 = legendGraphic35.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke38 = lineBorder37.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = lineBorder37.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        numberAxis40.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment44, verticalAlignment45, (double) (short) 100, (double) (-1));
        flowArrangement48.clear();
        org.jfree.data.general.Dataset dataset50 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48, dataset50, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer52.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer52.setHeight((double) (byte) 1);
        java.util.List list60 = legendItemBlockContainer52.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = legendItemBlockContainer52.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double64 = rectangleInsets62.calculateTopOutset((double) (short) 10);
        double double65 = rectangleInsets62.getLeft();
        double double67 = rectangleInsets62.trimWidth(0.0d);
        legendItemBlockContainer52.setMargin(rectangleInsets62);
        java.awt.geom.Rectangle2D rectangle2D69 = legendItemBlockContainer52.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double71 = numberAxis40.valueToJava2D((double) 1.0f, rectangle2D69, rectangleEdge70);
        java.awt.geom.Rectangle2D rectangle2D74 = rectangleInsets39.createOutsetRectangle(rectangle2D69, false, false);
        legendGraphic35.setLine((java.awt.Shape) rectangle2D74);
        org.jfree.chart.axis.AxisSpace axisSpace76 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray77 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean78 = axisSpace76.equals((java.lang.Object) shapeArray77);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge80);
        axisSpace76.add((double) 10, rectangleEdge81);
        double double83 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D74, rectangleEdge81);
        org.jfree.chart.axis.AxisSpace axisSpace84 = new org.jfree.chart.axis.AxisSpace();
        double double85 = axisSpace84.getRight();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace86 = numberAxis0.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot17, rectangle2D28, rectangleEdge81, axisSpace84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Layer.FOREGROUND" + "'", str20.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(list60);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(shapeArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(rectangleEdge81);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.ChartColor chartColor7 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment14, verticalAlignment15, (double) (short) 100, (double) (-1));
        flowArrangement18.clear();
        org.jfree.data.general.Dataset dataset20 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer22 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement18, dataset20, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer22.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer22.setHeight((double) (byte) 1);
        java.util.List list30 = legendItemBlockContainer22.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = legendItemBlockContainer22.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double34 = rectangleInsets32.calculateTopOutset((double) (short) 10);
        double double35 = rectangleInsets32.getLeft();
        double double37 = rectangleInsets32.trimWidth(0.0d);
        legendItemBlockContainer22.setMargin(rectangleInsets32);
        java.awt.geom.Rectangle2D rectangle2D39 = legendItemBlockContainer22.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double41 = numberAxis10.valueToJava2D((double) 1.0f, rectangle2D39, rectangleEdge40);
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = chartColor7.createContext(colorModel8, rectangle9, rectangle2D39, affineTransform42, renderingHints43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener47 = null;
        boolean boolean48 = numberAxis46.hasListener(eventListener47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis46.setTickLabelPaint((java.awt.Paint) color49);
        java.lang.String str51 = numberAxis46.getLabelToolTip();
        java.awt.Stroke stroke52 = numberAxis46.getTickMarkStroke();
        java.awt.Color color53 = java.awt.Color.pink;
        try {
            org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "RangeType.FULL", "ThreadContext", (java.awt.Shape) rectangle2D39, (java.awt.Paint) color45, stroke52, (java.awt.Paint) color53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment14);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNull(str51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(color53);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean2 = axisSpace0.equals((java.lang.Object) shapeArray1);
        double double3 = axisSpace0.getBottom();
        org.junit.Assert.assertNotNull(shapeArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        boolean boolean12 = numberAxis4.isAxisLineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener14 = null;
        boolean boolean15 = numberAxis13.hasListener(eventListener14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color16);
        java.awt.Font font20 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("", font20);
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine("rect", font20);
        numberAxis13.setTickLabelFont(font20);
        boolean boolean24 = numberAxis13.isInverted();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener26 = null;
        boolean boolean27 = numberAxis25.hasListener(eventListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis25.setTickLabelPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = numberAxis25.getTickUnit();
        numberAxis13.setTickUnit(numberTickUnit30);
        numberAxis4.setTickUnit(numberTickUnit30, false, true);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(numberTickUnit30);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis0.setNumberFormatOverride(numberFormat8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double12 = rectangleInsets10.calculateTopOutset((double) (short) 10);
        double double13 = rectangleInsets10.getLeft();
        double double15 = rectangleInsets10.trimWidth(0.0d);
        double double17 = rectangleInsets10.extendWidth((double) (-1L));
        numberAxis0.setTickLabelInsets(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-1.0d) + "'", double17 == (-1.0d));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 10.0f);
        double double4 = range2.constrain((double) 100);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range2, (double) (byte) 10, false);
        org.jfree.data.Range range10 = org.jfree.data.Range.expand(range7, (double) ' ', (double) (short) 100);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment12, (double) (short) 100, (double) (-1));
        flowArrangement15.clear();
        org.jfree.data.general.Dataset dataset17 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement15, dataset17, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer19.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer19.setHeight((double) (byte) 1);
        boolean boolean27 = range10.equals((java.lang.Object) legendItemBlockContainer19);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        numberAxis0.setLabelToolTip("");
        numberAxis0.setLabelToolTip("rect");
        numberAxis0.setFixedDimension((double) 15);
        java.awt.Paint paint12 = numberAxis0.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        float[] floatArray5 = new float[] { 'a', 10L };
        try {
            float[] floatArray6 = color1.getRGBColorComponents(floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = rectangleConstraint2.calculateConstrainedSize(size2D3);
        double double5 = size2D4.getHeight();
        double double6 = size2D4.getWidth();
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape9, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color22);
        java.awt.Shape shape24 = legendItem23.getLine();
        legendItem23.setSeriesKey((java.lang.Comparable) (byte) 1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "NO_CHANGE", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (short) 10);
        double double3 = rectangleInsets0.getLeft();
        double double5 = rectangleInsets0.trimWidth(0.0d);
        double double7 = rectangleInsets0.calculateBottomInset((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 1, (double) '4', (double) (byte) 1, (double) (byte) 100);
        double double6 = rectangleInsets4.extendWidth((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 152.0d + "'", double6 == 152.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        legendItemEntity1.setURLText("ThreadContext");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        java.lang.String str4 = legendItemEntity1.getShapeType();
        double[] doubleArray13 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray14);
        boolean boolean16 = legendItemEntity1.equals((java.lang.Object) categoryDataset15);
        java.lang.String str17 = legendItemEntity1.getURLText();
        java.lang.Object obj18 = legendItemEntity1.clone();
        java.lang.Object obj19 = legendItemEntity1.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        numberAxis0.resizeRange((double) (byte) 0);
        java.lang.String str4 = numberAxis0.getLabelURL();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        java.lang.String str4 = legendItemEntity1.getShapeType();
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[][] numberArray19 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18 };
        org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextBlockAnchor.CENTER_LEFT", "hi!", numberArray19);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset20, 0);
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset20);
        legendItemEntity1.setDataset((org.jfree.data.general.Dataset) categoryDataset20);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.Plot plot1 = numberAxis0.getPlot();
        try {
            numberAxis0.zoomRange((double) 0.5f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.5) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getRGB();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, 100, (int) (byte) 1);
        chartProgressEvent5.setType((int) (short) 100);
        int int8 = chartProgressEvent5.getType();
        chartProgressEvent5.setType((-1));
        java.lang.Object obj11 = chartProgressEvent5.getSource();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-20561) + "'", int1 == (-20561));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        textBlock0.addLine(textLine4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D7 = null;
        try {
            org.jfree.chart.util.Size2D size2D8 = textBlock0.calculateDimensions(graphics2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(horizontalAlignment6);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        numberAxis8.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement16 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment12, verticalAlignment13, (double) (short) 100, (double) (-1));
        flowArrangement16.clear();
        org.jfree.data.general.Dataset dataset18 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement16, dataset18, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer20.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer20.setHeight((double) (byte) 1);
        java.util.List list28 = legendItemBlockContainer20.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendItemBlockContainer20.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets30.calculateTopOutset((double) (short) 10);
        double double33 = rectangleInsets30.getLeft();
        double double35 = rectangleInsets30.trimWidth(0.0d);
        legendItemBlockContainer20.setMargin(rectangleInsets30);
        java.awt.geom.Rectangle2D rectangle2D37 = legendItemBlockContainer20.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double39 = numberAxis8.valueToJava2D((double) 1.0f, rectangle2D37, rectangleEdge38);
        java.awt.geom.AffineTransform affineTransform40 = null;
        java.awt.RenderingHints renderingHints41 = null;
        java.awt.PaintContext paintContext42 = chartColor5.createContext(colorModel6, rectangle7, rectangle2D37, affineTransform40, renderingHints41);
        try {
            java.awt.geom.Point2D point2D43 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) (byte) 100, (double) (byte) 100, (java.awt.geom.Rectangle2D) rectangle7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext42);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        boolean boolean7 = basicProjectInfo4.equals((java.lang.Object) 10.0f);
        basicProjectInfo4.setVersion("Layer.FOREGROUND");
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("0");
        java.lang.Object obj2 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("0");
        java.lang.String str2 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("NO_CHANGE", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        java.awt.Paint paint7 = textFragment5.getPaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets10.getRight();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder(paint7, stroke9, rectangleInsets10);
        java.awt.Stroke stroke13 = lineBorder12.getStroke();
        valueMarker1.setOutlineStroke(stroke13);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = valueMarker1.getLabelOffsetType();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = null;
        valueMarker1.notifyListeners(markerChangeEvent16);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor2, (double) '4', (double) (byte) 100);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor6);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType9 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor8, categoryLabelWidthType9, (float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(categoryLabelWidthType9);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) 1L);
        columnArrangement4.clear();
        java.lang.Object obj6 = null;
        boolean boolean7 = columnArrangement4.equals(obj6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) (short) 100, (double) (-1));
        flowArrangement12.clear();
        org.jfree.data.general.Dataset dataset14 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12, dataset14, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer16.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer16.setHeight((double) (byte) 1);
        java.util.List list24 = legendItemBlockContainer16.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = legendItemBlockContainer16.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double28 = rectangleInsets26.calculateTopOutset((double) (short) 10);
        double double29 = rectangleInsets26.getLeft();
        double double31 = rectangleInsets26.trimWidth(0.0d);
        legendItemBlockContainer16.setMargin(rectangleInsets26);
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity34 = new org.jfree.chart.entity.LegendItemEntity(shape33);
        org.jfree.data.general.Dataset dataset35 = legendItemEntity34.getDataset();
        org.jfree.data.general.Dataset dataset36 = legendItemEntity34.getDataset();
        java.lang.String str37 = legendItemEntity34.getShapeType();
        double[] doubleArray46 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray47 = new double[][] { doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray47);
        boolean boolean49 = legendItemEntity34.equals((java.lang.Object) categoryDataset48);
        legendItemEntity34.setSeriesKey((java.lang.Comparable) ' ');
        columnArrangement4.add((org.jfree.chart.block.Block) legendItemBlockContainer16, (java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(dataset35);
        org.junit.Assert.assertNull(dataset36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "rect" + "'", str37.equals("rect"));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder8.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double42 = numberAxis11.valueToJava2D((double) 1.0f, rectangle2D40, rectangleEdge41);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets10.createOutsetRectangle(rectangle2D40, false, false);
        legendGraphic6.setLine((java.awt.Shape) rectangle2D45);
        java.lang.Object obj47 = legendGraphic6.clone();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener49 = null;
        boolean boolean50 = numberAxis48.hasListener(eventListener49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis48.setTickLabelPaint((java.awt.Paint) color51);
        boolean boolean53 = numberAxis48.isAxisLineVisible();
        boolean boolean54 = numberAxis48.getAutoRangeIncludesZero();
        numberAxis48.setPositiveArrowVisible(false);
        boolean boolean57 = legendGraphic6.equals((java.lang.Object) numberAxis48);
        java.awt.Stroke stroke58 = legendGraphic6.getLineStroke();
        boolean boolean59 = legendGraphic6.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.Color color1 = java.awt.Color.orange;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color1);
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean4 = blockBorder2.equals((java.lang.Object) strokeArray3);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        valueMarker4.setAlpha(0.5f);
        double double8 = valueMarker4.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker4.setLabelAnchor(rectangleAnchor9);
        java.awt.Stroke stroke11 = valueMarker4.getStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 0.5f, Double.NaN);
        textTitle1.setTextAlignment(horizontalAlignment3);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape9, "NO_CHANGE", "");
        boolean boolean13 = horizontalAlignment3.equals((java.lang.Object) "NO_CHANGE");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Shape shape4 = null;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke6 = lineBorder5.getStroke();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "0", "RangeType.FULL", "LengthConstraintType.NONE", shape4, stroke6, (java.awt.Paint) chartColor10);
        java.awt.Stroke stroke12 = legendItem11.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        boolean boolean7 = legendGraphic6.isShapeOutlineVisible();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder9.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) (short) 100, (double) (-1));
        flowArrangement20.clear();
        org.jfree.data.general.Dataset dataset22 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement20, dataset22, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer24.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer24.setHeight((double) (byte) 1);
        java.util.List list32 = legendItemBlockContainer24.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendItemBlockContainer24.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double36 = rectangleInsets34.calculateTopOutset((double) (short) 10);
        double double37 = rectangleInsets34.getLeft();
        double double39 = rectangleInsets34.trimWidth(0.0d);
        legendItemBlockContainer24.setMargin(rectangleInsets34);
        java.awt.geom.Rectangle2D rectangle2D41 = legendItemBlockContainer24.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double43 = numberAxis12.valueToJava2D((double) 1.0f, rectangle2D41, rectangleEdge42);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets11.createOutsetRectangle(rectangle2D41, false, false);
        try {
            java.lang.Object obj48 = legendGraphic6.draw(graphics2D8, rectangle2D41, (java.lang.Object) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        valueMarker4.setAlpha(0.5f);
        java.lang.Object obj8 = valueMarker4.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick6 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock2, textBlockAnchor3, textAnchor4, (double) (short) 1);
        org.jfree.chart.text.TextBlock textBlock8 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick12 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock8, textBlockAnchor9, textAnchor10, (double) (short) 1);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick15 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (byte) 10, textBlock2, textBlockAnchor9, textAnchor13, (double) (-20561));
        java.lang.Object obj16 = categoryTick15.clone();
        java.lang.Comparable comparable17 = categoryTick15.getCategory();
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + (byte) 10 + "'", comparable17.equals((byte) 10));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        java.lang.String str4 = legendItemEntity1.getShapeType();
        double[] doubleArray13 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray14);
        boolean boolean16 = legendItemEntity1.equals((java.lang.Object) categoryDataset15);
        java.lang.String str17 = legendItemEntity1.getURLText();
        java.awt.Shape shape18 = legendItemEntity1.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5);
        java.lang.String str7 = textFragment6.getText();
        float float8 = textFragment6.getBaselineOffset();
        java.awt.Font font9 = textFragment6.getFont();
        try {
            barRenderer0.setSeriesItemLabelFont((int) (byte) -1, font9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (-20561), (float) (byte) 100);
        java.awt.Shape shape7 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity8 = new org.jfree.chart.entity.LegendItemEntity(shape7);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity11 = new org.jfree.chart.entity.TickLabelEntity(shape7, "ThreadContext", "ThreadContext");
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color12);
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("RectangleAnchor.RIGHT", "", "org.jfree.chart.event.ChartProgressEvent[source=java.awt.Color[r=255,g=175,b=175]]", "", shape6, (java.awt.Paint) color12);
        java.text.AttributedString attributedString15 = legendItem14.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(attributedString15);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        org.jfree.data.general.Dataset dataset14 = legendItemBlockContainer8.getDataset();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = rectangleConstraint18.calculateConstrainedSize(size2D19);
        java.lang.String str21 = rectangleConstraint18.toString();
        org.jfree.chart.util.Size2D size2D22 = legendItemBlockContainer8.arrange(graphics2D15, rectangleConstraint18);
        double double23 = size2D22.width;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(dataset14);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]" + "'", str21.equals("RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]"));
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 52.0d + "'", double23 == 52.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        try {
            axisSpace0.ensureAtLeast(0.0d, rectangleEdge3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: AxisSpace.ensureAtLeast(): unrecognised AxisLocation.");
        } catch (java.lang.IllegalStateException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        numberAxis16.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment20, verticalAlignment21, (double) (short) 100, (double) (-1));
        flowArrangement24.clear();
        org.jfree.data.general.Dataset dataset26 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer28 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement24, dataset26, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer28.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer28.setHeight((double) (byte) 1);
        java.util.List list36 = legendItemBlockContainer28.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = legendItemBlockContainer28.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double40 = rectangleInsets38.calculateTopOutset((double) (short) 10);
        double double41 = rectangleInsets38.getLeft();
        double double43 = rectangleInsets38.trimWidth(0.0d);
        legendItemBlockContainer28.setMargin(rectangleInsets38);
        java.awt.geom.Rectangle2D rectangle2D45 = legendItemBlockContainer28.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double47 = numberAxis16.valueToJava2D((double) 1.0f, rectangle2D45, rectangleEdge46);
        java.awt.geom.AffineTransform affineTransform48 = null;
        java.awt.RenderingHints renderingHints49 = null;
        java.awt.PaintContext paintContext50 = chartColor13.createContext(colorModel14, rectangle15, rectangle2D45, affineTransform48, renderingHints49);
        valueMarker9.setPaint((java.awt.Paint) chartColor13);
        legendGraphic6.setLinePaint((java.awt.Paint) chartColor13);
        int int53 = chartColor13.getRGB();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(list36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-16776960) + "'", int53 == (-16776960));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "0");
        try {
            java.lang.Number number7 = defaultStatisticalCategoryDataset0.getValue(0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement25 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment21, verticalAlignment22, (double) (short) 100, (double) (-1));
        flowArrangement25.clear();
        org.jfree.data.general.Dataset dataset27 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement25, dataset27, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer29.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer29.setHeight((double) (byte) 1);
        java.util.List list37 = legendItemBlockContainer29.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = legendItemBlockContainer29.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double41 = rectangleInsets39.calculateTopOutset((double) (short) 10);
        double double42 = rectangleInsets39.getLeft();
        double double44 = rectangleInsets39.trimWidth(0.0d);
        legendItemBlockContainer29.setMargin(rectangleInsets39);
        java.awt.geom.Rectangle2D rectangle2D46 = legendItemBlockContainer29.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double48 = numberAxis17.valueToJava2D((double) 1.0f, rectangle2D46, rectangleEdge47);
        try {
            categoryPlot11.drawBackground(graphics2D16, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextBlockAnchor.CENTER_LEFT", "hi!", numberArray14);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, 0);
        org.jfree.data.KeyToGroupMap keyToGroupMap18 = null;
        try {
            org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset15, keyToGroupMap18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(pieDataset17);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(false);
        org.jfree.chart.plot.Plot plot3 = numberAxis0.getPlot();
        org.jfree.chart.plot.Plot plot4 = numberAxis0.getPlot();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor5, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape8, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        java.lang.Object obj12 = numberAxis0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets13.createInsetRectangle(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[][] numberArray15 = new java.lang.Number[][] { numberArray6, numberArray10, numberArray14 };
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextBlockAnchor.CENTER_LEFT", "hi!", numberArray15);
        org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset16, 0);
        org.jfree.data.general.PieDataset pieDataset22 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset18, (java.lang.Comparable) 0.95f, (double) 10.0f, 10);
        boolean boolean23 = itemLabelAnchor0.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(pieDataset18);
        org.junit.Assert.assertNotNull(pieDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        java.lang.String str3 = legendItemEntity1.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis0.setNumberFormatOverride(numberFormat8);
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 10.0f);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range12, 0.0d, true);
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range12, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke20 = lineBorder19.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = lineBorder19.getInsets();
        boolean boolean22 = range12.equals((java.lang.Object) lineBorder19);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range12, 0.0d, false);
        numberAxis0.setRange(range12, false, false);
        java.awt.Paint paint29 = numberAxis0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        objectList0.set(8, (java.lang.Object) itemLabelAnchor2);
        java.lang.Object obj4 = objectList0.clone();
        objectList0.clear();
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.removeColumn((java.lang.Comparable) "MAJOR");
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment6, (double) (short) 100, (double) (-1));
        flowArrangement9.clear();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement9, dataset11, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer13.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer13.setHeight((double) (byte) 1);
        java.util.List list21 = legendItemBlockContainer13.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendItemBlockContainer13.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets23.calculateTopOutset((double) (short) 10);
        double double26 = rectangleInsets23.getLeft();
        double double28 = rectangleInsets23.trimWidth(0.0d);
        legendItemBlockContainer13.setMargin(rectangleInsets23);
        java.awt.geom.Rectangle2D rectangle2D30 = legendItemBlockContainer13.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double32 = numberAxis1.valueToJava2D((double) 1.0f, rectangle2D30, rectangleEdge31);
        boolean boolean33 = numberAxis1.isVerticalTickLabels();
        boolean boolean34 = booleanList0.equals((java.lang.Object) numberAxis1);
        numberAxis1.setLabel("0");
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(128, (int) (short) -1, 500);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 10.0f);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, 0.0d, true);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range3, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range3);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener12 = null;
        boolean boolean13 = numberAxis11.hasListener(eventListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color14);
        boolean boolean16 = numberAxis11.isAxisLineVisible();
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 10.0f);
        org.jfree.data.Range range22 = org.jfree.data.Range.shift(range19, 0.0d, true);
        numberAxis11.setRange(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint10.toRangeHeight(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint24.toUnconstrainedHeight();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint25.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot11.getRangeAxisEdge();
        categoryPlot11.setForegroundAlpha((float) (byte) 100);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer8 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj9 = standardGradientPaintTransformer8.clone();
        legendGraphic6.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer8);
        double double11 = legendGraphic6.getContentXOffset();
        boolean boolean12 = legendGraphic6.isShapeOutlineVisible();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = legendGraphic6.arrange(graphics2D13, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendGraphic6.getShapeAnchor();
        legendGraphic6.setShapeVisible(false);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        java.lang.String str4 = legendItemEntity1.getShapeType();
        java.lang.Comparable comparable5 = legendItemEntity1.getSeriesKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
        org.junit.Assert.assertNull(comparable5);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean2 = axisSpace0.equals((java.lang.Object) shapeArray1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        axisSpace0.add((double) 10, rectangleEdge5);
        java.lang.String str7 = axisSpace0.toString();
        java.lang.Object obj8 = axisSpace0.clone();
        org.junit.Assert.assertNotNull(shapeArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        numberAxis0.setLabelToolTip("");
        numberAxis0.zoomRange((double) 0.0f, 152.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        barRenderer0.setBasePaint(paint14);
        boolean boolean17 = barRenderer0.isSeriesVisible(2);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("rect", graphics2D1, (float) 'a', 0.0f, textAnchor4, 152.0d, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean2 = axisSpace0.equals((java.lang.Object) shapeArray1);
        double double3 = axisSpace0.getLeft();
        java.lang.Object obj4 = axisSpace0.clone();
        org.junit.Assert.assertNotNull(shapeArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Paint paint5 = textFragment3.getPaint();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke7 = lineBorder6.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets8.getRight();
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder(paint5, stroke7, rectangleInsets8);
        double double11 = rectangleInsets8.getRight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor5, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape8, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        java.lang.Object obj12 = numberAxis0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis0.getTickLabelInsets();
        double double15 = rectangleInsets13.calculateTopOutset(3.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        numberAxis0.setNegativeArrowVisible(true);
        java.awt.Font font4 = numberAxis0.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        org.jfree.chart.util.BooleanList booleanList16 = new org.jfree.chart.util.BooleanList();
        boolean boolean17 = legendItemBlockContainer8.equals((java.lang.Object) booleanList16);
        legendItemBlockContainer8.setURLText("");
        java.lang.Object obj20 = legendItemBlockContainer8.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color12 = java.awt.Color.lightGray;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("MAJOR", "Layer.FOREGROUND", "", "LengthConstraintType.NONE", shape4, (java.awt.Paint) color10, stroke11, (java.awt.Paint) color12);
        legendItem13.setDatasetIndex((-16777216));
        java.lang.Class<?> wildcardClass16 = legendItem13.getClass();
        boolean boolean17 = legendItem13.isLineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.setVersion("java.awt.Color[r=255,g=0,b=0]");
        java.lang.String str9 = basicProjectInfo4.getLicenceName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo14 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean16 = basicProjectInfo14.equals((java.lang.Object) (short) -1);
        basicProjectInfo14.setVersion("java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo23 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean25 = basicProjectInfo23.equals((java.lang.Object) (short) -1);
        basicProjectInfo14.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        basicProjectInfo4.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo23);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        categoryPlot11.setAnchorValue((double) (-1));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        double double6 = barRenderer0.getLowerClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        try {
            barRenderer0.setSeriesItemLabelGenerator((int) (short) -1, categoryItemLabelGenerator9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateY(0.0d);
        boolean boolean3 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.awt.Shape shape4 = null;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke6 = lineBorder5.getStroke();
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "0", "RangeType.FULL", "LengthConstraintType.NONE", shape4, stroke6, (java.awt.Paint) chartColor10);
        int int12 = legendItem11.getSeriesIndex();
        int int13 = legendItem11.getDatasetIndex();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color1 = java.awt.Color.gray;
        float[] floatArray2 = null;
        float[] floatArray3 = color1.getRGBColorComponents(floatArray2);
        try {
            float[] floatArray4 = color0.getRGBComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        java.awt.Color color41 = java.awt.Color.orange;
        categoryPlot40.setBackgroundPaint((java.awt.Paint) color41);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0, 8.0d, (double) 0.0f, (double) 0.95f);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        org.jfree.data.general.Dataset dataset14 = legendItemBlockContainer8.getDataset();
        java.lang.String str15 = legendItemBlockContainer8.getURLText();
        org.jfree.data.general.Dataset dataset16 = legendItemBlockContainer8.getDataset();
        double double17 = legendItemBlockContainer8.getContentYOffset();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(dataset14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNull(dataset16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            textFragment3.draw(graphics2D4, 10.0f, 0.0f, textAnchor7, (float) 500, (float) 15, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Comparable[] comparableArray3 = new java.lang.Comparable[] { 100.0d, 0.05d, (-16776960) };
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { 15.0d };
        double[] doubleArray9 = new double[] { 'a' };
        double[] doubleArray11 = new double[] { 'a' };
        double[] doubleArray13 = new double[] { 'a' };
        double[] doubleArray15 = new double[] { 'a' };
        double[] doubleArray17 = new double[] { 'a' };
        double[][] doubleArray18 = new double[][] { doubleArray9, doubleArray11, doubleArray13, doubleArray15, doubleArray17 };
        org.jfree.data.category.CategoryDataset categoryDataset19 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "0", doubleArray18);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray3, comparableArray5, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray3);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(categoryDataset19);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.RIGHT", graphics2D1, (double) 0L, (float) (byte) 0, (float) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke9);
        java.awt.Paint paint11 = valueMarker10.getLabelPaint();
        barRenderer0.setSeriesOutlinePaint((int) (short) 0, paint11, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double18 = defaultStatisticalCategoryDataset16.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean21 = numberAxis20.isTickLabelsVisible();
        boolean boolean22 = numberAxis20.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat23 = null;
        numberAxis20.setNumberFormatOverride(numberFormat23);
        boolean boolean25 = numberAxis20.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset16, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer26);
        org.jfree.chart.util.SortOrder sortOrder28 = categoryPlot27.getColumnRenderingOrder();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean30 = numberAxis29.isTickLabelsVisible();
        numberAxis29.setLabelToolTip("rect");
        numberAxis29.resizeRange((double) (short) 0);
        org.jfree.chart.block.LineBorder lineBorder35 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke36 = lineBorder35.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = lineBorder35.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement46 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment42, verticalAlignment43, (double) (short) 100, (double) (-1));
        flowArrangement46.clear();
        org.jfree.data.general.Dataset dataset48 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer50 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement46, dataset48, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer50.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer50.setHeight((double) (byte) 1);
        java.util.List list58 = legendItemBlockContainer50.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = legendItemBlockContainer50.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double62 = rectangleInsets60.calculateTopOutset((double) (short) 10);
        double double63 = rectangleInsets60.getLeft();
        double double65 = rectangleInsets60.trimWidth(0.0d);
        legendItemBlockContainer50.setMargin(rectangleInsets60);
        java.awt.geom.Rectangle2D rectangle2D67 = legendItemBlockContainer50.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double69 = numberAxis38.valueToJava2D((double) 1.0f, rectangle2D67, rectangleEdge68);
        java.awt.geom.Rectangle2D rectangle2D72 = rectangleInsets37.createOutsetRectangle(rectangle2D67, false, false);
        numberAxis29.setRightArrow((java.awt.Shape) rectangle2D72);
        try {
            barRenderer0.drawDomainGridline(graphics2D15, categoryPlot27, rectangle2D72, 8.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(sortOrder28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D72);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "0");
        double[] doubleArray15 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray16 = new double[][] { doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "hi!", doubleArray16);
        boolean boolean19 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) categoryDataset18);
        try {
            java.lang.Comparable comparable21 = defaultStatisticalCategoryDataset0.getColumnKey((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(15.0d, (double) (-1L), (double) 0, (double) (-2));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment20, (double) (short) 100, (double) (-1));
        flowArrangement23.clear();
        org.jfree.data.general.Dataset dataset25 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer27 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement23, dataset25, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer27.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer27.setHeight((double) (byte) 1);
        java.util.List list35 = legendItemBlockContainer27.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = legendItemBlockContainer27.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double39 = rectangleInsets37.calculateTopOutset((double) (short) 10);
        double double40 = rectangleInsets37.getLeft();
        double double42 = rectangleInsets37.trimWidth(0.0d);
        legendItemBlockContainer27.setMargin(rectangleInsets37);
        java.awt.geom.Rectangle2D rectangle2D44 = legendItemBlockContainer27.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double46 = numberAxis15.valueToJava2D((double) 1.0f, rectangle2D44, rectangleEdge45);
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation47, plotOrientation48);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener51 = null;
        boolean boolean52 = numberAxis50.hasListener(eventListener51);
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis50.setTickLabelPaint((java.awt.Paint) color53);
        boolean boolean55 = numberAxis50.isAxisLineVisible();
        boolean boolean56 = axisLocation47.equals((java.lang.Object) numberAxis50);
        try {
            java.lang.Object obj57 = legendItemBlockContainer8.draw(graphics2D14, rectangle2D44, (java.lang.Object) numberAxis50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) -1, (double) 100L);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = numberAxis3.hasListener(eventListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis3.isAxisLineVisible();
        boolean boolean9 = numberAxis3.getAutoRangeIncludesZero();
        boolean boolean10 = meanAndStandardDeviation2.equals((java.lang.Object) numberAxis3);
        double double11 = numberAxis3.getLabelAngle();
        numberAxis3.setAutoRange(true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = numberAxis3.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource14);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.awt.Paint paint14 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getRight();
        legendTitle1.setItemLabelPadding(rectangleInsets15);
        double double19 = rectangleInsets15.extendHeight((double) 1.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextBlockAnchor.CENTER_LEFT", "hi!", numberArray14);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, 0);
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset17, (java.lang.Comparable) 0.95f, (double) 10.0f, 10);
        org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset17, (java.lang.Comparable) "rect", 0.0d, (int) '4');
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertNotNull(pieDataset21);
        org.junit.Assert.assertNotNull(pieDataset25);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.Plot plot1 = numberAxis0.getPlot();
        numberAxis0.setVerticalTickLabels(false);
        org.junit.Assert.assertNull(plot1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis0.setNumberFormatOverride(numberFormat8);
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 10.0f);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range12, 0.0d, true);
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range12, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke20 = lineBorder19.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = lineBorder19.getInsets();
        boolean boolean22 = range12.equals((java.lang.Object) lineBorder19);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range12, 0.0d, false);
        numberAxis0.setRange(range12, false, false);
        try {
            numberAxis0.setRangeWithMargins((double) 15, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (15.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
        java.lang.String str3 = contributor2.getName();
        java.lang.String str4 = contributor2.getName();
        java.lang.String str5 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions2, categoryLabelPosition3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment6, (double) (short) 100, (double) (-1));
        flowArrangement9.clear();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement9, dataset11, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer13.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer13.setHeight((double) (byte) 1);
        java.util.List list21 = legendItemBlockContainer13.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendItemBlockContainer13.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets23.calculateTopOutset((double) (short) 10);
        double double26 = rectangleInsets23.getLeft();
        double double28 = rectangleInsets23.trimWidth(0.0d);
        legendItemBlockContainer13.setMargin(rectangleInsets23);
        java.awt.geom.Rectangle2D rectangle2D30 = legendItemBlockContainer13.getBounds();
        boolean boolean31 = categoryLabelPositions4.equals((java.lang.Object) legendItemBlockContainer13);
        boolean boolean32 = numberTickUnit1.equals((java.lang.Object) categoryLabelPositions4);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(false);
        org.jfree.chart.plot.Plot plot3 = numberAxis0.getPlot();
        java.awt.Shape shape4 = numberAxis0.getUpArrow();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        java.lang.Object obj4 = null;
        keyedObjects2D0.addObject(obj4, (java.lang.Comparable) 8, (java.lang.Comparable) "ThreadContext");
        int int9 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 8);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType10 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean11 = keyedObjects2D0.equals((java.lang.Object) gradientPaintTransformType10);
        java.awt.Color color13 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke15);
        java.awt.Paint paint17 = valueMarker16.getLabelPaint();
        keyedObjects2D0.setObject((java.lang.Object) paint17, (java.lang.Comparable) 1L, (java.lang.Comparable) 152.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str1.equals("java.awt.Color[r=192,g=192,b=192]"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener19 = null;
        boolean boolean20 = numberAxis18.hasListener(eventListener19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color21);
        boolean boolean23 = numberAxis18.isAxisLineVisible();
        boolean boolean24 = numberAxis18.getAutoRangeIncludesZero();
        numberAxis18.setPositiveArrowVisible(false);
        categoryPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        try {
            categoryPlot11.setBackgroundImageAlpha((float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        java.lang.String str4 = legendItemEntity1.getShapeType();
        double[] doubleArray13 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray14);
        boolean boolean16 = legendItemEntity1.equals((java.lang.Object) categoryDataset15);
        java.lang.String str17 = legendItemEntity1.getURLText();
        java.lang.Object obj18 = legendItemEntity1.clone();
        java.lang.String str19 = legendItemEntity1.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock1, textBlockAnchor2, textAnchor3, (double) (short) 1);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset6, true);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener13 = null;
        boolean boolean14 = numberAxis12.hasListener(eventListener13);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape15, rectangleAnchor17, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity23 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis12, shape20, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D24 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit26 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D24.removeColumn((java.lang.Comparable) numberTickUnit26);
        numberAxis12.setTickUnit(numberTickUnit26);
        defaultStatisticalCategoryDataset6.add(100.0d, (double) 10.0f, (java.lang.Comparable) 1.0f, (java.lang.Comparable) numberTickUnit26);
        boolean boolean30 = textBlockAnchor2.equals((java.lang.Object) numberTickUnit26);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.lang.Object obj14 = legendTitle1.clone();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 10.0f);
        org.jfree.data.Range range22 = org.jfree.data.Range.shift(range19, 0.0d, true);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range19, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range19);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener28 = null;
        boolean boolean29 = numberAxis27.hasListener(eventListener28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis27.setTickLabelPaint((java.awt.Paint) color30);
        boolean boolean32 = numberAxis27.isAxisLineVisible();
        org.jfree.data.Range range33 = null;
        org.jfree.data.Range range35 = org.jfree.data.Range.expandToInclude(range33, (double) 10.0f);
        org.jfree.data.Range range38 = org.jfree.data.Range.shift(range35, 0.0d, true);
        numberAxis27.setRange(range35);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = rectangleConstraint26.toRangeHeight(range35);
        try {
            org.jfree.chart.util.Size2D size2D41 = legendTitle1.arrange(graphics2D15, rectangleConstraint26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(rectangleConstraint40);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (short) 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Color color13 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke15);
        java.awt.Paint paint17 = valueMarker16.getLabelPaint();
        valueMarker16.setAlpha(0.5f);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str21 = layer20.toString();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer20);
        java.lang.String str23 = layer20.toString();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Layer.FOREGROUND" + "'", str21.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        double double5 = axisSpace4.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        axisSpace4.add((double) 100.0f, rectangleEdge8);
        axisState2.moveCursor((double) (short) 100, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.isTickLabelsVisible();
        numberAxis14.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, (double) (short) 100, (double) (-1));
        flowArrangement33.clear();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33, dataset35, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer37.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer37.setHeight((double) (byte) 1);
        java.util.List list45 = legendItemBlockContainer37.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendItemBlockContainer37.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) 10);
        double double50 = rectangleInsets47.getLeft();
        double double52 = rectangleInsets47.trimWidth(0.0d);
        legendItemBlockContainer37.setMargin(rectangleInsets47);
        java.awt.geom.Rectangle2D rectangle2D54 = legendItemBlockContainer37.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double56 = numberAxis25.valueToJava2D((double) 1.0f, rectangle2D54, rectangleEdge55);
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = chartColor22.createContext(colorModel23, rectangle24, rectangle2D54, affineTransform57, renderingHints58);
        org.jfree.chart.axis.AxisSpace axisSpace60 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray61 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean62 = axisSpace60.equals((java.lang.Object) shapeArray61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge64);
        axisSpace60.add((double) 10, rectangleEdge65);
        double double67 = numberAxis14.valueToJava2D(0.0d, rectangle2D54, rectangleEdge65);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets11.createInsetRectangle(rectangle2D54);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity71 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D68, "java.awt.Color[r=255,g=0,b=0]", "Layer.FOREGROUND");
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation72, plotOrientation73);
        java.util.List list75 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D68, rectangleEdge74);
        int int76 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(shapeArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 4 + "'", int76 == 4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedWidth(152.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint4.toFixedHeight((double) 10.0f);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot11.removeChangeListener(plotChangeListener18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState22 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.AxisSpace axisSpace24 = new org.jfree.chart.axis.AxisSpace();
        double double25 = axisSpace24.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
        axisSpace24.add((double) 100.0f, rectangleEdge28);
        axisState22.moveCursor((double) (short) 100, rectangleEdge28);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double33 = rectangleInsets31.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean35 = numberAxis34.isTickLabelsVisible();
        numberAxis34.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor42 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel43 = null;
        java.awt.Rectangle rectangle44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment49 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment50 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement53 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment49, verticalAlignment50, (double) (short) 100, (double) (-1));
        flowArrangement53.clear();
        org.jfree.data.general.Dataset dataset55 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer57 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement53, dataset55, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer57.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer57.setHeight((double) (byte) 1);
        java.util.List list65 = legendItemBlockContainer57.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = legendItemBlockContainer57.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double69 = rectangleInsets67.calculateTopOutset((double) (short) 10);
        double double70 = rectangleInsets67.getLeft();
        double double72 = rectangleInsets67.trimWidth(0.0d);
        legendItemBlockContainer57.setMargin(rectangleInsets67);
        java.awt.geom.Rectangle2D rectangle2D74 = legendItemBlockContainer57.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double76 = numberAxis45.valueToJava2D((double) 1.0f, rectangle2D74, rectangleEdge75);
        java.awt.geom.AffineTransform affineTransform77 = null;
        java.awt.RenderingHints renderingHints78 = null;
        java.awt.PaintContext paintContext79 = chartColor42.createContext(colorModel43, rectangle44, rectangle2D74, affineTransform77, renderingHints78);
        org.jfree.chart.axis.AxisSpace axisSpace80 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray81 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean82 = axisSpace80.equals((java.lang.Object) shapeArray81);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge84);
        axisSpace80.add((double) 10, rectangleEdge85);
        double double87 = numberAxis34.valueToJava2D(0.0d, rectangle2D74, rectangleEdge85);
        java.awt.geom.Rectangle2D rectangle2D88 = rectangleInsets31.createInsetRectangle(rectangle2D74);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity91 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D88, "java.awt.Color[r=255,g=0,b=0]", "Layer.FOREGROUND");
        org.jfree.chart.axis.AxisLocation axisLocation92 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation93 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge94 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation92, plotOrientation93);
        java.util.List list95 = categoryAxis20.refreshTicks(graphics2D21, axisState22, rectangle2D88, rectangleEdge94);
        categoryAxis20.setCategoryMargin((double) (byte) 0);
        categoryPlot11.setDomainAxis(categoryAxis20);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment49);
        org.junit.Assert.assertNotNull(list65);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(rectangleEdge75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext79);
        org.junit.Assert.assertNotNull(shapeArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D88);
        org.junit.Assert.assertNotNull(axisLocation92);
        org.junit.Assert.assertNotNull(plotOrientation93);
        org.junit.Assert.assertNotNull(rectangleEdge94);
        org.junit.Assert.assertNotNull(list95);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "0");
        java.lang.Number number7 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 1.0E-8d, (java.lang.Comparable) "RectangleEdge.RIGHT");
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        java.awt.Stroke stroke6 = numberAxis0.getTickMarkStroke();
        double double7 = numberAxis0.getLabelAngle();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = numberAxis0.getMarkerBand();
        numberAxis0.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        java.lang.Object obj4 = null;
        keyedObjects2D0.addObject(obj4, (java.lang.Comparable) 8, (java.lang.Comparable) "ThreadContext");
        int int9 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 8);
        java.lang.Comparable comparable11 = keyedObjects2D0.getColumnKey(0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + "ThreadContext" + "'", comparable11.equals("ThreadContext"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 10.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, 0.0d, true);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range5, (double) 4, false);
        boolean boolean11 = range5.intersects((double) 0.95f, (double) (short) 1);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(pieDataset3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        java.lang.Class<?> wildcardClass6 = barRenderer0.getClass();
        java.awt.Stroke stroke7 = barRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getPosition();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor5, (double) '4', (double) (byte) 100);
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        categoryPlot11.clearDomainMarkers();
        categoryPlot11.setRangeCrosshairValue(0.0d, true);
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot11.getDataset();
        try {
            categoryPlot11.setBackgroundImageAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(categoryDataset16);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (short) 10, (java.lang.Boolean) true);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesVisible(8);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("RangeType.NEGATIVE", "", "RectangleEdge.RIGHT", "0", "");
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) (short) 100, (double) (-1));
        flowArrangement8.clear();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, dataset10, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer12.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer12.setHeight((double) (byte) 1);
        java.util.List list20 = legendItemBlockContainer12.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendItemBlockContainer12.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.calculateTopOutset((double) (short) 10);
        double double25 = rectangleInsets22.getLeft();
        double double27 = rectangleInsets22.trimWidth(0.0d);
        legendItemBlockContainer12.setMargin(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D29 = legendItemBlockContainer12.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double31 = numberAxis0.valueToJava2D((double) 1.0f, rectangle2D29, rectangleEdge30);
        boolean boolean32 = numberAxis0.isVerticalTickLabels();
        numberAxis0.setAutoRangeIncludesZero(true);
        java.text.NumberFormat numberFormat35 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(numberFormat35);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder8.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double42 = numberAxis11.valueToJava2D((double) 1.0f, rectangle2D40, rectangleEdge41);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets10.createOutsetRectangle(rectangle2D40, false, false);
        legendGraphic6.setLine((java.awt.Shape) rectangle2D45);
        java.lang.Object obj47 = legendGraphic6.clone();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener49 = null;
        boolean boolean50 = numberAxis48.hasListener(eventListener49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis48.setTickLabelPaint((java.awt.Paint) color51);
        boolean boolean53 = numberAxis48.isAxisLineVisible();
        boolean boolean54 = numberAxis48.getAutoRangeIncludesZero();
        numberAxis48.setPositiveArrowVisible(false);
        boolean boolean57 = legendGraphic6.equals((java.lang.Object) numberAxis48);
        java.awt.Stroke stroke58 = legendGraphic6.getLineStroke();
        java.awt.Stroke stroke59 = legendGraphic6.getLineStroke();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(stroke58);
        org.junit.Assert.assertNull(stroke59);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Font font3 = barRenderer0.getSeriesItemLabelFont((int) '#');
        java.awt.Paint paint6 = barRenderer0.getItemPaint(0, (-16777216));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator(15, 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = barRenderer0.getPlot();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertNull(categoryPlot10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot11.getDomainAxisEdge();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot11.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        int int19 = categoryPlot11.getDomainAxisIndex(categoryAxis18);
        try {
            categoryPlot11.mapDatasetToDomainAxis((-2), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor7, (double) '4', (double) (byte) 100);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color13 = java.awt.Color.lightGray;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("MAJOR", "Layer.FOREGROUND", "", "LengthConstraintType.NONE", shape5, (java.awt.Paint) color11, stroke12, (java.awt.Paint) color13);
        legendItem14.setDatasetIndex((-16777216));
        java.lang.Class<?> wildcardClass17 = legendItem14.getClass();
        java.lang.Object obj18 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("LengthConstraintType.NONE", (java.lang.Class) wildcardClass17);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 10.0f);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, 0.0d, true);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range3, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range3);
        org.jfree.data.Range range11 = null;
        org.jfree.data.Range range13 = org.jfree.data.Range.expandToInclude(range11, (double) 10.0f);
        org.jfree.data.Range range16 = org.jfree.data.Range.shift(range13, 0.0d, true);
        org.jfree.data.Range range19 = org.jfree.data.Range.shift(range13, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke21 = lineBorder20.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = lineBorder20.getInsets();
        boolean boolean23 = range13.equals((java.lang.Object) lineBorder20);
        org.jfree.data.Range range26 = org.jfree.data.Range.shift(range13, 0.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint27 = rectangleConstraint10.toRangeHeight(range26);
        double double28 = rectangleConstraint10.getHeight();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(rectangleConstraint27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape9, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color22);
        org.jfree.data.general.Dataset dataset24 = legendItem23.getDataset();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj26 = standardGradientPaintTransformer25.clone();
        java.lang.Object obj27 = standardGradientPaintTransformer25.clone();
        legendItem23.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        java.awt.Paint paint29 = legendItem23.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(dataset24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis0.setStandardTickUnits(tickUnitSource3);
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.setVersion("java.awt.Color[r=255,g=0,b=0]");
        java.lang.String str9 = basicProjectInfo4.getCopyright();
        java.lang.String str10 = basicProjectInfo4.getInfo();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        java.awt.Font font4 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("", font4, (java.awt.Paint) color5);
        java.lang.String str7 = textFragment6.getText();
        java.awt.Font font8 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean9 = textFragment6.equals((java.lang.Object) font8);
        numberAxis1.setTickLabelFont(font8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryAxis11.setTickLabelPaint((java.lang.Comparable) (-16777216), paint13);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer18 = new org.jfree.chart.text.G2TextMeasurer(graphics2D17);
        try {
            org.jfree.chart.text.TextBlock textBlock19 = org.jfree.chart.text.TextUtilities.createTextBlock("RangeType.FULL", font8, paint13, 0.5f, 8, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((double) (-2), (double) (-2), (java.lang.Comparable) "rect", (java.lang.Comparable) (short) 10);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor5, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape8, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) (short) 100, (double) (-1));
        flowArrangement20.clear();
        org.jfree.data.general.Dataset dataset22 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement20, dataset22, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer24.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer24.setHeight((double) (byte) 1);
        java.util.List list32 = legendItemBlockContainer24.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = legendItemBlockContainer24.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double36 = rectangleInsets34.calculateTopOutset((double) (short) 10);
        double double37 = rectangleInsets34.getLeft();
        double double39 = rectangleInsets34.trimWidth(0.0d);
        legendItemBlockContainer24.setMargin(rectangleInsets34);
        java.awt.geom.Rectangle2D rectangle2D41 = legendItemBlockContainer24.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double43 = categoryAxis12.getCategoryJava2DCoordinate(categoryAnchor13, (-1), (int) (byte) -1, rectangle2D41, rectangleEdge42);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D41, (double) 'a', 52.0d);
        numberAxis0.setDownArrow(shape46);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke9);
        java.awt.Paint paint11 = valueMarker10.getLabelPaint();
        valueMarker10.setAlpha(0.5f);
        double double14 = valueMarker10.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker10.setLabelAnchor(rectangleAnchor15);
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor15);
        java.lang.Object obj18 = legendTitle5.clone();
        boolean boolean19 = legendItemEntity1.equals(obj18);
        org.jfree.data.general.Dataset dataset20 = legendItemEntity1.getDataset();
        java.lang.Object obj21 = null;
        boolean boolean22 = legendItemEntity1.equals(obj21);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(dataset20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        java.lang.String str2 = legendItemEntity1.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str2.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.isTickLabelsVisible();
        numberAxis3.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment19, (double) (short) 100, (double) (-1));
        flowArrangement22.clear();
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22, dataset24, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer26.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer26.setHeight((double) (byte) 1);
        java.util.List list34 = legendItemBlockContainer26.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendItemBlockContainer26.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateTopOutset((double) (short) 10);
        double double39 = rectangleInsets36.getLeft();
        double double41 = rectangleInsets36.trimWidth(0.0d);
        legendItemBlockContainer26.setMargin(rectangleInsets36);
        java.awt.geom.Rectangle2D rectangle2D43 = legendItemBlockContainer26.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double45 = numberAxis14.valueToJava2D((double) 1.0f, rectangle2D43, rectangleEdge44);
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = chartColor11.createContext(colorModel12, rectangle13, rectangle2D43, affineTransform46, renderingHints47);
        org.jfree.chart.axis.AxisSpace axisSpace49 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray50 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean51 = axisSpace49.equals((java.lang.Object) shapeArray50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        axisSpace49.add((double) 10, rectangleEdge54);
        double double56 = numberAxis3.valueToJava2D(0.0d, rectangle2D43, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets0.createInsetRectangle(rectangle2D43);
        org.jfree.chart.util.UnitType unitType58 = rectangleInsets0.getUnitType();
        java.lang.String str59 = unitType58.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext48);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(unitType58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "UnitType.ABSOLUTE" + "'", str59.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        java.util.List list18 = categoryPlot11.getCategories();
        java.util.List list19 = categoryPlot11.getAnnotations();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        basicProjectInfo4.setInfo("org.jfree.chart.event.ChartProgressEvent[source=java.awt.Color[r=255,g=175,b=175]]");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }
}

