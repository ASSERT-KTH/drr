import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (short) 10);
        double double3 = rectangleInsets0.getLeft();
        double double5 = rectangleInsets0.trimWidth(0.0d);
        java.awt.Color color6 = java.awt.Color.RED;
        java.lang.String str7 = color6.toString();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color6);
        double double9 = rectangleInsets0.getBottom();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray18 = new float[] { 1, '#', 10L, 1 };
        float[] floatArray19 = java.awt.Color.RGBtoHSB(500, (int) (short) 10, (int) (byte) 100, floatArray18);
        float[] floatArray20 = color10.getComponents(floatArray19);
        java.awt.image.ColorModel colorModel21 = null;
        java.awt.Rectangle rectangle22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener24 = null;
        boolean boolean25 = numberAxis23.hasListener(eventListener24);
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity27 = new org.jfree.chart.entity.LegendItemEntity(shape26);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape31 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape26, rectangleAnchor28, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis23, shape31, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D35 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D35.removeColumn((java.lang.Comparable) numberTickUnit37);
        numberAxis23.setTickUnit(numberTickUnit37);
        numberAxis23.setTickLabelsVisible(false);
        java.awt.Font font44 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color45 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("", font44, (java.awt.Paint) color45);
        java.lang.String str47 = textFragment46.getText();
        java.awt.Paint paint48 = textFragment46.getPaint();
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke50 = lineBorder49.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double52 = rectangleInsets51.getRight();
        org.jfree.chart.block.LineBorder lineBorder53 = new org.jfree.chart.block.LineBorder(paint48, stroke50, rectangleInsets51);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment54 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment55 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement58 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment54, verticalAlignment55, (double) (short) 100, (double) (-1));
        flowArrangement58.clear();
        org.jfree.data.general.Dataset dataset60 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer62 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement58, dataset60, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer62.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer62.setHeight((double) (byte) 1);
        java.util.List list70 = legendItemBlockContainer62.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = legendItemBlockContainer62.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double74 = rectangleInsets72.calculateTopOutset((double) (short) 10);
        double double75 = rectangleInsets72.getLeft();
        double double77 = rectangleInsets72.trimWidth(0.0d);
        legendItemBlockContainer62.setMargin(rectangleInsets72);
        java.awt.geom.Rectangle2D rectangle2D79 = legendItemBlockContainer62.getBounds();
        java.awt.geom.Rectangle2D rectangle2D80 = rectangleInsets51.createInsetRectangle(rectangle2D79);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions81 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition83 = categoryLabelPositions81.getLabelPosition(rectangleEdge82);
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition85 = categoryLabelPositions81.getLabelPosition(rectangleEdge84);
        double double86 = numberAxis23.valueToJava2D((double) (-16777216), rectangle2D79, rectangleEdge84);
        java.awt.geom.AffineTransform affineTransform87 = null;
        java.awt.RenderingHints renderingHints88 = null;
        java.awt.PaintContext paintContext89 = color10.createContext(colorModel21, rectangle22, rectangle2D79, affineTransform87, renderingHints88);
        try {
            rectangleInsets0.trim((java.awt.geom.Rectangle2D) rectangle22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str7.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment54);
        org.junit.Assert.assertNotNull(list70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(categoryLabelPositions81);
        org.junit.Assert.assertNull(categoryLabelPosition83);
        org.junit.Assert.assertNotNull(rectangleEdge84);
        org.junit.Assert.assertNotNull(categoryLabelPosition85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext89);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Comparable comparable1 = null;
        keyedObjects2D0.removeObject(comparable1, (java.lang.Comparable) 0.05d);
        java.lang.Object obj4 = keyedObjects2D0.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("RangeType.NEGATIVE");
        labelBlock1.setURLText("0");
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        java.lang.Object obj3 = valueMarker1.clone();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double6 = defaultStatisticalCategoryDataset4.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean9 = numberAxis8.isTickLabelsVisible();
        boolean boolean10 = numberAxis8.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat11 = null;
        numberAxis8.setNumberFormatOverride(numberFormat11);
        boolean boolean13 = numberAxis8.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer14);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str18 = layer17.toString();
        java.util.Collection collection19 = categoryPlot15.getDomainMarkers(0, layer17);
        categoryPlot15.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot15.getRangeAxisForDataset((-20561));
        java.awt.Stroke stroke23 = categoryPlot15.getRangeGridlineStroke();
        valueMarker1.setOutlineStroke(stroke23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Layer.FOREGROUND" + "'", str18.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        boolean boolean7 = legendGraphic6.isShapeOutlineVisible();
        java.awt.Paint paint8 = legendGraphic6.getLinePaint();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = legendGraphic6.arrange(graphics2D9);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(size2D10);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((-20561));
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot11.getRangeAxisForDataset(0);
        categoryPlot11.clearRangeAxes();
        java.awt.Stroke stroke22 = categoryPlot11.getRangeCrosshairStroke();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Color color2 = java.awt.Color.getColor("rect", (int) '#');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockParams blockParams1 = new org.jfree.chart.block.BlockParams();
        boolean boolean2 = flowArrangement0.equals((java.lang.Object) blockParams1);
        blockParams1.setTranslateX(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        org.jfree.data.general.Dataset dataset14 = legendItemBlockContainer8.getDataset();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = rectangleConstraint18.calculateConstrainedSize(size2D19);
        java.lang.String str21 = rectangleConstraint18.toString();
        org.jfree.chart.util.Size2D size2D22 = legendItemBlockContainer8.arrange(graphics2D15, rectangleConstraint18);
        double double23 = size2D22.getWidth();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(dataset14);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]" + "'", str21.equals("RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]"));
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 52.0d + "'", double23 == 52.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        java.lang.Object obj4 = legendItemEntity1.clone();
        java.lang.String str5 = legendItemEntity1.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str5.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        java.awt.Shape shape8 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D2, (float) 2, (float) (-1), textAnchor5, (double) 0.0f, textAnchor7);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double8 = defaultStatisticalCategoryDataset6.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean11 = numberAxis10.isTickLabelsVisible();
        boolean boolean12 = numberAxis10.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat13 = null;
        numberAxis10.setNumberFormatOverride(numberFormat13);
        boolean boolean15 = numberAxis10.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset6, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis10, categoryItemRenderer16);
        java.awt.Color color19 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke21 = lineBorder20.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke21);
        java.awt.Paint paint23 = valueMarker22.getLabelPaint();
        valueMarker22.setAlpha(0.5f);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str27 = layer26.toString();
        categoryPlot17.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker22, layer26);
        try {
            barRenderer0.addAnnotation(categoryAnnotation5, layer26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Layer.FOREGROUND" + "'", str27.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getLeft();
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(paint2);
        boolean boolean4 = axisSpace0.equals((java.lang.Object) blockBorder3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray7 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean8 = axisSpace6.equals((java.lang.Object) shapeArray7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        axisSpace6.add((double) 10, rectangleEdge11);
        axisSpace6.setTop((double) '4');
        java.lang.Object obj15 = axisSpace6.clone();
        java.lang.String str16 = axisSpace6.toString();
        java.awt.Font font18 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color19 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("", font18, (java.awt.Paint) color19);
        java.lang.String str21 = textFragment20.getText();
        java.awt.Paint paint22 = textFragment20.getPaint();
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke24 = lineBorder23.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double26 = rectangleInsets25.getRight();
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder(paint22, stroke24, rectangleInsets25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement32 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment28, verticalAlignment29, (double) (short) 100, (double) (-1));
        flowArrangement32.clear();
        org.jfree.data.general.Dataset dataset34 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer36 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement32, dataset34, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer36.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer36.setHeight((double) (byte) 1);
        java.util.List list44 = legendItemBlockContainer36.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendItemBlockContainer36.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double48 = rectangleInsets46.calculateTopOutset((double) (short) 10);
        double double49 = rectangleInsets46.getLeft();
        double double51 = rectangleInsets46.trimWidth(0.0d);
        legendItemBlockContainer36.setMargin(rectangleInsets46);
        java.awt.geom.Rectangle2D rectangle2D53 = legendItemBlockContainer36.getBounds();
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets25.createInsetRectangle(rectangle2D53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge55);
        java.awt.geom.Rectangle2D rectangle2D57 = axisSpace6.reserved(rectangle2D53, rectangleEdge55);
        try {
            blockBorder3.draw(graphics2D5, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shapeArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(rectangle2D57);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke9);
        java.awt.Paint paint11 = valueMarker10.getLabelPaint();
        barRenderer0.setSeriesOutlinePaint((int) (short) 0, paint11, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator14, true);
        boolean boolean18 = barRenderer0.equals((java.lang.Object) "ThreadContext");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.lang.String str44 = textTitle43.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment45 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment46 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement49 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment45, verticalAlignment46, (double) 0.5f, Double.NaN);
        textTitle43.setTextAlignment(horizontalAlignment45);
        textTitle43.setID("RangeType.FULL");
        try {
            jFreeChart39.addSubtitle((-1), (org.jfree.chart.title.Title) textTitle43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(horizontalAlignment45);
        org.junit.Assert.assertNotNull(verticalAlignment46);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment6, (double) (short) 100, (double) (-1));
        flowArrangement9.clear();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement9, dataset11, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer13.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer13.setHeight((double) (byte) 1);
        java.util.List list21 = legendItemBlockContainer13.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendItemBlockContainer13.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets23.calculateTopOutset((double) (short) 10);
        double double26 = rectangleInsets23.getLeft();
        double double28 = rectangleInsets23.trimWidth(0.0d);
        legendItemBlockContainer13.setMargin(rectangleInsets23);
        java.awt.geom.Rectangle2D rectangle2D30 = legendItemBlockContainer13.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double32 = numberAxis1.valueToJava2D((double) 1.0f, rectangle2D30, rectangleEdge31);
        boolean boolean33 = numberAxis1.isVerticalTickLabels();
        boolean boolean34 = booleanList0.equals((java.lang.Object) numberAxis1);
        java.lang.Boolean boolean36 = booleanList0.getBoolean((-16777216));
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(boolean36);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.lang.Object obj14 = legendTitle1.clone();
        org.jfree.chart.event.TitleChangeListener titleChangeListener15 = null;
        legendTitle1.removeChangeListener(titleChangeListener15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = legendTitle1.getVerticalAlignment();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(verticalAlignment17);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        java.awt.Color color21 = java.awt.Color.lightGray;
        categoryPlot11.setOutlinePaint((java.awt.Paint) color21);
        categoryPlot11.setDomainGridlinesVisible(true);
        java.awt.Image image25 = null;
        categoryPlot11.setBackgroundImage(image25);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent27 = null;
        categoryPlot11.notifyListeners(plotChangeEvent27);
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = barRenderer29.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke32 = null;
        barRenderer29.setSeriesOutlineStroke((int) (byte) 0, stroke32, true);
        double double35 = barRenderer29.getLowerClip();
        categoryPlot11.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer29, false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        java.util.List list18 = categoryPlot11.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot11.getDomainAxisEdge((int) (short) 1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer1.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double5 = defaultStatisticalCategoryDataset3.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean8 = numberAxis7.isTickLabelsVisible();
        boolean boolean9 = numberAxis7.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis7.setNumberFormatOverride(numberFormat10);
        boolean boolean12 = numberAxis7.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer13);
        java.awt.Paint paint15 = categoryPlot14.getDomainGridlinePaint();
        barRenderer1.setBasePaint(paint15);
        java.awt.Color color18 = java.awt.Color.RED;
        java.lang.String str19 = color18.toString();
        int int20 = color18.getBlue();
        int int21 = color18.getTransparency();
        barRenderer1.setSeriesPaint(2, (java.awt.Paint) color18, false);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer1.setBaseOutlinePaint(paint24, true);
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke29 = lineBorder28.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets30.calculateTopOutset((double) (short) 10);
        double double33 = rectangleInsets30.getLeft();
        org.jfree.chart.block.LineBorder lineBorder34 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color27, stroke29, rectangleInsets30);
        barRenderer1.setBaseItemLabelPaint((java.awt.Paint) color27);
        java.awt.Stroke stroke36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color37 = java.awt.Color.MAGENTA;
        java.awt.Color color38 = color37.darker();
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity44 = new org.jfree.chart.entity.LegendItemEntity(shape43);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape43, rectangleAnchor45, (double) '4', (double) (byte) 100);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color51 = java.awt.Color.lightGray;
        org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("MAJOR", "Layer.FOREGROUND", "", "LengthConstraintType.NONE", shape43, (java.awt.Paint) color49, stroke50, (java.awt.Paint) color51);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) '#', (java.awt.Paint) color27, stroke36, (java.awt.Paint) color38, stroke50, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str19.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener7 = null;
        boolean boolean8 = numberAxis6.hasListener(eventListener7);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor11, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity17 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis6, shape14, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D18 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D18.removeColumn((java.lang.Comparable) numberTickUnit20);
        numberAxis6.setTickUnit(numberTickUnit20);
        defaultStatisticalCategoryDataset0.add(100.0d, (double) 10.0f, (java.lang.Comparable) 1.0f, (java.lang.Comparable) numberTickUnit20);
        double double25 = defaultStatisticalCategoryDataset0.getRangeLowerBound(true);
        org.jfree.data.Range range27 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 'a', (float) '#', 0.95f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) 'a');
        java.lang.Object obj5 = keyedObjects0.getObject((java.lang.Comparable) 0L);
        java.lang.Object obj7 = keyedObjects0.getObject(128);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "rect");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer0.lookupSeriesShape((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer3.getPositiveItemLabelPositionFallback();
        barRenderer3.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBasePositiveItemLabelPosition();
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity4 = new org.jfree.chart.entity.LegendItemEntity(shape3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, rectangleAnchor5, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity11 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis0, shape8, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        java.lang.Object obj12 = numberAxis0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = numberAxis0.getTickLabelInsets();
        numberAxis0.setLabelToolTip("PlotOrientation.HORIZONTAL");
        boolean boolean16 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setLabelURL("");
        numberAxis0.setAutoRangeMinimumSize((double) 15, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        barRenderer0.setBasePaint(paint14);
        java.awt.Color color17 = java.awt.Color.RED;
        java.lang.String str18 = color17.toString();
        int int19 = color17.getBlue();
        int int20 = color17.getTransparency();
        barRenderer0.setSeriesPaint(2, (java.awt.Paint) color17, false);
        double double23 = barRenderer0.getBase();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str18.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        java.lang.Object obj1 = null;
        boolean boolean2 = categoryLabelWidthType0.equals(obj1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        java.util.List list16 = legendItemBlockContainer8.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendItemBlockContainer8.getMargin();
        org.jfree.data.Range range19 = null;
        org.jfree.data.Range range21 = org.jfree.data.Range.expandToInclude(range19, (double) 10.0f);
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range21, 0.0d, true);
        org.jfree.data.Range range27 = org.jfree.data.Range.shift(range21, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range21);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener30 = null;
        boolean boolean31 = numberAxis29.hasListener(eventListener30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color32);
        boolean boolean34 = numberAxis29.isAxisLineVisible();
        org.jfree.data.Range range35 = null;
        org.jfree.data.Range range37 = org.jfree.data.Range.expandToInclude(range35, (double) 10.0f);
        org.jfree.data.Range range40 = org.jfree.data.Range.shift(range37, 0.0d, true);
        numberAxis29.setRange(range37);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = rectangleConstraint28.toRangeHeight(range37);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = barRenderer43.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke46 = null;
        barRenderer43.setSeriesOutlineStroke((int) (byte) 0, stroke46, true);
        barRenderer43.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        boolean boolean53 = range37.equals((java.lang.Object) true);
        boolean boolean54 = rectangleInsets17.equals((java.lang.Object) range37);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(rectangleConstraint42);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = barRenderer0.getLegendItemToolTipGenerator();
        double double6 = barRenderer0.getLowerClip();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition7);
        barRenderer0.setMinimumBarLength((double) 500);
        barRenderer0.setBaseCreateEntities(true, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer15.getBasePositiveItemLabelPosition();
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 100, itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        valueMarker4.setAlpha(0.5f);
        double double8 = valueMarker4.getValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = null;
        valueMarker4.notifyListeners(markerChangeEvent9);
        org.jfree.chart.event.MarkerChangeListener markerChangeListener11 = null;
        valueMarker4.removeChangeListener(markerChangeListener11);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        valueMarker4.setOutlinePaint(paint13);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        int int4 = numberTickUnit2.getMinorTickCount();
        int int5 = numberTickUnit2.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        boolean boolean7 = legendGraphic6.isShapeOutlineVisible();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = legendGraphic6.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray2, strokeArray3, shapeArray4);
        java.lang.Object obj6 = defaultDrawingSupplier5.clone();
        java.awt.Stroke stroke7 = defaultDrawingSupplier5.getNextStroke();
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(strokeArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(shapeArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(false);
        org.jfree.chart.plot.Plot plot3 = numberAxis0.getPlot();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double6 = defaultStatisticalCategoryDataset4.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean9 = numberAxis8.isTickLabelsVisible();
        boolean boolean10 = numberAxis8.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat11 = null;
        numberAxis8.setNumberFormatOverride(numberFormat11);
        boolean boolean13 = numberAxis8.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer14);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str18 = layer17.toString();
        java.util.Collection collection19 = categoryPlot15.getDomainMarkers(0, layer17);
        categoryPlot15.clearRangeAxes();
        categoryPlot15.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint23 = categoryPlot15.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = categoryPlot15.getDatasetRenderingOrder();
        java.awt.Color color25 = java.awt.Color.lightGray;
        categoryPlot15.setOutlinePaint((java.awt.Paint) color25);
        categoryPlot15.setDomainGridlinesVisible(true);
        boolean boolean29 = numberAxis0.hasListener((java.util.EventListener) categoryPlot15);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Layer.FOREGROUND" + "'", str18.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        barRenderer0.setBasePaint(paint14);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Font font17 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        barRenderer0.setBaseItemLabelFont(font17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        boolean boolean20 = barRenderer0.removeAnnotation(categoryAnnotation19);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot11.getDomainAxisLocation(15);
        categoryPlot11.clearRangeMarkers(0);
        java.awt.Stroke stroke20 = categoryPlot11.getOutlineStroke();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Font font3 = barRenderer0.getSeriesItemLabelFont((int) '#');
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment19, (double) (short) 100, (double) (-1));
        flowArrangement22.clear();
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22, dataset24, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer26.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer26.setHeight((double) (byte) 1);
        java.util.List list34 = legendItemBlockContainer26.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendItemBlockContainer26.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateTopOutset((double) (short) 10);
        double double39 = rectangleInsets36.getLeft();
        double double41 = rectangleInsets36.trimWidth(0.0d);
        legendItemBlockContainer26.setMargin(rectangleInsets36);
        java.awt.geom.Rectangle2D rectangle2D43 = legendItemBlockContainer26.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double45 = numberAxis14.valueToJava2D((double) 1.0f, rectangle2D43, rectangleEdge44);
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = chartColor11.createContext(colorModel12, rectangle13, rectangle2D43, affineTransform46, renderingHints47);
        java.awt.geom.AffineTransform affineTransform49 = null;
        java.awt.RenderingHints renderingHints50 = null;
        java.awt.PaintContext paintContext51 = color5.createContext(colorModel6, rectangle7, rectangle2D43, affineTransform49, renderingHints50);
        barRenderer0.setSeriesShape(15, (java.awt.Shape) rectangle7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext48);
        org.junit.Assert.assertNotNull(paintContext51);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        boolean boolean7 = legendGraphic6.isShapeOutlineVisible();
        java.awt.Color color8 = java.awt.Color.BLACK;
        legendGraphic6.setLinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color8);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 0.5f, Double.NaN);
        textTitle1.setTextAlignment(horizontalAlignment3);
        java.awt.Paint paint9 = textTitle1.getBackgroundPaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        boolean boolean6 = numberAxis0.getAutoRangeIncludesZero();
        java.awt.Font font7 = numberAxis0.getLabelFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.awt.Paint paint14 = legendTitle1.getBackgroundPaint();
        java.awt.Font font16 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        legendTitle1.setItemFont(font16);
        double double19 = legendTitle1.getHeight();
        java.awt.Paint paint20 = legendTitle1.getItemPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        int int4 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (short) 10);
        double double3 = rectangleInsets0.getLeft();
        double double5 = rectangleInsets0.trimWidth(0.0d);
        double double7 = rectangleInsets0.extendWidth((double) (-1L));
        double double9 = rectangleInsets0.extendWidth((double) 500);
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke11 = lineBorder10.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = lineBorder10.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment17, verticalAlignment18, (double) (short) 100, (double) (-1));
        flowArrangement21.clear();
        org.jfree.data.general.Dataset dataset23 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement21, dataset23, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer25.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer25.setHeight((double) (byte) 1);
        java.util.List list33 = legendItemBlockContainer25.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendItemBlockContainer25.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double37 = rectangleInsets35.calculateTopOutset((double) (short) 10);
        double double38 = rectangleInsets35.getLeft();
        double double40 = rectangleInsets35.trimWidth(0.0d);
        legendItemBlockContainer25.setMargin(rectangleInsets35);
        java.awt.geom.Rectangle2D rectangle2D42 = legendItemBlockContainer25.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double44 = numberAxis13.valueToJava2D((double) 1.0f, rectangle2D42, rectangleEdge43);
        java.awt.geom.Rectangle2D rectangle2D47 = rectangleInsets12.createOutsetRectangle(rectangle2D42, false, false);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets0.createInsetRectangle(rectangle2D42, false, true);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 500.0d + "'", double9 == 500.0d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D50);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.awt.Font font7 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font7);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("rect", font7);
        numberAxis0.setTickLabelFont(font7);
        boolean boolean11 = numberAxis0.isInverted();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener13 = null;
        boolean boolean14 = numberAxis12.hasListener(eventListener13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis12.setTickLabelPaint((java.awt.Paint) color15);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis12.getTickUnit();
        numberAxis0.setTickUnit(numberTickUnit17);
        numberAxis0.configure();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(numberTickUnit17);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("ThreadContext");
        jFreeChart39.setTitle(textTitle41);
        try {
            org.jfree.chart.plot.XYPlot xYPlot43 = jFreeChart39.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color3 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("", font2, (java.awt.Paint) color3);
        java.lang.String str5 = textFragment4.getText();
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean7 = textFragment4.equals((java.lang.Object) font6);
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        double double17 = axisSpace16.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge19);
        axisSpace16.add((double) 100.0f, rectangleEdge20);
        axisState14.moveCursor((double) (short) 100, rectangleEdge20);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets23.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean27 = numberAxis26.isTickLabelsVisible();
        numberAxis26.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor34 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel35 = null;
        java.awt.Rectangle rectangle36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement45 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment41, verticalAlignment42, (double) (short) 100, (double) (-1));
        flowArrangement45.clear();
        org.jfree.data.general.Dataset dataset47 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer49 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement45, dataset47, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer49.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer49.setHeight((double) (byte) 1);
        java.util.List list57 = legendItemBlockContainer49.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendItemBlockContainer49.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double61 = rectangleInsets59.calculateTopOutset((double) (short) 10);
        double double62 = rectangleInsets59.getLeft();
        double double64 = rectangleInsets59.trimWidth(0.0d);
        legendItemBlockContainer49.setMargin(rectangleInsets59);
        java.awt.geom.Rectangle2D rectangle2D66 = legendItemBlockContainer49.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double68 = numberAxis37.valueToJava2D((double) 1.0f, rectangle2D66, rectangleEdge67);
        java.awt.geom.AffineTransform affineTransform69 = null;
        java.awt.RenderingHints renderingHints70 = null;
        java.awt.PaintContext paintContext71 = chartColor34.createContext(colorModel35, rectangle36, rectangle2D66, affineTransform69, renderingHints70);
        org.jfree.chart.axis.AxisSpace axisSpace72 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray73 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean74 = axisSpace72.equals((java.lang.Object) shapeArray73);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge76);
        axisSpace72.add((double) 10, rectangleEdge77);
        double double79 = numberAxis26.valueToJava2D(0.0d, rectangle2D66, rectangleEdge77);
        java.awt.geom.Rectangle2D rectangle2D80 = rectangleInsets23.createInsetRectangle(rectangle2D66);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity83 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D80, "java.awt.Color[r=255,g=0,b=0]", "Layer.FOREGROUND");
        org.jfree.chart.axis.AxisLocation axisLocation84 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation85 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation84, plotOrientation85);
        java.util.List list87 = categoryAxis12.refreshTicks(graphics2D13, axisState14, rectangle2D80, rectangleEdge86);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment88 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment89 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement92 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment88, verticalAlignment89, (double) 0.5f, Double.NaN);
        org.jfree.chart.util.VerticalAlignment verticalAlignment93 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets94 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.title.TextTitle textTitle95 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font6, (java.awt.Paint) chartColor11, rectangleEdge86, horizontalAlignment88, verticalAlignment93, rectangleInsets94);
        java.awt.Color color96 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        textTitle95.setBackgroundPaint((java.awt.Paint) color96);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext71);
        org.junit.Assert.assertNotNull(shapeArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rectangleEdge76);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(plotOrientation85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertNotNull(list87);
        org.junit.Assert.assertNotNull(horizontalAlignment88);
        org.junit.Assert.assertNotNull(verticalAlignment89);
        org.junit.Assert.assertNotNull(verticalAlignment93);
        org.junit.Assert.assertNotNull(color96);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        java.awt.Stroke stroke6 = numberAxis0.getTickMarkStroke();
        double double7 = numberAxis0.getLabelAngle();
        numberAxis0.setVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double12 = defaultStatisticalCategoryDataset10.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.isTickLabelsVisible();
        boolean boolean16 = numberAxis14.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat17 = null;
        numberAxis14.setNumberFormatOverride(numberFormat17);
        boolean boolean19 = numberAxis14.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset10, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis14, categoryItemRenderer20);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str24 = layer23.toString();
        java.util.Collection collection25 = categoryPlot21.getDomainMarkers(0, layer23);
        categoryPlot21.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot21.getRangeAxisForDataset((-20561));
        java.awt.Stroke stroke29 = categoryPlot21.getRangeGridlineStroke();
        numberAxis0.setTickMarkStroke(stroke29);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator2 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator3 = null;
        java.lang.String str4 = legendItemEntity1.getImageMapAreaTag(toolTipTagFragmentGenerator2, uRLTagFragmentGenerator3);
        java.lang.Comparable comparable5 = legendItemEntity1.getSeriesKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(comparable5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryLabelPosition4.getRotationAnchor();
        objectList0.set(0, (java.lang.Object) categoryLabelPosition4);
        float float7 = categoryLabelPosition4.getWidthRatio();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.95f + "'", float7 == 0.95f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        categoryPlot11.clearDomainMarkers();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent13);
        categoryPlot11.configureRangeAxes();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = barRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        legendItemBlockContainer8.setPadding(rectangleInsets16);
        org.jfree.chart.block.BlockFrame blockFrame18 = legendItemBlockContainer8.getFrame();
        java.lang.String str19 = legendItemBlockContainer8.getURLText();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(blockFrame18);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        java.lang.String str3 = numberTickUnit1.valueToString((double) (-2));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-2" + "'", str3.equals("-2"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (short) 100, (double) (-1));
        flowArrangement11.clear();
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11, dataset13, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer15.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer15.setHeight((double) (byte) 1);
        java.util.List list23 = legendItemBlockContainer15.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendItemBlockContainer15.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets25.calculateTopOutset((double) (short) 10);
        double double28 = rectangleInsets25.getLeft();
        double double30 = rectangleInsets25.trimWidth(0.0d);
        legendItemBlockContainer15.setMargin(rectangleInsets25);
        java.awt.geom.Rectangle2D rectangle2D32 = legendItemBlockContainer15.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double34 = numberAxis3.valueToJava2D((double) 1.0f, rectangle2D32, rectangleEdge33);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets2.createOutsetRectangle(rectangle2D32, false, false);
        double double38 = rectangleInsets2.getTop();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke(1);
        java.lang.Object obj3 = null;
        boolean boolean4 = strokeList0.equals(obj3);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        numberAxis1.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment6 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement9 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment5, verticalAlignment6, (double) (short) 100, (double) (-1));
        flowArrangement9.clear();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement9, dataset11, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer13.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer13.setHeight((double) (byte) 1);
        java.util.List list21 = legendItemBlockContainer13.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = legendItemBlockContainer13.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double25 = rectangleInsets23.calculateTopOutset((double) (short) 10);
        double double26 = rectangleInsets23.getLeft();
        double double28 = rectangleInsets23.trimWidth(0.0d);
        legendItemBlockContainer13.setMargin(rectangleInsets23);
        java.awt.geom.Rectangle2D rectangle2D30 = legendItemBlockContainer13.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double32 = numberAxis1.valueToJava2D((double) 1.0f, rectangle2D30, rectangleEdge31);
        boolean boolean33 = numberAxis1.isVerticalTickLabels();
        boolean boolean34 = booleanList0.equals((java.lang.Object) numberAxis1);
        java.lang.Boolean boolean36 = booleanList0.getBoolean((-20561));
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(boolean36);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        java.awt.Paint paint11 = barRenderer0.getSeriesPaint((int) (byte) 100);
        java.awt.Stroke stroke12 = barRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float1 = categoryLabelPosition0.getWidthRatio();
        double double2 = categoryLabelPosition0.getAngle();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float4 = categoryLabelPosition3.getWidthRatio();
        org.jfree.chart.util.ObjectList objectList5 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj7 = objectList5.get(15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor10 = categoryLabelPosition9.getRotationAnchor();
        objectList5.set(0, (java.lang.Object) categoryLabelPosition9);
        double double12 = categoryLabelPosition9.getAngle();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions14 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition3, categoryLabelPosition9, categoryLabelPosition13);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.95f + "'", float1 == 0.95f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.95f + "'", float4 == 0.95f);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("0", graphics2D1, (double) (byte) -1, (float) 10L, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        java.awt.Paint paint8 = legendGraphic6.getFillPaint();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        double double5 = axisSpace4.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        axisSpace4.add((double) 100.0f, rectangleEdge8);
        axisState2.moveCursor((double) (short) 100, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.isTickLabelsVisible();
        numberAxis14.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, (double) (short) 100, (double) (-1));
        flowArrangement33.clear();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33, dataset35, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer37.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer37.setHeight((double) (byte) 1);
        java.util.List list45 = legendItemBlockContainer37.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendItemBlockContainer37.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) 10);
        double double50 = rectangleInsets47.getLeft();
        double double52 = rectangleInsets47.trimWidth(0.0d);
        legendItemBlockContainer37.setMargin(rectangleInsets47);
        java.awt.geom.Rectangle2D rectangle2D54 = legendItemBlockContainer37.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double56 = numberAxis25.valueToJava2D((double) 1.0f, rectangle2D54, rectangleEdge55);
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = chartColor22.createContext(colorModel23, rectangle24, rectangle2D54, affineTransform57, renderingHints58);
        org.jfree.chart.axis.AxisSpace axisSpace60 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray61 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean62 = axisSpace60.equals((java.lang.Object) shapeArray61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge64);
        axisSpace60.add((double) 10, rectangleEdge65);
        double double67 = numberAxis14.valueToJava2D(0.0d, rectangle2D54, rectangleEdge65);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets11.createInsetRectangle(rectangle2D54);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity71 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D68, "java.awt.Color[r=255,g=0,b=0]", "Layer.FOREGROUND");
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation72, plotOrientation73);
        java.util.List list75 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D68, rectangleEdge74);
        categoryAxis0.setCategoryMargin((double) (byte) 0);
        java.lang.Comparable comparable78 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(shapeArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(list75);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis0.setNumberFormatOverride(numberFormat8);
        try {
            numberAxis0.setRangeWithMargins((double) 10.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Color color4 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder5 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke6 = lineBorder5.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke6);
        java.awt.Paint paint8 = valueMarker7.getLabelPaint();
        valueMarker7.setAlpha(0.5f);
        double double11 = valueMarker7.getValue();
        java.awt.Font font13 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine14 = new org.jfree.chart.text.TextLine("", font13);
        valueMarker7.setLabelFont(font13);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font13);
        java.awt.Font font17 = textFragment16.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double20 = defaultStatisticalCategoryDataset18.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean23 = numberAxis22.isTickLabelsVisible();
        boolean boolean24 = numberAxis22.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat25 = null;
        numberAxis22.setNumberFormatOverride(numberFormat25);
        boolean boolean27 = numberAxis22.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer28);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str32 = layer31.toString();
        java.util.Collection collection33 = categoryPlot29.getDomainMarkers(0, layer31);
        categoryPlot29.clearRangeAxes();
        categoryPlot29.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint37 = categoryPlot29.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = categoryPlot29.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart40 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font17, (org.jfree.chart.plot.Plot) categoryPlot29, true);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer45 = new org.jfree.chart.text.G2TextMeasurer(graphics2D44);
        try {
            org.jfree.chart.text.TextBlock textBlock46 = org.jfree.chart.text.TextUtilities.createTextBlock("LengthConstraintType.NONE", font17, (java.awt.Paint) color41, 10.0f, (-20561), (org.jfree.chart.text.TextMeasurer) g2TextMeasurer45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Layer.FOREGROUND" + "'", str32.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        java.awt.Shape shape8 = numberAxis0.getDownArrow();
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) numberAxis0);
        numberAxis0.setNegativeArrowVisible(false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double14 = defaultStatisticalCategoryDataset12.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean17 = numberAxis16.isTickLabelsVisible();
        boolean boolean18 = numberAxis16.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat19 = null;
        numberAxis16.setNumberFormatOverride(numberFormat19);
        boolean boolean21 = numberAxis16.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis16, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getDomainGridlinePaint();
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot23);
        double double26 = categoryPlot23.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        boolean boolean8 = numberAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font2);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("rect", font2);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getFirstTextFragment();
        float float6 = textFragment5.getBaselineOffset();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        numberAxis0.zoomRange(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        boolean boolean3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator3, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        java.lang.Object obj9 = legendItemBlockContainer8.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(true);
        double double3 = numberAxis0.getFixedDimension();
        numberAxis0.setUpperBound(0.0d);
        boolean boolean6 = numberAxis0.isTickLabelsVisible();
        numberAxis0.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener19 = null;
        boolean boolean20 = numberAxis18.hasListener(eventListener19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color21);
        boolean boolean23 = numberAxis18.isAxisLineVisible();
        boolean boolean24 = numberAxis18.getAutoRangeIncludesZero();
        numberAxis18.setPositiveArrowVisible(false);
        categoryPlot11.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        try {
            numberAxis18.zoomRange((double) 1.0f, (double) 0.95f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.05) <= upper (0.9974999874830246).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("PlotOrientation.HORIZONTAL", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 10.0f);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, 0.0d, true);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range3, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range3);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener12 = null;
        boolean boolean13 = numberAxis11.hasListener(eventListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color14);
        boolean boolean16 = numberAxis11.isAxisLineVisible();
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 10.0f);
        org.jfree.data.Range range22 = org.jfree.data.Range.shift(range19, 0.0d, true);
        numberAxis11.setRange(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint10.toRangeHeight(range19);
        org.jfree.chart.util.Size2D size2D25 = null;
        try {
            org.jfree.chart.util.Size2D size2D26 = rectangleConstraint10.calculateConstrainedSize(size2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        numberAxis0.setLabelFont(font5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot11.getInsets();
        int int22 = categoryPlot11.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot11.setDomainAxisLocation(axisLocation23);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        java.awt.Image image41 = null;
        jFreeChart39.setBackgroundImage(image41);
        java.awt.Image image43 = null;
        jFreeChart39.setBackgroundImage(image43);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray5, numberArray9, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextBlockAnchor.CENTER_LEFT", "hi!", numberArray14);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset15, 0);
        org.jfree.data.general.PieDataset pieDataset19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset15, 0);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertNotNull(pieDataset19);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        java.awt.Paint paint7 = textFragment5.getPaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets10.getRight();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder(paint7, stroke9, rectangleInsets10);
        java.awt.Stroke stroke13 = lineBorder12.getStroke();
        valueMarker1.setStroke(stroke13);
        java.lang.String str15 = valueMarker1.getLabel();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        boolean boolean17 = valueMarker1.equals((java.lang.Object) defaultStatisticalCategoryDataset16);
        java.lang.Object obj18 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer0.lookupSeriesShape((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer5.getBasePositiveItemLabelPosition();
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition6, true);
        boolean boolean9 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset((-16776960));
        categoryAxis0.setCategoryMargin((double) (-16776960));
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot11.getInsets();
        int int22 = categoryPlot11.getRangeAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean25 = axisSpace23.equals((java.lang.Object) shapeArray24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge27);
        axisSpace23.add((double) 10, rectangleEdge28);
        java.lang.String str30 = axisSpace23.toString();
        categoryPlot11.setFixedDomainAxisSpace(axisSpace23);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(shapeArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        numberAxis0.setLabelToolTip("rect");
        numberAxis0.resizeRange((double) (short) 0);
        numberAxis0.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) standardGradientPaintTransformer1);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType4 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        java.util.List list16 = legendItemBlockContainer8.getBlocks();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.Font font19 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color20 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("", font19, (java.awt.Paint) color20);
        java.lang.String str22 = textFragment21.getText();
        java.awt.Paint paint23 = textFragment21.getPaint();
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke25 = lineBorder24.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets26.getRight();
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder(paint23, stroke25, rectangleInsets26);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, (double) (short) 100, (double) (-1));
        flowArrangement33.clear();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33, dataset35, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer37.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer37.setHeight((double) (byte) 1);
        java.util.List list45 = legendItemBlockContainer37.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendItemBlockContainer37.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) 10);
        double double50 = rectangleInsets47.getLeft();
        double double52 = rectangleInsets47.trimWidth(0.0d);
        legendItemBlockContainer37.setMargin(rectangleInsets47);
        java.awt.geom.Rectangle2D rectangle2D54 = legendItemBlockContainer37.getBounds();
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets26.createInsetRectangle(rectangle2D54);
        try {
            legendItemBlockContainer8.draw(graphics2D17, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        java.awt.Shape shape8 = numberAxis0.getDownArrow();
        org.jfree.data.Range range9 = numberAxis0.getRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(range9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        int int2 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Font font3 = barRenderer0.getSeriesItemLabelFont((int) '#');
        java.awt.Paint paint6 = barRenderer0.getItemPaint(0, (-16777216));
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape9, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color22);
        org.jfree.data.general.Dataset dataset24 = legendItem23.getDataset();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj26 = standardGradientPaintTransformer25.clone();
        java.lang.Object obj27 = standardGradientPaintTransformer25.clone();
        legendItem23.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        java.text.AttributedString attributedString29 = legendItem23.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(dataset24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNull(attributedString29);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setUpperMargin((double) ' ');
        float float3 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryPlot11.getInsets();
        int int22 = categoryPlot11.getRangeAxisCount();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = categoryPlot11.getDatasetRenderingOrder();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 10.0f);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, 0.0d, true);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range3, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range3);
        double double11 = range3.getUpperBound();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        org.jfree.chart.block.Block block9 = null;
        legendItemBlockContainer8.add(block9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendItemBlockContainer8.getMargin();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot11.getRangeAxisForDataset(10);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = valueAxis17.getTickLabelInsets();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = null;
        axisState0.setTicks(list1);
        double double3 = axisState0.getCursor();
        axisState0.setMax((double) (-1));
        java.util.List list6 = axisState0.getTicks();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(list6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        java.lang.String str2 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LengthConstraintType.NONE" + "'", str2.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        java.awt.Color color21 = java.awt.Color.lightGray;
        categoryPlot11.setOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot11.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = categoryPlot11.getRenderer();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNull(categoryItemRenderer25);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        java.lang.Class<?> wildcardClass6 = barRenderer0.getClass();
        double double7 = barRenderer0.getBase();
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        try {
            org.jfree.chart.text.TextBlock textBlock3 = org.jfree.chart.text.TextUtilities.createTextBlock("-2", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double5 = defaultStatisticalCategoryDataset3.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean8 = numberAxis7.isTickLabelsVisible();
        boolean boolean9 = numberAxis7.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis7.setNumberFormatOverride(numberFormat10);
        boolean boolean12 = numberAxis7.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str17 = layer16.toString();
        java.util.Collection collection18 = categoryPlot14.getDomainMarkers(0, layer16);
        categoryPlot14.setDrawSharedDomainAxis(true);
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot14);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        numberAxis23.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment27, verticalAlignment28, (double) (short) 100, (double) (-1));
        flowArrangement31.clear();
        org.jfree.data.general.Dataset dataset33 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer35 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement31, dataset33, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer35.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer35.setHeight((double) (byte) 1);
        java.util.List list43 = legendItemBlockContainer35.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = legendItemBlockContainer35.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double47 = rectangleInsets45.calculateTopOutset((double) (short) 10);
        double double48 = rectangleInsets45.getLeft();
        double double50 = rectangleInsets45.trimWidth(0.0d);
        legendItemBlockContainer35.setMargin(rectangleInsets45);
        java.awt.geom.Rectangle2D rectangle2D52 = legendItemBlockContainer35.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double54 = numberAxis23.valueToJava2D((double) 1.0f, rectangle2D52, rectangleEdge53);
        try {
            categoryPlot14.drawBackground(graphics2D22, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Layer.FOREGROUND" + "'", str17.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertNotNull(list43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor2, (double) '4', (double) (byte) 100);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor6);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = numberAxis8.hasListener(eventListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis8.setTickLabelPaint((java.awt.Paint) color11);
        java.lang.String str13 = numberAxis8.getLabelToolTip();
        numberAxis8.setLabelToolTip("");
        java.awt.Stroke stroke16 = numberAxis8.getTickMarkStroke();
        boolean boolean17 = categoryLabelPosition7.equals((java.lang.Object) stroke16);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        java.awt.Paint paint11 = barRenderer0.getSeriesPaint((int) (byte) 100);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity13 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, rectangleAnchor14, (double) '4', (double) (byte) 100);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = numberAxis22.hasListener(eventListener23);
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity26 = new org.jfree.chart.entity.LegendItemEntity(shape25);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape25, rectangleAnchor27, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis22, shape30, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D34 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit36 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D34.removeColumn((java.lang.Comparable) numberTickUnit36);
        numberAxis22.setTickUnit(numberTickUnit36);
        numberAxis22.setTickLabelsVisible(false);
        java.awt.Font font43 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color44 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment45 = new org.jfree.chart.text.TextFragment("", font43, (java.awt.Paint) color44);
        java.lang.String str46 = textFragment45.getText();
        java.awt.Paint paint47 = textFragment45.getPaint();
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke49 = lineBorder48.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double51 = rectangleInsets50.getRight();
        org.jfree.chart.block.LineBorder lineBorder52 = new org.jfree.chart.block.LineBorder(paint47, stroke49, rectangleInsets50);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment53 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement57 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment53, verticalAlignment54, (double) (short) 100, (double) (-1));
        flowArrangement57.clear();
        org.jfree.data.general.Dataset dataset59 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer61 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement57, dataset59, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer61.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer61.setHeight((double) (byte) 1);
        java.util.List list69 = legendItemBlockContainer61.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = legendItemBlockContainer61.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double73 = rectangleInsets71.calculateTopOutset((double) (short) 10);
        double double74 = rectangleInsets71.getLeft();
        double double76 = rectangleInsets71.trimWidth(0.0d);
        legendItemBlockContainer61.setMargin(rectangleInsets71);
        java.awt.geom.Rectangle2D rectangle2D78 = legendItemBlockContainer61.getBounds();
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets50.createInsetRectangle(rectangle2D78);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions80 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition82 = categoryLabelPositions80.getLabelPosition(rectangleEdge81);
        org.jfree.chart.util.RectangleEdge rectangleEdge83 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition84 = categoryLabelPositions80.getLabelPosition(rectangleEdge83);
        double double85 = numberAxis22.valueToJava2D((double) (-16777216), rectangle2D78, rectangleEdge83);
        try {
            barRenderer0.drawDomainGridline(graphics2D20, categoryPlot21, rectangle2D78, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "" + "'", str46.equals(""));
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment53);
        org.junit.Assert.assertNotNull(list69);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(categoryLabelPositions80);
        org.junit.Assert.assertNull(categoryLabelPosition82);
        org.junit.Assert.assertNotNull(rectangleEdge83);
        org.junit.Assert.assertNotNull(categoryLabelPosition84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray3 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = legendTitle1.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(legendItemSourceArray3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Font font3 = barRenderer0.getSeriesItemLabelFont((int) '#');
        java.awt.Paint paint6 = barRenderer0.getItemPaint(0, (-16777216));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator(15, 0);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double13 = defaultStatisticalCategoryDataset11.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean16 = numberAxis15.isTickLabelsVisible();
        boolean boolean17 = numberAxis15.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat18 = null;
        numberAxis15.setNumberFormatOverride(numberFormat18);
        boolean boolean20 = numberAxis15.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer21);
        java.awt.Color color24 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder25 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke26 = lineBorder25.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke26);
        java.awt.Paint paint28 = valueMarker27.getLabelPaint();
        valueMarker27.setAlpha(0.5f);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str32 = layer31.toString();
        categoryPlot22.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker27, layer31);
        org.jfree.chart.util.SortOrder sortOrder34 = categoryPlot22.getColumnRenderingOrder();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            barRenderer0.drawBackground(graphics2D10, categoryPlot22, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Layer.FOREGROUND" + "'", str32.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(sortOrder34);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlock textBlock7 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick11 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock7, textBlockAnchor8, textAnchor9, (double) (short) 1);
        try {
            java.awt.Shape shape12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("UnitType.ABSOLUTE", graphics2D1, (float) 8, (float) (-1L), textAnchor4, (double) (short) -1, textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint3 = null;
        barRenderer0.setSeriesFillPaint(100, paint3, true);
        java.awt.Font font7 = barRenderer0.getSeriesItemLabelFont((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent2 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        java.awt.Paint paint3 = legendTitle1.getItemPaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "0");
        double[] doubleArray15 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray16 = new double[][] { doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "hi!", doubleArray16);
        boolean boolean19 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) categoryDataset18);
        try {
            org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset18, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        java.util.List list2 = axisCollection0.getAxesAtRight();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 10.0f);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, 0.0d, true);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range3, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range3);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener12 = null;
        boolean boolean13 = numberAxis11.hasListener(eventListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color14);
        boolean boolean16 = numberAxis11.isAxisLineVisible();
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 10.0f);
        org.jfree.data.Range range22 = org.jfree.data.Range.shift(range19, 0.0d, true);
        numberAxis11.setRange(range19);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = rectangleConstraint10.toRangeHeight(range19);
        org.jfree.data.Range range27 = org.jfree.data.Range.expand(range19, (double) 0.95f, 8.0d);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        categoryPlot11.mapDatasetToDomainAxis(0, (int) (byte) 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = categoryPlot11.getDomainGridlinePosition();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.Font font26 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color27 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("", font26, (java.awt.Paint) color27);
        java.lang.String str29 = textFragment28.getText();
        java.awt.Paint paint30 = textFragment28.getPaint();
        org.jfree.chart.block.LineBorder lineBorder31 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke32 = lineBorder31.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double34 = rectangleInsets33.getRight();
        org.jfree.chart.block.LineBorder lineBorder35 = new org.jfree.chart.block.LineBorder(paint30, stroke32, rectangleInsets33);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment36 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment37 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement40 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment36, verticalAlignment37, (double) (short) 100, (double) (-1));
        flowArrangement40.clear();
        org.jfree.data.general.Dataset dataset42 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer44 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement40, dataset42, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer44.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer44.setHeight((double) (byte) 1);
        java.util.List list52 = legendItemBlockContainer44.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = legendItemBlockContainer44.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double56 = rectangleInsets54.calculateTopOutset((double) (short) 10);
        double double57 = rectangleInsets54.getLeft();
        double double59 = rectangleInsets54.trimWidth(0.0d);
        legendItemBlockContainer44.setMargin(rectangleInsets54);
        java.awt.geom.Rectangle2D rectangle2D61 = legendItemBlockContainer44.getBounds();
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets33.createInsetRectangle(rectangle2D61);
        categoryPlot11.drawBackgroundImage(graphics2D24, rectangle2D61);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment36);
        org.junit.Assert.assertNotNull(list52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangle2D62);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        double double5 = axisSpace4.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        axisSpace4.add((double) 100.0f, rectangleEdge8);
        axisState2.moveCursor((double) (short) 100, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.isTickLabelsVisible();
        numberAxis14.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, (double) (short) 100, (double) (-1));
        flowArrangement33.clear();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33, dataset35, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer37.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer37.setHeight((double) (byte) 1);
        java.util.List list45 = legendItemBlockContainer37.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendItemBlockContainer37.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) 10);
        double double50 = rectangleInsets47.getLeft();
        double double52 = rectangleInsets47.trimWidth(0.0d);
        legendItemBlockContainer37.setMargin(rectangleInsets47);
        java.awt.geom.Rectangle2D rectangle2D54 = legendItemBlockContainer37.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double56 = numberAxis25.valueToJava2D((double) 1.0f, rectangle2D54, rectangleEdge55);
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = chartColor22.createContext(colorModel23, rectangle24, rectangle2D54, affineTransform57, renderingHints58);
        org.jfree.chart.axis.AxisSpace axisSpace60 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray61 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean62 = axisSpace60.equals((java.lang.Object) shapeArray61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge64);
        axisSpace60.add((double) 10, rectangleEdge65);
        double double67 = numberAxis14.valueToJava2D(0.0d, rectangle2D54, rectangleEdge65);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets11.createInsetRectangle(rectangle2D54);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity71 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D68, "java.awt.Color[r=255,g=0,b=0]", "Layer.FOREGROUND");
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation72, plotOrientation73);
        java.util.List list75 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D68, rectangleEdge74);
        categoryAxis0.setCategoryMargin((double) (byte) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets78 = categoryAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D80 = rectangleInsets78.createInsetRectangle(rectangle2D79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(shapeArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNotNull(rectangleInsets78);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendGraphic6.getShapeAnchor();
        java.lang.Object obj9 = legendGraphic6.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) false);
        java.lang.Object obj4 = datasetGroup1.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        java.awt.Paint paint11 = barRenderer0.getSeriesPaint((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer13 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType14 = standardGradientPaintTransformer13.getType();
        boolean boolean15 = itemLabelAnchor12.equals((java.lang.Object) standardGradientPaintTransformer13);
        java.lang.Object obj16 = standardGradientPaintTransformer13.clone();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer13);
        double double18 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(gradientPaintTransformType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) (short) 100, (double) (-1));
        flowArrangement8.clear();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, dataset10, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer12.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer12.setHeight((double) (byte) 1);
        java.util.List list20 = legendItemBlockContainer12.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendItemBlockContainer12.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.calculateTopOutset((double) (short) 10);
        double double25 = rectangleInsets22.getLeft();
        double double27 = rectangleInsets22.trimWidth(0.0d);
        legendItemBlockContainer12.setMargin(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D29 = legendItemBlockContainer12.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double31 = numberAxis0.valueToJava2D((double) 1.0f, rectangle2D29, rectangleEdge30);
        boolean boolean32 = numberAxis0.isVerticalTickLabels();
        numberAxis0.setTickLabelsVisible(false);
        org.jfree.chart.block.LineBorder lineBorder35 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke36 = lineBorder35.getStroke();
        numberAxis0.setAxisLineStroke(stroke36);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.util.List list12 = categoryPlot11.getCategories();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot11.getRenderer(8);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((-20561));
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener20 = null;
        boolean boolean21 = numberAxis19.hasListener(eventListener20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis19.setTickLabelPaint((java.awt.Paint) color22);
        boolean boolean24 = numberAxis19.isAxisLineVisible();
        boolean boolean25 = numberAxis19.getAutoRangeIncludesZero();
        numberAxis19.setPositiveArrowVisible(false);
        double double28 = numberAxis19.getLowerBound();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color33 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("", font32, (java.awt.Paint) color33);
        java.lang.String str35 = textFragment34.getText();
        java.awt.Paint paint36 = textFragment34.getPaint();
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke38 = lineBorder37.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double40 = rectangleInsets39.getRight();
        org.jfree.chart.block.LineBorder lineBorder41 = new org.jfree.chart.block.LineBorder(paint36, stroke38, rectangleInsets39);
        java.awt.Stroke stroke42 = lineBorder41.getStroke();
        valueMarker30.setStroke(stroke42);
        java.lang.String str44 = valueMarker30.getLabel();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener46 = null;
        boolean boolean47 = numberAxis45.hasListener(eventListener46);
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis45.setTickLabelPaint((java.awt.Paint) color48);
        java.lang.String str50 = numberAxis45.getLabelToolTip();
        java.awt.Stroke stroke51 = numberAxis45.getTickMarkStroke();
        valueMarker30.setStroke(stroke51);
        numberAxis19.setAxisLineStroke(stroke51);
        categoryPlot11.setRangeGridlineStroke(stroke51);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(str50);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        java.awt.Image image41 = null;
        jFreeChart39.setBackgroundImage(image41);
        org.jfree.chart.plot.Plot plot43 = jFreeChart39.getPlot();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertNotNull(plot43);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        categoryPlot11.setRangeCrosshairVisible(true);
        categoryPlot11.clearAnnotations();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        double double6 = barRenderer0.getLowerClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = barRenderer0.getPlot();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(categoryPlot8);
        org.junit.Assert.assertNull(categoryURLGenerator9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        int int13 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 152.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot11.getFixedLegendItems();
        java.awt.Stroke stroke20 = null;
        try {
            categoryPlot11.setRangeGridlineStroke(stroke20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(legendItemCollection19);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("LegendItemEntity: seriesKey=null, dataset=null");
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        barRenderer0.setBasePaint(paint14);
        java.awt.Color color17 = java.awt.Color.RED;
        java.lang.String str18 = color17.toString();
        int int19 = color17.getBlue();
        int int20 = color17.getTransparency();
        barRenderer0.setSeriesPaint(2, (java.awt.Paint) color17, false);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        barRenderer0.setBaseOutlinePaint(paint23, true);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str18.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        java.lang.Object obj4 = null;
        keyedObjects2D0.addObject(obj4, (java.lang.Comparable) 8, (java.lang.Comparable) "ThreadContext");
        keyedObjects2D0.removeObject((java.lang.Comparable) "NO_CHANGE", (java.lang.Comparable) 0.05d);
        try {
            keyedObjects2D0.removeRow((-20561));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) 'a', (double) (-16777216), 0.0d, 15.0d);
        boolean boolean7 = defaultDrawingSupplier0.equals((java.lang.Object) 'a');
        java.awt.Paint paint8 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) 1, (float) (short) 100);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        numberAxis4.setNegativeArrowVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer8.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener12 = null;
        boolean boolean13 = numberAxis11.hasListener(eventListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis11.setTickLabelPaint((java.awt.Paint) color14);
        boolean boolean16 = numberAxis11.isAxisLineVisible();
        boolean boolean17 = numberAxis11.getAutoRangeIncludesZero();
        numberAxis11.setPositiveArrowVisible(false);
        double double20 = numberAxis11.getLowerBound();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Font font24 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color25 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("", font24, (java.awt.Paint) color25);
        java.lang.String str27 = textFragment26.getText();
        java.awt.Paint paint28 = textFragment26.getPaint();
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke30 = lineBorder29.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets31.getRight();
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder(paint28, stroke30, rectangleInsets31);
        java.awt.Stroke stroke34 = lineBorder33.getStroke();
        valueMarker22.setStroke(stroke34);
        java.lang.String str36 = valueMarker22.getLabel();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener38 = null;
        boolean boolean39 = numberAxis37.hasListener(eventListener38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis37.setTickLabelPaint((java.awt.Paint) color40);
        java.lang.String str42 = numberAxis37.getLabelToolTip();
        java.awt.Stroke stroke43 = numberAxis37.getTickMarkStroke();
        valueMarker22.setStroke(stroke43);
        numberAxis11.setAxisLineStroke(stroke43);
        barRenderer8.setBaseOutlineStroke(stroke43, false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Boolean boolean2 = barRenderer0.getSeriesVisibleInLegend((-16777216));
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        org.jfree.chart.block.Arrangement arrangement14 = legendItemBlockContainer8.getArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement19);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(arrangement14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray11 = new float[] { 1, '#', 10L, 1 };
        float[] floatArray12 = java.awt.Color.RGBtoHSB(500, (int) (short) 10, (int) (byte) 100, floatArray11);
        float[] floatArray13 = color3.getComponents(floatArray12);
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = numberAxis16.hasListener(eventListener17);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, rectangleAnchor21, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity27 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis16, shape24, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D28 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit30 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D28.removeColumn((java.lang.Comparable) numberTickUnit30);
        numberAxis16.setTickUnit(numberTickUnit30);
        numberAxis16.setTickLabelsVisible(false);
        java.awt.Font font37 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color38 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("", font37, (java.awt.Paint) color38);
        java.lang.String str40 = textFragment39.getText();
        java.awt.Paint paint41 = textFragment39.getPaint();
        org.jfree.chart.block.LineBorder lineBorder42 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke43 = lineBorder42.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double45 = rectangleInsets44.getRight();
        org.jfree.chart.block.LineBorder lineBorder46 = new org.jfree.chart.block.LineBorder(paint41, stroke43, rectangleInsets44);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement51 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment47, verticalAlignment48, (double) (short) 100, (double) (-1));
        flowArrangement51.clear();
        org.jfree.data.general.Dataset dataset53 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer55 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement51, dataset53, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer55.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer55.setHeight((double) (byte) 1);
        java.util.List list63 = legendItemBlockContainer55.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = legendItemBlockContainer55.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double67 = rectangleInsets65.calculateTopOutset((double) (short) 10);
        double double68 = rectangleInsets65.getLeft();
        double double70 = rectangleInsets65.trimWidth(0.0d);
        legendItemBlockContainer55.setMargin(rectangleInsets65);
        java.awt.geom.Rectangle2D rectangle2D72 = legendItemBlockContainer55.getBounds();
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets44.createInsetRectangle(rectangle2D72);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions74 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition76 = categoryLabelPositions74.getLabelPosition(rectangleEdge75);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition78 = categoryLabelPositions74.getLabelPosition(rectangleEdge77);
        double double79 = numberAxis16.valueToJava2D((double) (-16777216), rectangle2D72, rectangleEdge77);
        java.awt.geom.AffineTransform affineTransform80 = null;
        java.awt.RenderingHints renderingHints81 = null;
        java.awt.PaintContext paintContext82 = color3.createContext(colorModel14, rectangle15, rectangle2D72, affineTransform80, renderingHints81);
        java.awt.geom.Point2D point2D83 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) '#', (-1.0d), rectangle2D72);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions84 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition86 = categoryLabelPositions84.getLabelPosition(rectangleEdge85);
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition88 = categoryLabelPositions84.getLabelPosition(rectangleEdge87);
        java.awt.geom.Rectangle2D rectangle2D89 = axisSpace0.reserved(rectangle2D72, rectangleEdge87);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(categoryLabelPositions74);
        org.junit.Assert.assertNull(categoryLabelPosition76);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertNotNull(categoryLabelPosition78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext82);
        org.junit.Assert.assertNotNull(point2D83);
        org.junit.Assert.assertNotNull(categoryLabelPositions84);
        org.junit.Assert.assertNull(categoryLabelPosition86);
        org.junit.Assert.assertNotNull(rectangleEdge87);
        org.junit.Assert.assertNotNull(categoryLabelPosition88);
        org.junit.Assert.assertNotNull(rectangle2D89);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 10.0f);
        double double4 = range2.constrain((double) 100);
        double double5 = range2.getLength();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(Double.NaN, (double) ' ', rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getRangeMarkers(layer13);
        java.lang.String str16 = layer13.toString();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Layer.FOREGROUND" + "'", str16.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Layer.FOREGROUND");
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) 'a');
        java.lang.Object obj4 = keyedObjects0.clone();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        textBlock0.addLine(textLine4);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset6, true);
        boolean boolean9 = textLine4.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.util.List list12 = categoryPlot11.getCategories();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        try {
            categoryPlot11.setDomainAxis((-1), categoryAxis14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.Font font3 = textTitle1.getFont();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toFixedWidth((double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedWidth(152.0d);
        org.jfree.data.Range range12 = null;
        org.jfree.data.Range range14 = org.jfree.data.Range.expandToInclude(range12, (double) 10.0f);
        org.jfree.data.Range range17 = org.jfree.data.Range.shift(range14, 0.0d, true);
        org.jfree.data.Range range20 = org.jfree.data.Range.shift(range14, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke22 = lineBorder21.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = lineBorder21.getInsets();
        boolean boolean24 = range14.equals((java.lang.Object) lineBorder21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = rectangleConstraint9.toRangeWidth(range14);
        try {
            org.jfree.chart.util.Size2D size2D26 = textTitle1.arrange(graphics2D4, rectangleConstraint25);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint25);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        numberAxis4.setNegativeArrowVisible(true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer8.getBasePositiveItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        try {
            categoryPlot10.addDomainMarker(categoryMarker11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        barRenderer0.setMaximumBarWidth(152.0d);
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("LengthConstraintType.NONE");
        java.awt.Font font10 = labelBlock9.getFont();
        java.awt.Font font11 = labelBlock9.getFont();
        barRenderer0.setBaseItemLabelFont(font11, true);
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getRangeMarkers(layer13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot11.getIndexOf(categoryItemRenderer16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("LengthConstraintType.NONE");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        float float7 = textFragment5.getBaselineOffset();
        java.awt.Font font8 = textFragment5.getFont();
        labelBlock1.setFont(font8);
        java.lang.String str10 = labelBlock1.getID();
        java.lang.Object obj11 = labelBlock1.clone();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Paint paint5 = textFragment3.getPaint();
        org.jfree.chart.block.LineBorder lineBorder6 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke7 = lineBorder6.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets8.getRight();
        org.jfree.chart.block.LineBorder lineBorder10 = new org.jfree.chart.block.LineBorder(paint5, stroke7, rectangleInsets8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset11 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double13 = defaultStatisticalCategoryDataset11.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean16 = numberAxis15.isTickLabelsVisible();
        boolean boolean17 = numberAxis15.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat18 = null;
        numberAxis15.setNumberFormatOverride(numberFormat18);
        boolean boolean20 = numberAxis15.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset11, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis15, categoryItemRenderer21);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        java.util.Collection collection26 = categoryPlot22.getDomainMarkers(0, layer24);
        java.lang.String str27 = categoryPlot22.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot22.rendererChanged(rendererChangeEvent28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = categoryPlot22.getFixedDomainAxisSpace();
        boolean boolean31 = lineBorder10.equals((java.lang.Object) categoryPlot22);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        valueMarker4.setAlpha(0.5f);
        double double8 = valueMarker4.getValue();
        java.awt.Font font10 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("", font10);
        valueMarker4.setLabelFont(font10);
        java.lang.Object obj13 = valueMarker4.clone();
        valueMarker4.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) (short) 100, (double) (-1));
        flowArrangement8.clear();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, dataset10, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer12.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer12.setHeight((double) (byte) 1);
        java.util.List list20 = legendItemBlockContainer12.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendItemBlockContainer12.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.calculateTopOutset((double) (short) 10);
        double double25 = rectangleInsets22.getLeft();
        double double27 = rectangleInsets22.trimWidth(0.0d);
        legendItemBlockContainer12.setMargin(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D29 = legendItemBlockContainer12.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double31 = numberAxis0.valueToJava2D((double) 1.0f, rectangle2D29, rectangleEdge30);
        boolean boolean32 = numberAxis0.isVerticalTickLabels();
        numberAxis0.setAutoRangeIncludesZero(true);
        numberAxis0.zoomRange((double) (-1.0f), (double) (short) 0);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        double double5 = axisSpace4.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        axisSpace4.add((double) 100.0f, rectangleEdge8);
        axisState2.moveCursor((double) (short) 100, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.isTickLabelsVisible();
        numberAxis14.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, (double) (short) 100, (double) (-1));
        flowArrangement33.clear();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33, dataset35, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer37.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer37.setHeight((double) (byte) 1);
        java.util.List list45 = legendItemBlockContainer37.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendItemBlockContainer37.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) 10);
        double double50 = rectangleInsets47.getLeft();
        double double52 = rectangleInsets47.trimWidth(0.0d);
        legendItemBlockContainer37.setMargin(rectangleInsets47);
        java.awt.geom.Rectangle2D rectangle2D54 = legendItemBlockContainer37.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double56 = numberAxis25.valueToJava2D((double) 1.0f, rectangle2D54, rectangleEdge55);
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = chartColor22.createContext(colorModel23, rectangle24, rectangle2D54, affineTransform57, renderingHints58);
        org.jfree.chart.axis.AxisSpace axisSpace60 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray61 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean62 = axisSpace60.equals((java.lang.Object) shapeArray61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge64);
        axisSpace60.add((double) 10, rectangleEdge65);
        double double67 = numberAxis14.valueToJava2D(0.0d, rectangle2D54, rectangleEdge65);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets11.createInsetRectangle(rectangle2D54);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity71 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D68, "java.awt.Color[r=255,g=0,b=0]", "Layer.FOREGROUND");
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation72, plotOrientation73);
        java.util.List list75 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D68, rectangleEdge74);
        categoryAxis0.setCategoryMargin((double) (byte) 0);
        java.lang.String str79 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (short) 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(shapeArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNull(str79);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray3 = legendTitle1.getSources();
        java.lang.Object obj4 = legendTitle1.clone();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toFixedWidth((double) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint10.toFixedWidth(152.0d);
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range15 = org.jfree.data.Range.expandToInclude(range13, (double) 10.0f);
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range15, 0.0d, true);
        org.jfree.data.Range range21 = org.jfree.data.Range.shift(range15, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke23 = lineBorder22.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = lineBorder22.getInsets();
        boolean boolean25 = range15.equals((java.lang.Object) lineBorder22);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = rectangleConstraint10.toRangeWidth(range15);
        try {
            org.jfree.chart.util.Size2D size2D27 = legendTitle1.arrange(graphics2D5, rectangleConstraint26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(legendItemSourceArray3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint26);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) -1);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.lang.Object obj14 = legendTitle1.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = legendTitle1.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 0.5f, Double.NaN);
        textTitle1.setTextAlignment(horizontalAlignment3);
        java.lang.Class<?> wildcardClass9 = textTitle1.getClass();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint3 = null;
        barRenderer0.setSeriesFillPaint(100, paint3, true);
        barRenderer0.setSeriesCreateEntities(15, (java.lang.Boolean) true, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        java.awt.Image image41 = null;
        jFreeChart39.setBackgroundImage(image41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean45 = numberAxis44.isTickLabelsVisible();
        numberAxis44.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor52 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel53 = null;
        java.awt.Rectangle rectangle54 = null;
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis();
        numberAxis55.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment59 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment60 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement63 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment59, verticalAlignment60, (double) (short) 100, (double) (-1));
        flowArrangement63.clear();
        org.jfree.data.general.Dataset dataset65 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer67 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement63, dataset65, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer67.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer67.setHeight((double) (byte) 1);
        java.util.List list75 = legendItemBlockContainer67.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = legendItemBlockContainer67.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double79 = rectangleInsets77.calculateTopOutset((double) (short) 10);
        double double80 = rectangleInsets77.getLeft();
        double double82 = rectangleInsets77.trimWidth(0.0d);
        legendItemBlockContainer67.setMargin(rectangleInsets77);
        java.awt.geom.Rectangle2D rectangle2D84 = legendItemBlockContainer67.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double86 = numberAxis55.valueToJava2D((double) 1.0f, rectangle2D84, rectangleEdge85);
        java.awt.geom.AffineTransform affineTransform87 = null;
        java.awt.RenderingHints renderingHints88 = null;
        java.awt.PaintContext paintContext89 = chartColor52.createContext(colorModel53, rectangle54, rectangle2D84, affineTransform87, renderingHints88);
        org.jfree.chart.axis.AxisSpace axisSpace90 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray91 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean92 = axisSpace90.equals((java.lang.Object) shapeArray91);
        org.jfree.chart.util.RectangleEdge rectangleEdge94 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge95 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge94);
        axisSpace90.add((double) 10, rectangleEdge95);
        double double97 = numberAxis44.valueToJava2D(0.0d, rectangle2D84, rectangleEdge95);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo98 = null;
        try {
            jFreeChart39.draw(graphics2D43, rectangle2D84, chartRenderingInfo98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment59);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext89);
        org.junit.Assert.assertNotNull(shapeArray91);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertNotNull(rectangleEdge94);
        org.junit.Assert.assertNotNull(rectangleEdge95);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        jFreeChart39.setTextAntiAlias(false);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.Plot plot44 = numberAxis43.getPlot();
        try {
            jFreeChart39.setTextAntiAlias((java.lang.Object) numberAxis43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.axis.NumberAxis@0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertNull(plot44);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D3 = null;
        org.jfree.chart.util.Size2D size2D4 = rectangleConstraint2.calculateConstrainedSize(size2D3);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean11 = basicProjectInfo9.equals((java.lang.Object) (short) -1);
        basicProjectInfo9.setVersion("java.awt.Color[r=255,g=0,b=0]");
        java.lang.String str14 = basicProjectInfo9.getCopyright();
        org.jfree.chart.ui.Library[] libraryArray15 = basicProjectInfo9.getLibraries();
        boolean boolean16 = size2D4.equals((java.lang.Object) basicProjectInfo9);
        java.lang.String str17 = basicProjectInfo9.getInfo();
        java.awt.Shape shape18 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity19 = new org.jfree.chart.entity.LegendItemEntity(shape18);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity22 = new org.jfree.chart.entity.TickLabelEntity(shape18, "ThreadContext", "ThreadContext");
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape18, (java.awt.Paint) color23);
        java.awt.Paint paint25 = legendGraphic24.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke27 = lineBorder26.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = lineBorder26.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement37 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment33, verticalAlignment34, (double) (short) 100, (double) (-1));
        flowArrangement37.clear();
        org.jfree.data.general.Dataset dataset39 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer41 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement37, dataset39, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer41.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer41.setHeight((double) (byte) 1);
        java.util.List list49 = legendItemBlockContainer41.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = legendItemBlockContainer41.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double53 = rectangleInsets51.calculateTopOutset((double) (short) 10);
        double double54 = rectangleInsets51.getLeft();
        double double56 = rectangleInsets51.trimWidth(0.0d);
        legendItemBlockContainer41.setMargin(rectangleInsets51);
        java.awt.geom.Rectangle2D rectangle2D58 = legendItemBlockContainer41.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double60 = numberAxis29.valueToJava2D((double) 1.0f, rectangle2D58, rectangleEdge59);
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets28.createOutsetRectangle(rectangle2D58, false, false);
        legendGraphic24.setLine((java.awt.Shape) rectangle2D63);
        java.lang.Object obj65 = legendGraphic24.clone();
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener67 = null;
        boolean boolean68 = numberAxis66.hasListener(eventListener67);
        java.awt.Color color69 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis66.setTickLabelPaint((java.awt.Paint) color69);
        boolean boolean71 = numberAxis66.isAxisLineVisible();
        boolean boolean72 = numberAxis66.getAutoRangeIncludesZero();
        numberAxis66.setPositiveArrowVisible(false);
        boolean boolean75 = legendGraphic24.equals((java.lang.Object) numberAxis66);
        java.awt.Stroke stroke76 = legendGraphic24.getLineStroke();
        java.awt.Color color77 = java.awt.Color.RED;
        legendGraphic24.setOutlinePaint((java.awt.Paint) color77);
        boolean boolean79 = basicProjectInfo9.equals((java.lang.Object) color77);
        org.junit.Assert.assertNotNull(size2D4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(libraryArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNull(stroke76);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        java.util.List list16 = legendItemBlockContainer8.getBlocks();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment19, (double) (short) 100, (double) (-1));
        flowArrangement22.clear();
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22, dataset24, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer26.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer26.setHeight((double) (byte) 1);
        java.util.List list34 = legendItemBlockContainer26.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendItemBlockContainer26.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateTopOutset((double) (short) 10);
        double double39 = rectangleInsets36.getLeft();
        double double41 = rectangleInsets36.trimWidth(0.0d);
        legendItemBlockContainer26.setMargin(rectangleInsets36);
        java.awt.geom.Rectangle2D rectangle2D43 = legendItemBlockContainer26.getBounds();
        java.awt.Font font45 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color46 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment47 = new org.jfree.chart.text.TextFragment("", font45, (java.awt.Paint) color46);
        java.lang.String str48 = textFragment47.getText();
        java.awt.Paint paint49 = textFragment47.getPaint();
        org.jfree.chart.block.LineBorder lineBorder50 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke51 = lineBorder50.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double53 = rectangleInsets52.getRight();
        org.jfree.chart.block.LineBorder lineBorder54 = new org.jfree.chart.block.LineBorder(paint49, stroke51, rectangleInsets52);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment55 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment56 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement59 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment55, verticalAlignment56, (double) (short) 100, (double) (-1));
        flowArrangement59.clear();
        org.jfree.data.general.Dataset dataset61 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer63 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement59, dataset61, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer63.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer63.setHeight((double) (byte) 1);
        java.util.List list71 = legendItemBlockContainer63.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = legendItemBlockContainer63.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets73 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double75 = rectangleInsets73.calculateTopOutset((double) (short) 10);
        double double76 = rectangleInsets73.getLeft();
        double double78 = rectangleInsets73.trimWidth(0.0d);
        legendItemBlockContainer63.setMargin(rectangleInsets73);
        java.awt.geom.Rectangle2D rectangle2D80 = legendItemBlockContainer63.getBounds();
        java.awt.geom.Rectangle2D rectangle2D81 = rectangleInsets52.createInsetRectangle(rectangle2D80);
        double double83 = rectangleInsets52.calculateTopOutset((double) '4');
        try {
            java.lang.Object obj84 = legendItemBlockContainer8.draw(graphics2D17, rectangle2D43, (java.lang.Object) double83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment55);
        org.junit.Assert.assertNotNull(list71);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertNotNull(rectangleInsets73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        barRenderer0.setMaximumBarWidth(152.0d);
        int int8 = barRenderer0.getColumnCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) 10);
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) 10.0f);
        double double9 = range7.constrain((double) 100);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range7, (double) (byte) 10, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint4.toRangeHeight(range12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint4.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        java.util.List list1 = null;
        axisState0.setTicks(list1);
        double double3 = axisState0.getCursor();
        axisState0.setMax((double) (-1));
        double double6 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str16 = layer15.toString();
        java.util.Collection collection17 = categoryPlot13.getDomainMarkers(0, layer15);
        categoryPlot13.clearRangeAxes();
        categoryPlot13.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint21 = categoryPlot13.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = categoryPlot13.getDatasetRenderingOrder();
        java.awt.Color color23 = java.awt.Color.lightGray;
        categoryPlot13.setOutlinePaint((java.awt.Paint) color23);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        double double26 = categoryPlot13.getRangeCrosshairValue();
        categoryPlot13.setRangeCrosshairValue((double) (-1.0f));
        org.jfree.data.Range range30 = null;
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range30, (double) 10.0f);
        org.jfree.data.Range range35 = org.jfree.data.Range.shift(range32, 0.0d, true);
        org.jfree.data.Range range38 = org.jfree.data.Range.shift(range32, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder39 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke40 = lineBorder39.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = lineBorder39.getInsets();
        boolean boolean42 = range32.equals((java.lang.Object) lineBorder39);
        java.lang.Number[] numberArray48 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray52 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[] numberArray56 = new java.lang.Number[] { 10.0d, (byte) -1, 0L };
        java.lang.Number[][] numberArray57 = new java.lang.Number[][] { numberArray48, numberArray52, numberArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextBlockAnchor.CENTER_LEFT", "hi!", numberArray57);
        boolean boolean59 = lineBorder39.equals((java.lang.Object) categoryDataset58);
        categoryPlot13.setDataset(0, categoryDataset58);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Layer.FOREGROUND" + "'", str16.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(numberArray48);
        org.junit.Assert.assertNotNull(numberArray52);
        org.junit.Assert.assertNotNull(numberArray56);
        org.junit.Assert.assertNotNull(numberArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 10.0f);
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, 0.0d, true);
        org.jfree.data.Range range9 = org.jfree.data.Range.shift(range3, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range3);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment12, (double) (short) 100, (double) (-1));
        flowArrangement15.clear();
        org.jfree.data.general.Dataset dataset17 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement15, dataset17, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer19.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        org.jfree.data.general.Dataset dataset25 = legendItemBlockContainer19.getDataset();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D30 = null;
        org.jfree.chart.util.Size2D size2D31 = rectangleConstraint29.calculateConstrainedSize(size2D30);
        java.lang.String str32 = rectangleConstraint29.toString();
        org.jfree.chart.util.Size2D size2D33 = legendItemBlockContainer19.arrange(graphics2D26, rectangleConstraint29);
        org.jfree.chart.util.Size2D size2D34 = rectangleConstraint10.calculateConstrainedSize(size2D33);
        size2D33.height = 0.95f;
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNull(dataset25);
        org.junit.Assert.assertNotNull(size2D31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]" + "'", str32.equals("RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]"));
        org.junit.Assert.assertNotNull(size2D33);
        org.junit.Assert.assertNotNull(size2D34);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke9);
        java.awt.Paint paint11 = valueMarker10.getLabelPaint();
        valueMarker10.setAlpha(0.5f);
        double double14 = valueMarker10.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker10.setLabelAnchor(rectangleAnchor15);
        legendTitle5.setLegendItemGraphicAnchor(rectangleAnchor15);
        java.lang.Object obj18 = legendTitle5.clone();
        boolean boolean19 = legendItemEntity1.equals(obj18);
        java.lang.String str20 = legendItemEntity1.getShapeType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "rect" + "'", str20.equals("rect"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBasePositiveItemLabelPosition();
        barRenderer0.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (-1), 1.0f, (float) (short) 10);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot18 = categoryPlot11.getParent();
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot11.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot11.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot11.getDomainAxisLocation();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Color color0 = java.awt.Color.gray;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        int int3 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        java.lang.String str16 = categoryPlot11.getNoDataMessage();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot11.getFixedDomainAxisSpace();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity25 = new org.jfree.chart.entity.LegendItemEntity(shape24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, rectangleAnchor26, (double) '4', (double) (byte) 100);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font32 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color33 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("", font32, (java.awt.Paint) color33);
        java.lang.String str35 = textFragment34.getText();
        java.awt.Paint paint36 = textFragment34.getPaint();
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke38 = lineBorder37.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double40 = rectangleInsets39.getRight();
        org.jfree.chart.block.LineBorder lineBorder41 = new org.jfree.chart.block.LineBorder(paint36, stroke38, rectangleInsets39);
        java.awt.Color color42 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape29, (java.awt.Paint) color30, stroke38, (java.awt.Paint) color42);
        categoryPlot11.setOutlineStroke(stroke38);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.awt.Paint paint14 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getRight();
        legendTitle1.setItemLabelPadding(rectangleInsets15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.title.Title title19 = titleChangeEvent18.getTitle();
        java.lang.Object obj20 = titleChangeEvent18.getSource();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(title19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) (short) 100, (double) (-1));
        flowArrangement7.clear();
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement7, dataset9, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer11.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer11.setHeight((double) (byte) 1);
        java.util.List list19 = legendItemBlockContainer11.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendItemBlockContainer11.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateTopOutset((double) (short) 10);
        double double24 = rectangleInsets21.getLeft();
        double double26 = rectangleInsets21.trimWidth(0.0d);
        legendItemBlockContainer11.setMargin(rectangleInsets21);
        java.awt.geom.Rectangle2D rectangle2D28 = legendItemBlockContainer11.getBounds();
        boolean boolean29 = categoryLabelPositions2.equals((java.lang.Object) legendItemBlockContainer11);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions30 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions31 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition33 = categoryLabelPositions31.getLabelPosition(rectangleEdge32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition35 = categoryLabelPositions31.getLabelPosition(rectangleEdge34);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions30, categoryLabelPosition35);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions37 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions2, categoryLabelPosition35);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions31);
        org.junit.Assert.assertNull(categoryLabelPosition33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(categoryLabelPosition35);
        org.junit.Assert.assertNotNull(categoryLabelPositions36);
        org.junit.Assert.assertNotNull(categoryLabelPositions37);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        double double6 = barRenderer0.getLowerClip();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 10, categoryToolTipGenerator8);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color12 = java.awt.Color.lightGray;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("MAJOR", "Layer.FOREGROUND", "", "LengthConstraintType.NONE", shape4, (java.awt.Paint) color10, stroke11, (java.awt.Paint) color12);
        java.awt.Paint paint14 = legendItem13.getOutlinePaint();
        boolean boolean15 = legendItem13.isLineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        double double5 = axisSpace4.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        axisSpace4.add((double) 100.0f, rectangleEdge8);
        axisState2.moveCursor((double) (short) 100, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.isTickLabelsVisible();
        numberAxis14.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, (double) (short) 100, (double) (-1));
        flowArrangement33.clear();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33, dataset35, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer37.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer37.setHeight((double) (byte) 1);
        java.util.List list45 = legendItemBlockContainer37.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendItemBlockContainer37.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) 10);
        double double50 = rectangleInsets47.getLeft();
        double double52 = rectangleInsets47.trimWidth(0.0d);
        legendItemBlockContainer37.setMargin(rectangleInsets47);
        java.awt.geom.Rectangle2D rectangle2D54 = legendItemBlockContainer37.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double56 = numberAxis25.valueToJava2D((double) 1.0f, rectangle2D54, rectangleEdge55);
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = chartColor22.createContext(colorModel23, rectangle24, rectangle2D54, affineTransform57, renderingHints58);
        org.jfree.chart.axis.AxisSpace axisSpace60 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray61 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean62 = axisSpace60.equals((java.lang.Object) shapeArray61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge64);
        axisSpace60.add((double) 10, rectangleEdge65);
        double double67 = numberAxis14.valueToJava2D(0.0d, rectangle2D54, rectangleEdge65);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets11.createInsetRectangle(rectangle2D54);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity71 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D68, "java.awt.Color[r=255,g=0,b=0]", "Layer.FOREGROUND");
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation72, plotOrientation73);
        java.util.List list75 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D68, rectangleEdge74);
        categoryAxis0.setUpperMargin((double) 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(shapeArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(list75);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Color color13 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke15);
        java.awt.Paint paint17 = valueMarker16.getLabelPaint();
        valueMarker16.setAlpha(0.5f);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str21 = layer20.toString();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer20);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot11.getColumnRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot11.zoomDomainAxes((-0.7853981633974483d), (double) 8, plotRenderingInfo26, point2D27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot11.getDomainAxis((int) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot11.getDomainAxis();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Layer.FOREGROUND" + "'", str21.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNull(categoryAxis31);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.Color color2 = java.awt.Color.getColor("LegendItemEntity: seriesKey=null, dataset=null", color1);
        java.awt.Stroke stroke3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double6 = rectangleInsets4.calculateLeftOutset((double) 0L);
        try {
            org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color2, stroke3, rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        boolean boolean6 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setPositiveArrowVisible(false);
        double double9 = numberAxis0.getLowerBound();
        boolean boolean10 = numberAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke9);
        java.awt.Paint paint11 = valueMarker10.getLabelPaint();
        barRenderer0.setSeriesOutlinePaint((int) (short) 0, paint11, true);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke(0, stroke15, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = barRenderer0.getURLGenerator((int) (byte) 10, 0);
        java.awt.Stroke stroke22 = barRenderer0.lookupSeriesStroke((int) '#');
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendGraphic6.getShapeAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Stroke stroke22 = lineBorder21.getStroke();
        valueMarker10.setOutlineStroke(stroke22);
        legendGraphic6.setOutlineStroke(stroke22);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.awt.Font font7 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font7);
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("rect", font7);
        numberAxis0.setTickLabelFont(font7);
        boolean boolean11 = numberAxis0.isInverted();
        boolean boolean12 = numberAxis0.isNegativeArrowVisible();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke14 = lineBorder13.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder13.getInsets();
        numberAxis0.setTickLabelInsets(rectangleInsets15);
        java.awt.Paint paint17 = numberAxis0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        java.awt.Paint paint11 = barRenderer0.getSeriesPaint((int) (byte) 100);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer13 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType14 = standardGradientPaintTransformer13.getType();
        boolean boolean15 = itemLabelAnchor12.equals((java.lang.Object) standardGradientPaintTransformer13);
        java.lang.Object obj16 = standardGradientPaintTransformer13.clone();
        barRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer13);
        java.awt.Font font18 = barRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(gradientPaintTransformType14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.awt.Paint paint14 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getRight();
        legendTitle1.setItemLabelPadding(rectangleInsets15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str20 = rectangleAnchor19.toString();
        legendTitle1.setLegendItemGraphicLocation(rectangleAnchor19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment26, verticalAlignment27, (double) (short) 100, (double) (-1));
        flowArrangement30.clear();
        org.jfree.data.general.Dataset dataset32 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement30, dataset32, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer34.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer34.setHeight((double) (byte) 1);
        java.util.List list42 = legendItemBlockContainer34.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = legendItemBlockContainer34.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double46 = rectangleInsets44.calculateTopOutset((double) (short) 10);
        double double47 = rectangleInsets44.getLeft();
        double double49 = rectangleInsets44.trimWidth(0.0d);
        legendItemBlockContainer34.setMargin(rectangleInsets44);
        java.awt.geom.Rectangle2D rectangle2D51 = legendItemBlockContainer34.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double53 = numberAxis22.valueToJava2D((double) 1.0f, rectangle2D51, rectangleEdge52);
        java.lang.String str54 = rectangleEdge52.toString();
        legendTitle1.setLegendItemGraphicEdge(rectangleEdge52);
        java.lang.String str56 = legendTitle1.getID();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleAnchor.RIGHT" + "'", str20.equals("RectangleAnchor.RIGHT"));
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "RectangleEdge.RIGHT" + "'", str54.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNull(str56);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke9);
        java.awt.Paint paint11 = valueMarker10.getLabelPaint();
        barRenderer0.setSeriesOutlinePaint((int) (short) 0, paint11, true);
        java.awt.Paint paint16 = barRenderer0.getItemLabelPaint(1, (int) '#');
        boolean boolean17 = barRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "TextBlockAnchor.CENTER_LEFT");
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 128);
        try {
            java.lang.Number number7 = defaultStatisticalCategoryDataset0.getStdDevValue((int) (short) 10, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Paint paint2 = valueMarker1.getPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot11.getDomainAxisEdge();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot11.getLegendItems();
        categoryPlot11.configureDomainAxes();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint3 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        try {
            barRenderer0.setSeriesPaint((int) (short) -1, paint3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean2 = axisSpace0.equals((java.lang.Object) shapeArray1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        axisSpace0.add((double) 10, rectangleEdge5);
        axisSpace0.setRight((double) 10.0f);
        org.junit.Assert.assertNotNull(shapeArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke9);
        java.awt.Paint paint11 = valueMarker10.getLabelPaint();
        barRenderer0.setSeriesOutlinePaint((int) (short) 0, paint11, true);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        boolean boolean15 = barRenderer0.equals((java.lang.Object) color14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer2.getPositiveItemLabelPositionFallback();
        barRenderer2.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer2.getBasePositiveItemLabelPosition();
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition6);
        int int8 = barRenderer0.getRowCount();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean12 = numberAxis11.isTickLabelsVisible();
        numberAxis11.setLabelToolTip("rect");
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean17 = axisSpace15.equals((java.lang.Object) shapeArray16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge19);
        axisSpace15.add((double) 10, rectangleEdge20);
        axisSpace15.setTop((double) '4');
        java.lang.Object obj24 = axisSpace15.clone();
        java.lang.String str25 = axisSpace15.toString();
        java.awt.Font font27 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color28 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("", font27, (java.awt.Paint) color28);
        java.lang.String str30 = textFragment29.getText();
        java.awt.Paint paint31 = textFragment29.getPaint();
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke33 = lineBorder32.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets34.getRight();
        org.jfree.chart.block.LineBorder lineBorder36 = new org.jfree.chart.block.LineBorder(paint31, stroke33, rectangleInsets34);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement41 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment37, verticalAlignment38, (double) (short) 100, (double) (-1));
        flowArrangement41.clear();
        org.jfree.data.general.Dataset dataset43 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer45 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement41, dataset43, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer45.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer45.setHeight((double) (byte) 1);
        java.util.List list53 = legendItemBlockContainer45.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets54 = legendItemBlockContainer45.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double57 = rectangleInsets55.calculateTopOutset((double) (short) 10);
        double double58 = rectangleInsets55.getLeft();
        double double60 = rectangleInsets55.trimWidth(0.0d);
        legendItemBlockContainer45.setMargin(rectangleInsets55);
        java.awt.geom.Rectangle2D rectangle2D62 = legendItemBlockContainer45.getBounds();
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets34.createInsetRectangle(rectangle2D62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge64);
        java.awt.geom.Rectangle2D rectangle2D66 = axisSpace15.reserved(rectangle2D62, rectangleEdge64);
        barRenderer0.drawRangeGridline(graphics2D9, categoryPlot10, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D66, Double.NaN);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNotNull(rectangleInsets54);
        org.junit.Assert.assertNotNull(rectangleInsets55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertNotNull(rectangle2D66);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "", jFreeChart3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent4.getType();
        org.jfree.chart.JFreeChart jFreeChart6 = chartChangeEvent4.getChart();
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker4.getLabelOffsetType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double9 = defaultStatisticalCategoryDataset7.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean12 = numberAxis11.isTickLabelsVisible();
        boolean boolean13 = numberAxis11.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat14 = null;
        numberAxis11.setNumberFormatOverride(numberFormat14);
        boolean boolean16 = numberAxis11.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str21 = layer20.toString();
        java.util.Collection collection22 = categoryPlot18.getDomainMarkers(0, layer20);
        categoryPlot18.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot25 = categoryPlot18.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot18.setDomainAxisLocation(500, axisLocation27, true);
        valueMarker4.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot18);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Layer.FOREGROUND" + "'", str21.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(axisLocation27);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (short) 1, (java.lang.Number) (-1L), (java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) 10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) (short) 100, (double) (-1));
        boolean boolean13 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) horizontalAlignment8);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset14 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset14, true);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener21 = null;
        boolean boolean22 = numberAxis20.hasListener(eventListener21);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity24 = new org.jfree.chart.entity.LegendItemEntity(shape23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, rectangleAnchor25, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity31 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis20, shape28, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D32 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit34 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D32.removeColumn((java.lang.Comparable) numberTickUnit34);
        numberAxis20.setTickUnit(numberTickUnit34);
        defaultStatisticalCategoryDataset14.add(100.0d, (double) 10.0f, (java.lang.Comparable) 1.0f, (java.lang.Comparable) numberTickUnit34);
        java.lang.Number number39 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) numberTickUnit34, (java.lang.Comparable) 100.0f);
        org.jfree.data.KeyToGroupMap keyToGroupMap40 = null;
        try {
            org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, keyToGroupMap40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(number39);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) 10);
        org.jfree.data.Range range5 = null;
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude(range5, (double) 10.0f);
        double double9 = range7.constrain((double) 100);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range7, (double) (byte) 10, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint4.toRangeHeight(range12);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType14 = rectangleConstraint13.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNotNull(lengthConstraintType14);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        double double6 = barRenderer0.getLowerClip();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = barRenderer0.getPlot();
        barRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(categoryPlot8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int3 = java.awt.Color.HSBtoRGB((float) '4', (float) 0, (float) 500);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-500) + "'", int3 == (-500));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        boolean boolean6 = numberAxis0.getAutoRangeIncludesZero();
        numberAxis0.setPositiveArrowVisible(false);
        try {
            numberAxis0.setRange((double) 100L, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = barRenderer0.getLegendItemToolTipGenerator();
        boolean boolean6 = barRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        barRenderer0.setBasePaint(paint14);
        java.awt.Color color17 = java.awt.Color.RED;
        java.lang.String str18 = color17.toString();
        int int19 = color17.getBlue();
        int int20 = color17.getTransparency();
        barRenderer0.setSeriesPaint(2, (java.awt.Paint) color17, false);
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesFillPaint();
        java.awt.Paint paint25 = barRenderer0.getSeriesItemLabelPaint(1);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str18.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        numberAxis0.setLabelToolTip("rect");
        numberAxis0.resizeRange((double) (short) 0);
        numberAxis0.setInverted(false);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis0.setNumberFormatOverride(numberFormat8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int3 = java.awt.Color.HSBtoRGB((-1.0f), (float) '4', (float) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-13434931) + "'", int3 == (-13434931));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str16 = layer15.toString();
        java.util.Collection collection17 = categoryPlot13.getDomainMarkers(0, layer15);
        categoryPlot13.clearRangeAxes();
        categoryPlot13.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint21 = categoryPlot13.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = categoryPlot13.getDatasetRenderingOrder();
        java.awt.Color color23 = java.awt.Color.lightGray;
        categoryPlot13.setOutlinePaint((java.awt.Paint) color23);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        java.awt.Paint paint26 = categoryPlot13.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Layer.FOREGROUND" + "'", str16.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        org.jfree.chart.plot.Plot plot41 = jFreeChart39.getPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        try {
            jFreeChart39.handleClick(500, (int) (byte) 0, chartRenderingInfo44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertNotNull(plot41);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setHeight((double) (byte) 1);
        org.jfree.chart.util.BooleanList booleanList16 = new org.jfree.chart.util.BooleanList();
        boolean boolean17 = legendItemBlockContainer8.equals((java.lang.Object) booleanList16);
        java.lang.Boolean boolean19 = booleanList16.getBoolean((int) (byte) 100);
        org.jfree.chart.axis.AxisSpace axisSpace20 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray21 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean22 = axisSpace20.equals((java.lang.Object) shapeArray21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge24);
        axisSpace20.add((double) 10, rectangleEdge25);
        boolean boolean27 = booleanList16.equals((java.lang.Object) axisSpace20);
        try {
            booleanList16.setBoolean((-13434931), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertNotNull(shapeArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=255,g=0,b=0]", "", "", "{0}");
        basicProjectInfo4.addOptionalLibrary("java.awt.Color[r=192,g=192,b=192]");
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double[] doubleArray10 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "hi!", doubleArray11);
        org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset13, (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(pieDataset15);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) 'a');
        java.util.List list4 = keyedObjects0.getKeys();
        int int6 = keyedObjects0.getIndex((java.lang.Comparable) false);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 128, (double) ' ', 2.0d, 500.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        barRenderer0.setBase((double) (-20561));
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double6 = defaultStatisticalCategoryDataset4.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean9 = numberAxis8.isTickLabelsVisible();
        boolean boolean10 = numberAxis8.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat11 = null;
        numberAxis8.setNumberFormatOverride(numberFormat11);
        boolean boolean13 = numberAxis8.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset4, categoryAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer14);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str18 = layer17.toString();
        java.util.Collection collection19 = categoryPlot15.getDomainMarkers(0, layer17);
        categoryPlot15.clearRangeAxes();
        categoryPlot15.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint23 = categoryPlot15.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = categoryPlot15.getDatasetRenderingOrder();
        java.awt.Color color25 = java.awt.Color.lightGray;
        categoryPlot15.setOutlinePaint((java.awt.Paint) color25);
        boolean boolean27 = barRenderer0.hasListener((java.util.EventListener) categoryPlot15);
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Layer.FOREGROUND" + "'", str18.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape9, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color22);
        org.jfree.data.general.Dataset dataset24 = legendItem23.getDataset();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj26 = standardGradientPaintTransformer25.clone();
        java.lang.Object obj27 = standardGradientPaintTransformer25.clone();
        legendItem23.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        java.awt.Stroke stroke29 = legendItem23.getLineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(dataset24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke1 = lineBorder0.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        numberAxis3.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (short) 100, (double) (-1));
        flowArrangement11.clear();
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11, dataset13, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer15.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer15.setHeight((double) (byte) 1);
        java.util.List list23 = legendItemBlockContainer15.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendItemBlockContainer15.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets25.calculateTopOutset((double) (short) 10);
        double double28 = rectangleInsets25.getLeft();
        double double30 = rectangleInsets25.trimWidth(0.0d);
        legendItemBlockContainer15.setMargin(rectangleInsets25);
        java.awt.geom.Rectangle2D rectangle2D32 = legendItemBlockContainer15.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double34 = numberAxis3.valueToJava2D((double) 1.0f, rectangle2D32, rectangleEdge33);
        java.awt.geom.Rectangle2D rectangle2D37 = rectangleInsets2.createOutsetRectangle(rectangle2D32, false, false);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset40 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset40, true);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener47 = null;
        boolean boolean48 = numberAxis46.hasListener(eventListener47);
        java.awt.Shape shape49 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity50 = new org.jfree.chart.entity.LegendItemEntity(shape49);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape49, rectangleAnchor51, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity57 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis46, shape54, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D58 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit60 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D58.removeColumn((java.lang.Comparable) numberTickUnit60);
        numberAxis46.setTickUnit(numberTickUnit60);
        defaultStatisticalCategoryDataset40.add(100.0d, (double) 10.0f, (java.lang.Comparable) 1.0f, (java.lang.Comparable) numberTickUnit60);
        double double65 = defaultStatisticalCategoryDataset40.getRangeLowerBound(true);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity68 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape) rectangle2D37, "44,96,52,96,52,104,44,104,44,96,44,96", "LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset40, (java.lang.Comparable) 100L, (java.lang.Comparable) 0.5f);
        org.jfree.data.category.CategoryDataset categoryDataset69 = null;
        try {
            categoryItemEntity68.setDataset(categoryDataset69);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D37);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 100.0d + "'", double65 == 100.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.awt.Paint paint14 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getRight();
        legendTitle1.setItemLabelPadding(rectangleInsets15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = legendTitle1.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        boolean boolean11 = barRenderer0.isSeriesItemLabelsVisible(8);
        boolean boolean12 = barRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        java.lang.String str5 = numberAxis0.getLabelToolTip();
        java.awt.Stroke stroke6 = numberAxis0.getTickMarkStroke();
        numberAxis0.setLabelAngle((double) 0);
        numberAxis0.setLabelToolTip("RectangleEdge.RIGHT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.lang.String str2 = textTitle1.getToolTipText();
        java.awt.Font font3 = textTitle1.getFont();
        java.lang.String str4 = textTitle1.getURLText();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("", font2);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("rect", font2);
        java.awt.Font font6 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color7 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("", font6, (java.awt.Paint) color7);
        textLine4.removeFragment(textFragment8);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.awt.Paint paint14 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getRight();
        legendTitle1.setItemLabelPadding(rectangleInsets15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.title.Title title19 = titleChangeEvent18.getTitle();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = title19.getPosition();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener22 = null;
        boolean boolean23 = numberAxis21.hasListener(eventListener22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis21.setTickLabelPaint((java.awt.Paint) color24);
        boolean boolean26 = numberAxis21.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand27 = null;
        numberAxis21.setMarkerBand(markerAxisBand27);
        java.awt.Shape shape29 = numberAxis21.getDownArrow();
        java.lang.Object obj30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) numberAxis21);
        boolean boolean31 = rectangleEdge20.equals((java.lang.Object) numberAxis21);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = numberAxis21.getTickLabelInsets();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(title19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(true);
        double double3 = numberAxis0.getFixedDimension();
        boolean boolean4 = numberAxis0.isAutoRange();
        numberAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 10, 0.5f, (float) (short) -1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 0L);
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot11.getRangeAxisForDataset(10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setVerticalTickLabels(false);
        org.jfree.data.Range range21 = categoryPlot11.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer22.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke25 = null;
        barRenderer22.setSeriesOutlineStroke((int) (byte) 0, stroke25, true);
        barRenderer22.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        java.awt.Paint paint33 = barRenderer22.getSeriesPaint((int) (byte) 100);
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity35 = new org.jfree.chart.entity.LegendItemEntity(shape34);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape34, rectangleAnchor36, (double) '4', (double) (byte) 100);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.clone(shape39);
        barRenderer22.setBaseShape(shape40);
        java.awt.Stroke stroke43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer22.setSeriesOutlineStroke((int) (short) 10, stroke43, true);
        categoryPlot11.setRangeCrosshairStroke(stroke43);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color12 = java.awt.Color.lightGray;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("MAJOR", "Layer.FOREGROUND", "", "LengthConstraintType.NONE", shape4, (java.awt.Paint) color10, stroke11, (java.awt.Paint) color12);
        int int14 = color12.getAlpha();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = null;
        numberAxis0.setMarkerBand(markerAxisBand1);
        java.awt.Shape shape3 = numberAxis0.getDownArrow();
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        jFreeChart39.fireChartChanged();
        int int42 = jFreeChart39.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 15 + "'", int42 == 15);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) 'a');
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D4.removeColumn((java.lang.Comparable) numberTickUnit6);
        int int8 = numberTickUnit6.getMinorTickCount();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) int8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape2 = barRenderer0.lookupSeriesShape((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (byte) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer5.getBasePositiveItemLabelPosition();
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition6, true);
        java.awt.Color color10 = java.awt.Color.yellow;
        try {
            barRenderer0.setSeriesPaint((-13434931), (java.awt.Paint) color10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Color color13 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke15);
        java.awt.Paint paint17 = valueMarker16.getLabelPaint();
        valueMarker16.setAlpha(0.5f);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str21 = layer20.toString();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer20);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot11.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot11.getDomainAxisLocation();
        boolean boolean25 = categoryPlot11.isDomainGridlinesVisible();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Layer.FOREGROUND" + "'", str21.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 0.5f, Double.NaN);
        java.lang.String str5 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "HorizontalAlignment.CENTER" + "'", str5.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("LengthConstraintType.NONE");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        float float7 = textFragment5.getBaselineOffset();
        java.awt.Font font8 = textFragment5.getFont();
        labelBlock1.setFont(font8);
        java.lang.String str10 = labelBlock1.getID();
        double double11 = labelBlock1.getContentXOffset();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.Color color13 = java.awt.Color.magenta;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        org.jfree.chart.ChartColor chartColor19 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel20 = null;
        java.awt.Rectangle rectangle21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment27 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement30 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment26, verticalAlignment27, (double) (short) 100, (double) (-1));
        flowArrangement30.clear();
        org.jfree.data.general.Dataset dataset32 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement30, dataset32, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer34.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer34.setHeight((double) (byte) 1);
        java.util.List list42 = legendItemBlockContainer34.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = legendItemBlockContainer34.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double46 = rectangleInsets44.calculateTopOutset((double) (short) 10);
        double double47 = rectangleInsets44.getLeft();
        double double49 = rectangleInsets44.trimWidth(0.0d);
        legendItemBlockContainer34.setMargin(rectangleInsets44);
        java.awt.geom.Rectangle2D rectangle2D51 = legendItemBlockContainer34.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double53 = numberAxis22.valueToJava2D((double) 1.0f, rectangle2D51, rectangleEdge52);
        java.awt.geom.AffineTransform affineTransform54 = null;
        java.awt.RenderingHints renderingHints55 = null;
        java.awt.PaintContext paintContext56 = chartColor19.createContext(colorModel20, rectangle21, rectangle2D51, affineTransform54, renderingHints55);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity59 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D51, "", "0");
        java.awt.geom.AffineTransform affineTransform60 = null;
        java.awt.RenderingHints renderingHints61 = null;
        java.awt.PaintContext paintContext62 = color13.createContext(colorModel14, rectangle15, rectangle2D51, affineTransform60, renderingHints61);
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener64 = null;
        boolean boolean65 = numberAxis63.hasListener(eventListener64);
        java.awt.Color color66 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis63.setTickLabelPaint((java.awt.Paint) color66);
        java.lang.String str68 = numberAxis63.getLabelToolTip();
        java.awt.Shape shape69 = numberAxis63.getUpArrow();
        java.awt.Paint paint70 = numberAxis63.getTickLabelPaint();
        try {
            java.lang.Object obj71 = labelBlock1.draw(graphics2D12, rectangle2D51, (java.lang.Object) paint70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext56);
        org.junit.Assert.assertNotNull(paintContext62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(paint70);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        float[] floatArray6 = new float[] { 10, (byte) 10, 1.0f };
        try {
            float[] floatArray7 = color1.getRGBComponents(floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis0.setMarkerBand(markerAxisBand6);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis0.setNumberFormatOverride(numberFormat8);
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 10.0f);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range12, 0.0d, true);
        org.jfree.data.Range range18 = org.jfree.data.Range.shift(range12, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke20 = lineBorder19.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = lineBorder19.getInsets();
        boolean boolean22 = range12.equals((java.lang.Object) lineBorder19);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range12, 0.0d, false);
        numberAxis0.setRange(range12, false, false);
        numberAxis0.setRangeAboutValue((double) 1.0f, (double) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        java.awt.Paint paint11 = barRenderer0.getSeriesPaint((int) (byte) 100);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity13 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, rectangleAnchor14, (double) '4', (double) (byte) 100);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        boolean boolean21 = barRenderer0.isSeriesVisibleInLegend((int) '4');
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        boolean boolean26 = barRenderer0.isSeriesVisibleInLegend((int) (byte) -1);
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) '4');
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtRight();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = numberAxis2.hasListener(eventListener3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis2.setTickLabelPaint((java.awt.Paint) color5);
        boolean boolean7 = numberAxis2.isAxisLineVisible();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis2.setMarkerBand(markerAxisBand8);
        java.awt.Shape shape10 = numberAxis2.getDownArrow();
        org.jfree.chart.axis.AxisCollection axisCollection11 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean13 = numberAxis12.isTickLabelsVisible();
        numberAxis12.setNegativeArrowVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = categoryLabelPositions16.getLabelPosition(rectangleEdge17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = categoryLabelPositions16.getLabelPosition(rectangleEdge19);
        axisCollection11.add((org.jfree.chart.axis.Axis) numberAxis12, rectangleEdge19);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge19);
        try {
            numberAxis2.setRange((double) (byte) 1, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNull(categoryLabelPosition18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(categoryLabelPosition20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        barRenderer0.setBasePaint(paint14);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Font font17 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        barRenderer0.setBaseItemLabelFont(font17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = barRenderer0.getPlot();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNull(categoryPlot19);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Stroke stroke3 = null;
        barRenderer0.setSeriesOutlineStroke((int) (byte) 0, stroke3, true);
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        java.awt.Paint paint11 = barRenderer0.getSeriesPaint((int) (byte) 100);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity13 = new org.jfree.chart.entity.LegendItemEntity(shape12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, rectangleAnchor14, (double) '4', (double) (byte) 100);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.clone(shape17);
        barRenderer0.setBaseShape(shape18);
        boolean boolean21 = barRenderer0.isSeriesVisibleInLegend((int) '4');
        java.awt.Paint paint23 = barRenderer0.getSeriesOutlinePaint(0);
        barRenderer0.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNotNull(itemLabelPosition1);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor7 = categoryLabelPosition6.getRotationAnchor();
        try {
            java.awt.Shape shape8 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("LengthConstraintType.NONE", graphics2D1, (float) 1L, (float) (short) 100, textAnchor4, 1.0d, textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (short) 1, (java.lang.Number) (-1L), (java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) 10);
        try {
            java.lang.Number number10 = defaultStatisticalCategoryDataset0.getValue((-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        double double5 = axisSpace4.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge7);
        axisSpace4.add((double) 100.0f, rectangleEdge8);
        axisState2.moveCursor((double) (short) 100, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double13 = rectangleInsets11.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean15 = numberAxis14.isTickLabelsVisible();
        numberAxis14.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor22 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel23 = null;
        java.awt.Rectangle rectangle24 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        numberAxis25.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, (double) (short) 100, (double) (-1));
        flowArrangement33.clear();
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33, dataset35, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer37.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer37.setHeight((double) (byte) 1);
        java.util.List list45 = legendItemBlockContainer37.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = legendItemBlockContainer37.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) 10);
        double double50 = rectangleInsets47.getLeft();
        double double52 = rectangleInsets47.trimWidth(0.0d);
        legendItemBlockContainer37.setMargin(rectangleInsets47);
        java.awt.geom.Rectangle2D rectangle2D54 = legendItemBlockContainer37.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double56 = numberAxis25.valueToJava2D((double) 1.0f, rectangle2D54, rectangleEdge55);
        java.awt.geom.AffineTransform affineTransform57 = null;
        java.awt.RenderingHints renderingHints58 = null;
        java.awt.PaintContext paintContext59 = chartColor22.createContext(colorModel23, rectangle24, rectangle2D54, affineTransform57, renderingHints58);
        org.jfree.chart.axis.AxisSpace axisSpace60 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray61 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean62 = axisSpace60.equals((java.lang.Object) shapeArray61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge64);
        axisSpace60.add((double) 10, rectangleEdge65);
        double double67 = numberAxis14.valueToJava2D(0.0d, rectangle2D54, rectangleEdge65);
        java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets11.createInsetRectangle(rectangle2D54);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity71 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D68, "java.awt.Color[r=255,g=0,b=0]", "Layer.FOREGROUND");
        org.jfree.chart.axis.AxisLocation axisLocation72 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation72, plotOrientation73);
        java.util.List list75 = categoryAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D68, rectangleEdge74);
        categoryAxis0.setCategoryMargin((double) (byte) 0);
        categoryAxis0.setLowerMargin((double) (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext59);
        org.junit.Assert.assertNotNull(shapeArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D68);
        org.junit.Assert.assertNotNull(axisLocation72);
        org.junit.Assert.assertNotNull(plotOrientation73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(list75);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        jFreeChart39.fireChartChanged();
        boolean boolean42 = jFreeChart39.isBorderVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        barRenderer0.setBasePaint(paint14);
        java.awt.Color color17 = java.awt.Color.RED;
        java.lang.String str18 = color17.toString();
        int int19 = color17.getBlue();
        int int20 = color17.getTransparency();
        barRenderer0.setSeriesPaint(2, (java.awt.Paint) color17, false);
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesFillPaint();
        boolean boolean24 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str18.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Color color0 = java.awt.Color.pink;
        int int1 = color0.getRGB();
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent5 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color0, jFreeChart2, 100, (int) (byte) 1);
        chartProgressEvent5.setType((int) (short) 100);
        int int8 = chartProgressEvent5.getType();
        int int9 = chartProgressEvent5.getType();
        int int10 = chartProgressEvent5.getType();
        java.lang.Object obj11 = chartProgressEvent5.getSource();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-20561) + "'", int1 == (-20561));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        int int4 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) "0");
        double[] doubleArray15 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray16 = new double[][] { doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "hi!", doubleArray16);
        boolean boolean19 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) categoryDataset18);
        org.jfree.data.general.DatasetGroup datasetGroup20 = defaultStatisticalCategoryDataset0.getGroup();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 52.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(datasetGroup20);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean8 = textFragment5.equals((java.lang.Object) font7);
        numberAxis0.setTickLabelFont(font7);
        java.awt.Paint paint10 = numberAxis0.getTickLabelPaint();
        java.awt.Shape shape11 = numberAxis0.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot11.getLegendItems();
        java.util.Iterator iterator18 = legendItemCollection17.iterator();
        java.util.Iterator iterator19 = legendItemCollection17.iterator();
        java.util.Iterator iterator20 = legendItemCollection17.iterator();
        int int21 = legendItemCollection17.getItemCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(iterator18);
        org.junit.Assert.assertNotNull(iterator19);
        org.junit.Assert.assertNotNull(iterator20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleInsets0.equals(obj1);
        double double4 = rectangleInsets0.calculateLeftInset((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        jFreeChart39.setTextAntiAlias(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener43 = null;
        jFreeChart39.removeProgressListener(chartProgressListener43);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        java.lang.String str5 = numberTickUnit2.valueToString((double) 0);
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 10.0f);
        org.jfree.data.Range range11 = org.jfree.data.Range.shift(range8, 0.0d, true);
        org.jfree.data.Range range14 = org.jfree.data.Range.shift(range8, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke16 = lineBorder15.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = lineBorder15.getInsets();
        boolean boolean18 = range8.equals((java.lang.Object) lineBorder15);
        org.jfree.data.Range range21 = org.jfree.data.Range.shift(range8, 0.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range8, 3.0d);
        boolean boolean24 = numberTickUnit2.equals((java.lang.Object) range8);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockParams blockParams1 = new org.jfree.chart.block.BlockParams();
        boolean boolean2 = flowArrangement0.equals((java.lang.Object) blockParams1);
        java.awt.Color color6 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke8 = lineBorder7.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke8);
        java.awt.Paint paint10 = valueMarker9.getLabelPaint();
        valueMarker9.setAlpha(0.5f);
        double double13 = valueMarker9.getValue();
        java.awt.Font font15 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("", font15);
        valueMarker9.setLabelFont(font15);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font15);
        java.awt.Font font19 = textFragment18.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double22 = defaultStatisticalCategoryDataset20.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean25 = numberAxis24.isTickLabelsVisible();
        boolean boolean26 = numberAxis24.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat27 = null;
        numberAxis24.setNumberFormatOverride(numberFormat27);
        boolean boolean29 = numberAxis24.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20, categoryAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer30);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str34 = layer33.toString();
        java.util.Collection collection35 = categoryPlot31.getDomainMarkers(0, layer33);
        categoryPlot31.clearRangeAxes();
        categoryPlot31.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint39 = categoryPlot31.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder40 = categoryPlot31.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart42 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font19, (org.jfree.chart.plot.Plot) categoryPlot31, true);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle("ThreadContext");
        jFreeChart42.setTitle(textTitle44);
        textTitle44.setText("ThreadContext");
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.ChartColor chartColor52 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel53 = null;
        java.awt.Rectangle rectangle54 = null;
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis();
        numberAxis55.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment59 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment60 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement63 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment59, verticalAlignment60, (double) (short) 100, (double) (-1));
        flowArrangement63.clear();
        org.jfree.data.general.Dataset dataset65 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer67 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement63, dataset65, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer67.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer67.setHeight((double) (byte) 1);
        java.util.List list75 = legendItemBlockContainer67.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = legendItemBlockContainer67.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double79 = rectangleInsets77.calculateTopOutset((double) (short) 10);
        double double80 = rectangleInsets77.getLeft();
        double double82 = rectangleInsets77.trimWidth(0.0d);
        legendItemBlockContainer67.setMargin(rectangleInsets77);
        java.awt.geom.Rectangle2D rectangle2D84 = legendItemBlockContainer67.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double86 = numberAxis55.valueToJava2D((double) 1.0f, rectangle2D84, rectangleEdge85);
        java.awt.geom.AffineTransform affineTransform87 = null;
        java.awt.RenderingHints renderingHints88 = null;
        java.awt.PaintContext paintContext89 = chartColor52.createContext(colorModel53, rectangle54, rectangle2D84, affineTransform87, renderingHints88);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity92 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D84, "", "0");
        org.jfree.data.RangeType rangeType93 = org.jfree.data.RangeType.FULL;
        java.lang.String str94 = rangeType93.toString();
        java.lang.Object obj95 = textTitle44.draw(graphics2D48, rectangle2D84, (java.lang.Object) rangeType93);
        flowArrangement0.add((org.jfree.chart.block.Block) textTitle44, (java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Layer.FOREGROUND" + "'", str34.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(datasetRenderingOrder40);
        org.junit.Assert.assertNotNull(horizontalAlignment59);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(rectangleInsets77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext89);
        org.junit.Assert.assertNotNull(rangeType93);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "RangeType.FULL" + "'", str94.equals("RangeType.FULL"));
        org.junit.Assert.assertNull(obj95);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.awt.Color color1 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder2 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke3 = lineBorder2.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        java.awt.Paint paint5 = valueMarker4.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = valueMarker4.getLabelOffsetType();
        org.jfree.data.KeyedObjects2D keyedObjects2D7 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D7.removeColumn((java.lang.Comparable) numberTickUnit9);
        java.lang.Object obj11 = null;
        keyedObjects2D7.addObject(obj11, (java.lang.Comparable) 8, (java.lang.Comparable) "ThreadContext");
        boolean boolean15 = lengthAdjustmentType6.equals((java.lang.Object) "ThreadContext");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean4 = numberAxis3.isTickLabelsVisible();
        numberAxis3.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor11 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel12 = null;
        java.awt.Rectangle rectangle13 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        numberAxis14.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment19, (double) (short) 100, (double) (-1));
        flowArrangement22.clear();
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22, dataset24, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer26.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer26.setHeight((double) (byte) 1);
        java.util.List list34 = legendItemBlockContainer26.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = legendItemBlockContainer26.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateTopOutset((double) (short) 10);
        double double39 = rectangleInsets36.getLeft();
        double double41 = rectangleInsets36.trimWidth(0.0d);
        legendItemBlockContainer26.setMargin(rectangleInsets36);
        java.awt.geom.Rectangle2D rectangle2D43 = legendItemBlockContainer26.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double45 = numberAxis14.valueToJava2D((double) 1.0f, rectangle2D43, rectangleEdge44);
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = chartColor11.createContext(colorModel12, rectangle13, rectangle2D43, affineTransform46, renderingHints47);
        org.jfree.chart.axis.AxisSpace axisSpace49 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray50 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean51 = axisSpace49.equals((java.lang.Object) shapeArray50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        axisSpace49.add((double) 10, rectangleEdge54);
        double double56 = numberAxis3.valueToJava2D(0.0d, rectangle2D43, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets0.createInsetRectangle(rectangle2D43);
        org.jfree.chart.util.UnitType unitType58 = rectangleInsets0.getUnitType();
        double double60 = rectangleInsets0.calculateBottomInset((double) (byte) 1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
        org.junit.Assert.assertNotNull(list34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext48);
        org.junit.Assert.assertNotNull(shapeArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(unitType58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder8.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double42 = numberAxis11.valueToJava2D((double) 1.0f, rectangle2D40, rectangleEdge41);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets10.createOutsetRectangle(rectangle2D40, false, false);
        legendGraphic6.setLine((java.awt.Shape) rectangle2D45);
        java.lang.Object obj47 = legendGraphic6.clone();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener49 = null;
        boolean boolean50 = numberAxis48.hasListener(eventListener49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis48.setTickLabelPaint((java.awt.Paint) color51);
        boolean boolean53 = numberAxis48.isAxisLineVisible();
        boolean boolean54 = numberAxis48.getAutoRangeIncludesZero();
        numberAxis48.setPositiveArrowVisible(false);
        boolean boolean57 = legendGraphic6.equals((java.lang.Object) numberAxis48);
        java.awt.Stroke stroke58 = legendGraphic6.getLineStroke();
        java.awt.Color color59 = java.awt.Color.pink;
        int int60 = color59.getRGB();
        legendGraphic6.setOutlinePaint((java.awt.Paint) color59);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(stroke58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-20561) + "'", int60 == (-20561));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        org.jfree.chart.ui.Library[] libraryArray5 = basicProjectInfo4.getOptionalLibraries();
        basicProjectInfo4.setCopyright("{0}");
        basicProjectInfo4.setCopyright("RectangleEdge.RIGHT");
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot18 = categoryPlot11.getParent();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset19, true);
        int int22 = defaultStatisticalCategoryDataset19.getRowCount();
        java.lang.Number number23 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot11.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset19);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertNull(categoryItemRenderer24);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder8.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double42 = numberAxis11.valueToJava2D((double) 1.0f, rectangle2D40, rectangleEdge41);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets10.createOutsetRectangle(rectangle2D40, false, false);
        legendGraphic6.setLine((java.awt.Shape) rectangle2D45);
        java.lang.Object obj47 = legendGraphic6.clone();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener49 = null;
        boolean boolean50 = numberAxis48.hasListener(eventListener49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis48.setTickLabelPaint((java.awt.Paint) color51);
        boolean boolean53 = numberAxis48.isAxisLineVisible();
        boolean boolean54 = numberAxis48.getAutoRangeIncludesZero();
        numberAxis48.setPositiveArrowVisible(false);
        boolean boolean57 = legendGraphic6.equals((java.lang.Object) numberAxis48);
        java.awt.Stroke stroke58 = legendGraphic6.getLineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor59 = legendGraphic6.getShapeAnchor();
        legendGraphic6.setLineVisible(false);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(stroke58);
        org.junit.Assert.assertNotNull(rectangleAnchor59);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getPosition();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        legendTitle1.setNotify(true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) (short) 100, (double) (-1));
        flowArrangement7.clear();
        org.jfree.data.general.Dataset dataset9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement7, dataset9, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer11.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer11.setHeight((double) (byte) 1);
        java.util.List list19 = legendItemBlockContainer11.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendItemBlockContainer11.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateTopOutset((double) (short) 10);
        double double24 = rectangleInsets21.getLeft();
        double double26 = rectangleInsets21.trimWidth(0.0d);
        legendItemBlockContainer11.setMargin(rectangleInsets21);
        java.awt.geom.Rectangle2D rectangle2D28 = legendItemBlockContainer11.getBounds();
        boolean boolean29 = categoryLabelPositions2.equals((java.lang.Object) legendItemBlockContainer11);
        org.jfree.data.general.Dataset dataset30 = legendItemBlockContainer11.getDataset();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(dataset30);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean7 = basicProjectInfo5.equals((java.lang.Object) (short) -1);
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo5.getOptionalLibraries();
        boolean boolean9 = borderArrangement0.equals((java.lang.Object) libraryArray8);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("LengthConstraintType.NONE");
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color14 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("", font13, (java.awt.Paint) color14);
        java.lang.String str16 = textFragment15.getText();
        float float17 = textFragment15.getBaselineOffset();
        java.awt.Font font18 = textFragment15.getFont();
        labelBlock11.setFont(font18);
        java.lang.String str20 = labelBlock11.getID();
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = valueMarker22.getLabelOffsetType();
        try {
            borderArrangement0.add((org.jfree.chart.block.Block) labelBlock11, (java.lang.Object) lengthAdjustmentType23);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.util.LengthAdjustmentType cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(libraryArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment4, verticalAlignment5, (double) (short) 100, (double) (-1));
        flowArrangement8.clear();
        org.jfree.data.general.Dataset dataset10 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, dataset10, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer12.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer12.setHeight((double) (byte) 1);
        java.util.List list20 = legendItemBlockContainer12.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = legendItemBlockContainer12.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double24 = rectangleInsets22.calculateTopOutset((double) (short) 10);
        double double25 = rectangleInsets22.getLeft();
        double double27 = rectangleInsets22.trimWidth(0.0d);
        legendItemBlockContainer12.setMargin(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D29 = legendItemBlockContainer12.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double31 = numberAxis0.valueToJava2D((double) 1.0f, rectangle2D29, rectangleEdge30);
        boolean boolean32 = numberAxis0.isVerticalTickLabels();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset33 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double35 = defaultStatisticalCategoryDataset33.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean38 = numberAxis37.isTickLabelsVisible();
        boolean boolean39 = numberAxis37.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat40 = null;
        numberAxis37.setNumberFormatOverride(numberFormat40);
        boolean boolean42 = numberAxis37.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset33, categoryAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer43);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str47 = layer46.toString();
        java.util.Collection collection48 = categoryPlot44.getDomainMarkers(0, layer46);
        categoryPlot44.clearRangeAxes();
        categoryPlot44.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint52 = categoryPlot44.getOutlinePaint();
        categoryPlot44.mapDatasetToDomainAxis(0, (int) (byte) 0);
        categoryPlot44.setOutlineVisible(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent58 = null;
        categoryPlot44.notifyListeners(plotChangeEvent58);
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot44);
        org.junit.Assert.assertNotNull(horizontalAlignment4);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Layer.FOREGROUND" + "'", str47.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 10.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, 0.0d, true);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range2, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder9.getInsets();
        boolean boolean12 = range2.equals((java.lang.Object) lineBorder9);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range2, 0.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range2, 3.0d);
        org.jfree.data.Range range18 = rectangleConstraint17.getWidthRange();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder8.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double42 = numberAxis11.valueToJava2D((double) 1.0f, rectangle2D40, rectangleEdge41);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets10.createOutsetRectangle(rectangle2D40, false, false);
        legendGraphic6.setLine((java.awt.Shape) rectangle2D45);
        java.lang.Object obj47 = legendGraphic6.clone();
        legendGraphic6.setPadding((double) 0.5f, 1.0E-8d, (double) 128, 0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = legendGraphic6.getShapeLocation();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(rectangleAnchor53);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesItemLabelsVisible((int) ' ', (java.lang.Boolean) true);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double42 = numberAxis11.valueToJava2D((double) 1.0f, rectangle2D40, rectangleEdge41);
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = chartColor8.createContext(colorModel9, rectangle10, rectangle2D40, affineTransform43, renderingHints44);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset46 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double48 = defaultStatisticalCategoryDataset46.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean51 = numberAxis50.isTickLabelsVisible();
        boolean boolean52 = numberAxis50.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat53 = null;
        numberAxis50.setNumberFormatOverride(numberFormat53);
        boolean boolean55 = numberAxis50.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset46, categoryAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer56);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str60 = layer59.toString();
        java.util.Collection collection61 = categoryPlot57.getDomainMarkers(0, layer59);
        categoryPlot57.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot64 = categoryPlot57.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation66 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot57.setDomainAxisLocation(500, axisLocation66, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState71 = barRenderer0.initialise(graphics2D4, rectangle2D40, categoryPlot57, (int) '4', plotRenderingInfo70);
        org.jfree.chart.plot.Plot plot72 = categoryPlot57.getRootPlot();
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext45);
        org.junit.Assert.assertEquals((double) double48, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Layer.FOREGROUND" + "'", str60.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNull(plot64);
        org.junit.Assert.assertNotNull(axisLocation66);
        org.junit.Assert.assertNotNull(categoryItemRendererState71);
        org.junit.Assert.assertNotNull(plot72);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot11.getDomainAxisLocation(15);
        categoryPlot11.clearRangeMarkers(0);
        org.jfree.chart.ChartColor chartColor23 = new org.jfree.chart.ChartColor((int) (byte) 0, (int) (byte) 10, (int) '#');
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color27 = java.awt.Color.gray;
        float[] floatArray28 = null;
        float[] floatArray29 = color27.getRGBColorComponents(floatArray28);
        float[] floatArray30 = color26.getRGBComponents(floatArray28);
        float[] floatArray31 = chartColor23.getColorComponents(colorSpace25, floatArray28);
        categoryPlot11.setRangeCrosshairPaint((java.awt.Paint) chartColor23);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(1.0d, (double) (byte) 100, 0.0d, (double) 8);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color8 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("", font7, (java.awt.Paint) color8);
        java.lang.String str10 = textFragment9.getText();
        java.awt.Paint paint11 = textFragment9.getPaint();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke13 = lineBorder12.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder(paint11, stroke13, rectangleInsets14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment17, verticalAlignment18, (double) (short) 100, (double) (-1));
        flowArrangement21.clear();
        org.jfree.data.general.Dataset dataset23 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement21, dataset23, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer25.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer25.setHeight((double) (byte) 1);
        java.util.List list33 = legendItemBlockContainer25.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = legendItemBlockContainer25.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double37 = rectangleInsets35.calculateTopOutset((double) (short) 10);
        double double38 = rectangleInsets35.getLeft();
        double double40 = rectangleInsets35.trimWidth(0.0d);
        legendItemBlockContainer25.setMargin(rectangleInsets35);
        java.awt.geom.Rectangle2D rectangle2D42 = legendItemBlockContainer25.getBounds();
        java.awt.geom.Rectangle2D rectangle2D43 = rectangleInsets14.createInsetRectangle(rectangle2D42);
        try {
            blockBorder4.draw(graphics2D5, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangle2D43);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        boolean boolean5 = numberAxis0.isAxisLineVisible();
        numberAxis0.setAutoRange(false);
        java.awt.Shape shape8 = numberAxis0.getUpArrow();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        int int11 = numberTickUnit10.getMinorTickCount();
        numberAxis0.setTickUnit(numberTickUnit10, true, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) (-16777216), (java.lang.Comparable) (byte) 1);
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 1);
        try {
            java.lang.Comparable comparable8 = defaultStatisticalCategoryDataset0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(pieDataset6);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean6 = textFragment3.equals((java.lang.Object) font5);
        java.lang.String str7 = textFragment3.getText();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        try {
            float float10 = textFragment3.calculateBaselineOffset(graphics2D8, textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 100);
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        java.awt.Paint paint7 = textFragment5.getPaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets10.getRight();
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder(paint7, stroke9, rectangleInsets10);
        java.awt.Stroke stroke13 = lineBorder12.getStroke();
        valueMarker1.setStroke(stroke13);
        java.lang.String str15 = valueMarker1.getLabel();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        boolean boolean17 = valueMarker1.equals((java.lang.Object) defaultStatisticalCategoryDataset16);
        org.jfree.data.general.DatasetGroup datasetGroup18 = defaultStatisticalCategoryDataset16.getGroup();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetGroup18);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        java.lang.Object obj4 = null;
        keyedObjects2D0.addObject(obj4, (java.lang.Comparable) 8, (java.lang.Comparable) "ThreadContext");
        int int9 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 8);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType10 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean11 = keyedObjects2D0.equals((java.lang.Object) gradientPaintTransformType10);
        java.util.List list12 = keyedObjects2D0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        categoryPlot11.clearDomainMarkers();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent13);
        boolean boolean15 = categoryPlot11.isRangeCrosshairVisible();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke9);
        java.awt.Paint paint11 = valueMarker10.getLabelPaint();
        barRenderer0.setSeriesOutlinePaint((int) (short) 0, paint11, true);
        java.awt.Paint paint16 = barRenderer0.getItemLabelPaint(1, (int) '#');
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot35 = categoryPlot28.getParent();
        categoryPlot28.clearRangeAxes();
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot28);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = barRenderer38.getBasePositiveItemLabelPosition();
        barRenderer38.setBase((double) (-20561));
        boolean boolean42 = barRenderer38.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator43 = barRenderer38.getLegendItemLabelGenerator();
        barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator43);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNull(plot35);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator43);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Font font3 = barRenderer0.getSeriesItemLabelFont((int) '#');
        java.awt.Paint paint6 = barRenderer0.getItemPaint(0, (-16777216));
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        boolean boolean9 = barRenderer0.getBaseCreateEntities();
        barRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 1.0d);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset3, (java.lang.Comparable) numberTickUnit4, (double) 15);
        double double7 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(pieDataset3);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor1 = categoryLabelPosition0.getRotationAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition0.getCategoryAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = categoryLabelPosition0.getWidthType();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("hi!");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double5 = defaultStatisticalCategoryDataset3.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean8 = numberAxis7.isTickLabelsVisible();
        boolean boolean9 = numberAxis7.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis7.setNumberFormatOverride(numberFormat10);
        boolean boolean12 = numberAxis7.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer13);
        java.util.List list15 = categoryPlot14.getCategories();
        projectInfo0.setContributors(list15);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(list15);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color2 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("", font1, (java.awt.Paint) color2);
        java.lang.String str4 = textFragment3.getText();
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean6 = textFragment3.equals((java.lang.Object) font5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick16 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock12, textBlockAnchor13, textAnchor14, (double) (short) 1);
        org.jfree.chart.text.TextBlock textBlock18 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick22 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock18, textBlockAnchor19, textAnchor20, (double) (short) 1);
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick25 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (byte) 10, textBlock12, textBlockAnchor19, textAnchor23, (double) (-20561));
        org.jfree.chart.text.TextAnchor textAnchor26 = categoryTick25.getRotationAnchor();
        try {
            textFragment3.draw(graphics2D7, (float) 1L, (float) (-20561), textAnchor26, (float) 10, 10.0f, (double) 192);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot11.getFixedDomainAxisSpace();
        categoryPlot11.clearRangeMarkers(15);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNull(axisSpace22);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        java.awt.Image image18 = null;
        categoryPlot11.setBackgroundImage(image18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryPlot11.getAxisOffset();
        double double21 = rectangleInsets20.getBottom();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 10.0f);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, 0.0d, true);
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 10.0f);
        org.jfree.data.Range range12 = org.jfree.data.Range.shift(range9, 0.0d, true);
        org.jfree.data.Range range15 = org.jfree.data.Range.shift(range9, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range9);
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 10.0f);
        org.jfree.data.Range range22 = org.jfree.data.Range.shift(range19, 0.0d, true);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range19, (double) (short) 100, true);
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke27 = lineBorder26.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = lineBorder26.getInsets();
        boolean boolean29 = range19.equals((java.lang.Object) lineBorder26);
        org.jfree.data.Range range32 = org.jfree.data.Range.shift(range19, 0.0d, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = rectangleConstraint16.toRangeHeight(range32);
        org.jfree.data.Range range34 = org.jfree.data.Range.combine(range5, range32);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(rectangleConstraint33);
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("UnitType.ABSOLUTE");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textFragment1.draw(graphics2D2, (float) 0L, (float) 10L, textAnchor5, (float) (-1), (float) (-20561), (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Font font3 = barRenderer0.getSeriesItemLabelFont((int) '#');
        java.awt.Paint paint6 = barRenderer0.getItemPaint(0, (-16777216));
        barRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        boolean boolean9 = barRenderer0.getBaseCreateEntities();
        java.awt.Paint paint10 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Stroke stroke11 = barRenderer0.getBaseOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer5.getPositiveItemLabelPositionFallback();
        barRenderer5.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer5.getBasePositiveItemLabelPosition();
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        numberAxis0.setNegativeArrowVisible(true);
        numberAxis0.setAutoRange(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 4, (byte) 0, (-16777216) };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 4, (byte) 0, (-16777216) };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 4, (byte) 0, (-16777216) };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 4, (byte) 0, (-16777216) };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray7, numberArray11, numberArray15, numberArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "java.awt.Color[r=255,g=0,b=0]", numberArray20);
        org.jfree.data.category.CategoryDataset categoryDataset22 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RangeType.FULL", "java.awt.Color[r=255,g=0,b=0]", numberArray20);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(categoryDataset22);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) 1L);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        java.awt.Color color8 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke10);
        java.awt.Paint paint12 = valueMarker11.getLabelPaint();
        valueMarker11.setAlpha(0.5f);
        double double15 = valueMarker11.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker11.setLabelAnchor(rectangleAnchor16);
        legendTitle6.setLegendItemGraphicAnchor(rectangleAnchor16);
        java.awt.Paint paint19 = legendTitle6.getBackgroundPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement24 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment20, verticalAlignment21, (double) (short) 100, (double) (-1));
        legendTitle6.setHorizontalAlignment(horizontalAlignment20);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double30 = rectangleInsets28.calculateTopOutset((double) (short) 10);
        double double31 = rectangleInsets28.getLeft();
        valueMarker27.setLabelOffset(rectangleInsets28);
        boolean boolean33 = legendTitle6.equals((java.lang.Object) rectangleInsets28);
        org.jfree.chart.block.BlockFrame blockFrame34 = legendTitle6.getFrame();
        boolean boolean35 = columnArrangement4.equals((java.lang.Object) legendTitle6);
        java.awt.Paint paint36 = legendTitle6.getItemPaint();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(blockFrame34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean2 = axisSpace0.equals((java.lang.Object) shapeArray1);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge4);
        axisSpace0.add((double) 10, rectangleEdge5);
        axisSpace0.setTop((double) '4');
        java.awt.Font font11 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color12 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("", font11, (java.awt.Paint) color12);
        java.lang.String str14 = textFragment13.getText();
        java.awt.Paint paint15 = textFragment13.getPaint();
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke17 = lineBorder16.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double19 = rectangleInsets18.getRight();
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder(paint15, stroke17, rectangleInsets18);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = lineBorder20.getInsets();
        double double23 = rectangleInsets21.calculateBottomInset(3.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement32 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment28, verticalAlignment29, (double) (short) 100, (double) (-1));
        flowArrangement32.clear();
        org.jfree.data.general.Dataset dataset34 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer36 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement32, dataset34, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer36.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer36.setHeight((double) (byte) 1);
        java.util.List list44 = legendItemBlockContainer36.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = legendItemBlockContainer36.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double48 = rectangleInsets46.calculateTopOutset((double) (short) 10);
        double double49 = rectangleInsets46.getLeft();
        double double51 = rectangleInsets46.trimWidth(0.0d);
        legendItemBlockContainer36.setMargin(rectangleInsets46);
        java.awt.geom.Rectangle2D rectangle2D53 = legendItemBlockContainer36.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double55 = categoryAxis24.getCategoryJava2DCoordinate(categoryAnchor25, (-1), (int) (byte) -1, rectangle2D53, rectangleEdge54);
        boolean boolean56 = rectangleInsets21.equals((java.lang.Object) rectangleEdge54);
        axisSpace0.add((double) 0.5f, rectangleEdge54);
        org.junit.Assert.assertNotNull(shapeArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertNotNull(horizontalAlignment28);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer8.setToolTipText("hi!");
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("", font12, (java.awt.Paint) color13);
        java.lang.String str15 = textFragment14.getText();
        java.awt.Paint paint16 = textFragment14.getPaint();
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets19.getRight();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint16, stroke18, rectangleInsets19);
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape9, (java.awt.Paint) color10, stroke18, (java.awt.Paint) color22);
        java.awt.Shape shape24 = legendItem23.getLine();
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape24, "ThreadContext", "");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("");
        textBlock0.addLine(textLine4);
        org.jfree.chart.text.TextFragment textFragment6 = textLine4.getFirstTextFragment();
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(textFragment6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (short) 1, (java.lang.Number) (-1L), (java.lang.Comparable) (-1.0d), (java.lang.Comparable) (short) 10);
        java.lang.Number number10 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0.0f, (java.lang.Comparable) (-16777216));
        int int11 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        categoryPlot11.mapDatasetToDomainAxis(0, (int) (byte) 0);
        categoryPlot11.setOutlineVisible(true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent25 = null;
        categoryPlot11.notifyListeners(plotChangeEvent25);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation30 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) -1, (double) 100L);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener32 = null;
        boolean boolean33 = numberAxis31.hasListener(eventListener32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis31.setTickLabelPaint((java.awt.Paint) color34);
        boolean boolean36 = numberAxis31.isAxisLineVisible();
        boolean boolean37 = numberAxis31.getAutoRangeIncludesZero();
        boolean boolean38 = meanAndStandardDeviation30.equals((java.lang.Object) numberAxis31);
        numberAxis31.setInverted(false);
        categoryPlot11.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis31, false);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        java.awt.Color color21 = java.awt.Color.lightGray;
        categoryPlot11.setOutlinePaint((java.awt.Paint) color21);
        categoryPlot11.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener26 = null;
        boolean boolean27 = numberAxis25.hasListener(eventListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis25.setTickLabelPaint((java.awt.Paint) color28);
        java.lang.String str30 = numberAxis25.getLabelToolTip();
        numberAxis25.setLabelToolTip("");
        numberAxis25.setLabelToolTip("rect");
        numberAxis25.setFixedDimension((double) 15);
        java.awt.Stroke stroke37 = numberAxis25.getAxisLineStroke();
        categoryPlot11.setOutlineStroke(stroke37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryPlot11.getInsets();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick9 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock5, textBlockAnchor6, textAnchor7, (double) (short) 1);
        java.awt.Shape shape13 = textBlock0.calculateBounds(graphics2D1, (float) 1, (float) 10, textBlockAnchor6, (float) 128, (float) 15, (double) 0L);
        java.lang.String str14 = textBlockAnchor6.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str14.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.awt.Shape shape4 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double7 = defaultStatisticalCategoryDataset5.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean10 = numberAxis9.isTickLabelsVisible();
        boolean boolean11 = numberAxis9.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat12 = null;
        numberAxis9.setNumberFormatOverride(numberFormat12);
        boolean boolean14 = numberAxis9.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis9, categoryItemRenderer15);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str19 = layer18.toString();
        java.util.Collection collection20 = categoryPlot16.getDomainMarkers(0, layer18);
        categoryPlot16.clearRangeAxes();
        categoryPlot16.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint24 = categoryPlot16.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot16.getDatasetRenderingOrder();
        java.awt.Color color26 = java.awt.Color.lightGray;
        categoryPlot16.setOutlinePaint((java.awt.Paint) color26);
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!", "", "RectangleEdge.RIGHT", "RangeType.FULL", shape4, (java.awt.Paint) color26);
        int int29 = color26.getRGB();
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Layer.FOREGROUND" + "'", str19.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-4144960) + "'", int29 == (-4144960));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke(1);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double5 = defaultStatisticalCategoryDataset3.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean8 = numberAxis7.isTickLabelsVisible();
        boolean boolean9 = numberAxis7.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat10 = null;
        numberAxis7.setNumberFormatOverride(numberFormat10);
        boolean boolean12 = numberAxis7.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, categoryAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer13);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str17 = layer16.toString();
        java.util.Collection collection18 = categoryPlot14.getDomainMarkers(0, layer16);
        categoryPlot14.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot21 = categoryPlot14.getParent();
        boolean boolean22 = strokeList0.equals((java.lang.Object) plot21);
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity28 = new org.jfree.chart.entity.LegendItemEntity(shape27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape27, rectangleAnchor29, (double) '4', (double) (byte) 100);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Font font35 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color36 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("", font35, (java.awt.Paint) color36);
        java.lang.String str38 = textFragment37.getText();
        java.awt.Paint paint39 = textFragment37.getPaint();
        org.jfree.chart.block.LineBorder lineBorder40 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke41 = lineBorder40.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double43 = rectangleInsets42.getRight();
        org.jfree.chart.block.LineBorder lineBorder44 = new org.jfree.chart.block.LineBorder(paint39, stroke41, rectangleInsets42);
        java.awt.Color color45 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("{0}", "", "hi!", "NO_CHANGE", shape32, (java.awt.Paint) color33, stroke41, (java.awt.Paint) color45);
        org.jfree.data.general.Dataset dataset47 = legendItem46.getDataset();
        java.lang.String str48 = legendItem46.getURLText();
        boolean boolean49 = strokeList0.equals((java.lang.Object) legendItem46);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Layer.FOREGROUND" + "'", str17.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNull(dataset47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "NO_CHANGE" + "'", str48.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Paint paint1 = blockBorder0.getPaint();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) -1, (double) 100L);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = numberAxis3.hasListener(eventListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis3.isAxisLineVisible();
        boolean boolean9 = numberAxis3.getAutoRangeIncludesZero();
        boolean boolean10 = meanAndStandardDeviation2.equals((java.lang.Object) numberAxis3);
        java.lang.Class<?> wildcardClass11 = numberAxis3.getClass();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine();
        textBlock0.addLine(textLine1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Color color13 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke15);
        java.awt.Paint paint17 = valueMarker16.getLabelPaint();
        valueMarker16.setAlpha(0.5f);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str21 = layer20.toString();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer20);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity24 = new org.jfree.chart.entity.LegendItemEntity(shape23);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity27 = new org.jfree.chart.entity.TickLabelEntity(shape23, "ThreadContext", "ThreadContext");
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic29 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color28);
        boolean boolean30 = legendGraphic29.isShapeOutlineVisible();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.LEFT;
        legendGraphic29.setShapeAnchor(rectangleAnchor31);
        valueMarker16.setLabelAnchor(rectangleAnchor31);
        org.jfree.chart.text.TextBlock textBlock36 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor37 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick40 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock36, textBlockAnchor37, textAnchor38, (double) (short) 1);
        org.jfree.chart.text.TextBlock textBlock42 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor44 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick46 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock42, textBlockAnchor43, textAnchor44, (double) (short) 1);
        org.jfree.chart.text.TextAnchor textAnchor47 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick49 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (byte) 10, textBlock36, textBlockAnchor43, textAnchor47, (double) (-20561));
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition50 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor31, textBlockAnchor43);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Layer.FOREGROUND" + "'", str21.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(textBlockAnchor37);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertNotNull(textAnchor47);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(0.0d, 3.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        barRenderer0.setBasePaint(paint14);
        java.awt.Color color17 = java.awt.Color.RED;
        java.lang.String str18 = color17.toString();
        int int19 = color17.getBlue();
        int int20 = color17.getTransparency();
        barRenderer0.setSeriesPaint(2, (java.awt.Paint) color17, false);
        boolean boolean23 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str18.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("LengthConstraintType.NONE");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        float float7 = textFragment5.getBaselineOffset();
        java.awt.Font font8 = textFragment5.getFont();
        labelBlock1.setFont(font8);
        java.lang.Object obj10 = labelBlock1.clone();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float12 = categoryLabelPosition11.getWidthRatio();
        org.jfree.chart.text.TextAnchor textAnchor13 = categoryLabelPosition11.getRotationAnchor();
        boolean boolean14 = labelBlock1.equals((java.lang.Object) categoryLabelPosition11);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.95f + "'", float12 == 0.95f);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Color color13 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke15 = lineBorder14.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke15);
        java.awt.Paint paint17 = valueMarker16.getLabelPaint();
        valueMarker16.setAlpha(0.5f);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str21 = layer20.toString();
        categoryPlot11.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer20);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot11.getColumnRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot11.getDomainAxisLocation();
        categoryPlot11.configureDomainAxes();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Layer.FOREGROUND" + "'", str21.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot18 = categoryPlot11.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot11.setDomainAxisLocation(500, axisLocation20, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            categoryPlot11.handleClick((int) (byte) 1, (int) (short) -1, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer8 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj9 = standardGradientPaintTransformer8.clone();
        legendGraphic6.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double42 = categoryAxis11.getCategoryJava2DCoordinate(categoryAnchor12, (-1), (int) (byte) -1, rectangle2D40, rectangleEdge41);
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D40, (double) 'a', 52.0d);
        legendGraphic6.setLine((java.awt.Shape) rectangle2D40);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        boolean boolean7 = legendGraphic6.isShapeOutlineVisible();
        java.awt.Paint paint8 = legendGraphic6.getLinePaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendGraphic6.getShapeLocation();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        java.lang.String str3 = legendItemEntity1.toString();
        java.lang.Comparable comparable4 = legendItemEntity1.getSeriesKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str3.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(comparable4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getRangeMarkers(layer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj17 = categoryAxis16.clone();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis16.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = new org.jfree.chart.axis.CategoryLabelPositions();
        categoryAxis16.setCategoryLabelPositions(categoryLabelPositions19);
        categoryPlot11.setDomainAxis(categoryAxis16);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = categoryPlot11.getDomainMarkers(layer22);
        categoryPlot11.clearDomainMarkers((int) (byte) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = numberAxis3.hasListener(eventListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis3.isAxisLineVisible();
        boolean boolean9 = axisLocation0.equals((java.lang.Object) numberAxis3);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer10.setSeriesItemLabelsVisible((int) ' ', (java.lang.Boolean) true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel19 = null;
        java.awt.Rectangle rectangle20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement29 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment25, verticalAlignment26, (double) (short) 100, (double) (-1));
        flowArrangement29.clear();
        org.jfree.data.general.Dataset dataset31 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer33 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement29, dataset31, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer33.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer33.setHeight((double) (byte) 1);
        java.util.List list41 = legendItemBlockContainer33.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = legendItemBlockContainer33.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double45 = rectangleInsets43.calculateTopOutset((double) (short) 10);
        double double46 = rectangleInsets43.getLeft();
        double double48 = rectangleInsets43.trimWidth(0.0d);
        legendItemBlockContainer33.setMargin(rectangleInsets43);
        java.awt.geom.Rectangle2D rectangle2D50 = legendItemBlockContainer33.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double52 = numberAxis21.valueToJava2D((double) 1.0f, rectangle2D50, rectangleEdge51);
        java.awt.geom.AffineTransform affineTransform53 = null;
        java.awt.RenderingHints renderingHints54 = null;
        java.awt.PaintContext paintContext55 = chartColor18.createContext(colorModel19, rectangle20, rectangle2D50, affineTransform53, renderingHints54);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset56 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double58 = defaultStatisticalCategoryDataset56.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean61 = numberAxis60.isTickLabelsVisible();
        boolean boolean62 = numberAxis60.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat63 = null;
        numberAxis60.setNumberFormatOverride(numberFormat63);
        boolean boolean65 = numberAxis60.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset56, categoryAxis59, (org.jfree.chart.axis.ValueAxis) numberAxis60, categoryItemRenderer66);
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str70 = layer69.toString();
        java.util.Collection collection71 = categoryPlot67.getDomainMarkers(0, layer69);
        categoryPlot67.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot74 = categoryPlot67.getParent();
        org.jfree.chart.axis.AxisLocation axisLocation76 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot67.setDomainAxisLocation(500, axisLocation76, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState81 = barRenderer10.initialise(graphics2D14, rectangle2D50, categoryPlot67, (int) '4', plotRenderingInfo80);
        numberAxis3.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot67);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext55);
        org.junit.Assert.assertEquals((double) double58, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Layer.FOREGROUND" + "'", str70.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertNull(plot74);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNotNull(categoryItemRendererState81);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener7 = null;
        boolean boolean8 = numberAxis6.hasListener(eventListener7);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor11, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity17 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis6, shape14, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D18 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D18.removeColumn((java.lang.Comparable) numberTickUnit20);
        numberAxis6.setTickUnit(numberTickUnit20);
        defaultStatisticalCategoryDataset0.add(100.0d, (double) 10.0f, (java.lang.Comparable) 1.0f, (java.lang.Comparable) numberTickUnit20);
        try {
            org.jfree.data.general.PieDataset pieDataset25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("PlotOrientation.HORIZONTAL", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        boolean boolean3 = unitType1.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D0.removeColumn((java.lang.Comparable) numberTickUnit2);
        try {
            keyedObjects2D0.removeColumn((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Font font3 = barRenderer0.getSeriesItemLabelFont((int) '#');
        java.awt.Paint paint6 = barRenderer0.getItemPaint(0, (-16777216));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer0.getItemLabelGenerator(15, 0);
        boolean boolean10 = barRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str16 = layer15.toString();
        java.util.Collection collection17 = categoryPlot13.getDomainMarkers(0, layer15);
        categoryPlot13.clearRangeAxes();
        categoryPlot13.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint21 = categoryPlot13.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder22 = categoryPlot13.getDatasetRenderingOrder();
        java.awt.Color color23 = java.awt.Color.lightGray;
        categoryPlot13.setOutlinePaint((java.awt.Paint) color23);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot13);
        org.jfree.chart.util.SortOrder sortOrder26 = categoryPlot13.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Layer.FOREGROUND" + "'", str16.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(datasetRenderingOrder22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(sortOrder26);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) -1, (double) 100L);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = numberAxis3.hasListener(eventListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis3.isAxisLineVisible();
        boolean boolean9 = numberAxis3.getAutoRangeIncludesZero();
        boolean boolean10 = meanAndStandardDeviation2.equals((java.lang.Object) numberAxis3);
        numberAxis3.setInverted(false);
        org.jfree.data.Range range13 = null;
        try {
            numberAxis3.setDefaultAutoRange(range13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 1.0f);
        axisState1.cursorLeft(8.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick9 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock5, textBlockAnchor6, textAnchor7, (double) (short) 1);
        java.awt.Shape shape13 = textBlock0.calculateBounds(graphics2D1, (float) 1, (float) 10, textBlockAnchor6, (float) 128, (float) 15, (double) 0L);
        java.awt.Font font16 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine17 = new org.jfree.chart.text.TextLine("", font16);
        java.awt.Color color18 = java.awt.Color.BLACK;
        textBlock0.addLine("LegendItemEntity: seriesKey=null, dataset=null", font16, (java.awt.Paint) color18);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor6, (double) '4', (double) (byte) 100);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.clone(shape9);
        java.awt.Shape shape15 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double18 = defaultStatisticalCategoryDataset16.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean21 = numberAxis20.isTickLabelsVisible();
        boolean boolean22 = numberAxis20.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat23 = null;
        numberAxis20.setNumberFormatOverride(numberFormat23);
        boolean boolean25 = numberAxis20.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset16, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis20, categoryItemRenderer26);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        java.util.Collection collection31 = categoryPlot27.getDomainMarkers(0, layer29);
        categoryPlot27.clearRangeAxes();
        categoryPlot27.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint35 = categoryPlot27.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = categoryPlot27.getDatasetRenderingOrder();
        java.awt.Color color37 = java.awt.Color.lightGray;
        categoryPlot27.setOutlinePaint((java.awt.Paint) color37);
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("hi!", "", "RectangleEdge.RIGHT", "RangeType.FULL", shape15, (java.awt.Paint) color37);
        int int40 = color37.getBlue();
        try {
            org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem(attributedString0, "", "MAJOR", "-2", shape10, (java.awt.Paint) color37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 192 + "'", int40 == 192);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMaximumBarWidth();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape2, "ThreadContext", "ThreadContext");
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color7);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color7, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        org.jfree.chart.axis.ValueAxis valueAxis17 = categoryPlot11.getRangeAxisForDataset(10);
        boolean boolean18 = categoryPlot11.isRangeZoomable();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener20 = null;
        boolean boolean21 = numberAxis19.hasListener(eventListener20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis19.setTickLabelPaint((java.awt.Paint) color22);
        java.lang.String str24 = numberAxis19.getLabelToolTip();
        numberAxis19.setLabelToolTip("");
        numberAxis19.setLabelToolTip("rect");
        numberAxis19.setFixedDimension((double) 15);
        java.awt.Stroke stroke31 = numberAxis19.getAxisLineStroke();
        org.jfree.data.Range range32 = categoryPlot11.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis19);
        categoryPlot11.setBackgroundImageAlignment(2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = categoryPlot11.getRenderer((int) (byte) 1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(valueAxis17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNull(categoryItemRenderer36);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getRangeMarkers(layer13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj17 = categoryAxis16.clone();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis16.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = new org.jfree.chart.axis.CategoryLabelPositions();
        categoryAxis16.setCategoryLabelPositions(categoryLabelPositions19);
        categoryPlot11.setDomainAxis(categoryAxis16);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection23 = categoryPlot11.getDomainMarkers(layer22);
        java.lang.String str24 = layer22.toString();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.Plot plot18 = categoryPlot11.getParent();
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot11.getFixedRangeAxisSpace();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot11);
        java.awt.Paint paint22 = jFreeChart21.getBackgroundPaint();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((-20561));
        java.awt.Stroke stroke19 = categoryPlot11.getRangeGridlineStroke();
        org.jfree.chart.plot.Plot plot20 = categoryPlot11.getParent();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge(0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick6 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock2, textBlockAnchor3, textAnchor4, (double) (short) 1);
        org.jfree.chart.text.TextBlock textBlock8 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick12 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock8, textBlockAnchor9, textAnchor10, (double) (short) 1);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick15 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (byte) 10, textBlock2, textBlockAnchor9, textAnchor13, (double) (-20561));
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        textBlock2.draw(graphics2D16, (float) (-2), 100.0f, textBlockAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range1 = rectangleConstraint0.getHeightRange();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray8 = new float[] { 1, '#', 10L, 1 };
        float[] floatArray9 = java.awt.Color.RGBtoHSB(500, (int) (short) 10, (int) (byte) 100, floatArray8);
        float[] floatArray10 = color0.getComponents(floatArray9);
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener14 = null;
        boolean boolean15 = numberAxis13.hasListener(eventListener14);
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape16, rectangleAnchor18, (double) '4', (double) (byte) 100);
        org.jfree.chart.entity.AxisLabelEntity axisLabelEntity24 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis) numberAxis13, shape21, "TextBlockAnchor.CENTER_LEFT", "java.awt.Color[r=255,g=0,b=0]");
        org.jfree.data.KeyedObjects2D keyedObjects2D25 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        keyedObjects2D25.removeColumn((java.lang.Comparable) numberTickUnit27);
        numberAxis13.setTickUnit(numberTickUnit27);
        numberAxis13.setTickLabelsVisible(false);
        java.awt.Font font34 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color35 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("", font34, (java.awt.Paint) color35);
        java.lang.String str37 = textFragment36.getText();
        java.awt.Paint paint38 = textFragment36.getPaint();
        org.jfree.chart.block.LineBorder lineBorder39 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke40 = lineBorder39.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double42 = rectangleInsets41.getRight();
        org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder(paint38, stroke40, rectangleInsets41);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment45 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement48 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment44, verticalAlignment45, (double) (short) 100, (double) (-1));
        flowArrangement48.clear();
        org.jfree.data.general.Dataset dataset50 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement48, dataset50, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer52.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer52.setHeight((double) (byte) 1);
        java.util.List list60 = legendItemBlockContainer52.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = legendItemBlockContainer52.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double64 = rectangleInsets62.calculateTopOutset((double) (short) 10);
        double double65 = rectangleInsets62.getLeft();
        double double67 = rectangleInsets62.trimWidth(0.0d);
        legendItemBlockContainer52.setMargin(rectangleInsets62);
        java.awt.geom.Rectangle2D rectangle2D69 = legendItemBlockContainer52.getBounds();
        java.awt.geom.Rectangle2D rectangle2D70 = rectangleInsets41.createInsetRectangle(rectangle2D69);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions71 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition73 = categoryLabelPositions71.getLabelPosition(rectangleEdge72);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition75 = categoryLabelPositions71.getLabelPosition(rectangleEdge74);
        double double76 = numberAxis13.valueToJava2D((double) (-16777216), rectangle2D69, rectangleEdge74);
        java.awt.geom.AffineTransform affineTransform77 = null;
        java.awt.RenderingHints renderingHints78 = null;
        java.awt.PaintContext paintContext79 = color0.createContext(colorModel11, rectangle12, rectangle2D69, affineTransform77, renderingHints78);
        int int80 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(list60);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D69);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(categoryLabelPositions71);
        org.junit.Assert.assertNull(categoryLabelPosition73);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(categoryLabelPosition75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 192 + "'", int80 == 192);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis0.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener7 = null;
        boolean boolean8 = numberAxis6.hasListener(eventListener7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis6.setTickLabelPaint((java.awt.Paint) color9);
        java.lang.String str11 = numberAxis6.getLabelToolTip();
        java.awt.Stroke stroke12 = numberAxis6.getTickMarkStroke();
        numberAxis0.setAxisLineStroke(stroke12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        categoryPlot11.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint19 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot11.getDatasetRenderingOrder();
        java.awt.Color color21 = java.awt.Color.lightGray;
        categoryPlot11.setOutlinePaint((java.awt.Paint) color21);
        int int23 = categoryPlot11.getRangeAxisCount();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendItemBlockContainer8.arrange(graphics2D14);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(size2D15);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) 'a');
        java.lang.Object obj5 = keyedObjects0.getObject((java.lang.Comparable) 0L);
        java.lang.Object obj7 = keyedObjects0.getObject(128);
        try {
            keyedObjects0.removeValue((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick6 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock2, textBlockAnchor3, textAnchor4, (double) (short) 1);
        org.jfree.chart.text.TextBlock textBlock8 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick12 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock8, textBlockAnchor9, textAnchor10, (double) (short) 1);
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick15 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) (byte) 10, textBlock2, textBlockAnchor9, textAnchor13, (double) (-20561));
        org.jfree.chart.text.TextBlock textBlock16 = categoryTick15.getLabel();
        double double17 = categoryTick15.getAngle();
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textBlock16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-20561.0d) + "'", double17 == (-20561.0d));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "hi!", "hi!", "");
        boolean boolean6 = basicProjectInfo4.equals((java.lang.Object) (short) -1);
        java.lang.String str7 = basicProjectInfo4.getCopyright();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean8 = textFragment5.equals((java.lang.Object) font7);
        org.jfree.chart.ChartColor chartColor12 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.AxisSpace axisSpace17 = new org.jfree.chart.axis.AxisSpace();
        double double18 = axisSpace17.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge20);
        axisSpace17.add((double) 100.0f, rectangleEdge21);
        axisState15.moveCursor((double) (short) 100, rectangleEdge21);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double26 = rectangleInsets24.calculateTopOutset((double) (short) 10);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean28 = numberAxis27.isTickLabelsVisible();
        numberAxis27.resizeRange((double) (byte) 0);
        org.jfree.chart.ChartColor chartColor35 = new org.jfree.chart.ChartColor((int) (byte) 0, 1, 0);
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement46 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment42, verticalAlignment43, (double) (short) 100, (double) (-1));
        flowArrangement46.clear();
        org.jfree.data.general.Dataset dataset48 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer50 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement46, dataset48, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer50.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer50.setHeight((double) (byte) 1);
        java.util.List list58 = legendItemBlockContainer50.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = legendItemBlockContainer50.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double62 = rectangleInsets60.calculateTopOutset((double) (short) 10);
        double double63 = rectangleInsets60.getLeft();
        double double65 = rectangleInsets60.trimWidth(0.0d);
        legendItemBlockContainer50.setMargin(rectangleInsets60);
        java.awt.geom.Rectangle2D rectangle2D67 = legendItemBlockContainer50.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge68 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double69 = numberAxis38.valueToJava2D((double) 1.0f, rectangle2D67, rectangleEdge68);
        java.awt.geom.AffineTransform affineTransform70 = null;
        java.awt.RenderingHints renderingHints71 = null;
        java.awt.PaintContext paintContext72 = chartColor35.createContext(colorModel36, rectangle37, rectangle2D67, affineTransform70, renderingHints71);
        org.jfree.chart.axis.AxisSpace axisSpace73 = new org.jfree.chart.axis.AxisSpace();
        java.awt.Shape[] shapeArray74 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean75 = axisSpace73.equals((java.lang.Object) shapeArray74);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge77);
        axisSpace73.add((double) 10, rectangleEdge78);
        double double80 = numberAxis27.valueToJava2D(0.0d, rectangle2D67, rectangleEdge78);
        java.awt.geom.Rectangle2D rectangle2D81 = rectangleInsets24.createInsetRectangle(rectangle2D67);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity84 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D81, "java.awt.Color[r=255,g=0,b=0]", "Layer.FOREGROUND");
        org.jfree.chart.axis.AxisLocation axisLocation85 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation86 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation85, plotOrientation86);
        java.util.List list88 = categoryAxis13.refreshTicks(graphics2D14, axisState15, rectangle2D81, rectangleEdge87);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment89 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment90 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement93 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment89, verticalAlignment90, (double) 0.5f, Double.NaN);
        org.jfree.chart.util.VerticalAlignment verticalAlignment94 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.jfree.chart.util.RectangleInsets rectangleInsets95 = new org.jfree.chart.util.RectangleInsets();
        org.jfree.chart.title.TextTitle textTitle96 = new org.jfree.chart.title.TextTitle("LegendItemEntity: seriesKey=null, dataset=null", font7, (java.awt.Paint) chartColor12, rectangleEdge87, horizontalAlignment89, verticalAlignment94, rectangleInsets95);
        org.jfree.chart.block.LineBorder lineBorder97 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint98 = lineBorder97.getPaint();
        org.jfree.chart.block.LabelBlock labelBlock99 = new org.jfree.chart.block.LabelBlock("NO_CHANGE", font7, paint98);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangleEdge68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(paintContext72);
        org.junit.Assert.assertNotNull(shapeArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertNotNull(rectangleEdge78);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D81);
        org.junit.Assert.assertNotNull(axisLocation85);
        org.junit.Assert.assertNotNull(plotOrientation86);
        org.junit.Assert.assertNotNull(rectangleEdge87);
        org.junit.Assert.assertNotNull(list88);
        org.junit.Assert.assertNotNull(horizontalAlignment89);
        org.junit.Assert.assertNotNull(verticalAlignment90);
        org.junit.Assert.assertNotNull(verticalAlignment94);
        org.junit.Assert.assertNotNull(paint98);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (short) 100, (double) (-1));
        flowArrangement4.clear();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4, dataset6, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer8.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        org.jfree.data.general.Dataset dataset14 = legendItemBlockContainer8.getDataset();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) '4', 0.0d);
        org.jfree.chart.util.Size2D size2D19 = null;
        org.jfree.chart.util.Size2D size2D20 = rectangleConstraint18.calculateConstrainedSize(size2D19);
        java.lang.String str21 = rectangleConstraint18.toString();
        org.jfree.chart.util.Size2D size2D22 = legendItemBlockContainer8.arrange(graphics2D15, rectangleConstraint18);
        java.lang.Object obj23 = size2D22.clone();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNull(dataset14);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]" + "'", str21.equals("RectangleConstraint[LengthConstraintType.FIXED: width=52.0, height=0.0]"));
        org.junit.Assert.assertNotNull(size2D22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 'a');
        int int2 = numberTickUnit1.getMinorTickCount();
        java.lang.String str4 = numberTickUnit1.valueToString(100.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "100" + "'", str4.equals("100"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock1, textBlockAnchor2, textAnchor3, (double) (short) 1);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = null;
        java.awt.Shape shape13 = textBlock1.calculateBounds(graphics2D6, (float) 2, 0.0f, textBlockAnchor9, 0.95f, (float) 0, (double) 2.0f);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        textBlock1.draw(graphics2D14, (float) '#', (float) 1L, textBlockAnchor17, (float) '4', (float) (byte) -1, 152.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = numberAxis0.hasListener(eventListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis0.getTickUnit();
        double double6 = numberAxis0.getFixedDimension();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double9 = defaultStatisticalCategoryDataset7.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean12 = numberAxis11.isTickLabelsVisible();
        boolean boolean13 = numberAxis11.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat14 = null;
        numberAxis11.setNumberFormatOverride(numberFormat14);
        boolean boolean16 = numberAxis11.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7, categoryAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis11, categoryItemRenderer17);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str21 = layer20.toString();
        java.util.Collection collection22 = categoryPlot18.getDomainMarkers(0, layer20);
        categoryPlot18.clearRangeAxes();
        categoryPlot18.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint26 = categoryPlot18.getOutlinePaint();
        categoryPlot18.mapDatasetToDomainAxis(0, (int) (byte) 0);
        boolean boolean30 = numberAxis0.hasListener((java.util.EventListener) categoryPlot18);
        org.jfree.data.general.DatasetGroup datasetGroup31 = categoryPlot18.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = null;
        try {
            categoryPlot18.addDomainMarker(categoryMarker32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Layer.FOREGROUND" + "'", str21.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(datasetGroup31);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isTickLabelsVisible();
        java.awt.Font font3 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("", font3, (java.awt.Paint) color4);
        java.lang.String str6 = textFragment5.getText();
        java.awt.Font font7 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        boolean boolean8 = textFragment5.equals((java.lang.Object) font7);
        numberAxis0.setTickLabelFont(font7);
        float float10 = numberAxis0.getTickMarkInsideLength();
        numberAxis0.setAutoTickUnitSelection(true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        int int2 = categoryAxis0.getCategoryLabelPositionOffset();
        double double3 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot11.getOrientation();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(plotOrientation16);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 1, textBlock1, textBlockAnchor2, textAnchor3, (double) (short) 1);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.awt.Shape shape13 = textBlock1.calculateBounds(graphics2D6, (float) 0, (float) 100L, textBlockAnchor9, (float) (short) 1, (float) (short) 10, (double) 10L);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        java.awt.Font font12 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("", font12);
        valueMarker6.setLabelFont(font12);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("RectangleAnchor.RIGHT", font12);
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double19 = defaultStatisticalCategoryDataset17.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean22 = numberAxis21.isTickLabelsVisible();
        boolean boolean23 = numberAxis21.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat24 = null;
        numberAxis21.setNumberFormatOverride(numberFormat24);
        boolean boolean26 = numberAxis21.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset17, categoryAxis20, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer27);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str31 = layer30.toString();
        java.util.Collection collection32 = categoryPlot28.getDomainMarkers(0, layer30);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setRangeCrosshairLockedOnData(true);
        java.awt.Paint paint36 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = categoryPlot28.getDatasetRenderingOrder();
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("44,96,52,96,52,104,44,104,44,96,44,96", font16, (org.jfree.chart.plot.Plot) categoryPlot28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = jFreeChart39.getCategoryPlot();
        org.jfree.chart.title.LegendTitle legendTitle42 = jFreeChart39.getLegend((-500));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Layer.FOREGROUND" + "'", str31.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(categoryPlot40);
        org.junit.Assert.assertNull(legendTitle42);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Color color3 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke5 = lineBorder4.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke5);
        java.awt.Paint paint7 = valueMarker6.getLabelPaint();
        valueMarker6.setAlpha(0.5f);
        double double10 = valueMarker6.getValue();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker6.setLabelAnchor(rectangleAnchor11);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor11);
        java.awt.Paint paint14 = legendTitle1.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets15.getRight();
        legendTitle1.setItemLabelPadding(rectangleInsets15);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        titleChangeEvent18.setType(chartChangeEventType19);
        org.jfree.chart.JFreeChart jFreeChart21 = titleChangeEvent18.getChart();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
        org.junit.Assert.assertNull(jFreeChart21);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape1 = barRenderer0.getBaseShape();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double4 = defaultStatisticalCategoryDataset2.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        boolean boolean8 = numberAxis6.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat9 = null;
        numberAxis6.setNumberFormatOverride(numberFormat9);
        boolean boolean11 = numberAxis6.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset2, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis6, categoryItemRenderer12);
        java.awt.Paint paint14 = categoryPlot13.getDomainGridlinePaint();
        barRenderer0.setBasePaint(paint14);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Font font17 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        barRenderer0.setBaseItemLabelFont(font17);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator19, false);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        legendGraphic6.setShapeVisible(false);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        legendGraphic6.setLine(shape10);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder8.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double42 = numberAxis11.valueToJava2D((double) 1.0f, rectangle2D40, rectangleEdge41);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets10.createOutsetRectangle(rectangle2D40, false, false);
        legendGraphic6.setLine((java.awt.Shape) rectangle2D45);
        boolean boolean47 = legendGraphic6.isShapeVisible();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = legendTitle1.getLegendItemGraphicEdge();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray3 = legendTitle1.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = legendTitle1.getItemLabelPadding();
        java.awt.Paint paint5 = legendTitle1.getBackgroundPaint();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(legendItemSourceArray3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        boolean boolean2 = borderArrangement0.equals((java.lang.Object) "rect");
        double[] doubleArray13 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=255,g=0,b=0]", "hi!", doubleArray14);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer18 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0, (org.jfree.data.general.Dataset) categoryDataset16, (java.lang.Comparable) 1.0f);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment19 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment20 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement23 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment19, verticalAlignment20, (double) (short) 100, (double) (-1));
        flowArrangement23.clear();
        org.jfree.data.general.Dataset dataset25 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer27 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement23, dataset25, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer27.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        org.jfree.data.general.Dataset dataset33 = legendItemBlockContainer27.getDataset();
        java.lang.String str34 = legendItemBlockContainer27.getURLText();
        org.jfree.data.general.Dataset dataset35 = legendItemBlockContainer27.getDataset();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.Range range38 = null;
        org.jfree.data.Range range40 = org.jfree.data.Range.expandToInclude(range38, (double) 10.0f);
        org.jfree.data.Range range43 = org.jfree.data.Range.shift(range40, 0.0d, true);
        org.jfree.data.Range range46 = org.jfree.data.Range.shift(range40, (double) (short) 100, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint47 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 10, range40);
        double double48 = rectangleConstraint47.getWidth();
        org.jfree.chart.util.Size2D size2D49 = borderArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer27, graphics2D36, rectangleConstraint47);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNotNull(horizontalAlignment19);
        org.junit.Assert.assertNull(dataset33);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertNull(dataset35);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertNotNull(size2D49);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "ThreadContext", "ThreadContext");
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color5);
        java.awt.Paint paint7 = legendGraphic6.getLinePaint();
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder8.getInsets();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, (double) (short) 100, (double) (-1));
        flowArrangement19.clear();
        org.jfree.data.general.Dataset dataset21 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement19, dataset21, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer23.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer23.setHeight((double) (byte) 1);
        java.util.List list31 = legendItemBlockContainer23.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = legendItemBlockContainer23.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double35 = rectangleInsets33.calculateTopOutset((double) (short) 10);
        double double36 = rectangleInsets33.getLeft();
        double double38 = rectangleInsets33.trimWidth(0.0d);
        legendItemBlockContainer23.setMargin(rectangleInsets33);
        java.awt.geom.Rectangle2D rectangle2D40 = legendItemBlockContainer23.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double42 = numberAxis11.valueToJava2D((double) 1.0f, rectangle2D40, rectangleEdge41);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets10.createOutsetRectangle(rectangle2D40, false, false);
        legendGraphic6.setLine((java.awt.Shape) rectangle2D45);
        java.lang.Object obj47 = legendGraphic6.clone();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener49 = null;
        boolean boolean50 = numberAxis48.hasListener(eventListener49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis48.setTickLabelPaint((java.awt.Paint) color51);
        boolean boolean53 = numberAxis48.isAxisLineVisible();
        boolean boolean54 = numberAxis48.getAutoRangeIncludesZero();
        numberAxis48.setPositiveArrowVisible(false);
        boolean boolean57 = legendGraphic6.equals((java.lang.Object) numberAxis48);
        java.awt.Paint paint58 = legendGraphic6.getOutlinePaint();
        java.awt.Paint paint59 = legendGraphic6.getLinePaint();
        boolean boolean60 = legendGraphic6.isShapeFilled();
        java.awt.Stroke stroke61 = legendGraphic6.getLineStroke();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNull(stroke61);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesVisible((int) (short) 10, (java.lang.Boolean) true);
        java.awt.Shape shape5 = barRenderer0.lookupSeriesShape((-16777216));
        boolean boolean8 = barRenderer0.isItemLabelVisible((int) (byte) 100, (-500));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(itemLabelPosition9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
        java.awt.Font font2 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        boolean boolean3 = textLine1.equals((java.lang.Object) font2);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("UnitType.ABSOLUTE");
        textLine1.addFragment(textFragment5);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        java.lang.String str1 = tickType0.toString();
        boolean boolean3 = tickType0.equals((java.lang.Object) "-2");
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAJOR" + "'", str1.equals("MAJOR"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (-1.0d), 0.0d, 0.0d, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (byte) -1, (double) 100L);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = numberAxis3.hasListener(eventListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        numberAxis3.setTickLabelPaint((java.awt.Paint) color6);
        boolean boolean8 = numberAxis3.isAxisLineVisible();
        boolean boolean9 = numberAxis3.getAutoRangeIncludesZero();
        boolean boolean10 = meanAndStandardDeviation2.equals((java.lang.Object) numberAxis3);
        double double11 = numberAxis3.getLabelAngle();
        numberAxis3.setAutoRange(true);
        double double14 = numberAxis3.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape5, rectangleAnchor7, (double) '4', (double) (byte) 100);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color13 = java.awt.Color.lightGray;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("MAJOR", "Layer.FOREGROUND", "", "LengthConstraintType.NONE", shape5, (java.awt.Paint) color11, stroke12, (java.awt.Paint) color13);
        legendItem14.setDatasetIndex((-16777216));
        java.lang.Class<?> wildcardClass17 = legendItem14.getClass();
        java.net.URL uRL18 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleAnchor.RIGHT", (java.lang.Class) wildcardClass17);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNull(uRL18);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.data.general.Dataset dataset2 = legendItemEntity1.getDataset();
        org.jfree.data.general.Dataset dataset3 = legendItemEntity1.getDataset();
        java.lang.String str4 = legendItemEntity1.getShapeType();
        double[] doubleArray13 = new double[] { 15, 10.0d, 10L, 10L, 1.0d, 10L };
        double[][] doubleArray14 = new double[][] { doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleAnchor.RIGHT", "java.awt.Color[r=255,g=0,b=0]", doubleArray14);
        boolean boolean16 = legendItemEntity1.equals((java.lang.Object) categoryDataset15);
        java.lang.String str17 = legendItemEntity1.getURLText();
        java.lang.Object obj18 = legendItemEntity1.clone();
        legendItemEntity1.setToolTipText("LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(dataset2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (short) 100, (double) (-1));
        flowArrangement11.clear();
        org.jfree.data.general.Dataset dataset13 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11, dataset13, (java.lang.Comparable) 1.0f);
        legendItemBlockContainer15.setMargin((double) 0.0f, (double) 100, (double) (short) 1, (double) 1.0f);
        legendItemBlockContainer15.setHeight((double) (byte) 1);
        java.util.List list23 = legendItemBlockContainer15.getBlocks();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendItemBlockContainer15.getMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets25.calculateTopOutset((double) (short) 10);
        double double28 = rectangleInsets25.getLeft();
        double double30 = rectangleInsets25.trimWidth(0.0d);
        legendItemBlockContainer15.setMargin(rectangleInsets25);
        java.awt.geom.Rectangle2D rectangle2D32 = legendItemBlockContainer15.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.LEFT;
        double double34 = categoryAxis3.getCategoryJava2DCoordinate(categoryAnchor4, (-1), (int) (byte) -1, rectangle2D32, rectangleEdge33);
        textTitle1.setBounds(rectangle2D32);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ThreadContext");
        java.lang.String str2 = textTitle1.getToolTipText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment4 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment3, verticalAlignment4, (double) 0.5f, Double.NaN);
        textTitle1.setTextAlignment(horizontalAlignment3);
        java.lang.String str9 = textTitle1.getToolTipText();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(verticalAlignment4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("hi!");
        java.awt.Image image3 = projectInfo0.getLogo();
        java.lang.Class<?> wildcardClass4 = projectInfo0.getClass();
        projectInfo0.setLicenceText("ThreadContext");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(image3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = barRenderer2.getPositiveItemLabelPositionFallback();
        barRenderer2.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer2.getBasePositiveItemLabelPosition();
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition6);
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        java.awt.Paint paint12 = categoryPlot11.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getRangeMarkers(layer13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        int int17 = categoryPlot11.getIndexOf(categoryItemRenderer16);
        org.jfree.chart.plot.Plot plot18 = categoryPlot11.getRootPlot();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(plot18);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke4 = barRenderer0.getItemOutlineStroke((int) (short) -1, 0);
        java.awt.Color color7 = java.awt.Color.gray;
        org.jfree.chart.block.LineBorder lineBorder8 = new org.jfree.chart.block.LineBorder();
        java.awt.Stroke stroke9 = lineBorder8.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke9);
        java.awt.Paint paint11 = valueMarker10.getLabelPaint();
        barRenderer0.setSeriesOutlinePaint((int) (short) 0, paint11, true);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        barRenderer0.setSeriesOutlineStroke(0, stroke15, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = barRenderer0.getURLGenerator((int) (byte) 10, 0);
        java.awt.Paint paint23 = barRenderer0.getItemOutlinePaint((int) (short) -1, (int) (short) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation24 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(categoryURLGenerator20);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot11.getRangeAxisLocation(0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color2 = java.awt.Color.getColor("hi!", color1);
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = blockBorder3.getInsets();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        double double2 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = numberAxis4.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat7 = null;
        numberAxis4.setNumberFormatOverride(numberFormat7);
        boolean boolean9 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis4, categoryItemRenderer10);
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str14 = layer13.toString();
        java.util.Collection collection15 = categoryPlot11.getDomainMarkers(0, layer13);
        categoryPlot11.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot11.getRangeAxisForDataset((-20561));
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot11.getRangeAxisForDataset(0);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryPlot11.setInsets(rectangleInsets21);
        java.awt.Paint paint23 = null;
        categoryPlot11.setOutlinePaint(paint23);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Layer.FOREGROUND" + "'", str14.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }
}

