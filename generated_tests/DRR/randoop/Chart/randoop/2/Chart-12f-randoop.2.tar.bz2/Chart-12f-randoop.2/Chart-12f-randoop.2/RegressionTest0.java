import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.Arrangement arrangement1 = null;
        org.jfree.chart.block.Arrangement arrangement2 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, arrangement1, arrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            piePlot1.setInsets(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setLicenceText("");
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo1.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray6 = projectInfo1.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(libraryArray5);
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn((java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 10");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(10, (int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        int int2 = defaultCategoryDataset0.getRowCount();
        try {
            defaultCategoryDataset0.incrementValue(100.0d, (java.lang.Comparable) (-1.0f), (java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 1");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int3 = java.awt.Color.HSBtoRGB((-1.0f), (float) 0L, (float) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-97) + "'", int3 == (-97));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieLabelLinkStyle.STANDARD", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        int int2 = defaultCategoryDataset0.getRowCount();
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset0.getRowKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray4 = new float[] { (-1L), '4' };
        try {
            float[] floatArray5 = color0.getColorComponents(colorSpace1, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable2 = null;
        java.lang.Comparable comparable3 = null;
        try {
            defaultCategoryDataset0.addValue((double) (short) 1, comparable2, comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        int int2 = defaultCategoryDataset0.getRowCount();
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset0.getRowKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("PieLabelLinkStyle.STANDARD", "PieLabelLinkStyle.STANDARD", "hi!", "rect", "");
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 10.0d, (double) (byte) 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = null;
        try {
            piePlot1.setLabelDistributor(abstractPieLabelDistributor6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        try {
            java.lang.Comparable comparable3 = defaultCategoryDataset0.getColumnKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        try {
            piePlot1.setInteriorGap(100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (100.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, (double) (byte) -1, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        java.awt.Color color6 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) (short) 1, (double) ' ', 0.0d, (java.awt.Paint) color6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        try {
            org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("rect", font1, (java.awt.Paint) color6, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'verticalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge1);
        try {
            double double3 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.awt.Shape shape7 = defaultDrawingSupplier4.getNextShape();
        java.lang.Object obj8 = defaultDrawingSupplier4.clone();
        java.awt.Paint paint9 = defaultDrawingSupplier4.getNextFillPaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            java.lang.Number number3 = defaultKeyedValues2D0.getValue((int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Paint paint4 = piePlot1.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textTitle1.arrange(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isOutlineVisible();
        float float5 = piePlot3.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot3.setURLGenerator(pieURLGenerator6);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot3.getLabelGenerator();
        java.awt.Shape shape9 = piePlot3.getLegendItemShape();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot3.setBaseSectionPaint((java.awt.Paint) color10);
        boolean boolean12 = rectangleEdge0.equals((java.lang.Object) color10);
        java.lang.String str13 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.BOTTOM" + "'", str13.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getRowKeys();
        try {
            java.lang.Number number4 = defaultKeyedValues2D0.getValue((java.lang.Comparable) 100.0d, (java.lang.Comparable) (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: -1.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isOutlineVisible();
        float float10 = piePlot8.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot8.setURLGenerator(pieURLGenerator11);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = piePlot8.getLabelGenerator();
        piePlot8.setSimpleLabels(false);
        boolean boolean16 = piePlot8.isSubplot();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor18 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        piePlot8.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor18);
        try {
            jFreeChart3.setTextAntiAlias((java.lang.Object) piePlot8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.plot.PiePlot@3193fea8 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.lang.String str6 = piePlot5.getNoDataMessage();
        boolean boolean7 = piePlot5.isCircular();
        java.awt.Stroke stroke9 = piePlot5.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.PiePlotState piePlotState16 = piePlot5.initialise(graphics2D10, rectangle2D11, piePlot13, (java.lang.Integer) (-97), plotRenderingInfo15);
        try {
            jFreeChart3.setTextAntiAlias((java.lang.Object) plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(piePlotState16);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        defaultCategoryDataset0.setValue((java.lang.Number) 0.025d, (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0);
        defaultCategoryDataset0.removeRow(0);
        java.lang.Comparable comparable12 = null;
        try {
            defaultCategoryDataset0.addValue((double) '#', comparable12, (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "PieLabelLinkStyle.STANDARD", image3, "rect", "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", "RectangleEdge.BOTTOM");
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color4 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) (short) 1, (double) ' ', 0.0d, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        java.awt.Paint paint7 = blockBorder5.getPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) (-97), (double) (byte) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test059");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        projectInfo1.setLicenceText("");
//        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo5.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
//        projectInfo5.setLicenceName("rect");
//        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        java.lang.String str11 = projectInfo1.toString();
//        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo1.getOptionalLibraries();
//        projectInfo1.setLicenceName("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertNotNull(projectInfo5);
//        org.junit.Assert.assertNotNull(projectInfo6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str11.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
//        org.junit.Assert.assertNotNull(libraryArray12);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) "PieLabelLinkStyle.STANDARD");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot1.getDatasetGroup();
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        piePlot1.setLabelBackgroundPaint(paint7);
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        boolean boolean11 = piePlot10.isOutlineVisible();
        float float12 = piePlot10.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = null;
        piePlot10.setURLGenerator(pieURLGenerator13);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator15 = piePlot10.getLabelGenerator();
        piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator15);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator15);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        piePlot1.handleClick((-97), (int) (short) 0, plotRenderingInfo8);
        java.awt.Font font10 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        piePlot1.setLabelFont(font10);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        float float4 = piePlot2.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator5);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        org.jfree.chart.plot.Plot plot8 = piePlot2.getParent();
        try {
            java.lang.Object obj9 = plot8.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightOutset((double) 0);
        double double4 = rectangleInsets0.calculateTopOutset((double) (-1));
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createInsetRectangle(rectangle2D5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        java.awt.Paint paint7 = null;
        jFreeChart3.setBorderPaint(paint7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = null;
        try {
            jFreeChart3.plotChanged(plotChangeEvent9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 0.0f, (java.lang.Comparable) ' ', (java.lang.Comparable) (byte) 100);
        try {
            java.lang.Number number7 = defaultKeyedValues2D0.getValue((java.lang.Comparable) (short) -1, (java.lang.Comparable) 100L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 100");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint6 = null;
        jFreeChart5.setBorderPaint(paint6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart5.createBufferedImage(1, (int) ' ', (int) '#', chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 35");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        projectInfo2.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
        projectInfo3.setInfo("");
        java.lang.String str7 = projectInfo3.getLicenceText();
        boolean boolean8 = rectangleEdge0.equals((java.lang.Object) str7);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(projectInfo2);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 102.0d, 0.025d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.image.BufferedImage bufferedImage14 = jFreeChart8.createBufferedImage(1, (int) (byte) 1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset15 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list16 = defaultCategoryDataset15.getColumnKeys();
        defaultCategoryDataset15.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        try {
            jFreeChart8.setTextAntiAlias((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: -1 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(bufferedImage14);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        boolean boolean2 = tableOrder0.equals((java.lang.Object) "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.Object obj3 = null;
        boolean boolean4 = tableOrder0.equals(obj3);
        java.lang.Object obj5 = null;
        boolean boolean6 = tableOrder0.equals(obj5);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint6 = null;
        jFreeChart5.setBorderPaint(paint6);
        org.jfree.chart.event.ChartChangeListener chartChangeListener8 = null;
        try {
            jFreeChart5.addChangeListener(chartChangeListener8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        java.awt.Font font14 = null;
        try {
            legendTitle13.setItemFont(font14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        piePlot1.markerChanged(markerChangeEvent13);
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) (short) 1, (double) ' ', 0.0d, (java.awt.Paint) color19);
        piePlot1.setLabelPaint((java.awt.Paint) color19);
        piePlot1.setPieIndex(100);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Color color1 = java.awt.Color.getColor("Rotation.CLOCKWISE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        int int2 = defaultCategoryDataset0.getRowCount();
        try {
            java.lang.Comparable comparable4 = defaultCategoryDataset0.getRowKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.awt.Shape shape7 = defaultDrawingSupplier4.getNextShape();
        java.lang.Object obj8 = defaultDrawingSupplier4.clone();
        java.lang.Object obj9 = defaultDrawingSupplier4.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font2);
        java.awt.Font font4 = textTitle3.getFont();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.PiePlotState piePlotState17 = piePlot6.initialise(graphics2D11, rectangle2D12, piePlot14, (java.lang.Integer) (-97), plotRenderingInfo16);
        piePlot6.setShadowXOffset((double) '4');
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", font4, (org.jfree.chart.plot.Plot) piePlot6, true);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = null;
        try {
            jFreeChart21.titleChanged(titleChangeEvent22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(piePlotState17);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        java.awt.Graphics2D graphics2D13 = null;
        try {
            org.jfree.chart.util.Size2D size2D14 = textTitle1.arrange(graphics2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image3, "rect", "", "PieLabelLinkStyle.STANDARD");
        projectInfo7.setLicenceText("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.plot.Plot plot8 = piePlot1.getParent();
        try {
            plot8.setBackgroundImageAlignment(255);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) "PieSection: 0, 0(3)");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: PieSection: 0, 0(3)");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        try {
            java.awt.image.BufferedImage bufferedImage8 = jFreeChart3.createBufferedImage((int) ' ', (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (32) and height (-97) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("-4,-4,4,4", "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", "hi!", "Rotation.CLOCKWISE", "-4,-4,4,4");
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        java.awt.Paint paint9 = jFreeChart3.getBorderPaint();
        java.awt.Font font12 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font12);
        textTitle13.setText("PieLabelLinkStyle.STANDARD");
        try {
            jFreeChart3.addSubtitle((int) '4', (org.jfree.chart.title.Title) textTitle13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font2);
        java.awt.Font font4 = textTitle3.getFont();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.PiePlotState piePlotState17 = piePlot6.initialise(graphics2D11, rectangle2D12, piePlot14, (java.lang.Integer) (-97), plotRenderingInfo16);
        piePlot6.setShadowXOffset((double) '4');
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", font4, (org.jfree.chart.plot.Plot) piePlot6, true);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            jFreeChart21.draw(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(piePlotState17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        java.awt.Graphics2D graphics2D3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle2.arrange(graphics2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        pieLabelDistributor1.sort();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        float float4 = piePlot2.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator5);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        piePlot2.setShadowYOffset((double) (byte) 100);
        piePlot2.setNoDataMessage("UnitType.ABSOLUTE");
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer7.setPadding((double) 0.5f, 0.0d, 10.0d, (double) (byte) 10);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = blockContainer7.arrange(graphics2D13, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.lang.String str9 = piePlot8.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        double double12 = rectangleInsets10.calculateRightOutset((double) 0);
        double double14 = rectangleInsets10.calculateTopOutset((double) (-1));
        piePlot8.setLabelPadding(rectangleInsets10);
        double double17 = rectangleInsets10.extendWidth((double) (short) 100);
        jFreeChart3.setPadding(rectangleInsets10);
        try {
            org.jfree.chart.plot.XYPlot xYPlot19 = jFreeChart3.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 102.0d + "'", double17 == 102.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.LEFT" + "'", str1.equals("RectangleAnchor.LEFT"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        java.lang.Number number2 = null;
        java.lang.Comparable comparable3 = null;
        try {
            defaultKeyedValues2D0.addValue(number2, comparable3, (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart3.getLegend((int) (short) 100);
        try {
            org.jfree.chart.title.Title title7 = jFreeChart3.getSubtitle((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(legendTitle5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", "", "PieLabelLinkStyle.STANDARD");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        org.jfree.chart.title.LegendTitle legendTitle13 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot9);
        java.awt.Paint paint14 = null;
        try {
            legendTitle13.setItemPaint(paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getLabelGap();
        piePlot1.setBackgroundImageAlpha(0.0f);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            piePlot1.drawOutline(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) '4');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.getSectionOutlinesVisible();
        java.awt.Font font4 = piePlot1.getNoDataMessageFont();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("UnitType.ABSOLUTE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key UnitType.ABSOLUTE");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        piePlot1.setStartAngle(0.0d);
        piePlot1.setOutlineVisible(false);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        defaultCategoryDataset0.setValue((java.lang.Number) 0.025d, (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0);
        java.lang.Comparable comparable10 = null;
        try {
            defaultCategoryDataset0.incrementValue((double) 0.5f, comparable10, (java.lang.Comparable) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        java.awt.Paint paint3 = null;
        try {
            piePlot1.setBaseSectionPaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetGroup datasetGroup11 = piePlot6.getDatasetGroup();
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        piePlot6.setLabelBackgroundPaint(paint12);
        boolean boolean14 = textTitle2.equals((java.lang.Object) piePlot6);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        piePlot6.setDataset(pieDataset15);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = null;
        try {
            legendTitle7.setItemLabelPadding(rectangleInsets8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        java.lang.String str5 = piePlot4.getNoDataMessage();
        boolean boolean6 = piePlot4.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier7);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier7);
        piePlot1.setShadowXOffset((double) 1L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        java.lang.Object obj5 = textTitle2.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) 255);
        java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator1.getAttributedLabel((int) (short) 1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(attributedString6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            piePlot1.setInsets(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setInfo("");
        java.awt.Image image5 = null;
        projectInfo1.setLogo(image5);
        java.util.List list7 = projectInfo1.getContributors();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        boolean boolean10 = piePlot9.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot9);
        boolean boolean12 = projectInfo1.equals((java.lang.Object) jFreeChart11);
        org.jfree.chart.ui.Library library13 = null;
        try {
            projectInfo1.addLibrary(library13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        java.awt.Font font13 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font13);
        try {
            jFreeChart3.addSubtitle((int) (byte) 10, (org.jfree.chart.title.Title) textTitle14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        piePlot1.setPieIndex((int) (byte) 10);
        java.lang.Object obj6 = piePlot1.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        try {
            piePlot1.setLegendLabelGenerator(pieSectionLabelGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        try {
            legendTitle9.setLegendItemGraphicEdge(rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D0.getColumnKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list1 = defaultKeyedValues2D0.getRowKeys();
        java.lang.Comparable comparable3 = null;
        try {
            java.lang.Number number4 = defaultKeyedValues2D0.getValue((java.lang.Comparable) "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        jFreeChart3.setTextAntiAlias(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        float float4 = piePlot2.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator5);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        int int9 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) false);
        try {
            java.lang.Comparable comparable11 = defaultCategoryDataset0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle7.setPaint((java.awt.Paint) color8);
        java.lang.String str10 = textTitle7.getText();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot12);
        jFreeChart14.setAntiAlias(false);
        textTitle7.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart14);
        float float18 = jFreeChart14.getBackgroundImageAlpha();
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) pieToolTipGenerator4, jFreeChart14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str10.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo12 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
        projectInfo12.addLibrary((org.jfree.chart.ui.Library) projectInfo13);
        org.jfree.chart.ui.ProjectInfo projectInfo15 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo16 = org.jfree.chart.JFreeChart.INFO;
        projectInfo15.addLibrary((org.jfree.chart.ui.Library) projectInfo16);
        projectInfo16.setInfo("");
        java.awt.Image image20 = null;
        projectInfo16.setLogo(image20);
        org.jfree.chart.ui.Library[] libraryArray22 = projectInfo16.getOptionalLibraries();
        projectInfo13.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo16);
        try {
            java.lang.Object obj24 = legendTitle9.draw(graphics2D10, rectangle2D11, (java.lang.Object) projectInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(projectInfo12);
        org.junit.Assert.assertNotNull(projectInfo13);
        org.junit.Assert.assertNotNull(projectInfo15);
        org.junit.Assert.assertNotNull(projectInfo16);
        org.junit.Assert.assertNotNull(libraryArray22);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateRightOutset((double) 0);
        double double7 = rectangleInsets3.calculateTopOutset((double) (-1));
        piePlot1.setLabelPadding(rectangleInsets3);
        double double10 = rectangleInsets3.calculateRightInset((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets3.createInsetRectangle(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        java.awt.Paint paint7 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) (short) 10);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            piePlot1.drawOutline(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle1.setHorizontalAlignment(horizontalAlignment13);
        org.jfree.chart.block.BlockFrame blockFrame15 = textTitle1.getFrame();
        org.jfree.chart.block.BlockFrame blockFrame16 = textTitle1.getFrame();
        textTitle1.setExpandToFitSpace(false);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        try {
            org.jfree.chart.util.Size2D size2D21 = textTitle1.arrange(graphics2D19, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(blockFrame15);
        org.junit.Assert.assertNotNull(blockFrame16);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateRightOutset((double) 0);
        double double7 = rectangleInsets3.calculateTopOutset((double) (-1));
        piePlot1.setLabelPadding(rectangleInsets3);
        double double10 = rectangleInsets3.calculateRightOutset(0.0d);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        piePlot1.setPieIndex((int) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean8 = piePlot7.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot7);
        jFreeChart9.setAntiAlias(false);
        java.lang.Object obj12 = jFreeChart9.clone();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        try {
            org.jfree.chart.plot.XYPlot xYPlot14 = jFreeChart9.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 0.0f, (java.lang.Comparable) ' ', (java.lang.Comparable) (byte) 100);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D0.getColumnKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) ' ', 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart3.createBufferedImage(10, (int) (short) 0, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (10) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        piePlot1.handleClick((-97), (int) (short) 0, plotRenderingInfo8);
        try {
            piePlot1.setInteriorGap((double) (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-97.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer7.setPadding((double) 0.5f, 0.0d, 10.0d, (double) (byte) 10);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle15.setPaint((java.awt.Paint) color16);
        java.lang.String str18 = textTitle15.getText();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        boolean boolean21 = piePlot20.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot20);
        jFreeChart22.setAntiAlias(false);
        textTitle15.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        java.lang.String str28 = piePlot27.getNoDataMessage();
        float float29 = piePlot27.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator30 = null;
        piePlot27.setToolTipGenerator(pieToolTipGenerator30);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke34 = defaultDrawingSupplier33.getNextOutlineStroke();
        piePlot27.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke34);
        java.awt.Stroke stroke36 = piePlot27.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = new org.jfree.chart.util.RectangleInsets();
        piePlot27.setInsets(rectangleInsets37);
        textTitle15.setMargin(rectangleInsets37);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle15.getBounds();
        try {
            blockContainer7.draw(graphics2D13, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str18.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        java.lang.String str2 = pieLabelDistributor1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieSectionLabelGenerator1.generateSectionLabel(pieDataset2, (java.lang.Comparable) 255);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        try {
            java.text.AttributedString attributedString7 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset5, (java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) -1, 0.4d, (double) 10, 0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 10.0f, (double) '#', (-1.0d), 0.14d);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        chartEntity2.setToolTipText("");
        chartEntity2.setURLText("");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        java.awt.Color color9 = java.awt.Color.orange;
        jFreeChart3.setBorderPaint((java.awt.Paint) color9);
        int int11 = color9.getTransparency();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        double double4 = piePlot1.getInteriorGap();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color2 = color1.darker();
        java.awt.Color color3 = java.awt.Color.getColor("hi!", color2);
        int int4 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart3.getLegend();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        try {
            jFreeChart3.handleClick((int) (byte) 10, (-1), chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(legendTitle9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart5.setAntiAlias(false);
        java.lang.Object obj8 = jFreeChart5.clone();
        jFreeChart5.setNotify(true);
        java.lang.Object obj11 = jFreeChart5.getTextAntiAlias();
        boolean boolean12 = defaultCategoryDataset0.hasListener((java.util.EventListener) jFreeChart5);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        try {
            jFreeChart5.addSubtitle((-1), (org.jfree.chart.title.Title) textTitle15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment22);
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle10.getFrame();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer7.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) color25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = null;
        try {
            org.jfree.chart.util.Size2D size2D29 = blockContainer7.arrange(graphics2D27, rectangleConstraint28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleEdge.BOTTOM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        boolean boolean3 = defaultCategoryDataset0.equals((java.lang.Object) 1.0f);
        java.util.List list4 = defaultCategoryDataset0.getRowKeys();
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) "PieLabelLinkStyle.STANDARD");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: PieLabelLinkStyle.STANDARD");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D0.getColumnKey(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rect" + "'", str3.equals("rect"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartEntity: tooltip = " + "'", str4.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        java.awt.Paint paint9 = jFreeChart3.getBorderPaint();
        jFreeChart3.setTextAntiAlias(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        defaultKeyedValues2D0.removeColumn((int) (byte) 0);
        try {
            defaultKeyedValues2D0.removeColumn((-97));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.fireChartChanged();
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot8 = jFreeChart3.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Paint paint6 = null;
        jFreeChart5.setBorderPaint(paint6);
        try {
            org.jfree.chart.plot.XYPlot xYPlot8 = jFreeChart5.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setInfo("");
        java.awt.Image image5 = null;
        projectInfo1.setLogo(image5);
        java.util.List list7 = projectInfo1.getContributors();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        boolean boolean10 = piePlot9.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot9);
        boolean boolean12 = projectInfo1.equals((java.lang.Object) jFreeChart11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = null;
        try {
            java.awt.image.BufferedImage bufferedImage17 = jFreeChart11.createBufferedImage((int) (short) -1, (int) (short) 1, (int) (byte) 1, chartRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle1.setHorizontalAlignment(horizontalAlignment13);
        java.lang.String str15 = horizontalAlignment13.toString();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "HorizontalAlignment.CENTER" + "'", str15.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 0.0f, (java.lang.Comparable) ' ', (java.lang.Comparable) (byte) 100);
        try {
            java.lang.Comparable comparable6 = defaultKeyedValues2D0.getRowKey((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.AttributedString attributedString2 = standardPieSectionLabelGenerator0.getAttributedLabel(0);
        org.junit.Assert.assertNull(attributedString2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        try {
            defaultKeyedValues2D0.removeRow(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.fireChartChanged();
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart3.createBufferedImage((int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            java.awt.Color color1 = java.awt.Color.decode("PieSection: 0, 0(3)");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"PieSection: 0, 0(3)\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        java.lang.Comparable comparable6 = null;
        try {
            java.lang.Number number7 = defaultCategoryDataset0.getValue((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=]", comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = null;
        try {
            org.jfree.chart.util.Size2D size2D7 = textTitle2.arrange(graphics2D5, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment22);
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle10.getFrame();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer7.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) color25);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = null;
        try {
            org.jfree.chart.util.Size2D size2D29 = textTitle10.arrange(graphics2D27, rectangleConstraint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateRightOutset((double) 0);
        double double7 = rectangleInsets3.calculateTopOutset((double) (-1));
        piePlot1.setLabelPadding(rectangleInsets3);
        double double10 = rectangleInsets3.calculateRightInset((double) 0.0f);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets3.getUnitType();
        double double12 = rectangleInsets3.getLeft();
        double double13 = rectangleInsets3.getLeft();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setLicenceText("");
        projectInfo0.setLicenceName("HorizontalAlignment.CENTER");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = null;
        org.jfree.chart.util.Size2D size2D13 = legendTitle9.arrange(graphics2D11, rectangleConstraint12);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(size2D13);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "PieSection: 0, 0(3)");
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity7.setDataset(pieDataset11);
        pieSectionEntity7.setURLText("");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle1.getTextAlignment();
        java.lang.String str13 = horizontalAlignment12.toString();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "HorizontalAlignment.CENTER" + "'", str13.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.lang.String str4 = piePlot3.getNoDataMessage();
        boolean boolean5 = piePlot3.isCircular();
        java.awt.Stroke stroke7 = piePlot3.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.PiePlotState piePlotState14 = piePlot3.initialise(graphics2D8, rectangle2D9, piePlot11, (java.lang.Integer) (-97), plotRenderingInfo13);
        piePlot3.setShadowXOffset((double) '4');
        double double17 = piePlot3.getInteriorGap();
        piePlot3.zoom((double) (byte) 10);
        piePlot3.setShadowXOffset((double) 100);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(piePlotState14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.08d + "'", double17 == 0.08d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        piePlot1.markerChanged(markerChangeEvent13);
        java.awt.Color color19 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) (short) 1, (double) ' ', 0.0d, (java.awt.Paint) color19);
        piePlot1.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator23 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.Object obj24 = standardPieSectionLabelGenerator23.clone();
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator23);
        java.text.NumberFormat numberFormat26 = standardPieSectionLabelGenerator23.getPercentFormat();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(numberFormat26);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        try {
            java.lang.String[] strArray4 = jFreeChartResources0.getStringArray("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        defaultKeyedValues2D0.removeColumn((int) (byte) 0);
        try {
            defaultKeyedValues2D0.removeColumn((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "");
        java.lang.String str5 = chartEntity4.getURLText();
        boolean boolean6 = rectangleInsets1.equals((java.lang.Object) str5);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.lang.String str8 = piePlot7.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.calculateRightOutset((double) 0);
        double double13 = rectangleInsets9.calculateTopOutset((double) (-1));
        piePlot7.setLabelPadding(rectangleInsets9);
        double double16 = rectangleInsets9.calculateRightInset((double) 0.0f);
        jFreeChart5.setPadding(rectangleInsets9);
        java.awt.Image image18 = jFreeChart5.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNull(image18);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        float float4 = piePlot2.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator5);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        java.util.List list8 = defaultCategoryDataset0.getRowKeys();
        java.util.List list9 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup10 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj11 = datasetGroup10.clone();
        defaultCategoryDataset0.setGroup(datasetGroup10);
        try {
            java.lang.Comparable comparable14 = defaultCategoryDataset0.getColumnKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        try {
            defaultKeyedValues2D0.removeColumn(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setNoDataMessage("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        piePlot1.setMaximumLabelWidth((double) (byte) -1);
        float float17 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot1.getInsets();
        boolean boolean20 = rectangleInsets18.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str4 = standardPieSectionLabelGenerator3.getLabelFormat();
        java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator3.getAttributedLabel((-97));
        java.text.NumberFormat numberFormat7 = standardPieSectionLabelGenerator3.getPercentFormat();
        int int8 = objectList1.indexOf((java.lang.Object) standardPieSectionLabelGenerator3);
        java.lang.Object obj9 = objectList1.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertNull(attributedString6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) '#', 0.0f, (float) 10L);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isOutlineVisible();
        float float5 = piePlot3.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot3.setURLGenerator(pieURLGenerator6);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot3.getLabelGenerator();
        java.awt.Shape shape9 = piePlot3.getLegendItemShape();
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot3.setBaseSectionPaint((java.awt.Paint) color10);
        boolean boolean12 = rectangleEdge0.equals((java.lang.Object) color10);
        java.awt.Color color13 = java.awt.Color.PINK;
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int15 = color14.getTransparency();
        float[] floatArray16 = null;
        float[] floatArray17 = color14.getComponents(floatArray16);
        float[] floatArray18 = color13.getRGBComponents(floatArray17);
        float[] floatArray19 = color10.getComponents(floatArray17);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        int int9 = pieSectionEntity7.getPieIndex();
        java.lang.Comparable comparable10 = pieSectionEntity7.getSectionKey();
        int int11 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 3 + "'", comparable10.equals(3));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "PieSection: 0, 0(3)");
        java.lang.String str11 = pieSectionEntity7.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setLicenceText("");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        projectInfo5.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
        projectInfo5.setLicenceName("rect");
        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
        projectInfo5.setInfo("");
        org.jfree.chart.ui.Library library13 = null;
        try {
            projectInfo5.addLibrary(library13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(projectInfo6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setLicenceName("rect");
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle6.setPaint((java.awt.Paint) color7);
        java.lang.String str9 = textTitle6.getText();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        boolean boolean12 = piePlot11.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot11);
        jFreeChart13.setAntiAlias(false);
        textTitle6.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart13);
        java.awt.image.BufferedImage bufferedImage19 = jFreeChart13.createBufferedImage(1, (int) (byte) 1);
        projectInfo0.setLogo((java.awt.Image) bufferedImage19);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str9.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(bufferedImage19);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setInfo("");
        java.awt.Image image5 = null;
        projectInfo1.setLogo(image5);
        java.util.List list7 = projectInfo1.getContributors();
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        boolean boolean10 = piePlot9.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot9);
        boolean boolean12 = projectInfo1.equals((java.lang.Object) jFreeChart11);
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle15.setPaint((java.awt.Paint) color16);
        java.lang.String str18 = textTitle15.getText();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        boolean boolean21 = piePlot20.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot20);
        jFreeChart22.setAntiAlias(false);
        textTitle15.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart22);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment26 = textTitle15.getTextAlignment();
        java.awt.Font font28 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle29 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font28);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = textTitle29.getHorizontalAlignment();
        textTitle15.setTextAlignment(horizontalAlignment30);
        try {
            jFreeChart11.addSubtitle(2, (org.jfree.chart.title.Title) textTitle15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str18.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        float float6 = piePlot1.getBackgroundAlpha();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.lang.String str8 = piePlot7.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.calculateRightOutset((double) 0);
        double double13 = rectangleInsets9.calculateTopOutset((double) (-1));
        piePlot7.setLabelPadding(rectangleInsets9);
        double double16 = rectangleInsets9.calculateRightInset((double) 0.0f);
        jFreeChart5.setPadding(rectangleInsets9);
        java.util.List list18 = jFreeChart5.getSubtitles();
        org.jfree.chart.event.ChartChangeListener chartChangeListener19 = null;
        try {
            jFreeChart5.addChangeListener(chartChangeListener19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke8);
        java.awt.Stroke stroke10 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        piePlot1.setInsets(rectangleInsets11);
        piePlot1.setSectionOutlinesVisible(true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Color color16 = java.awt.Color.PINK;
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle20.setPaint((java.awt.Paint) color21);
        java.lang.String str23 = textTitle20.getText();
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        boolean boolean26 = piePlot25.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot25);
        jFreeChart27.setAntiAlias(false);
        textTitle20.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart27);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        java.lang.String str33 = piePlot32.getNoDataMessage();
        float float34 = piePlot32.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator35 = null;
        piePlot32.setToolTipGenerator(pieToolTipGenerator35);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
        piePlot32.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke39);
        java.awt.Stroke stroke41 = piePlot32.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets();
        piePlot32.setInsets(rectangleInsets42);
        textTitle20.setMargin(rectangleInsets42);
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle20.getBounds();
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = color16.createContext(colorModel17, rectangle18, rectangle2D45, affineTransform46, renderingHints47);
        java.awt.geom.Point2D point2D49 = null;
        org.jfree.chart.plot.PlotState plotState50 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        try {
            piePlot1.draw(graphics2D15, (java.awt.geom.Rectangle2D) rectangle18, point2D49, plotState50, plotRenderingInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str23.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(paintContext48);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        float float4 = piePlot2.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator5);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        java.util.List list8 = defaultCategoryDataset0.getRowKeys();
        try {
            java.lang.Comparable comparable10 = defaultCategoryDataset0.getColumnKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("UnitType.ABSOLUTE", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        java.lang.String str2 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOID" + "'", str2.equals("NOID"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        java.awt.Font font3 = textTitle2.getFont();
        textTitle2.setPadding(3.0d, (double) 1.0f, 1.0E-5d, (double) (short) 100);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = textTitle2.arrange(graphics2D9, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        piePlot1.setPieIndex((int) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean8 = piePlot7.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot7);
        jFreeChart9.setAntiAlias(false);
        java.lang.Object obj12 = jFreeChart9.clone();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        java.lang.Object obj14 = jFreeChart9.getTextAntiAlias();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.lang.String str6 = textTitle3.getText();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot8);
        jFreeChart10.setAntiAlias(false);
        textTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart10);
        org.jfree.chart.plot.Plot plot14 = jFreeChart10.getPlot();
        boolean boolean15 = columnArrangement0.equals((java.lang.Object) plot14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) 100L, (double) 100);
        flowArrangement20.clear();
        org.jfree.chart.block.BlockContainer blockContainer22 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement20);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = null;
        try {
            org.jfree.chart.util.Size2D size2D25 = columnArrangement0.arrange(blockContainer22, graphics2D23, rectangleConstraint24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str6.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str4 = jFreeChartResources0.getString("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strEnumeration2);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image3, "rect", "", "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "");
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a', jFreeChart10, chartChangeEventType11);
        chartChangeEvent8.setType(chartChangeEventType11);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = chartChangeEvent8.getType();
        org.jfree.chart.JFreeChart jFreeChart15 = chartChangeEvent8.getChart();
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertNull(jFreeChart15);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        try {
            java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.generateAttributedSectionLabel(pieDataset2, (java.lang.Comparable) "ChartEntity: tooltip = ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        java.awt.Paint paint7 = null;
        jFreeChart3.setBorderPaint(paint7);
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.lang.String str4 = piePlot3.getNoDataMessage();
        boolean boolean5 = piePlot3.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot3.axisChanged(axisChangeEvent8);
        piePlot3.setStartAngle(0.0d);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle16.setPaint((java.awt.Paint) color17);
        java.lang.String str19 = textTitle16.getText();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        boolean boolean22 = piePlot21.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot21);
        jFreeChart23.setAntiAlias(false);
        textTitle16.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart23);
        java.awt.Paint paint27 = textTitle16.getPaint();
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle16.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        try {
            jFreeChart13.draw(graphics2D14, rectangle2D28, chartRenderingInfo29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str19.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangle2D28);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        try {
            java.lang.Number number8 = defaultKeyedValues2D0.getValue(0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int3 = java.awt.Color.HSBtoRGB((float) 15, (float) 10L, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        java.lang.Object obj3 = standardPieSectionLabelGenerator1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str2.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        piePlot1.setPieIndex((int) (byte) -1);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.lang.String str8 = piePlot7.getNoDataMessage();
        float float9 = piePlot7.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator10 = null;
        piePlot7.setToolTipGenerator(pieToolTipGenerator10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        piePlot7.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke14);
        piePlot1.setLabelLinkStroke(stroke14);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list18 = defaultCategoryDataset17.getColumnKeys();
        int int19 = defaultCategoryDataset17.getRowCount();
        boolean boolean20 = piePlot1.equals((java.lang.Object) defaultCategoryDataset17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        piePlot1.zoom((double) (byte) 10);
        piePlot1.setIgnoreNullValues(true);
        java.awt.Paint paint20 = piePlot1.getShadowPaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key (C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle9.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendTitle9.arrange(graphics2D13, rectangleConstraint14);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle9.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle9.getPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = legendTitle9.getLegendItemGraphicPadding();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        boolean boolean22 = piePlot21.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot21);
        jFreeChart23.setAntiAlias(false);
        java.lang.Object obj26 = jFreeChart23.clone();
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.lang.String str29 = piePlot28.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.calculateRightOutset((double) 0);
        double double34 = rectangleInsets30.calculateTopOutset((double) (-1));
        piePlot28.setLabelPadding(rectangleInsets30);
        double double37 = rectangleInsets30.extendWidth((double) (short) 100);
        jFreeChart23.setPadding(rectangleInsets30);
        double double40 = rectangleInsets30.calculateLeftOutset(0.08d);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D43 = textTitle42.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D45 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D43, rectangleAnchor44);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets30.createAdjustedRectangle(rectangle2D43, lengthAdjustmentType46, lengthAdjustmentType47);
        java.awt.Paint[] paintArray49 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray50 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray51 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray52 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Shape shape53 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape54 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset55 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity61 = new org.jfree.chart.entity.PieSectionEntity(shape54, pieDataset55, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.awt.Shape shape62 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape shape63 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape64 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape[] shapeArray65 = new java.awt.Shape[] { shape53, shape54, shape62, shape63, shape64 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier66 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray49, paintArray50, strokeArray51, strokeArray52, shapeArray65);
        try {
            java.lang.Object obj67 = legendTitle9.draw(graphics2D19, rectangle2D48, (java.lang.Object) strokeArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 102.0d + "'", double37 == 102.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(point2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(paintArray49);
        org.junit.Assert.assertNotNull(paintArray50);
        org.junit.Assert.assertNotNull(strokeArray51);
        org.junit.Assert.assertNotNull(strokeArray52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(shapeArray65);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        try {
            java.lang.Comparable comparable3 = defaultKeyedValues2D0.getRowKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart5.setAntiAlias(false);
        java.lang.Object obj8 = jFreeChart5.clone();
        jFreeChart5.setNotify(true);
        java.lang.Object obj11 = jFreeChart5.getTextAntiAlias();
        boolean boolean12 = defaultCategoryDataset0.hasListener((java.util.EventListener) jFreeChart5);
        try {
            java.lang.Number number15 = defaultCategoryDataset0.getValue((-16777216), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        piePlot1.setBackgroundImageAlignment((int) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.image.ColorModel colorModel22 = null;
        java.awt.Rectangle rectangle23 = null;
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        java.lang.String str26 = piePlot25.getNoDataMessage();
        float float27 = piePlot25.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator28 = null;
        piePlot25.setToolTipGenerator(pieToolTipGenerator28);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke32 = defaultDrawingSupplier31.getNextOutlineStroke();
        piePlot25.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke32);
        java.awt.Stroke stroke34 = piePlot25.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = new org.jfree.chart.util.RectangleInsets();
        piePlot25.setInsets(rectangleInsets35);
        java.lang.Object obj37 = null;
        boolean boolean38 = rectangleInsets35.equals(obj37);
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        java.lang.String str41 = piePlot40.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets();
        double double44 = rectangleInsets42.calculateRightOutset((double) 0);
        double double46 = rectangleInsets42.calculateTopOutset((double) (-1));
        piePlot40.setLabelPadding(rectangleInsets42);
        double double49 = rectangleInsets42.extendWidth((double) (short) 100);
        double double51 = rectangleInsets42.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D54 = textTitle53.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D56 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D54, rectangleAnchor55);
        java.awt.geom.Rectangle2D rectangle2D57 = rectangleInsets42.createInsetRectangle(rectangle2D54);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets35.createAdjustedRectangle(rectangle2D54, lengthAdjustmentType58, lengthAdjustmentType59);
        java.awt.geom.AffineTransform affineTransform61 = null;
        java.awt.RenderingHints renderingHints62 = null;
        java.awt.PaintContext paintContext63 = color21.createContext(colorModel22, rectangle23, rectangle2D60, affineTransform61, renderingHints62);
        try {
            piePlot1.drawOutline(graphics2D20, (java.awt.geom.Rectangle2D) rectangle23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 102.0d + "'", double49 == 102.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertNotNull(point2D56);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(paintContext63);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        defaultKeyedValues2D0.removeColumn((int) (byte) 0);
        defaultKeyedValues2D0.clear();
        java.lang.Comparable comparable11 = null;
        try {
            defaultKeyedValues2D0.addValue((java.lang.Number) 0.4d, (java.lang.Comparable) "RectangleAnchor.LEFT", comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot0.getDataset();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable1 = null;
        try {
            defaultCategoryDataset0.removeRow(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle1.setHorizontalAlignment(horizontalAlignment13);
        org.jfree.chart.block.BlockFrame blockFrame15 = textTitle1.getFrame();
        java.lang.String str16 = textTitle1.getToolTipText();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(blockFrame15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        defaultCategoryDataset0.addValue((-1.0d), (java.lang.Comparable) "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", (java.lang.Comparable) 0L);
        java.lang.Comparable comparable7 = defaultCategoryDataset0.getRowKey(0);
        java.lang.Comparable comparable9 = defaultCategoryDataset0.getRowKey(0);
        try {
            java.lang.Number number12 = defaultCategoryDataset0.getValue((java.lang.Comparable) "RectangleEdge.BOTTOM", (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: true");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", comparable7.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", comparable9.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Font font1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.lang.String str4 = piePlot3.getNoDataMessage();
        boolean boolean5 = piePlot3.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = null;
        piePlot3.axisChanged(axisChangeEvent8);
        piePlot3.setStartAngle(0.0d);
        org.jfree.chart.JFreeChart jFreeChart13 = new org.jfree.chart.JFreeChart("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", font1, (org.jfree.chart.plot.Plot) piePlot3, false);
        java.awt.Image image14 = jFreeChart13.getBackgroundImage();
        java.lang.Object obj15 = jFreeChart13.clone();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(image14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        java.awt.Shape shape7 = piePlot1.getLegendItemShape();
        boolean boolean8 = piePlot1.getIgnoreZeroValues();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) (short) 10, (float) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-123) + "'", int3 == (-123));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) (-1.0d));
        java.lang.String str11 = pieSectionEntity7.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str11.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        defaultKeyedValues2D0.removeColumn((int) (byte) 0);
        int int8 = defaultKeyedValues2D0.getRowCount();
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) "PieSection: 0, 0(-1.0)");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent16 = null;
        piePlot1.datasetChanged(datasetChangeEvent16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot1.getSimpleLabelOffset();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity7.setDataset(pieDataset11);
        java.lang.String str13 = pieSectionEntity7.getToolTipText();
        java.lang.Object obj14 = pieSectionEntity7.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.BOTTOM" + "'", str13.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        piePlot1.zoom((double) (byte) 10);
        piePlot1.setShadowXOffset((double) 100);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        piePlot1.notifyListeners(plotChangeEvent20);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        float float4 = piePlot2.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator5);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        org.jfree.chart.plot.Plot plot8 = piePlot2.getParent();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        try {
            plot8.axisChanged(axisChangeEvent9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0], locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        boolean boolean4 = piePlot1.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        try {
            java.awt.image.BufferedImage bufferedImage9 = jFreeChart5.createBufferedImage((int) ' ', 0, chartRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (32) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.lang.String str8 = piePlot7.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        double double11 = rectangleInsets9.calculateRightOutset((double) 0);
        double double13 = rectangleInsets9.calculateTopOutset((double) (-1));
        piePlot7.setLabelPadding(rectangleInsets9);
        double double16 = rectangleInsets9.calculateRightInset((double) 0.0f);
        jFreeChart5.setPadding(rectangleInsets9);
        float float18 = jFreeChart5.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.5f + "'", float18 == 0.5f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        textTitle1.setWidth((double) (-97));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 3, (double) (byte) 0, (double) (short) 0, (double) 0.5f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        defaultKeyedValues2D0.removeColumn((int) (byte) 0);
        defaultKeyedValues2D0.clear();
        try {
            java.lang.Comparable comparable10 = defaultKeyedValues2D0.getRowKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getLabelPadding();
        double double6 = rectangleInsets4.calculateBottomInset((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart3.getLegend((int) (short) 100);
        java.awt.Paint paint6 = jFreeChart3.getBorderPaint();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent7 = null;
        try {
            jFreeChart3.titleChanged(titleChangeEvent7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(legendTitle5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        pieLabelDistributor1.sort();
        pieLabelDistributor1.clear();
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("-4,-4,4,4", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image3, "rect", "", "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isOutlineVisible();
        float float14 = piePlot12.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        piePlot12.setURLGenerator(pieURLGenerator15);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot12.getLabelGenerator();
        java.awt.Shape shape18 = piePlot12.getLegendItemShape();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot12.setBaseSectionPaint((java.awt.Paint) color19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", (org.jfree.chart.plot.Plot) piePlot12);
        java.awt.Stroke stroke22 = jFreeChart21.getBorderStroke();
        boolean boolean23 = chartChangeEventType9.equals((java.lang.Object) stroke22);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle25.setPaint((java.awt.Paint) color26);
        java.lang.String str28 = textTitle25.getText();
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        boolean boolean31 = piePlot30.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot30);
        jFreeChart32.setAntiAlias(false);
        textTitle25.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart32);
        java.awt.Paint paint36 = textTitle25.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment37 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle25.setHorizontalAlignment(horizontalAlignment37);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.data.general.PieDataset pieDataset40 = null;
        org.jfree.chart.plot.PiePlot piePlot41 = new org.jfree.chart.plot.PiePlot(pieDataset40);
        java.lang.String str42 = piePlot41.getNoDataMessage();
        float float43 = piePlot41.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator44 = null;
        piePlot41.setToolTipGenerator(pieToolTipGenerator44);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier47 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke48 = defaultDrawingSupplier47.getNextOutlineStroke();
        piePlot41.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke48);
        java.awt.Stroke stroke50 = piePlot41.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = new org.jfree.chart.util.RectangleInsets();
        piePlot41.setInsets(rectangleInsets51);
        java.lang.Object obj53 = null;
        boolean boolean54 = rectangleInsets51.equals(obj53);
        org.jfree.data.general.PieDataset pieDataset55 = null;
        org.jfree.chart.plot.PiePlot piePlot56 = new org.jfree.chart.plot.PiePlot(pieDataset55);
        java.lang.String str57 = piePlot56.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = new org.jfree.chart.util.RectangleInsets();
        double double60 = rectangleInsets58.calculateRightOutset((double) 0);
        double double62 = rectangleInsets58.calculateTopOutset((double) (-1));
        piePlot56.setLabelPadding(rectangleInsets58);
        double double65 = rectangleInsets58.extendWidth((double) (short) 100);
        double double67 = rectangleInsets58.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D70 = textTitle69.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor71 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D72 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D70, rectangleAnchor71);
        java.awt.geom.Rectangle2D rectangle2D73 = rectangleInsets58.createInsetRectangle(rectangle2D70);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType74 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType75 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets51.createAdjustedRectangle(rectangle2D70, lengthAdjustmentType74, lengthAdjustmentType75);
        java.awt.Shape shape77 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity79 = new org.jfree.chart.entity.ChartEntity(shape77, "");
        java.lang.String str80 = chartEntity79.toString();
        java.lang.Object obj81 = textTitle25.draw(graphics2D39, rectangle2D76, (java.lang.Object) str80);
        boolean boolean82 = chartChangeEventType9.equals(obj81);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str28.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(horizontalAlignment37);
        org.junit.Assert.assertNull(str42);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 1.0f + "'", float43 == 1.0f);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(str57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60 == 1.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62 == 1.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 102.0d + "'", double65 == 102.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(rectangleAnchor71);
        org.junit.Assert.assertNotNull(point2D72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "ChartEntity: tooltip = " + "'", str80.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertNull(obj81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = legendTitle9.getItemLabelPadding();
        double double14 = rectangleInsets12.calculateTopInset((double) 0.5f);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.image.BufferedImage bufferedImage14 = jFreeChart8.createBufferedImage(1, (int) (byte) 1);
        jFreeChart8.setBorderVisible(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.lang.String str20 = piePlot19.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets();
        double double23 = rectangleInsets21.calculateRightOutset((double) 0);
        double double25 = rectangleInsets21.calculateTopOutset((double) (-1));
        piePlot19.setLabelPadding(rectangleInsets21);
        double double28 = rectangleInsets21.extendWidth((double) (short) 100);
        double double30 = rectangleInsets21.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle32.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets21.createInsetRectangle(rectangle2D33);
        try {
            jFreeChart8.draw(graphics2D17, rectangle2D36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(bufferedImage14);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 102.0d + "'", double28 == 102.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(rectangle2D36);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.lang.String str9 = piePlot8.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        double double12 = rectangleInsets10.calculateRightOutset((double) 0);
        double double14 = rectangleInsets10.calculateTopOutset((double) (-1));
        piePlot8.setLabelPadding(rectangleInsets10);
        double double17 = rectangleInsets10.extendWidth((double) (short) 100);
        jFreeChart3.setPadding(rectangleInsets10);
        double double20 = rectangleInsets10.calculateLeftOutset(0.08d);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle22.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D25 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D23, rectangleAnchor24);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets10.createAdjustedRectangle(rectangle2D23, lengthAdjustmentType26, lengthAdjustmentType27);
        double double30 = rectangleInsets10.calculateLeftInset((double) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 102.0d + "'", double17 == 102.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(point2D25);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        java.awt.Stroke stroke9 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean10 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.lang.String str14 = piePlot13.getNoDataMessage();
        float float15 = piePlot13.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot13.setToolTipGenerator(pieToolTipGenerator16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke20);
        java.awt.Stroke stroke22 = piePlot13.getLabelOutlineStroke();
        java.awt.Color color23 = java.awt.Color.white;
        piePlot13.setLabelLinkPaint((java.awt.Paint) color23);
        piePlot1.setSectionPaint((java.lang.Comparable) '#', (java.awt.Paint) color23);
        int int26 = color23.getBlue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 255 + "'", int26 == 255);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) false, (java.lang.Comparable) '4');
        try {
            java.lang.Number number7 = defaultKeyedValues2D1.getValue(1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        org.jfree.chart.plot.Plot plot9 = jFreeChart3.getPlot();
        java.awt.Color color10 = java.awt.Color.yellow;
        int int11 = color10.getAlpha();
        jFreeChart3.setBorderPaint((java.awt.Paint) color10);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) (short) -1, 0.4d, (double) 10, 0.0d);
        java.awt.Color color22 = java.awt.Color.getColor("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]", (-1));
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        java.lang.String str25 = piePlot24.getNoDataMessage();
        boolean boolean26 = piePlot24.isCircular();
        java.awt.Stroke stroke28 = piePlot24.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = piePlot24.initialise(graphics2D29, rectangle2D30, piePlot32, (java.lang.Integer) (-97), plotRenderingInfo34);
        piePlot24.setShadowXOffset((double) '4');
        double double38 = piePlot24.getInteriorGap();
        org.jfree.chart.util.Rotation rotation39 = piePlot24.getDirection();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        piePlot24.setDataset(pieDataset40);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke43 = defaultDrawingSupplier42.getNextOutlineStroke();
        piePlot24.setLabelLinkStroke(stroke43);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot(pieDataset45);
        java.lang.String str47 = piePlot46.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets();
        double double50 = rectangleInsets48.calculateRightOutset((double) 0);
        double double52 = rectangleInsets48.calculateTopOutset((double) (-1));
        piePlot46.setLabelPadding(rectangleInsets48);
        double double55 = rectangleInsets48.calculateRightInset((double) 0.0f);
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color22, stroke43, rectangleInsets48);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D60 = textTitle59.getBounds();
        lineBorder56.draw(graphics2D57, rectangle2D60);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets19.createInsetRectangle(rectangle2D60, false, true);
        org.jfree.chart.title.TextTitle textTitle66 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D67 = textTitle66.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D69 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D67, rectangleAnchor68);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = null;
        try {
            jFreeChart3.draw(graphics2D13, rectangle2D60, point2D69, chartRenderingInfo70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.08d + "'", double38 == 0.08d);
        org.junit.Assert.assertNotNull(rotation39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D64);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(point2D69);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(1.0E-5d, (double) 0.5f, (double) (short) 10, (double) 0L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setNoDataMessage("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        piePlot1.setMaximumLabelWidth((double) (byte) -1);
        float float17 = piePlot1.getBackgroundImageAlpha();
        boolean boolean18 = piePlot1.isCircular();
        java.lang.Comparable comparable19 = null;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        java.lang.String str22 = piePlot21.getNoDataMessage();
        float float23 = piePlot21.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator24 = null;
        piePlot21.setToolTipGenerator(pieToolTipGenerator24);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke28 = defaultDrawingSupplier27.getNextOutlineStroke();
        piePlot21.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke28);
        java.awt.Stroke stroke30 = piePlot21.getLabelOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        java.lang.String str33 = piePlot32.getNoDataMessage();
        boolean boolean34 = piePlot32.isCircular();
        java.awt.Stroke stroke36 = piePlot32.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.data.general.PieDataset pieDataset39 = null;
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot(pieDataset39);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        org.jfree.chart.plot.PiePlotState piePlotState43 = piePlot32.initialise(graphics2D37, rectangle2D38, piePlot40, (java.lang.Integer) (-97), plotRenderingInfo42);
        piePlot32.setShadowXOffset((double) '4');
        double double46 = piePlot32.getInteriorGap();
        java.awt.Stroke stroke47 = piePlot32.getBaseSectionOutlineStroke();
        piePlot21.setLabelOutlineStroke(stroke47);
        try {
            piePlot1.setSectionOutlineStroke(comparable19, stroke47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(stroke36);
        org.junit.Assert.assertNotNull(piePlotState43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.08d + "'", double46 == 0.08d);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateRightOutset((double) 0);
        double double7 = rectangleInsets3.calculateTopOutset((double) (-1));
        piePlot1.setLabelPadding(rectangleInsets3);
        double double10 = rectangleInsets3.calculateRightInset((double) 0.0f);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets3.getUnitType();
        double double13 = rectangleInsets3.extendHeight((double) (short) 10);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 12.0d + "'", double13 == 12.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        int int9 = pieSectionEntity7.getPieIndex();
        java.lang.String str10 = pieSectionEntity7.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RectangleEdge.BOTTOM" + "'", str10.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        java.util.List list6 = defaultKeyedValues2D0.getColumnKeys();
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        java.awt.Stroke stroke16 = piePlot1.getBaseSectionOutlineStroke();
        double double18 = piePlot1.getExplodePercent((java.lang.Comparable) "-4,-4,4,4");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        piePlot1.zoom((double) (byte) 10);
        piePlot1.setIgnoreNullValues(true);
        org.jfree.data.general.DatasetGroup datasetGroup20 = piePlot1.getDatasetGroup();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNull(datasetGroup20);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        boolean boolean3 = rectangleEdge0.equals((java.lang.Object) paint2);
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color7.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int15 = color14.getTransparency();
        float[] floatArray16 = null;
        float[] floatArray17 = color14.getComponents(floatArray16);
        float[] floatArray18 = color7.getColorComponents(floatArray17);
        float[] floatArray19 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (byte) 10, 0, floatArray18);
        boolean boolean20 = rectangleEdge0.equals((java.lang.Object) (byte) 10);
        boolean boolean21 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintContext13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color3 = java.awt.Color.white;
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color5 = java.awt.Color.cyan;
        float[] floatArray10 = new float[] { 0L, 10L, (-1L), 100L };
        float[] floatArray11 = color5.getColorComponents(floatArray10);
        float[] floatArray12 = color4.getRGBComponents(floatArray11);
        float[] floatArray13 = color3.getColorComponents(floatArray12);
        float[] floatArray14 = java.awt.Color.RGBtoHSB(1, (int) (byte) -1, (int) (short) 0, floatArray13);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        boolean boolean2 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        java.lang.String str3 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleEdge.BOTTOM" + "'", str3.equals("RectangleEdge.BOTTOM"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("PieLabelLinkStyle.STANDARD");
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        java.lang.Object obj3 = objectList1.get(0);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateRightOutset((double) 0);
        double double7 = rectangleInsets3.calculateTopOutset((double) (-1));
        piePlot1.setLabelPadding(rectangleInsets3);
        piePlot1.setMaximumLabelWidth((double) (byte) 0);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot1.setLabelOutlinePaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateRightOutset((double) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge16);
        java.awt.Paint paint18 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        boolean boolean19 = rectangleEdge16.equals((java.lang.Object) paint18);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder(rectangleInsets13, paint18);
        piePlot1.setOutlinePaint(paint18);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            piePlot1.drawOutline(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        objectList1.clear();
        java.lang.Object obj4 = objectList1.get((int) '#');
        int int5 = objectList1.size();
        java.lang.Object obj7 = objectList1.get(2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.awt.Color color0 = java.awt.Color.white;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment22);
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle10.getFrame();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer7.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) color25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment27);
        java.lang.String str29 = horizontalAlignment27.toString();
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "HorizontalAlignment.CENTER" + "'", str29.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D2 = textTitle1.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D4 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D2, rectangleAnchor3);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D();
        int int6 = defaultKeyedValues2D5.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.lang.String str9 = piePlot8.getNoDataMessage();
        boolean boolean10 = piePlot8.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator11 = piePlot8.getLegendLabelToolTipGenerator();
        float float12 = piePlot8.getForegroundAlpha();
        double double13 = piePlot8.getInteriorGap();
        java.awt.Paint paint14 = piePlot8.getBackgroundPaint();
        boolean boolean15 = defaultKeyedValues2D5.equals((java.lang.Object) paint14);
        defaultKeyedValues2D5.setValue((java.lang.Number) (-1), (java.lang.Comparable) 1.0f, (java.lang.Comparable) (-1));
        boolean boolean20 = rectangleAnchor3.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(rectangle2D2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08d + "'", double13 == 0.08d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_START_ANGLE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 90.0d + "'", double0 == 90.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity7.setDataset(pieDataset11);
        java.lang.String str13 = pieSectionEntity7.getToolTipText();
        java.lang.String str14 = pieSectionEntity7.toString();
        java.lang.String str15 = pieSectionEntity7.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.BOTTOM" + "'", str13.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieSection: 0, 0(-1.0)" + "'", str14.equals("PieSection: 0, 0(-1.0)"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str15.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("");
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle13.getBounds();
        jFreeChart8.addSubtitle((org.jfree.chart.title.Title) textTitle13);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangle2D14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.ABSOLUTE", (-8388608));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        jFreeChart3.setBorderVisible(false);
        try {
            org.jfree.chart.title.Title title12 = jFreeChart3.getSubtitle((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isOutlineVisible();
        float float5 = piePlot3.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = null;
        piePlot3.setURLGenerator(pieURLGenerator6);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot3.getLabelGenerator();
        piePlot3.setSimpleLabels(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.lang.String str14 = piePlot13.getNoDataMessage();
        float float15 = piePlot13.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot13.setToolTipGenerator(pieToolTipGenerator16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke20);
        java.awt.Stroke stroke22 = piePlot13.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets();
        piePlot13.setInsets(rectangleInsets23);
        java.lang.Object obj25 = null;
        boolean boolean26 = rectangleInsets23.equals(obj25);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.lang.String str29 = piePlot28.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        double double32 = rectangleInsets30.calculateRightOutset((double) 0);
        double double34 = rectangleInsets30.calculateTopOutset((double) (-1));
        piePlot28.setLabelPadding(rectangleInsets30);
        double double37 = rectangleInsets30.extendWidth((double) (short) 100);
        double double39 = rectangleInsets30.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle41.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor43);
        java.awt.geom.Rectangle2D rectangle2D45 = rectangleInsets30.createInsetRectangle(rectangle2D42);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets23.createAdjustedRectangle(rectangle2D42, lengthAdjustmentType46, lengthAdjustmentType47);
        piePlot3.drawBackgroundImage(graphics2D11, rectangle2D48);
        try {
            blockBorder0.draw(graphics2D1, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 102.0d + "'", double37 == 102.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D48);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(2, 15, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        boolean boolean3 = defaultCategoryDataset0.equals((java.lang.Object) 1.0f);
        defaultCategoryDataset0.addValue((double) 10L, (java.lang.Comparable) 0.025d, (java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        java.lang.String str11 = piePlot10.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets();
        double double14 = rectangleInsets12.calculateRightOutset((double) 0);
        double double16 = rectangleInsets12.calculateTopOutset((double) (-1));
        piePlot10.setLabelPadding(rectangleInsets12);
        piePlot10.setMaximumLabelWidth((double) (byte) 0);
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot10.setLabelOutlinePaint((java.awt.Paint) color20);
        piePlot10.setMinimumArcAngleToDraw((double) (-97));
        java.awt.Color color25 = java.awt.Color.BLUE;
        piePlot10.setSectionOutlinePaint((java.lang.Comparable) (byte) 1, (java.awt.Paint) color25);
        boolean boolean27 = rectangleEdge8.equals((java.lang.Object) (byte) 1);
        boolean boolean28 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image3, "rect", "", "PieLabelLinkStyle.STANDARD");
        java.lang.String str8 = projectInfo7.getName();
        projectInfo7.setCopyright("TableOrder.BY_COLUMN");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str8.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_ROW;
        org.junit.Assert.assertNotNull(tableOrder0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        piePlot1.setShadowYOffset(0.4d);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        piePlot1.setDataset(pieDataset6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        textTitle1.setPadding(0.025d, (double) 'a', (double) (byte) 0, 8.0d);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle1.arrange(graphics2D7, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        org.jfree.chart.util.Rotation rotation16 = piePlot1.getDirection();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        piePlot1.setDataset(pieDataset17);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        piePlot1.setLabelLinkStroke(stroke20);
        java.awt.Color color22 = java.awt.Color.cyan;
        float[] floatArray27 = new float[] { 0L, 10L, (-1L), 100L };
        float[] floatArray28 = color22.getColorComponents(floatArray27);
        piePlot1.setBackgroundPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        piePlot1.handleClick((int) (byte) -1, (int) (short) 10, plotRenderingInfo32);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor34 = piePlot1.getLabelDistributor();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor34);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        java.awt.Paint paint9 = jFreeChart3.getBorderPaint();
        org.jfree.chart.title.TextTitle textTitle10 = jFreeChart3.getTitle();
        jFreeChart3.removeLegend();
        boolean boolean12 = jFreeChart3.getAntiAlias();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(textTitle10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        float float4 = piePlot2.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot2.setURLGenerator(pieURLGenerator5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot2.getLabelGenerator();
        java.awt.Shape shape8 = piePlot2.getLegendItemShape();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot2.setBaseSectionPaint((java.awt.Paint) color9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke12 = jFreeChart11.getBorderStroke();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent13 = null;
        try {
            jFreeChart11.titleChanged(titleChangeEvent13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean2 = basicProjectInfo0.equals((java.lang.Object) true);
        org.jfree.chart.ui.Library[] libraryArray3 = basicProjectInfo0.getOptionalLibraries();
        java.lang.String str4 = basicProjectInfo0.getLicenceName();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        piePlot1.setPieIndex((int) (byte) 10);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.lang.String str10 = piePlot9.getNoDataMessage();
        boolean boolean11 = piePlot9.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot9.getLegendLabelToolTipGenerator();
        float float13 = piePlot9.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.PiePlotState piePlotState16 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) 0, plotRenderingInfo15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        piePlot1.handleClick((int) (byte) 10, 2, plotRenderingInfo19);
        org.jfree.chart.block.Arrangement arrangement21 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement26 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment22, verticalAlignment23, (double) 100L, (double) 100);
        try {
            org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, arrangement21, (org.jfree.chart.block.Arrangement) flowArrangement26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState16);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.CYAN;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color2);
        int int4 = color2.getGreen();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 255 + "'", int4 == 255);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setInfo("");
        java.awt.Image image5 = null;
        projectInfo1.setLogo(image5);
        java.lang.String str7 = projectInfo1.getVersion();
        java.lang.String str8 = projectInfo1.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JFreeChart" + "'", str8.equals("JFreeChart"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart5.setBorderStroke(stroke6);
        boolean boolean8 = jFreeChart5.isBorderVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = null;
        try {
            java.awt.image.BufferedImage bufferedImage13 = jFreeChart5.createBufferedImage((int) (short) -1, 0, (int) 'a', chartRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        java.util.List list9 = null;
        try {
            jFreeChart3.setSubtitles(list9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'subtitles' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("Multiple Pie Plot");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) (short) -1, (java.lang.Comparable) (-1L), (java.lang.Comparable) (short) 10);
        int int5 = defaultKeyedValues2D0.getRowCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        java.awt.Stroke stroke9 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean10 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.lang.String str14 = piePlot13.getNoDataMessage();
        float float15 = piePlot13.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot13.setToolTipGenerator(pieToolTipGenerator16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke20);
        java.awt.Stroke stroke22 = piePlot13.getLabelOutlineStroke();
        java.awt.Color color23 = java.awt.Color.white;
        piePlot13.setLabelLinkPaint((java.awt.Paint) color23);
        piePlot1.setSectionPaint((java.lang.Comparable) '#', (java.awt.Paint) color23);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor26 = piePlot1.getLabelDistributor();
        abstractPieLabelDistributor26.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor26);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint paint8 = legendTitle7.getItemPaint();
        java.awt.Font font9 = legendTitle7.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle7.getLegendItemGraphicAnchor();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getHorizontalAlignment();
        textTitle2.setPadding((double) (-123), (double) '4', (double) (byte) 10, (double) 10L);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        float float5 = piePlot1.getForegroundAlpha();
        double double6 = piePlot1.getInteriorGap();
        boolean boolean7 = piePlot1.getSectionOutlinesVisible();
        java.lang.Comparable comparable8 = null;
        try {
            piePlot1.setExplodePercent(comparable8, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.08d + "'", double6 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        float float11 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        jFreeChart3.setPadding(rectangleInsets12);
        boolean boolean14 = jFreeChart3.isNotify();
        jFreeChart3.setTitle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        paintMap0.clear();
        java.awt.Paint paint3 = paintMap0.getPaint((java.lang.Comparable) 2.025d);
        java.lang.Object obj4 = null;
        boolean boolean5 = paintMap0.equals(obj4);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(0.0d, (double) '4', (double) (short) 0, (double) 100);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.util.List list8 = blockContainer7.getBlocks();
        boolean boolean9 = blockContainer7.isEmpty();
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        int int9 = pieSectionEntity7.getPieIndex();
        pieSectionEntity7.setSectionIndex((-1));
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        java.lang.String str8 = piePlot7.getNoDataMessage();
        float float9 = piePlot7.getForegroundAlpha();
        piePlot7.setPieIndex((int) (byte) 10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.lang.String str16 = piePlot15.getNoDataMessage();
        boolean boolean17 = piePlot15.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = piePlot15.getLegendLabelToolTipGenerator();
        float float19 = piePlot15.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.PiePlotState piePlotState22 = piePlot7.initialise(graphics2D12, rectangle2D13, piePlot15, (java.lang.Integer) 0, plotRenderingInfo21);
        double double23 = piePlot15.getMaximumExplodePercent();
        piePlot15.setShadowXOffset(0.0d);
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        boolean boolean28 = piePlot27.isOutlineVisible();
        float float29 = piePlot27.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator30 = null;
        piePlot27.setURLGenerator(pieURLGenerator30);
        org.jfree.chart.plot.Plot plot32 = piePlot27.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot27);
        java.awt.Paint paint34 = legendTitle33.getItemPaint();
        java.awt.Font font35 = legendTitle33.getItemFont();
        piePlot15.setNoDataMessageFont(font35);
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot15);
        defaultCategoryDataset0.addValue((java.lang.Number) 3.0d, (java.lang.Comparable) (byte) -1, (java.lang.Comparable) "rect");
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(plot32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart3.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            legendTitle9.setLegendItemGraphicPadding(rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(legendTitle9);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        textTitle1.setText("RectangleAnchor.LEFT");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot6);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart9.setBorderStroke(stroke10);
        textTitle1.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart9);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D13 = new org.jfree.data.DefaultKeyedValues2D();
        int int14 = defaultKeyedValues2D13.getColumnCount();
        defaultKeyedValues2D13.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        java.util.List list19 = defaultKeyedValues2D13.getColumnKeys();
        try {
            jFreeChart9.setSubtitles(list19);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to org.jfree.chart.title.Title");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (-123), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getLabelGap();
        piePlot1.setBackgroundImageAlpha(0.0f);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        float float8 = piePlot6.getForegroundAlpha();
        java.awt.Color color9 = java.awt.Color.orange;
        piePlot6.setLabelPaint((java.awt.Paint) color9);
        piePlot1.setBaseSectionPaint((java.awt.Paint) color9);
        piePlot1.setIgnoreNullValues(true);
        piePlot1.setPieIndex(0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(0.4d, (double) 1, (double) (short) -1, (double) 10);
        piePlot2.setInsets(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font2);
        java.awt.Font font4 = textTitle3.getFont();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.PiePlotState piePlotState17 = piePlot6.initialise(graphics2D11, rectangle2D12, piePlot14, (java.lang.Integer) (-97), plotRenderingInfo16);
        piePlot6.setShadowXOffset((double) '4');
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", font4, (org.jfree.chart.plot.Plot) piePlot6, true);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.title.TextTitle textTitle24 = null;
        jFreeChart21.setTitle(textTitle24);
        try {
            org.jfree.chart.plot.CategoryPlot categoryPlot26 = jFreeChart21.getCategoryPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.CategoryPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(piePlotState17);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.Comparable comparable1 = null;
        try {
            multiplePiePlot0.setAggregatedItemsKey(comparable1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.String str3 = jFreeChartResources0.getString("UnitType.ABSOLUTE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key UnitType.ABSOLUTE");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.awt.Color color4 = java.awt.Color.GREEN;
        int int5 = color4.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((double) 1.0f, 3.0d, (double) 100.0f, (double) (short) 100, (java.awt.Paint) color4);
        java.lang.Object obj7 = null;
        boolean boolean8 = blockBorder6.equals(obj7);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-16711936) + "'", int5 == (-16711936));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font2);
        java.awt.Font font4 = textTitle3.getFont();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.PiePlotState piePlotState17 = piePlot6.initialise(graphics2D11, rectangle2D12, piePlot14, (java.lang.Integer) (-97), plotRenderingInfo16);
        piePlot6.setShadowXOffset((double) '4');
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", font4, (org.jfree.chart.plot.Plot) piePlot6, true);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.title.TextTitle textTitle24 = null;
        jFreeChart21.setTitle(textTitle24);
        java.awt.RenderingHints renderingHints26 = null;
        try {
            jFreeChart21.setRenderingHints(renderingHints26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(piePlotState17);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.image.BufferedImage bufferedImage14 = jFreeChart8.createBufferedImage(1, (int) (byte) 1);
        float float15 = jFreeChart8.getBackgroundImageAlpha();
        jFreeChart8.setAntiAlias(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(bufferedImage14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint paint8 = legendTitle7.getItemPaint();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        org.jfree.chart.util.Size2D size2D11 = legendTitle7.arrange(graphics2D9, rectangleConstraint10);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(size2D11);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Enumeration<java.lang.String> strEnumeration2 = jFreeChartResources0.getKeys();
        java.util.Enumeration<java.lang.String> strEnumeration3 = jFreeChartResources0.getKeys();
        java.lang.Object obj5 = jFreeChartResources0.handleGetObject("RectangleEdge.BOTTOM");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(strEnumeration2);
        org.junit.Assert.assertNotNull(strEnumeration3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.lang.String str2 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: (C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str2.equals("org.jfree.data.UnknownKeyException: (C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        java.awt.Color color1 = java.awt.Color.yellow;
        boolean boolean2 = columnArrangement0.equals((java.lang.Object) color1);
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = columnArrangement0.arrange(blockContainer3, graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image3, "rect", "", "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "");
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a', jFreeChart10, chartChangeEventType11);
        chartChangeEvent8.setType(chartChangeEventType11);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = chartChangeEvent8.getType();
        java.awt.Image image18 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo22 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image18, "rect", "", "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = chartChangeEvent23.getType();
        chartChangeEvent8.setType(chartChangeEventType24);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.lang.String str14 = piePlot13.getNoDataMessage();
        float float15 = piePlot13.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot13.setToolTipGenerator(pieToolTipGenerator16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke20);
        java.awt.Stroke stroke22 = piePlot13.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets();
        piePlot13.setInsets(rectangleInsets23);
        textTitle1.setMargin(rectangleInsets23);
        java.awt.geom.Rectangle2D rectangle2D26 = textTitle1.getBounds();
        textTitle1.setURLText("PieSection: 0, 0(-1.0)");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment22);
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle10.getFrame();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer7.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) color25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment27);
        textTitle10.setWidth((double) '#');
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        piePlot1.setPieIndex((int) (byte) -1);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        double double8 = piePlot1.getLabelGap();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025d + "'", double8 == 0.025d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        boolean boolean9 = piePlot1.isSubplot();
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor11 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor11);
        pieLabelDistributor11.sort();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord15 = pieLabelDistributor11.getPieLabelRecord((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
        java.lang.String str2 = licences0.getLGPL();
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        java.awt.Paint paint7 = null;
        jFreeChart3.setBorderPaint(paint7);
        org.jfree.chart.plot.Plot plot9 = jFreeChart3.getPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            java.awt.image.BufferedImage bufferedImage15 = jFreeChart3.createBufferedImage(100, 0, (double) 0.5f, 3.0d, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (100) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.awt.geom.Rectangle2D rectangle2D2 = textTitle1.getBounds();
        textTitle1.setPadding((double) 3, (double) (short) 10, 10.0d, (double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke8);
        java.awt.Stroke stroke10 = piePlot1.getLabelOutlineStroke();
        java.awt.Stroke stroke11 = null;
        piePlot1.setOutlineStroke(stroke11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) (short) -1, 0.4d, (double) 10, 0.0d);
        java.awt.Color color22 = java.awt.Color.getColor("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]", (-1));
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        java.lang.String str25 = piePlot24.getNoDataMessage();
        boolean boolean26 = piePlot24.isCircular();
        java.awt.Stroke stroke28 = piePlot24.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        org.jfree.chart.plot.PiePlotState piePlotState35 = piePlot24.initialise(graphics2D29, rectangle2D30, piePlot32, (java.lang.Integer) (-97), plotRenderingInfo34);
        piePlot24.setShadowXOffset((double) '4');
        double double38 = piePlot24.getInteriorGap();
        org.jfree.chart.util.Rotation rotation39 = piePlot24.getDirection();
        org.jfree.data.general.PieDataset pieDataset40 = null;
        piePlot24.setDataset(pieDataset40);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke43 = defaultDrawingSupplier42.getNextOutlineStroke();
        piePlot24.setLabelLinkStroke(stroke43);
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot(pieDataset45);
        java.lang.String str47 = piePlot46.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = new org.jfree.chart.util.RectangleInsets();
        double double50 = rectangleInsets48.calculateRightOutset((double) 0);
        double double52 = rectangleInsets48.calculateTopOutset((double) (-1));
        piePlot46.setLabelPadding(rectangleInsets48);
        double double55 = rectangleInsets48.calculateRightInset((double) 0.0f);
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color22, stroke43, rectangleInsets48);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D60 = textTitle59.getBounds();
        lineBorder56.draw(graphics2D57, rectangle2D60);
        java.awt.geom.Rectangle2D rectangle2D64 = rectangleInsets19.createInsetRectangle(rectangle2D60, false, true);
        try {
            piePlot1.drawBackground(graphics2D13, rectangle2D60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(stroke28);
        org.junit.Assert.assertNotNull(piePlotState35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.08d + "'", double38 == 0.08d);
        org.junit.Assert.assertNotNull(rotation39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D64);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        float float4 = piePlot2.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot2.setURLGenerator(pieURLGenerator5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot2.getLabelGenerator();
        java.awt.Shape shape8 = piePlot2.getLegendItemShape();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot2.setBaseSectionPaint((java.awt.Paint) color9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.event.ChartChangeListener chartChangeListener12 = null;
        try {
            jFreeChart11.removeChangeListener(chartChangeListener12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.lang.String str9 = piePlot8.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        double double12 = rectangleInsets10.calculateRightOutset((double) 0);
        double double14 = rectangleInsets10.calculateTopOutset((double) (-1));
        piePlot8.setLabelPadding(rectangleInsets10);
        double double17 = rectangleInsets10.extendWidth((double) (short) 100);
        jFreeChart3.setPadding(rectangleInsets10);
        try {
            jFreeChart3.setTextAntiAlias((java.lang.Object) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 100.0 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 102.0d + "'", double17 == 102.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment22);
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle10.getFrame();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer7.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) color25);
        java.lang.String str27 = textTitle10.getURLText();
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addOptionalLibrary("hi!");
        java.lang.String str3 = basicProjectInfo0.getVersion();
        java.lang.String str4 = basicProjectInfo0.getLicenceName();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
        piePlot1.markerChanged(markerChangeEvent13);
        try {
            piePlot1.setInteriorGap((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (-1.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        boolean boolean9 = piePlot1.isSubplot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        piePlot1.datasetChanged(datasetChangeEvent10);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor13 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        piePlot1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor13);
        boolean boolean15 = piePlot1.getSectionOutlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        java.awt.Image image11 = null;
        jFreeChart3.setBackgroundImage(image11);
        jFreeChart3.setNotify(true);
        jFreeChart3.setBorderVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        double double9 = legendTitle7.getContentXOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = legendTitle7.getLegendItemGraphicLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = legendTitle7.getLegendItemGraphicPadding();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle9.getLegendItemGraphicLocation();
        legendTitle9.setMargin((double) 1, 1.0d, (double) (-1.0f), (double) 10.0f);
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle9.getItemContainer();
        boolean boolean19 = blockContainer18.isEmpty();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo4.setInfo("");
        java.awt.Image image8 = null;
        projectInfo4.setLogo(image8);
        java.util.List list10 = projectInfo4.getContributors();
        projectInfo1.setContributors(list10);
        projectInfo1.setInfo("PieSection: 0, 0(3)");
        projectInfo1.setLicenceText("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]");
        projectInfo1.setVersion("TableOrder.BY_COLUMN");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.awt.Paint paint6 = piePlot1.getOutlinePaint();
        java.lang.Object obj7 = null;
        boolean boolean8 = piePlot1.equals(obj7);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.chart.event.ChartProgressListener chartProgressListener7 = null;
        jFreeChart3.removeProgressListener(chartProgressListener7);
        int int9 = jFreeChart3.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        java.lang.String str6 = piePlot2.getNoDataMessage();
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel9 = null;
        java.awt.Rectangle rectangle10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.AffineTransform affineTransform12 = null;
        java.awt.RenderingHints renderingHints13 = null;
        java.awt.PaintContext paintContext14 = color8.createContext(colorModel9, rectangle10, rectangle2D11, affineTransform12, renderingHints13);
        piePlot2.setSectionPaint((java.lang.Comparable) (-97), (java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintContext14);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        piePlot1.setPieIndex((int) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        boolean boolean8 = piePlot7.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot7);
        jFreeChart9.setAntiAlias(false);
        java.lang.Object obj12 = jFreeChart9.clone();
        piePlot1.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart9);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle16.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            jFreeChart9.draw(graphics2D14, rectangle2D17, chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        float float11 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        jFreeChart3.setPadding(rectangleInsets12);
        java.awt.Paint paint14 = jFreeChart3.getBackgroundPaint();
        jFreeChart3.fireChartChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment22);
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle10.getFrame();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer7.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) color25);
        java.awt.Color color27 = java.awt.Color.orange;
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color27);
        java.awt.color.ColorSpace colorSpace29 = color27.getColorSpace();
        float[] floatArray30 = null;
        float[] floatArray31 = color25.getComponents(colorSpace29, floatArray30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel33 = null;
        java.awt.Rectangle rectangle34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        java.awt.geom.AffineTransform affineTransform36 = null;
        java.awt.RenderingHints renderingHints37 = null;
        java.awt.PaintContext paintContext38 = color32.createContext(colorModel33, rectangle34, rectangle2D35, affineTransform36, renderingHints37);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int40 = color39.getTransparency();
        float[] floatArray41 = null;
        float[] floatArray42 = color39.getComponents(floatArray41);
        float[] floatArray43 = color32.getColorComponents(floatArray42);
        float[] floatArray44 = color25.getRGBColorComponents(floatArray43);
        int int45 = color25.getGreen();
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintContext38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 128 + "'", int45 == 128);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        boolean boolean3 = defaultCategoryDataset0.equals((java.lang.Object) 1.0f);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String str1 = multiplePiePlot0.getPlotType();
        org.jfree.data.general.DatasetGroup datasetGroup2 = multiplePiePlot0.getDatasetGroup();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.UnitType unitType4 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets(unitType4, (double) (short) -1, 0.4d, (double) 10, 0.0d);
        java.awt.Color color12 = java.awt.Color.getColor("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]", (-1));
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.lang.String str15 = piePlot14.getNoDataMessage();
        boolean boolean16 = piePlot14.isCircular();
        java.awt.Stroke stroke18 = piePlot14.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.general.PieDataset pieDataset21 = null;
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot(pieDataset21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.PiePlotState piePlotState25 = piePlot14.initialise(graphics2D19, rectangle2D20, piePlot22, (java.lang.Integer) (-97), plotRenderingInfo24);
        piePlot14.setShadowXOffset((double) '4');
        double double28 = piePlot14.getInteriorGap();
        org.jfree.chart.util.Rotation rotation29 = piePlot14.getDirection();
        org.jfree.data.general.PieDataset pieDataset30 = null;
        piePlot14.setDataset(pieDataset30);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke33 = defaultDrawingSupplier32.getNextOutlineStroke();
        piePlot14.setLabelLinkStroke(stroke33);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        java.lang.String str37 = piePlot36.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets();
        double double40 = rectangleInsets38.calculateRightOutset((double) 0);
        double double42 = rectangleInsets38.calculateTopOutset((double) (-1));
        piePlot36.setLabelPadding(rectangleInsets38);
        double double45 = rectangleInsets38.calculateRightInset((double) 0.0f);
        org.jfree.chart.block.LineBorder lineBorder46 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color12, stroke33, rectangleInsets38);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.title.TextTitle textTitle49 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D50 = textTitle49.getBounds();
        lineBorder46.draw(graphics2D47, rectangle2D50);
        java.awt.geom.Rectangle2D rectangle2D54 = rectangleInsets9.createInsetRectangle(rectangle2D50, false, true);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D57 = textTitle56.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D59 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D57, rectangleAnchor58);
        org.jfree.chart.plot.PlotState plotState60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        try {
            multiplePiePlot0.draw(graphics2D3, rectangle2D54, point2D59, plotState60, plotRenderingInfo61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Multiple Pie Plot" + "'", str1.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(piePlotState25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.08d + "'", double28 == 0.08d);
        org.junit.Assert.assertNotNull(rotation29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D54);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(point2D59);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "PieSection: 0, 0(3)");
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity7.setDataset(pieDataset11);
        java.lang.String str13 = pieSectionEntity7.getShapeCoords();
        org.jfree.data.general.PieDataset pieDataset14 = pieSectionEntity7.getDataset();
        java.awt.Shape shape15 = null;
        try {
            pieSectionEntity7.setArea(shape15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str13.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertNull(pieDataset14);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.awt.Paint paint7 = defaultDrawingSupplier4.getNextFillPaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        boolean boolean2 = color0.equals((java.lang.Object) 100L);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list2 = defaultCategoryDataset1.getColumnKeys();
        defaultCategoryDataset1.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        defaultCategoryDataset1.setValue((java.lang.Number) 0.025d, (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0);
        org.jfree.data.general.DatasetGroup datasetGroup10 = defaultCategoryDataset1.getGroup();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        java.lang.String str13 = piePlot12.getNoDataMessage();
        boolean boolean14 = piePlot12.isCircular();
        java.awt.Stroke stroke16 = piePlot12.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.plot.PiePlotState piePlotState23 = piePlot12.initialise(graphics2D17, rectangle2D18, piePlot20, (java.lang.Integer) (-97), plotRenderingInfo22);
        piePlot12.setShadowXOffset((double) '4');
        double double26 = piePlot12.getInteriorGap();
        piePlot12.zoom((double) (byte) 10);
        piePlot12.setIgnoreNullValues(true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = null;
        piePlot12.datasetChanged(datasetChangeEvent31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = new org.jfree.chart.util.RectangleInsets();
        piePlot12.setLabelPadding(rectangleInsets33);
        boolean boolean35 = defaultCategoryDataset1.hasListener((java.util.EventListener) piePlot12);
        boolean boolean36 = tableOrder0.equals((java.lang.Object) boolean35);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(datasetGroup10);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertNotNull(piePlotState23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.08d + "'", double26 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke8);
        java.awt.Stroke stroke10 = piePlot1.getLabelOutlineStroke();
        java.awt.Color color11 = java.awt.Color.white;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color11);
        java.awt.Color color13 = java.awt.Color.GREEN;
        piePlot1.setBaseSectionPaint((java.awt.Paint) color13);
        java.awt.Paint paint15 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("{0}", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0, 0.08d, 0.08d, (double) 100.0f, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        java.awt.Paint paint7 = blockBorder5.getPaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        boolean boolean9 = piePlot1.isSubplot();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent10 = null;
        piePlot1.datasetChanged(datasetChangeEvent10);
        double double12 = piePlot1.getStartAngle();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        java.lang.String str15 = piePlot14.getNoDataMessage();
        float float16 = piePlot14.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = piePlot14.getInsets();
        double double19 = rectangleInsets17.calculateLeftInset((double) (-1.0f));
        piePlot1.setSimpleLabelOffset(rectangleInsets17);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = piePlot1.getLegendLabelURLGenerator();
        piePlot1.setBackgroundImageAlpha(0.5f);
        piePlot1.setNoDataMessage("-4,-4,4,4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertNull(pieURLGenerator21);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo4.setInfo("");
        java.awt.Image image8 = null;
        projectInfo4.setLogo(image8);
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo4.getOptionalLibraries();
        projectInfo1.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo1.setCopyright("");
        java.lang.String str14 = projectInfo1.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(libraryArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "JFreeChart" + "'", str14.equals("JFreeChart"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle2.setTextAlignment(horizontalAlignment5);
        java.lang.String str7 = horizontalAlignment5.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "HorizontalAlignment.CENTER" + "'", str7.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Color color1 = java.awt.Color.getColor("rect");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("RectangleAnchor.LEFT");
        try {
            java.lang.Object obj4 = jFreeChartResources0.getObject("RectangleAnchor.LEFT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleAnchor.LEFT");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        java.lang.Comparable comparable3 = null;
        org.jfree.data.general.PieDataset pieDataset4 = null;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        java.lang.String str6 = piePlot5.getNoDataMessage();
        float float7 = piePlot5.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = null;
        piePlot5.setToolTipGenerator(pieToolTipGenerator8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke12 = defaultDrawingSupplier11.getNextOutlineStroke();
        piePlot5.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke12);
        java.awt.Stroke stroke14 = piePlot5.getLabelOutlineStroke();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.lang.String str17 = piePlot16.getNoDataMessage();
        boolean boolean18 = piePlot16.isCircular();
        java.awt.Stroke stroke20 = piePlot16.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = piePlot16.initialise(graphics2D21, rectangle2D22, piePlot24, (java.lang.Integer) (-97), plotRenderingInfo26);
        piePlot16.setShadowXOffset((double) '4');
        double double30 = piePlot16.getInteriorGap();
        java.awt.Stroke stroke31 = piePlot16.getBaseSectionOutlineStroke();
        piePlot5.setLabelOutlineStroke(stroke31);
        try {
            piePlot1.setSectionOutlineStroke(comparable3, stroke31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.08d + "'", double30 == 0.08d);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        java.lang.Object obj2 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        java.awt.Stroke stroke9 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        piePlot1.setExplodePercent((java.lang.Comparable) 255, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        float float4 = piePlot2.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator5);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        java.util.List list8 = defaultCategoryDataset0.getRowKeys();
        java.util.List list9 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.general.DatasetGroup datasetGroup10 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj11 = datasetGroup10.clone();
        defaultCategoryDataset0.setGroup(datasetGroup10);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) "JFreeChart version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Object obj2 = textTitle1.clone();
        java.awt.Paint paint3 = textTitle1.getPaint();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "ChartEntity: tooltip = ");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        defaultCategoryDataset0.setValue((java.lang.Number) 0.025d, (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0);
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.lang.String str12 = piePlot11.getNoDataMessage();
        boolean boolean13 = piePlot11.isCircular();
        java.awt.Stroke stroke15 = piePlot11.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.PiePlotState piePlotState22 = piePlot11.initialise(graphics2D16, rectangle2D17, piePlot19, (java.lang.Integer) (-97), plotRenderingInfo21);
        piePlot11.setShadowXOffset((double) '4');
        double double25 = piePlot11.getInteriorGap();
        piePlot11.zoom((double) (byte) 10);
        piePlot11.setIgnoreNullValues(true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        piePlot11.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        piePlot11.setLabelPadding(rectangleInsets32);
        boolean boolean34 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot11);
        int int35 = defaultCategoryDataset0.getRowCount();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertNotNull(piePlotState22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.08d + "'", double25 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint paint8 = legendTitle7.getItemPaint();
        java.awt.Font font9 = legendTitle7.getItemFont();
        java.awt.Font font10 = null;
        try {
            legendTitle7.setItemFont(font10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.lang.String str4 = piePlot3.getNoDataMessage();
        float float5 = piePlot3.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = null;
        piePlot3.setToolTipGenerator(pieToolTipGenerator6);
        defaultCategoryDataset1.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        int int10 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) false);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        java.lang.String str12 = multiplePiePlot0.getNoDataMessage();
        java.awt.Color color13 = java.awt.Color.cyan;
        float[] floatArray18 = new float[] { 0L, 10L, (-1L), 100L };
        float[] floatArray19 = color13.getColorComponents(floatArray18);
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color13);
        java.awt.Color color21 = color13.brighter();
        java.awt.Color color22 = color21.darker();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart5.setBorderStroke(stroke6);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = jFreeChart5.createBufferedImage((int) (byte) 0, 0, (int) (byte) 0, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setNoDataMessage("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        org.jfree.data.general.PieDataset pieDataset15 = null;
        piePlot1.setDataset(pieDataset15);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int2 = color1.getTransparency();
        float[] floatArray3 = null;
        float[] floatArray4 = color1.getComponents(floatArray3);
        float[] floatArray5 = color0.getRGBComponents(floatArray4);
        java.awt.color.ColorSpace colorSpace6 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(colorSpace6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset3 = piePlot1.getDataset();
        java.awt.Paint paint4 = piePlot1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(pieDataset3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo0.setLicenceText("");
        java.lang.String str5 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle2.setTextAlignment(horizontalAlignment5);
        java.awt.Font font8 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font8);
        textTitle9.setText("PieLabelLinkStyle.STANDARD");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.lang.String str14 = piePlot13.getNoDataMessage();
        boolean boolean15 = piePlot13.isCircular();
        java.awt.Stroke stroke17 = piePlot13.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetGroup datasetGroup18 = piePlot13.getDatasetGroup();
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        piePlot13.setLabelBackgroundPaint(paint19);
        boolean boolean21 = textTitle9.equals((java.lang.Object) piePlot13);
        java.lang.String str22 = textTitle9.getID();
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = textTitle9.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment23, (double) (-1L), (double) (short) -1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement31 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment27, verticalAlignment28, (double) 100L, (double) 100);
        flowArrangement31.clear();
        org.jfree.chart.block.BlockContainer blockContainer33 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement31);
        org.jfree.chart.block.BlockContainer blockContainer34 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement31);
        blockContainer34.setPadding((double) 0.5f, 0.0d, 10.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = blockContainer34.getPadding();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = null;
        try {
            org.jfree.chart.util.Size2D size2D43 = columnArrangement26.arrange(blockContainer34, graphics2D41, rectangleConstraint42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertNotNull(rectangleInsets40);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "PieSection: 0, 0(3)");
        int int11 = pieSectionEntity7.getSectionIndex();
        java.awt.Shape shape12 = pieSectionEntity7.getArea();
        pieSectionEntity7.setPieIndex((int) (byte) 1);
        java.lang.Comparable comparable15 = pieSectionEntity7.getSectionKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + "PieSection: 0, 0(3)" + "'", comparable15.equals("PieSection: 0, 0(3)"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.lang.String str4 = piePlot3.getNoDataMessage();
        float float5 = piePlot3.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = null;
        piePlot3.setToolTipGenerator(pieToolTipGenerator6);
        defaultCategoryDataset1.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        int int10 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) false);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) (short) 1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        jFreeChart8.fireChartChanged();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        java.awt.Shape shape5 = piePlot1.getLegendItemShape();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle8.setPaint((java.awt.Paint) color9);
        java.lang.String str11 = textTitle8.getText();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean14 = piePlot13.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot13);
        jFreeChart15.setAntiAlias(false);
        textTitle8.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        java.lang.String str21 = piePlot20.getNoDataMessage();
        float float22 = piePlot20.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator23 = null;
        piePlot20.setToolTipGenerator(pieToolTipGenerator23);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke27 = defaultDrawingSupplier26.getNextOutlineStroke();
        piePlot20.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke27);
        java.awt.Stroke stroke29 = piePlot20.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = new org.jfree.chart.util.RectangleInsets();
        piePlot20.setInsets(rectangleInsets30);
        textTitle8.setMargin(rectangleInsets30);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle8.getBounds();
        try {
            piePlot1.drawOutline(graphics2D6, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str11.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setInfo("");
        org.jfree.chart.ui.Library[] libraryArray5 = projectInfo1.getLibraries();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(libraryArray5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        boolean boolean8 = blockContainer7.isEmpty();
        boolean boolean9 = blockContainer7.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        float float11 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        jFreeChart3.setPadding(rectangleInsets12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.lang.String str16 = piePlot15.getNoDataMessage();
        float float17 = piePlot15.getForegroundAlpha();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke19 = defaultDrawingSupplier18.getNextOutlineStroke();
        piePlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18);
        java.awt.Paint paint21 = defaultDrawingSupplier18.getNextOutlinePaint();
        boolean boolean22 = jFreeChart3.equals((java.lang.Object) defaultDrawingSupplier18);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint1 = lineBorder0.getPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        double double3 = textTitle2.getWidth();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "PieSection: 0, 0(3)");
        pieSectionEntity7.setSectionIndex(0);
        int int13 = pieSectionEntity7.getPieIndex();
        int int14 = pieSectionEntity7.getPieIndex();
        int int15 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        org.jfree.chart.plot.Plot plot9 = jFreeChart3.getPlot();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle12.setPaint((java.awt.Paint) color13);
        java.lang.String str15 = textTitle12.getText();
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        boolean boolean18 = piePlot17.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot17);
        jFreeChart19.setAntiAlias(false);
        textTitle12.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart19);
        java.awt.Paint paint23 = textTitle12.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment24 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle12.setHorizontalAlignment(horizontalAlignment24);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.lang.String str29 = piePlot28.getNoDataMessage();
        float float30 = piePlot28.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator31 = null;
        piePlot28.setToolTipGenerator(pieToolTipGenerator31);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke35 = defaultDrawingSupplier34.getNextOutlineStroke();
        piePlot28.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke35);
        java.awt.Stroke stroke37 = piePlot28.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets();
        piePlot28.setInsets(rectangleInsets38);
        java.lang.Object obj40 = null;
        boolean boolean41 = rectangleInsets38.equals(obj40);
        org.jfree.data.general.PieDataset pieDataset42 = null;
        org.jfree.chart.plot.PiePlot piePlot43 = new org.jfree.chart.plot.PiePlot(pieDataset42);
        java.lang.String str44 = piePlot43.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = new org.jfree.chart.util.RectangleInsets();
        double double47 = rectangleInsets45.calculateRightOutset((double) 0);
        double double49 = rectangleInsets45.calculateTopOutset((double) (-1));
        piePlot43.setLabelPadding(rectangleInsets45);
        double double52 = rectangleInsets45.extendWidth((double) (short) 100);
        double double54 = rectangleInsets45.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D57 = textTitle56.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D59 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D57, rectangleAnchor58);
        java.awt.geom.Rectangle2D rectangle2D60 = rectangleInsets45.createInsetRectangle(rectangle2D57);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType61 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = rectangleInsets38.createAdjustedRectangle(rectangle2D57, lengthAdjustmentType61, lengthAdjustmentType62);
        java.awt.Shape shape64 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity66 = new org.jfree.chart.entity.ChartEntity(shape64, "");
        java.lang.String str67 = chartEntity66.toString();
        java.lang.Object obj68 = textTitle12.draw(graphics2D26, rectangle2D63, (java.lang.Object) str67);
        try {
            plot9.drawOutline(graphics2D10, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str15.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(horizontalAlignment24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 102.0d + "'", double52 == 102.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(point2D59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "ChartEntity: tooltip = " + "'", str67.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertNull(obj68);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment22);
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle10.getFrame();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer7.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) color25);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.lang.String str29 = piePlot28.getNoDataMessage();
        float float30 = piePlot28.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator31 = null;
        piePlot28.setToolTipGenerator(pieToolTipGenerator31);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke35 = defaultDrawingSupplier34.getNextOutlineStroke();
        piePlot28.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke35);
        java.awt.Stroke stroke37 = piePlot28.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets();
        piePlot28.setInsets(rectangleInsets38);
        double double41 = rectangleInsets38.calculateBottomInset((double) 1.0f);
        blockContainer7.setMargin(rectangleInsets38);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.util.UnitType unitType47 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = new org.jfree.chart.util.RectangleInsets(unitType47, (double) (short) -1, 0.4d, (double) 10, 0.0d);
        java.awt.Color color55 = java.awt.Color.getColor("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]", (-1));
        org.jfree.data.general.PieDataset pieDataset56 = null;
        org.jfree.chart.plot.PiePlot piePlot57 = new org.jfree.chart.plot.PiePlot(pieDataset56);
        java.lang.String str58 = piePlot57.getNoDataMessage();
        boolean boolean59 = piePlot57.isCircular();
        java.awt.Stroke stroke61 = piePlot57.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.data.general.PieDataset pieDataset64 = null;
        org.jfree.chart.plot.PiePlot piePlot65 = new org.jfree.chart.plot.PiePlot(pieDataset64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        org.jfree.chart.plot.PiePlotState piePlotState68 = piePlot57.initialise(graphics2D62, rectangle2D63, piePlot65, (java.lang.Integer) (-97), plotRenderingInfo67);
        piePlot57.setShadowXOffset((double) '4');
        double double71 = piePlot57.getInteriorGap();
        org.jfree.chart.util.Rotation rotation72 = piePlot57.getDirection();
        org.jfree.data.general.PieDataset pieDataset73 = null;
        piePlot57.setDataset(pieDataset73);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier75 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke76 = defaultDrawingSupplier75.getNextOutlineStroke();
        piePlot57.setLabelLinkStroke(stroke76);
        org.jfree.data.general.PieDataset pieDataset78 = null;
        org.jfree.chart.plot.PiePlot piePlot79 = new org.jfree.chart.plot.PiePlot(pieDataset78);
        java.lang.String str80 = piePlot79.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = new org.jfree.chart.util.RectangleInsets();
        double double83 = rectangleInsets81.calculateRightOutset((double) 0);
        double double85 = rectangleInsets81.calculateTopOutset((double) (-1));
        piePlot79.setLabelPadding(rectangleInsets81);
        double double88 = rectangleInsets81.calculateRightInset((double) 0.0f);
        org.jfree.chart.block.LineBorder lineBorder89 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color55, stroke76, rectangleInsets81);
        java.awt.Graphics2D graphics2D90 = null;
        org.jfree.chart.title.TextTitle textTitle92 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D93 = textTitle92.getBounds();
        lineBorder89.draw(graphics2D90, rectangle2D93);
        java.awt.geom.Rectangle2D rectangle2D97 = rectangleInsets52.createInsetRectangle(rectangle2D93, false, true);
        textTitle45.draw(graphics2D46, rectangle2D97);
        try {
            blockContainer7.draw(graphics2D43, rectangle2D97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(unitType47);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNull(str58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(stroke61);
        org.junit.Assert.assertNotNull(piePlotState68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.08d + "'", double71 == 0.08d);
        org.junit.Assert.assertNotNull(rotation72);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNull(str80);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.0d + "'", double83 == 1.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 1.0d + "'", double85 == 1.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1.0d + "'", double88 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D93);
        org.junit.Assert.assertNotNull(rectangle2D97);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle1.setHorizontalAlignment(horizontalAlignment13);
        org.jfree.chart.block.BlockFrame blockFrame15 = textTitle1.getFrame();
        org.jfree.chart.block.BlockFrame blockFrame16 = textTitle1.getFrame();
        textTitle1.setExpandToFitSpace(false);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        java.lang.String str21 = piePlot20.getNoDataMessage();
        float float22 = piePlot20.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator23 = null;
        piePlot20.setToolTipGenerator(pieToolTipGenerator23);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke27 = defaultDrawingSupplier26.getNextOutlineStroke();
        piePlot20.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke27);
        java.awt.Stroke stroke29 = piePlot20.getLabelOutlineStroke();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot20.setBackgroundPaint((java.awt.Paint) color30);
        textTitle1.setBackgroundPaint((java.awt.Paint) color30);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(blockFrame15);
        org.junit.Assert.assertNotNull(blockFrame16);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(8);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("JFreeChart", "hi!");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment13 = textTitle1.getVerticalAlignment();
        org.jfree.chart.util.UnitType unitType14 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = new org.jfree.chart.util.RectangleInsets(unitType14, (double) (short) -1, 0.4d, (double) 10, 0.0d);
        java.lang.String str20 = unitType14.toString();
        boolean boolean21 = verticalAlignment13.equals((java.lang.Object) str20);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list23 = defaultCategoryDataset22.getColumnKeys();
        defaultCategoryDataset22.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        defaultCategoryDataset22.setValue((java.lang.Number) 0.025d, (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0);
        defaultCategoryDataset22.validateObject();
        boolean boolean32 = verticalAlignment13.equals((java.lang.Object) defaultCategoryDataset22);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(verticalAlignment13);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "UnitType.ABSOLUTE" + "'", str20.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.block.Arrangement arrangement9 = blockContainer7.getArrangement();
        org.jfree.chart.block.Arrangement arrangement10 = null;
        try {
            blockContainer7.setArrangement(arrangement10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(arrangement9);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Color color4 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) (short) 1, (double) ' ', 0.0d, (java.awt.Paint) color4);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        projectInfo6.addLibrary((org.jfree.chart.ui.Library) projectInfo7);
        projectInfo7.setInfo("");
        boolean boolean11 = blockBorder5.equals((java.lang.Object) projectInfo7);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        boolean boolean14 = piePlot13.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot13);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset16 = new org.jfree.data.category.DefaultCategoryDataset();
        int int17 = defaultCategoryDataset16.getColumnCount();
        java.util.List list18 = defaultCategoryDataset16.getRowKeys();
        jFreeChart15.setSubtitles(list18);
        projectInfo7.setContributors(list18);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.awt.Color color7 = java.awt.Color.cyan;
        float[] floatArray12 = new float[] { 0L, 10L, (-1L), 100L };
        float[] floatArray13 = color7.getColorComponents(floatArray12);
        boolean boolean14 = flowArrangement4.equals((java.lang.Object) floatArray13);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateRightOutset((double) 0);
        double double7 = rectangleInsets3.calculateTopOutset((double) (-1));
        piePlot1.setLabelPadding(rectangleInsets3);
        double double10 = rectangleInsets3.calculateRightInset((double) 0.0f);
        double double12 = rectangleInsets3.calculateTopInset((double) 0.5f);
        double double14 = rectangleInsets3.calculateRightOutset((double) 'a');
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        java.lang.String str4 = piePlot3.getNoDataMessage();
        float float5 = piePlot3.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator6 = null;
        piePlot3.setToolTipGenerator(pieToolTipGenerator6);
        defaultCategoryDataset1.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot3);
        int int10 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) false);
        multiplePiePlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateRightOutset((double) 0);
        double double4 = rectangleInsets0.calculateTopOutset((double) (-1));
        java.lang.Class<?> wildcardClass5 = rectangleInsets0.getClass();
        double double6 = rectangleInsets0.getLeft();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.lang.String str14 = piePlot13.getNoDataMessage();
        float float15 = piePlot13.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot13.setToolTipGenerator(pieToolTipGenerator16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke20);
        java.awt.Stroke stroke22 = piePlot13.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets();
        piePlot13.setInsets(rectangleInsets23);
        textTitle1.setMargin(rectangleInsets23);
        java.awt.Font font26 = textTitle1.getFont();
        java.awt.Graphics2D graphics2D27 = null;
        try {
            org.jfree.chart.util.Size2D size2D28 = textTitle1.arrange(graphics2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("PieSection: 0, 0(-1.0)");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key PieSection: 0, 0(-1.0)");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        jFreeChart5.setAntiAlias(false);
        java.lang.Object obj8 = jFreeChart5.clone();
        jFreeChart5.setNotify(true);
        java.lang.Object obj11 = jFreeChart5.getTextAntiAlias();
        boolean boolean12 = defaultCategoryDataset0.hasListener((java.util.EventListener) jFreeChart5);
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) 102.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 102.0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Color color14 = java.awt.Color.getColor("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]", (-1));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.lang.String str17 = piePlot16.getNoDataMessage();
        boolean boolean18 = piePlot16.isCircular();
        java.awt.Stroke stroke20 = piePlot16.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = piePlot16.initialise(graphics2D21, rectangle2D22, piePlot24, (java.lang.Integer) (-97), plotRenderingInfo26);
        piePlot16.setShadowXOffset((double) '4');
        double double30 = piePlot16.getInteriorGap();
        org.jfree.chart.util.Rotation rotation31 = piePlot16.getDirection();
        org.jfree.data.general.PieDataset pieDataset32 = null;
        piePlot16.setDataset(pieDataset32);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke35 = defaultDrawingSupplier34.getNextOutlineStroke();
        piePlot16.setLabelLinkStroke(stroke35);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot(pieDataset37);
        java.lang.String str39 = piePlot38.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        double double42 = rectangleInsets40.calculateRightOutset((double) 0);
        double double44 = rectangleInsets40.calculateTopOutset((double) (-1));
        piePlot38.setLabelPadding(rectangleInsets40);
        double double47 = rectangleInsets40.calculateRightInset((double) 0.0f);
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke35, rectangleInsets40);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D52 = textTitle51.getBounds();
        lineBorder48.draw(graphics2D49, rectangle2D52);
        try {
            jFreeChart3.draw(graphics2D11, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.08d + "'", double30 == 0.08d);
        org.junit.Assert.assertNotNull(rotation31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D52);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        defaultCategoryDataset0.setValue((java.lang.Number) 0.025d, (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0);
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.lang.String str12 = piePlot11.getNoDataMessage();
        boolean boolean13 = piePlot11.isCircular();
        java.awt.Stroke stroke15 = piePlot11.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.PiePlotState piePlotState22 = piePlot11.initialise(graphics2D16, rectangle2D17, piePlot19, (java.lang.Integer) (-97), plotRenderingInfo21);
        piePlot11.setShadowXOffset((double) '4');
        double double25 = piePlot11.getInteriorGap();
        piePlot11.zoom((double) (byte) 10);
        piePlot11.setIgnoreNullValues(true);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = null;
        piePlot11.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = new org.jfree.chart.util.RectangleInsets();
        piePlot11.setLabelPadding(rectangleInsets32);
        boolean boolean34 = defaultCategoryDataset0.hasListener((java.util.EventListener) piePlot11);
        defaultCategoryDataset0.setValue((double) 0, (java.lang.Comparable) (-97), (java.lang.Comparable) 10);
        defaultCategoryDataset0.addValue((double) 1L, (java.lang.Comparable) (byte) 10, (java.lang.Comparable) 0.0d);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertNotNull(piePlotState22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.08d + "'", double25 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        float float11 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        jFreeChart3.setPadding(rectangleInsets12);
        java.awt.Paint paint14 = jFreeChart3.getBackgroundPaint();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.Color color18 = java.awt.Color.getColor("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]", (-1));
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        java.lang.String str21 = piePlot20.getNoDataMessage();
        boolean boolean22 = piePlot20.isCircular();
        java.awt.Stroke stroke24 = piePlot20.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.PiePlotState piePlotState31 = piePlot20.initialise(graphics2D25, rectangle2D26, piePlot28, (java.lang.Integer) (-97), plotRenderingInfo30);
        piePlot20.setShadowXOffset((double) '4');
        double double34 = piePlot20.getInteriorGap();
        org.jfree.chart.util.Rotation rotation35 = piePlot20.getDirection();
        org.jfree.data.general.PieDataset pieDataset36 = null;
        piePlot20.setDataset(pieDataset36);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke39 = defaultDrawingSupplier38.getNextOutlineStroke();
        piePlot20.setLabelLinkStroke(stroke39);
        org.jfree.data.general.PieDataset pieDataset41 = null;
        org.jfree.chart.plot.PiePlot piePlot42 = new org.jfree.chart.plot.PiePlot(pieDataset41);
        java.lang.String str43 = piePlot42.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = new org.jfree.chart.util.RectangleInsets();
        double double46 = rectangleInsets44.calculateRightOutset((double) 0);
        double double48 = rectangleInsets44.calculateTopOutset((double) (-1));
        piePlot42.setLabelPadding(rectangleInsets44);
        double double51 = rectangleInsets44.calculateRightInset((double) 0.0f);
        org.jfree.chart.block.LineBorder lineBorder52 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke39, rectangleInsets44);
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D56 = textTitle55.getBounds();
        lineBorder52.draw(graphics2D53, rectangle2D56);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = null;
        try {
            jFreeChart3.draw(graphics2D15, rectangle2D56, chartRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNotNull(piePlotState31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.08d + "'", double34 == 0.08d);
        org.junit.Assert.assertNotNull(rotation35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D56);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint paint8 = legendTitle7.getItemPaint();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = null;
        org.jfree.chart.util.Size2D size2D11 = legendTitle7.arrange(graphics2D9, rectangleConstraint10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle14.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(0.4d, (double) 1, (double) (short) -1, (double) 10);
        java.lang.String str23 = rectangleInsets22.toString();
        double double24 = rectangleInsets22.getLeft();
        try {
            java.lang.Object obj25 = legendTitle7.draw(graphics2D12, rectangle2D15, (java.lang.Object) rectangleInsets22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor16);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]" + "'", str23.equals("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]"));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("UnitType.ABSOLUTE");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        piePlot1.setPieIndex((int) (byte) 10);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.lang.String str10 = piePlot9.getNoDataMessage();
        boolean boolean11 = piePlot9.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot9.getLegendLabelToolTipGenerator();
        float float13 = piePlot9.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.PiePlotState piePlotState16 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) 0, plotRenderingInfo15);
        java.awt.Color color17 = java.awt.Color.RED;
        piePlot1.setBackgroundPaint((java.awt.Paint) color17);
        float float19 = piePlot1.getForegroundAlpha();
        java.awt.Paint paint20 = piePlot1.getBackgroundPaint();
        double double22 = piePlot1.getExplodePercent((java.lang.Comparable) 90.0d);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        java.awt.Color color4 = java.awt.Color.orange;
        piePlot1.setLabelPaint((java.awt.Paint) color4);
        java.awt.Color color6 = java.awt.Color.white;
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color8 = java.awt.Color.cyan;
        float[] floatArray13 = new float[] { 0L, 10L, (-1L), 100L };
        float[] floatArray14 = color8.getColorComponents(floatArray13);
        float[] floatArray15 = color7.getRGBComponents(floatArray14);
        float[] floatArray16 = color6.getColorComponents(floatArray15);
        float[] floatArray17 = color4.getComponents(floatArray15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean19 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge18);
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        boolean boolean22 = piePlot21.isOutlineVisible();
        float float23 = piePlot21.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator24 = null;
        piePlot21.setURLGenerator(pieURLGenerator24);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = piePlot21.getLabelGenerator();
        java.awt.Shape shape27 = piePlot21.getLegendItemShape();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot21.setBaseSectionPaint((java.awt.Paint) color28);
        boolean boolean30 = rectangleEdge18.equals((java.lang.Object) color28);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel35 = null;
        java.awt.Rectangle rectangle36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        java.awt.geom.AffineTransform affineTransform38 = null;
        java.awt.RenderingHints renderingHints39 = null;
        java.awt.PaintContext paintContext40 = color34.createContext(colorModel35, rectangle36, rectangle2D37, affineTransform38, renderingHints39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int42 = color41.getTransparency();
        float[] floatArray43 = null;
        float[] floatArray44 = color41.getComponents(floatArray43);
        float[] floatArray45 = color34.getColorComponents(floatArray44);
        float[] floatArray46 = java.awt.Color.RGBtoHSB((int) (short) 0, (int) (byte) 10, 0, floatArray45);
        float[] floatArray47 = color28.getRGBComponents(floatArray45);
        float[] floatArray48 = color4.getRGBComponents(floatArray47);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paintContext40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Color color1 = java.awt.Color.getColor("Multiple Pie Plot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.lang.String str6 = textTitle3.getText();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot8);
        jFreeChart10.setAntiAlias(false);
        textTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart10);
        org.jfree.chart.plot.Plot plot14 = jFreeChart10.getPlot();
        boolean boolean15 = columnArrangement0.equals((java.lang.Object) plot14);
        org.jfree.data.general.DatasetGroup datasetGroup16 = plot14.getDatasetGroup();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str6.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(datasetGroup16);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        defaultKeyedValues2D0.removeColumn((int) (byte) 0);
        int int8 = defaultKeyedValues2D0.getRowCount();
        java.lang.Comparable comparable11 = null;
        try {
            defaultKeyedValues2D0.setValue((java.lang.Number) 128, (java.lang.Comparable) 2, comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        org.jfree.chart.plot.Plot plot9 = jFreeChart3.getPlot();
        java.awt.Color color10 = java.awt.Color.yellow;
        int int11 = color10.getAlpha();
        jFreeChart3.setBorderPaint((java.awt.Paint) color10);
        jFreeChart3.setNotify(false);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            jFreeChart3.draw(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment22);
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle10.getFrame();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer7.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) color25);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.lang.String str29 = piePlot28.getNoDataMessage();
        float float30 = piePlot28.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator31 = null;
        piePlot28.setToolTipGenerator(pieToolTipGenerator31);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke35 = defaultDrawingSupplier34.getNextOutlineStroke();
        piePlot28.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke35);
        java.awt.Stroke stroke37 = piePlot28.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets();
        piePlot28.setInsets(rectangleInsets38);
        double double41 = rectangleInsets38.calculateBottomInset((double) 1.0f);
        blockContainer7.setMargin(rectangleInsets38);
        double double44 = rectangleInsets38.calculateLeftOutset((double) (byte) 0);
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        try {
            java.lang.Number number8 = defaultKeyedValues2D0.getValue((int) '#', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str4 = standardPieSectionLabelGenerator3.getLabelFormat();
        java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator3.getAttributedLabel((-97));
        java.text.NumberFormat numberFormat7 = standardPieSectionLabelGenerator3.getPercentFormat();
        int int8 = objectList1.indexOf((java.lang.Object) standardPieSectionLabelGenerator3);
        objectList1.clear();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertNull(attributedString6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Multiple Pie Plot", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(-1.0)", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) (short) -1, 0.4d, (double) 10, 0.0d);
        java.awt.Color color14 = java.awt.Color.getColor("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]", (-1));
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        java.lang.String str17 = piePlot16.getNoDataMessage();
        boolean boolean18 = piePlot16.isCircular();
        java.awt.Stroke stroke20 = piePlot16.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.PiePlotState piePlotState27 = piePlot16.initialise(graphics2D21, rectangle2D22, piePlot24, (java.lang.Integer) (-97), plotRenderingInfo26);
        piePlot16.setShadowXOffset((double) '4');
        double double30 = piePlot16.getInteriorGap();
        org.jfree.chart.util.Rotation rotation31 = piePlot16.getDirection();
        org.jfree.data.general.PieDataset pieDataset32 = null;
        piePlot16.setDataset(pieDataset32);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke35 = defaultDrawingSupplier34.getNextOutlineStroke();
        piePlot16.setLabelLinkStroke(stroke35);
        org.jfree.data.general.PieDataset pieDataset37 = null;
        org.jfree.chart.plot.PiePlot piePlot38 = new org.jfree.chart.plot.PiePlot(pieDataset37);
        java.lang.String str39 = piePlot38.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = new org.jfree.chart.util.RectangleInsets();
        double double42 = rectangleInsets40.calculateRightOutset((double) 0);
        double double44 = rectangleInsets40.calculateTopOutset((double) (-1));
        piePlot38.setLabelPadding(rectangleInsets40);
        double double47 = rectangleInsets40.calculateRightInset((double) 0.0f);
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke35, rectangleInsets40);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D52 = textTitle51.getBounds();
        lineBorder48.draw(graphics2D49, rectangle2D52);
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets11.createInsetRectangle(rectangle2D52, false, true);
        try {
            piePlot2.drawOutline(graphics2D5, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertNotNull(piePlotState27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.08d + "'", double30 == 0.08d);
        org.junit.Assert.assertNotNull(rotation31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(str39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D56);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.toString();
        java.lang.String str4 = chartEntity2.getShapeType();
        java.lang.String str5 = chartEntity2.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartEntity: tooltip = " + "'", str3.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "rect" + "'", str4.equals("rect"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartEntity: tooltip = " + "'", str5.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot1.getDatasetGroup();
        java.awt.Paint paint7 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        piePlot1.setLabelBackgroundPaint(paint7);
        piePlot1.setShadowYOffset((double) (short) 10);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        int int1 = defaultKeyedValues2D0.getColumnCount();
        defaultKeyedValues2D0.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        defaultKeyedValues2D0.removeColumn((int) (byte) 0);
        int int8 = defaultKeyedValues2D0.getRowCount();
        java.util.List list9 = defaultKeyedValues2D0.getRowKeys();
        try {
            defaultKeyedValues2D0.removeColumn((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle9.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle9.getItemContainer();
        boolean boolean15 = blockContainer13.equals((java.lang.Object) '4');
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle2.setTextAlignment(horizontalAlignment5);
        java.awt.Font font8 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font8);
        textTitle9.setText("PieLabelLinkStyle.STANDARD");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.lang.String str14 = piePlot13.getNoDataMessage();
        boolean boolean15 = piePlot13.isCircular();
        java.awt.Stroke stroke17 = piePlot13.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetGroup datasetGroup18 = piePlot13.getDatasetGroup();
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        piePlot13.setLabelBackgroundPaint(paint19);
        boolean boolean21 = textTitle9.equals((java.lang.Object) piePlot13);
        java.lang.String str22 = textTitle9.getID();
        org.jfree.chart.util.VerticalAlignment verticalAlignment23 = textTitle9.getVerticalAlignment();
        org.jfree.chart.block.ColumnArrangement columnArrangement26 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment5, verticalAlignment23, (double) (-1L), (double) (short) -1);
        java.lang.String str27 = verticalAlignment23.toString();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNull(datasetGroup18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(verticalAlignment23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "VerticalAlignment.CENTER" + "'", str27.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        defaultCategoryDataset0.setValue((java.lang.Number) 0.025d, (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0);
        defaultCategoryDataset0.removeRow(0);
        defaultCategoryDataset0.addValue((double) 10.0f, (java.lang.Comparable) 100.0d, (java.lang.Comparable) "hi!");
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        java.awt.Paint paint6 = piePlot1.getOutlinePaint();
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Paint paint9 = null;
        piePlot1.setOutlinePaint(paint9);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        defaultKeyedValues2D0.addValue((java.lang.Number) 0.0f, (java.lang.Comparable) ' ', (java.lang.Comparable) (byte) 100);
        java.lang.Comparable comparable5 = null;
        try {
            int int6 = defaultKeyedValues2D0.getRowIndex(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String str1 = multiplePiePlot0.getPlotType();
        double double2 = multiplePiePlot0.getLimit();
        boolean boolean3 = multiplePiePlot0.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Multiple Pie Plot" + "'", str1.equals("Multiple Pie Plot"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        java.awt.geom.Rectangle2D rectangle2D13 = textTitle1.getBounds();
        java.awt.Font font14 = textTitle1.getFont();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = textTitle1.getTextAlignment();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangle2D13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo1.getOptionalLibraries();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list5 = defaultCategoryDataset4.getColumnKeys();
        defaultCategoryDataset4.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultCategoryDataset4.getGroup();
        java.util.List list10 = defaultCategoryDataset4.getColumnKeys();
        projectInfo1.setContributors(list10);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(datasetGroup9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.PaintMap paintMap0 = new org.jfree.chart.PaintMap();
        paintMap0.clear();
        java.awt.Paint paint3 = paintMap0.getPaint((java.lang.Comparable) 2.025d);
        boolean boolean5 = paintMap0.containsKey((java.lang.Comparable) "PieSection: 0, 0(3)");
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        double double1 = textTitle0.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Multiple Pie Plot", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        objectList1.clear();
        boolean boolean4 = objectList1.equals((java.lang.Object) 0.4d);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.PiePlotState piePlotState17 = piePlot6.initialise(graphics2D11, rectangle2D12, piePlot14, (java.lang.Integer) (-97), plotRenderingInfo16);
        piePlot6.setNoDataMessage("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        piePlot6.setMaximumLabelWidth((double) (byte) -1);
        float float22 = piePlot6.getBackgroundImageAlpha();
        boolean boolean23 = objectList1.equals((java.lang.Object) piePlot6);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(piePlotState17);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.5f + "'", float22 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.awt.Color color1 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color2 = java.awt.Color.getColor("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        java.lang.String str9 = pieSectionEntity7.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke3);
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9);
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.TableOrder tableOrder13 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        boolean boolean15 = tableOrder13.equals((java.lang.Object) "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.Object obj16 = null;
        boolean boolean17 = tableOrder13.equals(obj16);
        java.lang.String str18 = tableOrder13.toString();
        boolean boolean19 = lineBorder12.equals((java.lang.Object) str18);
        boolean boolean20 = defaultDrawingSupplier9.equals((java.lang.Object) boolean19);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(tableOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TableOrder.BY_COLUMN" + "'", str18.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator3 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator4 = null;
        java.lang.String str5 = chartEntity2.getImageMapAreaTag(toolTipTagFragmentGenerator3, uRLTagFragmentGenerator4);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        double double6 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getURLText();
        java.lang.Object obj4 = chartEntity2.clone();
        java.lang.String str5 = chartEntity2.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        defaultCategoryDataset0.setValue((java.lang.Number) 0.025d, (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0);
        org.jfree.data.general.DatasetGroup datasetGroup9 = defaultCategoryDataset0.getGroup();
        defaultCategoryDataset0.validateObject();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 0.025d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(datasetGroup9);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke8);
        java.awt.Stroke stroke10 = piePlot1.getLabelOutlineStroke();
        piePlot1.setLabelLinksVisible(true);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = piePlot1.getLegendLabelURLGenerator();
        boolean boolean14 = piePlot1.getLabelLinksVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(pieURLGenerator13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        java.awt.Stroke stroke9 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean10 = piePlot1.isOutlineVisible();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.lang.String str14 = piePlot13.getNoDataMessage();
        float float15 = piePlot13.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot13.setToolTipGenerator(pieToolTipGenerator16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke20);
        java.awt.Stroke stroke22 = piePlot13.getLabelOutlineStroke();
        java.awt.Color color23 = java.awt.Color.white;
        piePlot13.setLabelLinkPaint((java.awt.Paint) color23);
        piePlot1.setSectionPaint((java.lang.Comparable) '#', (java.awt.Paint) color23);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor26 = piePlot1.getLabelDistributor();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = piePlot1.getInsets();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle1.setHorizontalAlignment(horizontalAlignment13);
        org.jfree.chart.block.BlockFrame blockFrame15 = textTitle1.getFrame();
        org.jfree.chart.block.BlockFrame blockFrame16 = textTitle1.getFrame();
        java.lang.String str17 = textTitle1.getID();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(blockFrame15);
        org.junit.Assert.assertNotNull(blockFrame16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image3, "rect", "", "PieLabelLinkStyle.STANDARD");
        java.lang.String str8 = projectInfo7.getName();
        java.lang.String str9 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str8.equals("PieLabelLinkStyle.STANDARD"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str9.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        boolean boolean9 = piePlot1.isSubplot();
        float float10 = piePlot1.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String str1 = multiplePiePlot0.getPlotType();
        org.jfree.data.general.DatasetGroup datasetGroup2 = multiplePiePlot0.getDatasetGroup();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Multiple Pie Plot" + "'", str1.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle1.setHorizontalAlignment(horizontalAlignment13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.lang.String str18 = piePlot17.getNoDataMessage();
        float float19 = piePlot17.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator20 = null;
        piePlot17.setToolTipGenerator(pieToolTipGenerator20);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextOutlineStroke();
        piePlot17.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke24);
        java.awt.Stroke stroke26 = piePlot17.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets();
        piePlot17.setInsets(rectangleInsets27);
        java.lang.Object obj29 = null;
        boolean boolean30 = rectangleInsets27.equals(obj29);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        java.lang.String str33 = piePlot32.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets();
        double double36 = rectangleInsets34.calculateRightOutset((double) 0);
        double double38 = rectangleInsets34.calculateTopOutset((double) (-1));
        piePlot32.setLabelPadding(rectangleInsets34);
        double double41 = rectangleInsets34.extendWidth((double) (short) 100);
        double double43 = rectangleInsets34.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle45.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets34.createInsetRectangle(rectangle2D46);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets27.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType50, lengthAdjustmentType51);
        java.awt.Shape shape53 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity55 = new org.jfree.chart.entity.ChartEntity(shape53, "");
        java.lang.String str56 = chartEntity55.toString();
        java.lang.Object obj57 = textTitle1.draw(graphics2D15, rectangle2D52, (java.lang.Object) str56);
        java.awt.Paint paint58 = textTitle1.getBackgroundPaint();
        textTitle1.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 102.0d + "'", double41 == 102.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "ChartEntity: tooltip = " + "'", str56.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertNull(obj57);
        org.junit.Assert.assertNull(paint58);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font2);
        java.awt.Font font4 = textTitle3.getFont();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.PiePlotState piePlotState17 = piePlot6.initialise(graphics2D11, rectangle2D12, piePlot14, (java.lang.Integer) (-97), plotRenderingInfo16);
        piePlot6.setShadowXOffset((double) '4');
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", font4, (org.jfree.chart.plot.Plot) piePlot6, true);
        jFreeChart21.setTextAntiAlias(true);
        org.jfree.chart.title.TextTitle textTitle24 = null;
        jFreeChart21.setTitle(textTitle24);
        jFreeChart21.removeLegend();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.data.general.PieDataset pieDataset28 = null;
        org.jfree.chart.plot.PiePlot piePlot29 = new org.jfree.chart.plot.PiePlot(pieDataset28);
        boolean boolean30 = piePlot29.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot29);
        jFreeChart31.setAntiAlias(false);
        java.lang.Object obj34 = jFreeChart31.clone();
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        java.lang.String str37 = piePlot36.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets();
        double double40 = rectangleInsets38.calculateRightOutset((double) 0);
        double double42 = rectangleInsets38.calculateTopOutset((double) (-1));
        piePlot36.setLabelPadding(rectangleInsets38);
        double double45 = rectangleInsets38.extendWidth((double) (short) 100);
        jFreeChart31.setPadding(rectangleInsets38);
        double double48 = rectangleInsets38.calculateLeftOutset(0.08d);
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D51 = textTitle50.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D51, rectangleAnchor52);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = rectangleInsets38.createAdjustedRectangle(rectangle2D51, lengthAdjustmentType54, lengthAdjustmentType55);
        org.jfree.chart.block.BlockBorder blockBorder57 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = blockBorder57.getInsets();
        org.jfree.data.general.PieDataset pieDataset59 = null;
        org.jfree.chart.plot.PiePlot piePlot60 = new org.jfree.chart.plot.PiePlot(pieDataset59);
        java.lang.String str61 = piePlot60.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = new org.jfree.chart.util.RectangleInsets();
        double double64 = rectangleInsets62.calculateRightOutset((double) 0);
        double double66 = rectangleInsets62.calculateTopOutset((double) (-1));
        piePlot60.setLabelPadding(rectangleInsets62);
        double double69 = rectangleInsets62.extendWidth((double) (short) 100);
        double double71 = rectangleInsets62.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D74 = textTitle73.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D76 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D74, rectangleAnchor75);
        java.awt.geom.Rectangle2D rectangle2D77 = rectangleInsets62.createInsetRectangle(rectangle2D74);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType78 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = rectangleInsets58.createAdjustedRectangle(rectangle2D74, lengthAdjustmentType78, lengthAdjustmentType79);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor81 = null;
        java.awt.geom.Point2D point2D82 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D80, rectangleAnchor81);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo83 = null;
        try {
            jFreeChart21.draw(graphics2D27, rectangle2D56, point2D82, chartRenderingInfo83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(piePlotState17);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 102.0d + "'", double45 == 102.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNull(str61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.0d + "'", double66 == 1.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 102.0d + "'", double69 == 102.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.0d + "'", double71 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D74);
        org.junit.Assert.assertNotNull(rectangleAnchor75);
        org.junit.Assert.assertNotNull(point2D76);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertNotNull(rectangle2D80);
        org.junit.Assert.assertNotNull(point2D82);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textTitle1.getTextAlignment();
        java.awt.Font font14 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font14);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = textTitle15.getHorizontalAlignment();
        textTitle1.setTextAlignment(horizontalAlignment16);
        java.lang.String str18 = textTitle1.getToolTipText();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(horizontalAlignment16);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        boolean boolean9 = piePlot1.isSubplot();
        piePlot1.setLabelLinksVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo4.setInfo("");
        java.awt.Image image8 = null;
        projectInfo4.setLogo(image8);
        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo4.getOptionalLibraries();
        projectInfo1.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        projectInfo1.setCopyright("");
        projectInfo1.setCopyright("JFreeChart");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(libraryArray10);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.util.TableOrder tableOrder0 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        boolean boolean2 = tableOrder0.equals((java.lang.Object) "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.Object obj3 = null;
        boolean boolean4 = tableOrder0.equals(obj3);
        java.lang.String str5 = tableOrder0.toString();
        java.lang.Object obj6 = null;
        boolean boolean7 = tableOrder0.equals(obj6);
        org.junit.Assert.assertNotNull(tableOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TableOrder.BY_COLUMN" + "'", str5.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        piePlot1.zoom((double) (byte) 10);
        piePlot1.setIgnoreNullValues(true);
        piePlot1.setBackgroundImageAlignment(15);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            piePlot1.drawOutline(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 8, (float) (byte) 1, (float) 255);
        org.junit.Assert.assertNotNull(color3);
    }
}

