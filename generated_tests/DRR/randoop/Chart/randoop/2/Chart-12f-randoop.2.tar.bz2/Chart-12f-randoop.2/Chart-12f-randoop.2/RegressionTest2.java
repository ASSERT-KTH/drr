import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot1.getLegendItems();
        java.awt.Stroke stroke7 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = piePlot1.getLabelLinkStyle();
        java.awt.Image image9 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
        org.junit.Assert.assertNull(image9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int1 = color0.getTransparency();
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        boolean boolean4 = piePlot3.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot3);
        boolean boolean6 = color0.equals((java.lang.Object) jFreeChart5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        boolean boolean10 = jFreeChart3.isNotify();
        jFreeChart3.setBorderVisible(false);
        boolean boolean13 = jFreeChart3.getAntiAlias();
        org.jfree.chart.plot.Plot plot14 = jFreeChart3.getPlot();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        java.awt.Font font11 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle9.getLegendItemGraphicAnchor();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        org.jfree.chart.plot.Plot plot12 = jFreeChart8.getPlot();
        int int13 = jFreeChart8.getSubtitleCount();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plot12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = new org.jfree.chart.util.RectangleInsets();
        double double5 = rectangleInsets3.calculateRightOutset((double) 0);
        double double7 = rectangleInsets3.calculateTopOutset((double) (-1));
        piePlot1.setLabelPadding(rectangleInsets3);
        double double10 = rectangleInsets3.extendWidth((double) (short) 100);
        double double12 = rectangleInsets3.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.util.UnitType unitType13 = rectangleInsets3.getUnitType();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 102.0d + "'", double10 == 102.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(unitType13);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        textTitle1.setHorizontalAlignment(horizontalAlignment7);
        java.awt.Font font9 = textTitle1.getFont();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = null;
        try {
            org.jfree.chart.util.Size2D size2D12 = textTitle1.arrange(graphics2D10, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle9.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle9.getItemContainer();
        java.util.List list14 = blockContainer13.getBlocks();
        org.jfree.chart.block.Arrangement arrangement15 = blockContainer13.getArrangement();
        blockContainer13.clear();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle19.setPaint((java.awt.Paint) color20);
        java.lang.String str22 = textTitle19.getText();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        boolean boolean25 = piePlot24.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot24);
        jFreeChart26.setAntiAlias(false);
        textTitle19.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart26);
        org.jfree.data.general.PieDataset pieDataset30 = null;
        org.jfree.chart.plot.PiePlot piePlot31 = new org.jfree.chart.plot.PiePlot(pieDataset30);
        java.lang.String str32 = piePlot31.getNoDataMessage();
        float float33 = piePlot31.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator34 = null;
        piePlot31.setToolTipGenerator(pieToolTipGenerator34);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke38 = defaultDrawingSupplier37.getNextOutlineStroke();
        piePlot31.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke38);
        java.awt.Stroke stroke40 = piePlot31.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets();
        piePlot31.setInsets(rectangleInsets41);
        textTitle19.setMargin(rectangleInsets41);
        java.awt.geom.Rectangle2D rectangle2D44 = textTitle19.getBounds();
        org.jfree.data.general.PieDataset pieDataset45 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity51 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D44, pieDataset45, (int) (short) 1, 1, (java.lang.Comparable) "Multiple Pie Plot", "", "");
        org.jfree.chart.title.TextTitle textTitle53 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color54 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle53.setPaint((java.awt.Paint) color54);
        java.lang.String str56 = textTitle53.getText();
        java.lang.String str57 = textTitle53.getText();
        try {
            java.lang.Object obj58 = blockContainer13.draw(graphics2D17, rectangle2D44, (java.lang.Object) textTitle53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(arrangement15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str22.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str56.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str57.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        piePlot1.zoom((double) (byte) 10);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.lang.String str20 = piePlot19.getNoDataMessage();
        float float21 = piePlot19.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator22 = null;
        piePlot19.setToolTipGenerator(pieToolTipGenerator22);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke26 = defaultDrawingSupplier25.getNextOutlineStroke();
        piePlot19.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke26);
        java.awt.Stroke stroke28 = piePlot19.getLabelOutlineStroke();
        java.awt.Stroke stroke29 = null;
        piePlot19.setOutlineStroke(stroke29);
        piePlot19.setSectionOutlinesVisible(true);
        java.awt.Stroke stroke33 = piePlot19.getLabelOutlineStroke();
        piePlot1.setBaseSectionOutlineStroke(stroke33);
        java.awt.Paint paint35 = piePlot1.getLabelOutlinePaint();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((-16777216));
        pieLabelDistributor1.distributeLabels((double) (byte) 10, (double) (-16777216));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str3 = standardPieSectionLabelGenerator2.getLabelFormat();
        java.text.AttributedString attributedString5 = standardPieSectionLabelGenerator2.getAttributedLabel((-97));
        java.text.NumberFormat numberFormat6 = standardPieSectionLabelGenerator2.getPercentFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.text.NumberFormat numberFormat8 = standardPieSectionLabelGenerator7.getPercentFormat();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TableOrder.BY_COLUMN", numberFormat6, numberFormat8);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        java.lang.String str12 = standardPieSectionLabelGenerator9.generateSectionLabel(pieDataset10, (java.lang.Comparable) 12.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str3.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertNull(attributedString5);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint paint8 = legendTitle7.getItemPaint();
        java.awt.Font font9 = legendTitle7.getItemFont();
        java.awt.Color color15 = java.awt.Color.cyan;
        java.awt.Color color16 = java.awt.Color.getColor("UnitType.ABSOLUTE", color15);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) (short) 0, 0.0d, (double) 100.0f, (double) 100, (java.awt.Paint) color16);
        java.awt.Paint paint18 = blockBorder17.getPaint();
        legendTitle7.setItemPaint(paint18);
        org.jfree.chart.util.UnitType unitType20 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = new org.jfree.chart.util.RectangleInsets(unitType20, (double) (short) -1, 0.4d, (double) 10, 0.0d);
        double double27 = rectangleInsets25.calculateBottomInset(0.0d);
        legendTitle7.setLegendItemGraphicPadding(rectangleInsets25);
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = legendTitle7.getLegendItemGraphicPadding();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(unitType20);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("");
        java.lang.Object obj2 = textTitle1.clone();
        java.awt.Paint paint3 = textTitle1.getBackgroundPaint();
        java.lang.String str4 = textTitle1.getToolTipText();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        double double4 = piePlot1.getInteriorGap();
        double double5 = piePlot1.getLabelGap();
        java.awt.Paint paint6 = piePlot1.getNoDataMessagePaint();
        org.jfree.chart.block.ColumnArrangement columnArrangement7 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement8.clear();
        boolean boolean11 = columnArrangement8.equals((java.lang.Object) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1, (org.jfree.chart.block.Arrangement) columnArrangement7, (org.jfree.chart.block.Arrangement) columnArrangement8);
        columnArrangement8.clear();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.08d + "'", double4 == 0.08d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.025d + "'", double5 == 0.025d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.awt.Color color4 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) (short) 1, (double) ' ', 0.0d, (java.awt.Paint) color4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = blockBorder5.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder5.getInsets();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultCategoryDataset0.getGroup();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot8);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot8);
        boolean boolean12 = datasetGroup5.equals((java.lang.Object) jFreeChart11);
        java.lang.Object obj13 = jFreeChart11.getTextAntiAlias();
        org.jfree.chart.plot.Plot plot14 = jFreeChart11.getPlot();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke8);
        java.awt.Stroke stroke10 = piePlot1.getLabelOutlineStroke();
        java.awt.Color color11 = java.awt.Color.white;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color11);
        java.awt.Color color13 = color11.brighter();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        piePlot1.zoom((double) (byte) 10);
        piePlot1.setIgnoreNullValues(true);
        piePlot1.setBackgroundImageAlignment(15);
        try {
            piePlot1.setInteriorGap((double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (35.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle9.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendTitle9.arrange(graphics2D13, rectangleConstraint14);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D19 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D15, (double) 1L, 0.0d, rectangleAnchor18);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        java.lang.String str1 = multiplePiePlot0.getPlotType();
        multiplePiePlot0.setNoDataMessage("");
        org.jfree.chart.LegendItemCollection legendItemCollection4 = multiplePiePlot0.getLegendItems();
        java.lang.Comparable comparable5 = multiplePiePlot0.getAggregatedItemsKey();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) 2.025d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Multiple Pie Plot" + "'", str1.equals("Multiple Pie Plot"));
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + "Other" + "'", comparable5.equals("Other"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        textTitle1.setID("PieLabelLinkStyle.STANDARD");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = null;
        try {
            org.jfree.chart.util.Size2D size2D9 = textTitle1.arrange(graphics2D7, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets();
        double double6 = rectangleInsets4.calculateRightOutset((double) 0);
        double double8 = rectangleInsets4.calculateTopOutset((double) (-1));
        piePlot2.setLabelPadding(rectangleInsets4);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.lang.String str12 = piePlot11.getNoDataMessage();
        float float13 = piePlot11.getForegroundAlpha();
        piePlot11.setPieIndex((int) (byte) 10);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.lang.String str20 = piePlot19.getNoDataMessage();
        boolean boolean21 = piePlot19.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator22 = piePlot19.getLegendLabelToolTipGenerator();
        float float23 = piePlot19.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.PiePlotState piePlotState26 = piePlot11.initialise(graphics2D16, rectangle2D17, piePlot19, (java.lang.Integer) 0, plotRenderingInfo25);
        piePlot2.setParent((org.jfree.chart.plot.Plot) piePlot19);
        boolean boolean28 = pieLabelLinkStyle0.equals((java.lang.Object) piePlot2);
        org.jfree.data.general.PieDataset pieDataset29 = null;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot(pieDataset29);
        boolean boolean31 = piePlot30.isOutlineVisible();
        float float32 = piePlot30.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator33 = null;
        piePlot30.setURLGenerator(pieURLGenerator33);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator35 = piePlot30.getLabelGenerator();
        java.awt.Image image36 = null;
        piePlot30.setBackgroundImage(image36);
        boolean boolean38 = pieLabelLinkStyle0.equals((java.lang.Object) piePlot30);
        java.awt.Shape shape39 = piePlot30.getLegendItemShape();
        piePlot30.setCircular(false, false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator22);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 1.0f + "'", float32 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.lang.String str12 = piePlot11.getNoDataMessage();
        float float13 = piePlot11.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator14 = null;
        piePlot11.setToolTipGenerator(pieToolTipGenerator14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        piePlot11.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke18);
        java.awt.Stroke stroke20 = piePlot11.getLabelOutlineStroke();
        java.awt.Color color21 = java.awt.Color.white;
        piePlot11.setLabelLinkPaint((java.awt.Paint) color21);
        legendTitle9.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray24 = legendTitle9.getSources();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(legendItemSourceArray24);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        piePlot1.setPieIndex((int) (byte) 10);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        java.lang.String str10 = piePlot9.getNoDataMessage();
        boolean boolean11 = piePlot9.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot9.getLegendLabelToolTipGenerator();
        float float13 = piePlot9.getForegroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.PiePlotState piePlotState16 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) 0, plotRenderingInfo15);
        java.awt.Color color17 = java.awt.Color.RED;
        piePlot1.setBackgroundPaint((java.awt.Paint) color17);
        float float19 = piePlot1.getForegroundAlpha();
        java.awt.Paint paint20 = piePlot1.getBackgroundPaint();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState26 = piePlot1.initialise(graphics2D21, rectangle2D22, piePlot23, (java.lang.Integer) (-16777216), plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertNotNull(piePlotState16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        java.text.AttributedString attributedString4 = standardPieSectionLabelGenerator1.getAttributedLabel((-97));
        java.text.NumberFormat numberFormat5 = standardPieSectionLabelGenerator1.getNumberFormat();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str2.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertNull(attributedString4);
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 255, (double) 3, 104.0d);
        double double6 = rectangleInsets4.extendHeight(90.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 92.0d + "'", double6 == 92.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        java.awt.Image image12 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image12, "rect", "", "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = chartChangeEvent17.getType();
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.plot.PiePlot piePlot21 = new org.jfree.chart.plot.PiePlot(pieDataset20);
        boolean boolean22 = piePlot21.isOutlineVisible();
        float float23 = piePlot21.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator24 = null;
        piePlot21.setURLGenerator(pieURLGenerator24);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = piePlot21.getLabelGenerator();
        java.awt.Shape shape27 = piePlot21.getLegendItemShape();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot21.setBaseSectionPaint((java.awt.Paint) color28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", (org.jfree.chart.plot.Plot) piePlot21);
        java.awt.Stroke stroke31 = jFreeChart30.getBorderStroke();
        boolean boolean32 = chartChangeEventType18.equals((java.lang.Object) stroke31);
        piePlot1.setLabelOutlineStroke(stroke31);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle9.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockContainer blockContainer13 = legendTitle9.getItemContainer();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.lang.String str16 = piePlot15.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        double double19 = rectangleInsets17.calculateRightOutset((double) 0);
        double double21 = rectangleInsets17.calculateTopOutset((double) (-1));
        piePlot15.setLabelPadding(rectangleInsets17);
        double double24 = rectangleInsets17.extendWidth((double) (short) 100);
        double double26 = rectangleInsets17.calculateBottomInset((double) (byte) -1);
        legendTitle9.setLegendItemGraphicPadding(rectangleInsets17);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.TableOrder tableOrder30 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        boolean boolean32 = tableOrder30.equals((java.lang.Object) "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.Object obj33 = null;
        boolean boolean34 = tableOrder30.equals(obj33);
        java.lang.String str35 = tableOrder30.toString();
        boolean boolean36 = lineBorder29.equals((java.lang.Object) str35);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("");
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle39.getBounds();
        lineBorder29.draw(graphics2D37, rectangle2D40);
        try {
            legendTitle9.draw(graphics2D28, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(blockContainer13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 102.0d + "'", double24 == 102.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(tableOrder30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "TableOrder.BY_COLUMN" + "'", str35.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("RectangleAnchor.LEFT");
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        float float4 = piePlot2.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator5 = null;
        piePlot2.setToolTipGenerator(pieToolTipGenerator5);
        defaultCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot2);
        org.jfree.chart.plot.Plot plot8 = piePlot2.getParent();
        java.awt.Paint paint9 = piePlot2.getLabelOutlinePaint();
        piePlot2.setExplodePercent((java.lang.Comparable) (byte) 100, (double) 1L);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getColumnKeys();
        defaultCategoryDataset0.removeValue((java.lang.Comparable) (-1), (java.lang.Comparable) "rect");
        defaultCategoryDataset0.setValue((java.lang.Number) 0.025d, (java.lang.Comparable) 10.0d, (java.lang.Comparable) 0);
        try {
            java.lang.Comparable comparable10 = defaultCategoryDataset0.getRowKey(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = legendTitle7.getLegendItemGraphicEdge();
        double double9 = legendTitle7.getContentXOffset();
        legendTitle7.setPadding((double) (-1.0f), 104.0d, (double) ' ', 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image3, "rect", "", "PieLabelLinkStyle.STANDARD");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent8.getType();
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        boolean boolean13 = piePlot12.isOutlineVisible();
        float float14 = piePlot12.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator15 = null;
        piePlot12.setURLGenerator(pieURLGenerator15);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = piePlot12.getLabelGenerator();
        java.awt.Shape shape18 = piePlot12.getLegendItemShape();
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot12.setBaseSectionPaint((java.awt.Paint) color19);
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", (org.jfree.chart.plot.Plot) piePlot12);
        java.awt.Stroke stroke22 = jFreeChart21.getBorderStroke();
        boolean boolean23 = chartChangeEventType9.equals((java.lang.Object) stroke22);
        boolean boolean25 = chartChangeEventType9.equals((java.lang.Object) 1.0E-5d);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        boolean boolean9 = piePlot1.isSubplot();
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot(pieDataset10);
        java.lang.String str12 = piePlot11.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets();
        double double15 = rectangleInsets13.calculateRightOutset((double) 0);
        double double17 = rectangleInsets13.calculateTopOutset((double) (-1));
        piePlot11.setLabelPadding(rectangleInsets13);
        piePlot11.setMaximumLabelWidth((double) (byte) 0);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot11.setLabelOutlinePaint((java.awt.Paint) color21);
        piePlot11.setMinimumArcAngleToDraw((double) (-97));
        java.awt.Color color26 = java.awt.Color.BLUE;
        piePlot11.setSectionOutlinePaint((java.lang.Comparable) (byte) 1, (java.awt.Paint) color26);
        piePlot1.setLabelShadowPaint((java.awt.Paint) color26);
        piePlot1.setPieIndex(2);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        java.awt.Paint paint15 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        boolean boolean16 = rectangleEdge13.equals((java.lang.Object) paint15);
        textTitle1.setPosition(rectangleEdge13);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = textTitle2.getHorizontalAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = textTitle2.getPadding();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        java.awt.Paint paint3 = piePlot1.getBaseSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        java.awt.Stroke stroke5 = piePlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getInsets();
        piePlot1.setOutlineVisible(true);
        org.jfree.chart.util.UnitType unitType9 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str10 = unitType9.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets(unitType9, 102.0d, (double) 10L, (double) 0.0f, (double) (-1L));
        piePlot1.setInsets(rectangleInsets15, true);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(unitType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UnitType.ABSOLUTE" + "'", str10.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int2 = color1.getTransparency();
        float[] floatArray3 = null;
        float[] floatArray4 = color1.getComponents(floatArray3);
        float[] floatArray5 = color0.getRGBComponents(floatArray4);
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.awt.Color color4 = java.awt.Color.BLUE;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (short) 1, (double) (short) 1, (double) ' ', 0.0d, (java.awt.Paint) color4);
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = org.jfree.chart.JFreeChart.INFO;
        projectInfo6.addLibrary((org.jfree.chart.ui.Library) projectInfo7);
        projectInfo7.setInfo("");
        boolean boolean11 = blockBorder5.equals((java.lang.Object) projectInfo7);
        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo7.getLibraries();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(projectInfo7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(libraryArray12);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot4 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot4.getLegendItems();
        java.awt.Color color6 = java.awt.Color.CYAN;
        multiplePiePlot4.setAggregatedItemsPaint((java.awt.Paint) color6);
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(3.0d, (-1.0d), (double) 0.5f, 10.0d, (java.awt.Paint) color6);
        java.awt.Color color9 = color6.brighter();
        java.lang.String str10 = color9.toString();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment11, verticalAlignment12, (double) 100L, (double) 100);
        flowArrangement15.clear();
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement15);
        org.jfree.chart.block.BlockContainer blockContainer18 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement15);
        org.jfree.chart.block.Arrangement arrangement19 = blockContainer18.getArrangement();
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle21.setPaint((java.awt.Paint) color22);
        java.lang.String str24 = textTitle21.getText();
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.plot.PiePlot piePlot26 = new org.jfree.chart.plot.PiePlot(pieDataset25);
        boolean boolean27 = piePlot26.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot26);
        jFreeChart28.setAntiAlias(false);
        textTitle21.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart28);
        java.awt.Paint paint32 = textTitle21.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle21.setHorizontalAlignment(horizontalAlignment33);
        org.jfree.chart.block.BlockFrame blockFrame35 = textTitle21.getFrame();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer18.add((org.jfree.chart.block.Block) textTitle21, (java.lang.Object) color36);
        java.awt.Color color38 = java.awt.Color.orange;
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color38);
        java.awt.color.ColorSpace colorSpace40 = color38.getColorSpace();
        float[] floatArray41 = null;
        float[] floatArray42 = color36.getComponents(colorSpace40, floatArray41);
        float[] floatArray43 = color9.getColorComponents(floatArray42);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str10.equals("java.awt.Color[r=0,g=255,b=255]"));
        org.junit.Assert.assertNotNull(arrangement19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str24.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(blockFrame35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(colorSpace40);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("RectangleAnchor.LEFT");
        java.lang.Object obj4 = jFreeChartResources0.handleGetObject("Pie Plot");
        java.util.Locale locale5 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNull(obj4);
        org.junit.Assert.assertNull(locale5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        int int8 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        float float5 = piePlot1.getForegroundAlpha();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj7 = defaultDrawingSupplier6.clone();
        java.awt.Paint paint8 = defaultDrawingSupplier6.getNextFillPaint();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.lang.Object obj2 = jFreeChartResources0.handleGetObject("RectangleAnchor.LEFT");
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        java.util.Locale locale4 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(obj2);
        org.junit.Assert.assertNotNull(strSet3);
        org.junit.Assert.assertNull(locale4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        int int9 = pieSectionEntity7.getPieIndex();
        java.lang.String str10 = pieSectionEntity7.getURLText();
        pieSectionEntity7.setSectionIndex(0);
        pieSectionEntity7.setSectionIndex(1);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        boolean boolean3 = defaultCategoryDataset0.equals((java.lang.Object) 1.0f);
        int int4 = defaultCategoryDataset0.getRowCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setLicenceText("");
        projectInfo1.setVersion("hi!");
        java.awt.Image image7 = null;
        projectInfo1.setLogo(image7);
        projectInfo1.setCopyright("java.awt.Color[r=0,g=255,b=255]");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        java.awt.Stroke stroke9 = piePlot1.getBaseSectionOutlineStroke();
        boolean boolean10 = piePlot1.getIgnoreZeroValues();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockBorder12.getInsets();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.lang.String str16 = piePlot15.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets();
        double double19 = rectangleInsets17.calculateRightOutset((double) 0);
        double double21 = rectangleInsets17.calculateTopOutset((double) (-1));
        piePlot15.setLabelPadding(rectangleInsets17);
        double double24 = rectangleInsets17.extendWidth((double) (short) 100);
        double double26 = rectangleInsets17.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle28.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor30);
        java.awt.geom.Rectangle2D rectangle2D32 = rectangleInsets17.createInsetRectangle(rectangle2D29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType33 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets13.createAdjustedRectangle(rectangle2D29, lengthAdjustmentType33, lengthAdjustmentType34);
        piePlot1.drawBackgroundImage(graphics2D11, rectangle2D35);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle38.setPaint((java.awt.Paint) color39);
        java.awt.Font font42 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font42);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = textTitle43.getHorizontalAlignment();
        textTitle38.setHorizontalAlignment(horizontalAlignment44);
        textTitle38.setExpandToFitSpace(true);
        double double48 = textTitle38.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = textTitle38.getPosition();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge49);
        double double51 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D35, rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 102.0d + "'", double24 == 102.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        piePlot1.setPieIndex((int) (byte) 10);
        java.lang.Object obj6 = piePlot1.clone();
        double double7 = piePlot1.getMaximumExplodePercent();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) 100L, (double) 100);
        flowArrangement12.clear();
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        org.jfree.chart.block.Arrangement arrangement16 = blockContainer15.getArrangement();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle18.setPaint((java.awt.Paint) color19);
        java.lang.String str21 = textTitle18.getText();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean24 = piePlot23.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot23);
        jFreeChart25.setAntiAlias(false);
        textTitle18.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart25);
        java.awt.Paint paint29 = textTitle18.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment30 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle18.setHorizontalAlignment(horizontalAlignment30);
        org.jfree.chart.block.BlockFrame blockFrame32 = textTitle18.getFrame();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer15.add((org.jfree.chart.block.Block) textTitle18, (java.lang.Object) color33);
        org.jfree.data.general.PieDataset pieDataset35 = null;
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot(pieDataset35);
        java.lang.String str37 = piePlot36.getNoDataMessage();
        float float38 = piePlot36.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator39 = null;
        piePlot36.setToolTipGenerator(pieToolTipGenerator39);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke43 = defaultDrawingSupplier42.getNextOutlineStroke();
        piePlot36.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke43);
        java.awt.Stroke stroke45 = piePlot36.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = new org.jfree.chart.util.RectangleInsets();
        piePlot36.setInsets(rectangleInsets46);
        double double49 = rectangleInsets46.calculateBottomInset((double) 1.0f);
        blockContainer15.setMargin(rectangleInsets46);
        piePlot1.setInsets(rectangleInsets46);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(arrangement16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str21.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(horizontalAlignment30);
        org.junit.Assert.assertNotNull(blockFrame32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 1.0f + "'", float38 == 1.0f);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        float float11 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("Rotation.CLOCKWISE");
        java.lang.String str14 = textTitle13.getURLText();
        double double15 = textTitle13.getWidth();
        java.lang.Object obj16 = textTitle13.clone();
        textTitle13.setPadding(1.0E-5d, (double) (short) 10, 0.0d, (double) 0);
        jFreeChart3.setTitle(textTitle13);
        textTitle13.setText("JFreeChart version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().PieLabelLinkStyle.STANDARD  ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(obj16);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test051");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        projectInfo1.setLicenceText("");
//        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo5.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
//        projectInfo5.setLicenceName("rect");
//        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        java.lang.String str11 = projectInfo1.toString();
//        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo1.getOptionalLibraries();
//        java.lang.String str13 = projectInfo1.getCopyright();
//        projectInfo1.addOptionalLibrary("JFreeChart version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().PieLabelLinkStyle.STANDARD  ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n (C)opyright 2000-2007, by Object Refinery Limited and Contributors ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertNotNull(projectInfo5);
//        org.junit.Assert.assertNotNull(projectInfo6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JFreeChart version hi!.\njava.awt.Color[r=0,g=255,b=255].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().PieLabelLinkStyle.STANDARD  ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n (C)opyright 2000-2007, by Object Refinery Limited and Contributors ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str11.equals("JFreeChart version hi!.\njava.awt.Color[r=0,g=255,b=255].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().PieLabelLinkStyle.STANDARD  ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n (C)opyright 2000-2007, by Object Refinery Limited and Contributors ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
//        org.junit.Assert.assertNotNull(libraryArray12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str13.equals("java.awt.Color[r=0,g=255,b=255]"));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getGPL();
        java.lang.String str2 = licences0.getGPL();
        java.lang.String str3 = licences0.getLGPL();
        java.lang.String str4 = licences0.getLGPL();
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "PieSection: 0, 0(3)");
        pieSectionEntity7.setSectionIndex(0);
        int int13 = pieSectionEntity7.getPieIndex();
        int int14 = pieSectionEntity7.getPieIndex();
        pieSectionEntity7.setSectionIndex(128);
        java.lang.Comparable comparable17 = pieSectionEntity7.getSectionKey();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator18 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator19 = null;
        try {
            java.lang.String str20 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator18, uRLTagFragmentGenerator19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + "PieSection: 0, 0(3)" + "'", comparable17.equals("PieSection: 0, 0(3)"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addOptionalLibrary("hi!");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list4 = defaultCategoryDataset3.getColumnKeys();
        int int5 = defaultCategoryDataset3.getRowCount();
        java.util.List list6 = defaultCategoryDataset3.getRowKeys();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) list6);
        java.lang.String str8 = basicProjectInfo0.getInfo();
        basicProjectInfo0.setVersion("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        float float11 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        jFreeChart3.setPadding(rectangleInsets12);
        int int14 = jFreeChart3.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test056");
//        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
//        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
//        boolean boolean3 = tableOrder1.equals((java.lang.Object) "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
//        java.lang.Object obj4 = null;
//        boolean boolean5 = tableOrder1.equals(obj4);
//        java.lang.String str6 = tableOrder1.toString();
//        boolean boolean7 = lineBorder0.equals((java.lang.Object) str6);
//        java.awt.Graphics2D graphics2D8 = null;
//        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
//        java.awt.geom.Rectangle2D rectangle2D11 = textTitle10.getBounds();
//        lineBorder0.draw(graphics2D8, rectangle2D11);
//        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo14 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo13.addLibrary((org.jfree.chart.ui.Library) projectInfo14);
//        projectInfo14.setLicenceText("");
//        org.jfree.chart.ui.ProjectInfo projectInfo18 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo19 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo18.addLibrary((org.jfree.chart.ui.Library) projectInfo19);
//        projectInfo18.setLicenceName("rect");
//        projectInfo14.addLibrary((org.jfree.chart.ui.Library) projectInfo18);
//        java.lang.String str24 = projectInfo14.toString();
//        org.jfree.chart.ui.Library[] libraryArray25 = projectInfo14.getOptionalLibraries();
//        java.lang.String str26 = projectInfo14.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray27 = projectInfo14.getLibraries();
//        boolean boolean28 = lineBorder0.equals((java.lang.Object) projectInfo14);
//        org.junit.Assert.assertNotNull(tableOrder1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TableOrder.BY_COLUMN" + "'", str6.equals("TableOrder.BY_COLUMN"));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(rectangle2D11);
//        org.junit.Assert.assertNotNull(projectInfo13);
//        org.junit.Assert.assertNotNull(projectInfo14);
//        org.junit.Assert.assertNotNull(projectInfo18);
//        org.junit.Assert.assertNotNull(projectInfo19);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "JFreeChart version hi!.\njava.awt.Color[r=0,g=255,b=255].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().PieLabelLinkStyle.STANDARD  ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n (C)opyright 2000-2007, by Object Refinery Limited and Contributors ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str24.equals("JFreeChart version hi!.\njava.awt.Color[r=0,g=255,b=255].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().PieLabelLinkStyle.STANDARD  ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n (C)opyright 2000-2007, by Object Refinery Limited and Contributors ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
//        org.junit.Assert.assertNotNull(libraryArray25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str26.equals("java.awt.Color[r=0,g=255,b=255]"));
//        org.junit.Assert.assertNotNull(libraryArray27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Shape shape2 = piePlot1.getLegendItemShape();
        piePlot1.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetGroup datasetGroup11 = piePlot6.getDatasetGroup();
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        piePlot6.setLabelBackgroundPaint(paint12);
        boolean boolean14 = textTitle2.equals((java.lang.Object) piePlot6);
        double double15 = textTitle2.getContentXOffset();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle18.setPaint((java.awt.Paint) color19);
        java.lang.String str21 = textTitle18.getText();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean24 = piePlot23.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot23);
        jFreeChart25.setAntiAlias(false);
        textTitle18.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart25);
        java.awt.Paint paint29 = textTitle18.getPaint();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle18.getBounds();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        boolean boolean33 = piePlot32.isOutlineVisible();
        float float34 = piePlot32.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator35 = null;
        piePlot32.setURLGenerator(pieURLGenerator35);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator37 = piePlot32.getLabelGenerator();
        java.awt.Shape shape38 = piePlot32.getLegendItemShape();
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot32.setBaseSectionPaint((java.awt.Paint) color39);
        java.lang.Object obj41 = textTitle2.draw(graphics2D16, rectangle2D30, (java.lang.Object) color39);
        java.lang.Object obj42 = textTitle2.clone();
        textTitle2.setURLText("");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str21.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNotNull(obj42);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.lang.String str6 = textTitle3.getText();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot8);
        jFreeChart10.setAntiAlias(false);
        textTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart10);
        org.jfree.chart.plot.Plot plot14 = jFreeChart10.getPlot();
        boolean boolean15 = columnArrangement0.equals((java.lang.Object) plot14);
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.lang.String str18 = piePlot17.getNoDataMessage();
        boolean boolean19 = piePlot17.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = null;
        piePlot17.axisChanged(axisChangeEvent22);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator24 = piePlot17.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot17);
        java.awt.Font font26 = legendTitle25.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = legendTitle25.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = legendTitle25.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockContainer blockContainer29 = legendTitle25.getItemContainer();
        java.util.List list30 = blockContainer29.getBlocks();
        org.jfree.chart.block.Arrangement arrangement31 = blockContainer29.getArrangement();
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle33.setPaint((java.awt.Paint) color34);
        java.lang.String str36 = textTitle33.getText();
        textTitle33.setID("PieLabelLinkStyle.STANDARD");
        blockContainer29.add((org.jfree.chart.block.Block) textTitle33);
        java.lang.Object obj40 = null;
        boolean boolean41 = blockContainer29.equals(obj40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = null;
        try {
            org.jfree.chart.util.Size2D size2D44 = columnArrangement0.arrange(blockContainer29, graphics2D42, rectangleConstraint43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str6.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(plot14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(blockContainer29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(arrangement31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str36.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        org.jfree.chart.plot.Plot plot9 = jFreeChart3.getPlot();
        java.awt.Color color10 = java.awt.Color.yellow;
        int int11 = color10.getAlpha();
        jFreeChart3.setBorderPaint((java.awt.Paint) color10);
        jFreeChart3.setNotify(false);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int16 = color15.getTransparency();
        float[] floatArray17 = null;
        float[] floatArray18 = color15.getComponents(floatArray17);
        jFreeChart3.setBorderPaint((java.awt.Paint) color15);
        org.jfree.chart.event.ChartProgressListener chartProgressListener20 = null;
        jFreeChart3.addProgressListener(chartProgressListener20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getLabelGap();
        java.awt.Paint paint3 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) false, (java.lang.Comparable) '4');
        defaultKeyedValues2D1.setValue((java.lang.Number) 10.0d, (java.lang.Comparable) '4', (java.lang.Comparable) "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        try {
            defaultKeyedValues2D1.removeColumn((java.lang.Comparable) 2.025d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unknown key: 2.025");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetGroup datasetGroup11 = piePlot6.getDatasetGroup();
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        piePlot6.setLabelBackgroundPaint(paint12);
        boolean boolean14 = textTitle2.equals((java.lang.Object) piePlot6);
        double double15 = textTitle2.getContentXOffset();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle18.setPaint((java.awt.Paint) color19);
        java.lang.String str21 = textTitle18.getText();
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        boolean boolean24 = piePlot23.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot23);
        jFreeChart25.setAntiAlias(false);
        textTitle18.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart25);
        java.awt.Paint paint29 = textTitle18.getPaint();
        java.awt.geom.Rectangle2D rectangle2D30 = textTitle18.getBounds();
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        boolean boolean33 = piePlot32.isOutlineVisible();
        float float34 = piePlot32.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator35 = null;
        piePlot32.setURLGenerator(pieURLGenerator35);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator37 = piePlot32.getLabelGenerator();
        java.awt.Shape shape38 = piePlot32.getLegendItemShape();
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot32.setBaseSectionPaint((java.awt.Paint) color39);
        java.lang.Object obj41 = textTitle2.draw(graphics2D16, rectangle2D30, (java.lang.Object) color39);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel43 = null;
        java.awt.Rectangle rectangle44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        java.awt.geom.AffineTransform affineTransform46 = null;
        java.awt.RenderingHints renderingHints47 = null;
        java.awt.PaintContext paintContext48 = color42.createContext(colorModel43, rectangle44, rectangle2D45, affineTransform46, renderingHints47);
        java.awt.color.ColorSpace colorSpace49 = color42.getColorSpace();
        org.jfree.data.general.PieDataset pieDataset50 = null;
        org.jfree.chart.plot.PiePlot piePlot51 = new org.jfree.chart.plot.PiePlot(pieDataset50);
        java.lang.String str52 = piePlot51.getNoDataMessage();
        float float53 = piePlot51.getForegroundAlpha();
        java.awt.Color color54 = java.awt.Color.orange;
        piePlot51.setLabelPaint((java.awt.Paint) color54);
        java.awt.Color color56 = java.awt.Color.white;
        java.awt.Color color57 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color58 = java.awt.Color.cyan;
        float[] floatArray63 = new float[] { 0L, 10L, (-1L), 100L };
        float[] floatArray64 = color58.getColorComponents(floatArray63);
        float[] floatArray65 = color57.getRGBComponents(floatArray64);
        float[] floatArray66 = color56.getColorComponents(floatArray65);
        float[] floatArray67 = color54.getComponents(floatArray65);
        float[] floatArray68 = color39.getColorComponents(colorSpace49, floatArray67);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str21.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNull(obj41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paintContext48);
        org.junit.Assert.assertNotNull(colorSpace49);
        org.junit.Assert.assertNull(str52);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 1.0f + "'", float53 == 1.0f);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(floatArray67);
        org.junit.Assert.assertNotNull(floatArray68);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        java.awt.Image image7 = null;
        piePlot1.setBackgroundImage(image7);
        java.awt.Paint paint9 = piePlot1.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint paint8 = legendTitle7.getItemPaint();
        legendTitle7.setHeight(102.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.awt.Font font5 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textTitle6.getHorizontalAlignment();
        textTitle1.setHorizontalAlignment(horizontalAlignment7);
        textTitle1.setExpandToFitSpace(true);
        double double11 = textTitle1.getContentYOffset();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = textTitle1.getPosition();
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge12);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity7.setDataset(pieDataset11);
        int int13 = pieSectionEntity7.getSectionIndex();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.lang.String str16 = piePlot15.getNoDataMessage();
        boolean boolean17 = piePlot15.isCircular();
        java.awt.Stroke stroke19 = piePlot15.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.general.PieDataset pieDataset22 = null;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot(pieDataset22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.PiePlotState piePlotState26 = piePlot15.initialise(graphics2D20, rectangle2D21, piePlot23, (java.lang.Integer) (-97), plotRenderingInfo25);
        piePlot15.setNoDataMessage("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        piePlot15.setMaximumLabelWidth((double) (byte) -1);
        float float31 = piePlot15.getBackgroundImageAlpha();
        boolean boolean32 = piePlot15.isCircular();
        boolean boolean33 = pieSectionEntity7.equals((java.lang.Object) piePlot15);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent34 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) piePlot15);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNotNull(piePlotState26);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setInfo("");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D();
        java.util.List list6 = defaultKeyedValues2D5.getRowKeys();
        projectInfo1.setContributors(list6);
        java.lang.String str8 = projectInfo1.getInfo();
        java.lang.String str9 = projectInfo1.getName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JFreeChart" + "'", str9.equals("JFreeChart"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        double double7 = piePlot1.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj2 = datasetGroup1.clone();
        java.lang.String str3 = datasetGroup1.getID();
        defaultCategoryDataset0.setGroup(datasetGroup1);
        try {
            defaultCategoryDataset0.removeColumn((-97));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "NOID" + "'", str3.equals("NOID"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        projectInfo1.setLicenceText("");
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        projectInfo5.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
        projectInfo5.setLicenceName("rect");
        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
        java.awt.Image image11 = projectInfo1.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(image11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer7.getArrangement();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle10.setHorizontalAlignment(horizontalAlignment22);
        org.jfree.chart.block.BlockFrame blockFrame24 = textTitle10.getFrame();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        blockContainer7.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) color25);
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.lang.String str29 = piePlot28.getNoDataMessage();
        float float30 = piePlot28.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator31 = null;
        piePlot28.setToolTipGenerator(pieToolTipGenerator31);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke35 = defaultDrawingSupplier34.getNextOutlineStroke();
        piePlot28.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke35);
        java.awt.Stroke stroke37 = piePlot28.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets();
        piePlot28.setInsets(rectangleInsets38);
        double double41 = rectangleInsets38.calculateBottomInset((double) 1.0f);
        blockContainer7.setMargin(rectangleInsets38);
        boolean boolean43 = blockContainer7.isEmpty();
        blockContainer7.clear();
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(blockFrame24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        double double2 = piePlot1.getLabelGap();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        piePlot1.setDataset(pieDataset3);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent5 = null;
        piePlot1.datasetChanged(datasetChangeEvent5);
        java.awt.Color color7 = java.awt.Color.lightGray;
        piePlot1.setOutlinePaint((java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.025d + "'", double2 == 0.025d);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        boolean boolean4 = piePlot2.isCircular();
        java.awt.Stroke stroke6 = piePlot2.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.PiePlotState piePlotState13 = piePlot2.initialise(graphics2D7, rectangle2D8, piePlot10, (java.lang.Integer) (-97), plotRenderingInfo12);
        piePlot2.setShadowXOffset((double) '4');
        double double16 = piePlot2.getInteriorGap();
        piePlot2.zoom((double) (byte) 10);
        piePlot2.setShadowXOffset((double) 100);
        piePlot2.setIgnoreZeroValues(false);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("java.awt.Color[r=0,g=255,b=255]", (org.jfree.chart.plot.Plot) piePlot2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(piePlotState13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.08d + "'", double16 == 0.08d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        org.jfree.chart.util.Rotation rotation16 = piePlot1.getDirection();
        org.jfree.data.general.PieDataset pieDataset17 = null;
        piePlot1.setDataset(pieDataset17);
        org.jfree.chart.plot.Plot plot19 = piePlot1.getParent();
        piePlot1.setIgnoreZeroValues(false);
        try {
            piePlot1.setBackgroundImageAlpha((float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertNull(plot19);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.getSimpleLabels();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getParent();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D2 = textTitle1.getBounds();
        textTitle1.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(rectangle2D2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        piePlot1.zoom((double) (byte) 10);
        piePlot1.setShadowXOffset((double) 100);
        java.awt.Paint paint20 = piePlot1.getLabelLinkPaint();
        java.awt.Paint paint21 = piePlot1.getNoDataMessagePaint();
        piePlot1.setCircular(false);
        org.jfree.chart.block.ColumnArrangement columnArrangement24 = new org.jfree.chart.block.ColumnArrangement();
        java.awt.Color color25 = java.awt.Color.yellow;
        boolean boolean26 = columnArrangement24.equals((java.lang.Object) color25);
        piePlot1.setLabelLinkPaint((java.awt.Paint) color25);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean2 = basicProjectInfo0.equals((java.lang.Object) true);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo4 = org.jfree.chart.JFreeChart.INFO;
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) projectInfo4);
        org.jfree.chart.ui.Library[] libraryArray6 = projectInfo4.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray7 = projectInfo4.getLibraries();
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertNotNull(projectInfo4);
        org.junit.Assert.assertNotNull(libraryArray6);
        org.junit.Assert.assertNotNull(libraryArray7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
        org.jfree.chart.util.TableOrder tableOrder1 = org.jfree.chart.util.TableOrder.BY_COLUMN;
        boolean boolean3 = tableOrder1.equals((java.lang.Object) "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.Object obj4 = null;
        boolean boolean5 = tableOrder1.equals(obj4);
        java.lang.String str6 = tableOrder1.toString();
        boolean boolean7 = lineBorder0.equals((java.lang.Object) str6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("");
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle10.getBounds();
        lineBorder0.draw(graphics2D8, rectangle2D11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = lineBorder0.getInsets();
        org.junit.Assert.assertNotNull(tableOrder1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TableOrder.BY_COLUMN" + "'", str6.equals("TableOrder.BY_COLUMN"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = piePlot1.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = piePlot1.getLabelPadding();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot1.getLegendItems();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.Color color8 = color7.darker();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.text.NumberFormat numberFormat11 = standardPieSectionLabelGenerator10.getPercentFormat();
        java.lang.Object obj12 = null;
        boolean boolean13 = standardPieSectionLabelGenerator10.equals(obj12);
        boolean boolean14 = color8.equals((java.lang.Object) standardPieSectionLabelGenerator10);
        piePlot1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator10);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        piePlot1.zoom((double) (byte) 10);
        piePlot1.setShadowXOffset((double) 100);
        java.awt.Paint paint20 = piePlot1.getLabelLinkPaint();
        java.awt.Paint paint21 = piePlot1.getNoDataMessagePaint();
        java.awt.Paint paint23 = piePlot1.getSectionPaint((java.lang.Comparable) 0.4d);
        java.awt.Paint paint25 = piePlot1.getSectionOutlinePaint((java.lang.Comparable) 0.08d);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNull(paint25);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        piePlot1.setPieIndex((int) (byte) 10);
        java.awt.Paint paint6 = piePlot1.getLabelOutlinePaint();
        java.awt.Image image7 = piePlot1.getBackgroundImage();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        java.awt.Paint paint12 = textTitle1.getPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textTitle1.setHorizontalAlignment(horizontalAlignment13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.lang.String str18 = piePlot17.getNoDataMessage();
        float float19 = piePlot17.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator20 = null;
        piePlot17.setToolTipGenerator(pieToolTipGenerator20);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke24 = defaultDrawingSupplier23.getNextOutlineStroke();
        piePlot17.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke24);
        java.awt.Stroke stroke26 = piePlot17.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets();
        piePlot17.setInsets(rectangleInsets27);
        java.lang.Object obj29 = null;
        boolean boolean30 = rectangleInsets27.equals(obj29);
        org.jfree.data.general.PieDataset pieDataset31 = null;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot(pieDataset31);
        java.lang.String str33 = piePlot32.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = new org.jfree.chart.util.RectangleInsets();
        double double36 = rectangleInsets34.calculateRightOutset((double) 0);
        double double38 = rectangleInsets34.calculateTopOutset((double) (-1));
        piePlot32.setLabelPadding(rectangleInsets34);
        double double41 = rectangleInsets34.extendWidth((double) (short) 100);
        double double43 = rectangleInsets34.calculateBottomInset((double) (byte) -1);
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle45.getBounds();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        java.awt.geom.Rectangle2D rectangle2D49 = rectangleInsets34.createInsetRectangle(rectangle2D46);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType50 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets27.createAdjustedRectangle(rectangle2D46, lengthAdjustmentType50, lengthAdjustmentType51);
        java.awt.Shape shape53 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity55 = new org.jfree.chart.entity.ChartEntity(shape53, "");
        java.lang.String str56 = chartEntity55.toString();
        java.lang.Object obj57 = textTitle1.draw(graphics2D15, rectangle2D52, (java.lang.Object) str56);
        double double58 = textTitle1.getContentXOffset();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 102.0d + "'", double41 == 102.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "ChartEntity: tooltip = " + "'", str56.equals("ChartEntity: tooltip = "));
        org.junit.Assert.assertNull(obj57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle2.setPaint((java.awt.Paint) color3);
        java.lang.String str5 = textTitle2.getText();
        textTitle2.setID("PieLabelLinkStyle.STANDARD");
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle9.setPaint((java.awt.Paint) color10);
        java.lang.String str12 = textTitle9.getText();
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        boolean boolean15 = piePlot14.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot14);
        jFreeChart16.setAntiAlias(false);
        textTitle9.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart16);
        java.awt.Paint paint20 = textTitle9.getPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment21 = textTitle9.getVerticalAlignment();
        boolean boolean23 = verticalAlignment21.equals((java.lang.Object) "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        textTitle2.setVerticalAlignment(verticalAlignment21);
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment21, (double) 3, (double) 15);
        org.jfree.chart.block.BlockContainer blockContainer28 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement27);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement33 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment29, verticalAlignment30, (double) 100L, (double) 100);
        flowArrangement33.clear();
        org.jfree.chart.block.BlockContainer blockContainer35 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33);
        org.jfree.chart.block.BlockContainer blockContainer36 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement33);
        blockContainer36.setPadding((double) 0.5f, 0.0d, 10.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = blockContainer36.getPadding();
        blockContainer36.setPadding(0.0d, (double) 1, (double) (short) 1, (double) 100);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = null;
        try {
            org.jfree.chart.util.Size2D size2D50 = columnArrangement27.arrange(blockContainer36, graphics2D48, rectangleConstraint49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str5.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str12.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(verticalAlignment21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangleInsets42);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        boolean boolean7 = basicProjectInfo5.equals((java.lang.Object) true);
        org.jfree.chart.ui.Library[] libraryArray8 = basicProjectInfo5.getOptionalLibraries();
        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(libraryArray8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) (-1.0d));
        org.jfree.data.general.PieDataset pieDataset11 = null;
        pieSectionEntity7.setDataset(pieDataset11);
        java.lang.String str13 = pieSectionEntity7.getToolTipText();
        java.lang.String str14 = pieSectionEntity7.toString();
        java.lang.String str15 = pieSectionEntity7.toString();
        pieSectionEntity7.setToolTipText("RectangleAnchor.RIGHT");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleEdge.BOTTOM" + "'", str13.equals("RectangleEdge.BOTTOM"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PieSection: 0, 0(-1.0)" + "'", str14.equals("PieSection: 0, 0(-1.0)"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PieSection: 0, 0(-1.0)" + "'", str15.equals("PieSection: 0, 0(-1.0)"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
        int int2 = defaultKeyedValues2D1.getRowCount();
        java.util.List list3 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.lang.Number number6 = defaultKeyedValues2D1.getValue((java.lang.Comparable) "PieSection: 0, 0(UnitType.ABSOLUTE)", (java.lang.Comparable) 0.08d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0.08");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.Library[] libraryArray3 = projectInfo1.getOptionalLibraries();
        org.jfree.chart.ui.Library[] libraryArray4 = projectInfo1.getLibraries();
        projectInfo1.setLicenceText("");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNotNull(libraryArray3);
        org.junit.Assert.assertNotNull(libraryArray4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle3.setPaint((java.awt.Paint) color4);
        java.lang.String str6 = textTitle3.getText();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        boolean boolean9 = piePlot8.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot8);
        jFreeChart10.setAntiAlias(false);
        textTitle3.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart10);
        float float14 = jFreeChart10.getBackgroundImageAlpha();
        jFreeChart10.setTextAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart10);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str6.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addOptionalLibrary("hi!");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list4 = defaultCategoryDataset3.getColumnKeys();
        int int5 = defaultCategoryDataset3.getRowCount();
        java.util.List list6 = defaultCategoryDataset3.getRowKeys();
        boolean boolean7 = basicProjectInfo0.equals((java.lang.Object) list6);
        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
        projectInfo8.addLibrary((org.jfree.chart.ui.Library) projectInfo9);
        projectInfo9.setInfo("");
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo9);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(projectInfo8);
        org.junit.Assert.assertNotNull(projectInfo9);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset4 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset4.getColumnCount();
        java.util.List list6 = defaultCategoryDataset4.getRowKeys();
        jFreeChart3.setSubtitles(list6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color10 = color9.darker();
        java.awt.Color color11 = java.awt.Color.getColor("hi!", color10);
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.title.LegendTitle legendTitle14 = jFreeChart3.getLegend((int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNull(legendTitle14);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        double double4 = textTitle1.getContentYOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle1.setTextAlignment(horizontalAlignment5);
        boolean boolean7 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        java.awt.Font font3 = textTitle2.getFont();
        double double4 = textTitle2.getWidth();
        java.lang.String str5 = textTitle2.getText();
        textTitle2.setToolTipText("");
        double double8 = textTitle2.getContentXOffset();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle10.setPaint((java.awt.Paint) color11);
        java.lang.String str13 = textTitle10.getText();
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        boolean boolean16 = piePlot15.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot15);
        jFreeChart17.setAntiAlias(false);
        textTitle10.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart17);
        java.awt.Paint paint21 = textTitle10.getPaint();
        org.jfree.chart.util.VerticalAlignment verticalAlignment22 = textTitle10.getVerticalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment23 = textTitle10.getTextAlignment();
        textTitle2.setTextAlignment(horizontalAlignment23);
        boolean boolean25 = textTitle2.getNotify();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str5.equals("PieLabelLinkStyle.STANDARD"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str13.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(verticalAlignment22);
        org.junit.Assert.assertNotNull(horizontalAlignment23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 0);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.lang.String str4 = standardPieSectionLabelGenerator3.getLabelFormat();
        java.text.AttributedString attributedString6 = standardPieSectionLabelGenerator3.getAttributedLabel((-97));
        java.text.NumberFormat numberFormat7 = standardPieSectionLabelGenerator3.getPercentFormat();
        int int8 = objectList1.indexOf((java.lang.Object) standardPieSectionLabelGenerator3);
        int int9 = objectList1.size();
        java.lang.Object obj11 = objectList1.get(0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertNull(attributedString6);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(false);
        org.jfree.chart.plot.Plot plot9 = jFreeChart3.getPlot();
        java.awt.Color color10 = java.awt.Color.yellow;
        int int11 = color10.getAlpha();
        jFreeChart3.setBorderPaint((java.awt.Paint) color10);
        jFreeChart3.setNotify(false);
        int int15 = jFreeChart3.getBackgroundImageAlignment();
        jFreeChart3.setBorderVisible(false);
        try {
            org.jfree.chart.title.Title title19 = jFreeChart3.getSubtitle((-123));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(plot9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("PieLabelLinkStyle.STANDARD", "", "", image3, "rect", "", "PieLabelLinkStyle.STANDARD");
        java.lang.String str8 = projectInfo7.getName();
        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        projectInfo9.addLibrary((org.jfree.chart.ui.Library) projectInfo10);
        projectInfo10.setInfo("");
        java.lang.String str14 = projectInfo10.getLicenceText();
        java.lang.String str15 = projectInfo10.getLicenceName();
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str8.equals("PieLabelLinkStyle.STANDARD"));
        org.junit.Assert.assertNotNull(projectInfo9);
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "rect" + "'", str15.equals("rect"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) "PieSection: 0, 0(3)");
        pieSectionEntity7.setSectionIndex(0);
        java.lang.String str13 = pieSectionEntity7.getURLText();
        pieSectionEntity7.setToolTipText("org.jfree.chart.event.ChartChangeEvent[source=]");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = null;
        piePlot1.axisChanged(axisChangeEvent6);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot1.getToolTipGenerator();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Font font10 = legendTitle9.getItemFont();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = legendTitle9.getLegendItemGraphicEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle9.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = null;
        org.jfree.chart.util.Size2D size2D15 = legendTitle9.arrange(graphics2D13, rectangleConstraint14);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray16 = legendTitle9.getSources();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = legendTitle9.getPadding();
        org.jfree.chart.block.BlockContainer blockContainer18 = legendTitle9.getItemContainer();
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        java.lang.String str21 = piePlot20.getNoDataMessage();
        float float22 = piePlot20.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator23 = null;
        piePlot20.setToolTipGenerator(pieToolTipGenerator23);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke27 = defaultDrawingSupplier26.getNextOutlineStroke();
        piePlot20.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke27);
        java.awt.Stroke stroke29 = piePlot20.getLabelOutlineStroke();
        java.awt.Color color30 = java.awt.Color.white;
        piePlot20.setLabelLinkPaint((java.awt.Paint) color30);
        legendTitle9.setBackgroundPaint((java.awt.Paint) color30);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(legendItemSourceArray16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(blockContainer18);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        java.awt.Paint paint3 = piePlot1.getBaseSectionPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = piePlot1.getURLGenerator();
        java.awt.Stroke stroke5 = piePlot1.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = piePlot1.getInsets();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor7 = null;
        try {
            piePlot1.setLabelDistributor(abstractPieLabelDistributor7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.plot.Plot plot6 = piePlot1.getRootPlot();
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) piePlot1);
        java.awt.Paint paint8 = legendTitle7.getItemPaint();
        java.awt.Font font9 = legendTitle7.getItemFont();
        org.jfree.chart.LegendItemSource[] legendItemSourceArray10 = legendTitle7.getSources();
        java.lang.Class<?> wildcardClass11 = legendItemSourceArray10.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(plot6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(legendItemSourceArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (short) 1);
        pieLabelDistributor1.clear();
        int int3 = pieLabelDistributor1.getItemCount();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        textTitle1.setURLText("ChartEntity: tooltip = ");
        textTitle1.setWidth((double) '4');
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle1.getBounds();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 0, (int) (byte) 0, (java.lang.Comparable) 3, "RectangleEdge.BOTTOM", "");
        java.lang.String str8 = pieSectionEntity7.toString();
        int int9 = pieSectionEntity7.getPieIndex();
        java.lang.String str10 = pieSectionEntity7.getURLText();
        int int11 = pieSectionEntity7.getSectionIndex();
        org.jfree.data.general.PieDataset pieDataset12 = null;
        pieSectionEntity7.setDataset(pieDataset12);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PieSection: 0, 0(3)" + "'", str8.equals("PieSection: 0, 0(3)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        float float4 = piePlot2.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot2.setURLGenerator(pieURLGenerator5);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot2.getLabelGenerator();
        java.awt.Shape shape8 = piePlot2.getLegendItemShape();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        piePlot2.setBaseSectionPaint((java.awt.Paint) color9);
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", (org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        piePlot2.addChangeListener(plotChangeListener12);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        java.lang.String str16 = piePlot15.getNoDataMessage();
        boolean boolean17 = piePlot15.isCircular();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        piePlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18);
        java.awt.Stroke stroke20 = defaultDrawingSupplier18.getNextOutlineStroke();
        piePlot2.setLabelOutlineStroke(stroke20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        boolean boolean3 = piePlot2.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot2);
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart("PieSection: 0, 0(3)", (org.jfree.chart.plot.Plot) piePlot2);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        jFreeChart5.setBorderStroke(stroke6);
        boolean boolean8 = jFreeChart5.isBorderVisible();
        jFreeChart5.clearSubtitles();
        org.jfree.chart.plot.Plot plot10 = jFreeChart5.getPlot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot(pieDataset8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.PiePlotState piePlotState12 = piePlot1.initialise(graphics2D6, rectangle2D7, piePlot9, (java.lang.Integer) (-97), plotRenderingInfo11);
        piePlot1.setShadowXOffset((double) '4');
        double double15 = piePlot1.getInteriorGap();
        org.jfree.chart.util.Rotation rotation16 = piePlot1.getDirection();
        java.lang.Object obj17 = null;
        boolean boolean18 = rotation16.equals(obj17);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(piePlotState12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.08d + "'", double15 == 0.08d);
        org.junit.Assert.assertNotNull(rotation16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        float float11 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        jFreeChart3.setPadding(rectangleInsets12);
        boolean boolean14 = jFreeChart3.isNotify();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D15 = new org.jfree.data.DefaultKeyedValues2D();
        int int16 = defaultKeyedValues2D15.getColumnCount();
        defaultKeyedValues2D15.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        defaultKeyedValues2D15.removeColumn((int) (byte) 0);
        int int23 = defaultKeyedValues2D15.getRowCount();
        boolean boolean24 = jFreeChart3.equals((java.lang.Object) defaultKeyedValues2D15);
        int int25 = jFreeChart3.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ");
        java.awt.geom.Rectangle2D rectangle2D29 = textTitle28.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = null;
        try {
            jFreeChart3.draw(graphics2D26, rectangle2D29, chartRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(rectangle2D29);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        float float3 = piePlot1.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator4 = null;
        piePlot1.setToolTipGenerator(pieToolTipGenerator4);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke8);
        java.awt.Stroke stroke10 = piePlot1.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets();
        piePlot1.setInsets(rectangleInsets11);
        double double14 = rectangleInsets11.calculateBottomInset((double) 1.0f);
        double double16 = rectangleInsets11.calculateLeftInset((double) 10);
        double double18 = rectangleInsets11.calculateRightOutset(0.0d);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 100);
        flowArrangement4.clear();
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer7.setPadding((double) 0.5f, 0.0d, 10.0d, (double) (byte) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = blockContainer7.getPadding();
        boolean boolean14 = blockContainer7.isEmpty();
        org.jfree.chart.util.UnitType unitType15 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot(pieDataset16);
        java.lang.String str18 = piePlot17.getNoDataMessage();
        boolean boolean19 = piePlot17.isCircular();
        java.awt.Stroke stroke21 = piePlot17.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.PiePlotState piePlotState28 = piePlot17.initialise(graphics2D22, rectangle2D23, piePlot25, (java.lang.Integer) (-97), plotRenderingInfo27);
        piePlot17.setShadowXOffset((double) '4');
        double double31 = piePlot17.getInteriorGap();
        piePlot17.zoom((double) (byte) 10);
        piePlot17.setShadowXOffset((double) 100);
        java.awt.Paint paint36 = piePlot17.getLabelLinkPaint();
        boolean boolean37 = unitType15.equals((java.lang.Object) piePlot17);
        boolean boolean38 = blockContainer7.equals((java.lang.Object) unitType15);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(unitType15);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(stroke21);
        org.junit.Assert.assertNotNull(piePlotState28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.08d + "'", double31 == 0.08d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart3.getLegend((int) (short) 100);
        java.lang.Object obj6 = jFreeChart3.clone();
        java.awt.RenderingHints renderingHints7 = jFreeChart3.getRenderingHints();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(legendTitle5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(renderingHints7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.awt.Color color2 = java.awt.Color.getColor("poly", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        jFreeChart3.setNotify(true);
        java.lang.Object obj9 = jFreeChart3.getTextAntiAlias();
        java.awt.Paint paint10 = jFreeChart3.getBackgroundPaint();
        float float11 = jFreeChart3.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        jFreeChart3.setPadding(rectangleInsets12);
        boolean boolean14 = jFreeChart3.isNotify();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D15 = new org.jfree.data.DefaultKeyedValues2D();
        int int16 = defaultKeyedValues2D15.getColumnCount();
        defaultKeyedValues2D15.setValue((java.lang.Number) 1, (java.lang.Comparable) 1.0d, (java.lang.Comparable) 0.4d);
        defaultKeyedValues2D15.removeColumn((int) (byte) 0);
        int int23 = defaultKeyedValues2D15.getRowCount();
        boolean boolean24 = jFreeChart3.equals((java.lang.Object) defaultKeyedValues2D15);
        int int25 = jFreeChart3.getBackgroundImageAlignment();
        java.awt.Color color26 = java.awt.Color.green;
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        java.lang.String str29 = piePlot28.getNoDataMessage();
        float float30 = piePlot28.getForegroundAlpha();
        java.awt.Color color31 = java.awt.Color.orange;
        piePlot28.setLabelPaint((java.awt.Paint) color31);
        java.awt.Color color33 = java.awt.Color.white;
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color35 = java.awt.Color.cyan;
        float[] floatArray40 = new float[] { 0L, 10L, (-1L), 100L };
        float[] floatArray41 = color35.getColorComponents(floatArray40);
        float[] floatArray42 = color34.getRGBComponents(floatArray41);
        float[] floatArray43 = color33.getColorComponents(floatArray42);
        float[] floatArray44 = color31.getComponents(floatArray42);
        float[] floatArray45 = color26.getRGBComponents(floatArray42);
        boolean boolean46 = jFreeChart3.equals((java.lang.Object) floatArray42);
        java.lang.Object obj47 = jFreeChart3.getTextAntiAlias();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(obj47);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        java.awt.Stroke stroke5 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetGroup datasetGroup6 = piePlot1.getDatasetGroup();
        piePlot1.setPieIndex((int) (byte) -1);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot1.setBaseSectionOutlineStroke(stroke9);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.awt.Font font2 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font2);
        java.awt.Font font4 = textTitle3.getFont();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.general.PieDataset pieDataset13 = null;
        org.jfree.chart.plot.PiePlot piePlot14 = new org.jfree.chart.plot.PiePlot(pieDataset13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.PiePlotState piePlotState17 = piePlot6.initialise(graphics2D11, rectangle2D12, piePlot14, (java.lang.Integer) (-97), plotRenderingInfo16);
        piePlot6.setShadowXOffset((double) '4');
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n", font4, (org.jfree.chart.plot.Plot) piePlot6, true);
        jFreeChart21.setTextAntiAlias(true);
        jFreeChart21.setTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        org.jfree.chart.plot.Plot plot26 = jFreeChart21.getPlot();
        java.awt.Paint paint27 = jFreeChart21.getBorderPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(piePlotState17);
        org.junit.Assert.assertNotNull(plot26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("PieLabelLinkStyle.STANDARD", font1);
        textTitle2.setText("PieLabelLinkStyle.STANDARD");
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        java.lang.String str7 = piePlot6.getNoDataMessage();
        boolean boolean8 = piePlot6.isCircular();
        java.awt.Stroke stroke10 = piePlot6.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        org.jfree.data.general.DatasetGroup datasetGroup11 = piePlot6.getDatasetGroup();
        java.awt.Paint paint12 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        piePlot6.setLabelBackgroundPaint(paint12);
        boolean boolean14 = textTitle2.equals((java.lang.Object) piePlot6);
        java.lang.String str15 = textTitle2.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(datasetGroup11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getNoDataMessage();
        boolean boolean3 = piePlot1.isCircular();
        org.jfree.chart.plot.Plot plot4 = piePlot1.getRootPlot();
        org.jfree.chart.JFreeChart jFreeChart5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        java.awt.Color color8 = java.awt.Color.getColor("RectangleInsets[t=0.4,l=1.0,b=-1.0,r=10.0]", (-1));
        java.awt.Color color9 = color8.brighter();
        jFreeChart5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.event.ChartProgressListener chartProgressListener11 = null;
        jFreeChart5.addProgressListener(chartProgressListener11);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        java.lang.String str1 = pieLabelLinkStyle0.toString();
        java.lang.String str2 = pieLabelLinkStyle0.toString();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str1.equals("PieLabelLinkStyle.STANDARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str2.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        double double4 = textTitle1.getContentYOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle1.setTextAlignment(horizontalAlignment5);
        textTitle1.setURLText("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n");
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        textTitle1.setPaint((java.awt.Paint) color2);
        java.lang.String str4 = textTitle1.getText();
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot(pieDataset5);
        boolean boolean7 = piePlot6.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot6);
        jFreeChart8.setAntiAlias(false);
        textTitle1.removeChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart8);
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        java.lang.String str14 = piePlot13.getNoDataMessage();
        float float15 = piePlot13.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = null;
        piePlot13.setToolTipGenerator(pieToolTipGenerator16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        piePlot13.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke20);
        java.awt.Stroke stroke22 = piePlot13.getLabelOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets();
        piePlot13.setInsets(rectangleInsets23);
        textTitle1.setMargin(rectangleInsets23);
        double double27 = rectangleInsets23.extendWidth((double) 3);
        double double28 = rectangleInsets23.getTop();
        double double29 = rectangleInsets23.getRight();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str4.equals("JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).David Forslund (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 5.0d + "'", double27 == 5.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getColumnCount();
        boolean boolean3 = defaultCategoryDataset0.equals((java.lang.Object) 1.0f);
        java.util.List list4 = defaultCategoryDataset0.getRowKeys();
        java.lang.Class<?> wildcardClass5 = list4.getClass();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        java.lang.String str3 = piePlot2.getNoDataMessage();
        boolean boolean4 = piePlot2.isCircular();
        java.awt.Stroke stroke6 = piePlot2.getSectionOutlineStroke((java.lang.Comparable) "hi!");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.general.PieDataset pieDataset9 = null;
        org.jfree.chart.plot.PiePlot piePlot10 = new org.jfree.chart.plot.PiePlot(pieDataset9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.plot.PiePlotState piePlotState13 = piePlot2.initialise(graphics2D7, rectangle2D8, piePlot10, (java.lang.Integer) (-97), plotRenderingInfo12);
        piePlot2.setShadowXOffset((double) '4');
        double double16 = piePlot2.getInteriorGap();
        piePlot2.zoom((double) (byte) 10);
        piePlot2.setShadowXOffset((double) 100);
        java.awt.Paint paint21 = piePlot2.getLabelLinkPaint();
        boolean boolean22 = unitType0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 8, 1.0d, (double) (-16777216), 1.0d);
        org.jfree.chart.util.UnitType unitType28 = rectangleInsets27.getUnitType();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(piePlotState13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.08d + "'", double16 == 0.08d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(unitType28);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test125");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo1);
//        projectInfo1.setLicenceText("");
//        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
//        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo5.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
//        projectInfo5.setLicenceName("rect");
//        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        java.lang.String str11 = projectInfo1.toString();
//        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo1.getOptionalLibraries();
//        java.lang.String str13 = projectInfo1.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray14 = projectInfo1.getLibraries();
//        org.jfree.chart.ui.Library[] libraryArray15 = projectInfo1.getOptionalLibraries();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(projectInfo1);
//        org.junit.Assert.assertNotNull(projectInfo5);
//        org.junit.Assert.assertNotNull(projectInfo6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "JFreeChart version hi!.\njava.awt.Color[r=0,g=255,b=255].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().PieLabelLinkStyle.STANDARD  ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n (C)opyright 2000-2007, by Object Refinery Limited and Contributors ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n" + "'", str11.equals("JFreeChart version hi!.\njava.awt.Color[r=0,g=255,b=255].\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().PieLabelLinkStyle.STANDARD  ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart version hi!.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n (C)opyright 2000-2007, by Object Refinery Limited and Contributors ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().JFreeChart hi! ().\nJFreeChart LICENCE TERMS:\n"));
//        org.junit.Assert.assertNotNull(libraryArray12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "java.awt.Color[r=0,g=255,b=255]" + "'", str13.equals("java.awt.Color[r=0,g=255,b=255]"));
//        org.junit.Assert.assertNotNull(libraryArray14);
//        org.junit.Assert.assertNotNull(libraryArray15);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        float float3 = piePlot1.getBackgroundAlpha();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot1.setURLGenerator(pieURLGenerator4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLabelGenerator();
        piePlot1.setSimpleLabels(false);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.image.ColorModel colorModel11 = null;
        java.awt.Rectangle rectangle12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.AffineTransform affineTransform14 = null;
        java.awt.RenderingHints renderingHints15 = null;
        java.awt.PaintContext paintContext16 = color10.createContext(colorModel11, rectangle12, rectangle2D13, affineTransform14, renderingHints15);
        piePlot1.setSectionPaint((java.lang.Comparable) (-8388608), (java.awt.Paint) color10);
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        java.lang.String str20 = piePlot19.getNoDataMessage();
        boolean boolean21 = piePlot19.isCircular();
        org.jfree.chart.plot.Plot plot22 = piePlot19.getRootPlot();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor23 = piePlot19.getLabelDistributor();
        piePlot1.setLabelDistributor(abstractPieLabelDistributor23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintContext16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor23);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        java.awt.Color color2 = java.awt.Color.CYAN;
        multiplePiePlot0.setAggregatedItemsPaint((java.awt.Paint) color2);
        org.jfree.chart.util.TableOrder tableOrder4 = multiplePiePlot0.getDataExtractOrder();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = multiplePiePlot0.getLegendItems();
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(tableOrder4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        boolean boolean2 = piePlot1.isOutlineVisible();
        org.jfree.chart.JFreeChart jFreeChart3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot1);
        jFreeChart3.setAntiAlias(false);
        java.lang.Object obj6 = jFreeChart3.clone();
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        java.lang.String str9 = piePlot8.getNoDataMessage();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets();
        double double12 = rectangleInsets10.calculateRightOutset((double) 0);
        double double14 = rectangleInsets10.calculateTopOutset((double) (-1));
        piePlot8.setLabelPadding(rectangleInsets10);
        double double17 = rectangleInsets10.extendWidth((double) (short) 100);
        jFreeChart3.setPadding(rectangleInsets10);
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.plot.PiePlot piePlot20 = new org.jfree.chart.plot.PiePlot(pieDataset19);
        java.lang.String str21 = piePlot20.getNoDataMessage();
        float float22 = piePlot20.getForegroundAlpha();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator23 = null;
        piePlot20.setToolTipGenerator(pieToolTipGenerator23);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke27 = defaultDrawingSupplier26.getNextOutlineStroke();
        piePlot20.setSectionOutlineStroke((java.lang.Comparable) (short) 0, stroke27);
        java.awt.Stroke stroke29 = piePlot20.getLabelOutlineStroke();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot20.setBackgroundPaint((java.awt.Paint) color30);
        org.jfree.data.general.PieDataset pieDataset32 = piePlot20.getDataset();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color34 = color33.darker();
        int int35 = color33.getRed();
        piePlot20.setLabelPaint((java.awt.Paint) color33);
        jFreeChart3.setBackgroundPaint((java.awt.Paint) color33);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 102.0d + "'", double17 == 102.0d);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNull(pieDataset32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 128 + "'", int35 == 128);
    }
}

