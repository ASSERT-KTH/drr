import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str11 = spreadsheetDate7.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean16 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean22 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str23 = spreadsheetDate19.toString();
        boolean boolean24 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean25 = spreadsheetDate2.equals((java.lang.Object) boolean24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "17-May-1927" + "'", str11.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "17-May-1927" + "'", str23.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems((long) 2147483647, false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.lang.String str13 = spreadsheetDate9.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate9.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate15, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate7.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate17);
        int int20 = spreadsheetDate7.getYYYY();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate7);
        int int22 = spreadsheetDate3.compare(serialDate21);
        try {
            org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '#', serialDate21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "17-May-1927" + "'", str13.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1927 + "'", int20 == 1927);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 30 + "'", int22 == 30);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str6 = timeSeries5.getDomainDescription();
        timeSeries5.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class9 = timeSeries5.getTimePeriodClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize(class9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long16 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
        timeSeries12.removeAgedItems((-1L), true);
        long long22 = timeSeries12.getMaximumItemAge();
        timeSeries12.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str27 = timeSeries26.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timeSeries26.addPropertyChangeListener(propertyChangeListener28);
        java.util.Collection collection30 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries26);
        java.lang.Class class31 = timeSeries12.getTimePeriodClass();
        java.lang.Object obj32 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class9, class31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean43 = timeSeries42.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long46 = fixedMillisecond45.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond45, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries42.removeChangeListener(seriesChangeListener49);
        timeSeries42.setNotify(true);
        java.lang.Class<?> wildcardClass53 = timeSeries42.getClass();
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day38, "", "ClassContext", (java.lang.Class) wildcardClass53);
        java.lang.Class class55 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass53);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean62 = timeSeries61.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long65 = fixedMillisecond64.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener68 = null;
        timeSeries61.removeChangeListener(seriesChangeListener68);
        timeSeries61.setNotify(true);
        java.lang.Class<?> wildcardClass72 = timeSeries61.getClass();
        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass72);
        java.io.InputStream inputStream74 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass72);
        java.lang.Object obj75 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", (java.lang.Class) wildcardClass53, (java.lang.Class) wildcardClass72);
        java.lang.Object obj76 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class31, (java.lang.Class) wildcardClass53);
        java.lang.Object obj77 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Time", (java.lang.Class) wildcardClass53);
        java.net.URL uRL78 = org.jfree.chart.util.ObjectUtilities.getResource("17-May-1927", (java.lang.Class) wildcardClass53);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(class31);
        org.junit.Assert.assertNull(obj32);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 35L + "'", long46 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem48);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 35L + "'", long65 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertNotNull(inputStream74);
        org.junit.Assert.assertNull(obj75);
        org.junit.Assert.assertNull(obj76);
        org.junit.Assert.assertNull(obj77);
        org.junit.Assert.assertNull(uRL78);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str3 = timeSeries2.getDomainDescription();
        timeSeries2.setKey((java.lang.Comparable) (-1.0f));
        timeSeries2.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean10 = timeSeries9.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long13 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 0.0d);
        timeSeries9.removeAgedItems((-1L), true);
        long long19 = timeSeries9.getMaximumItemAge();
        timeSeries9.setMaximumItemAge((long) 1927);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long24 = fixedMillisecond23.getMiddleMillisecond();
        java.util.Date date25 = fixedMillisecond23.getEnd();
        boolean boolean26 = timeSeries9.equals((java.lang.Object) fixedMillisecond23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) (-1345219200000L));
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str31 = timeSeries30.getDomainDescription();
        int int32 = timeSeries30.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean35 = timeSeries34.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long38 = fixedMillisecond37.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries34.removeChangeListener(seriesChangeListener41);
        timeSeries34.setNotify(true);
        java.lang.Class<?> wildcardClass45 = timeSeries34.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long48 = fixedMillisecond47.getMiddleMillisecond();
        java.util.Date date49 = fixedMillisecond47.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        long long51 = year50.getLastMillisecond();
        timeSeries34.setKey((java.lang.Comparable) year50);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str55 = timeSeries54.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long58 = fixedMillisecond57.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) year50, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond57);
        java.util.Calendar calendar62 = null;
        long long63 = fixedMillisecond57.getLastMillisecond(calendar62);
        java.util.Calendar calendar64 = null;
        long long65 = fixedMillisecond57.getLastMillisecond(calendar64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (double) 35L);
        java.lang.Class class68 = timeSeries2.getTimePeriodClass();
        java.io.InputStream inputStream69 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Time", class68);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 35L + "'", long24 == 35L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2147483647 + "'", int32 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 35L + "'", long38 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 35L + "'", long48 == 35L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 28799999L + "'", long51 == 28799999L);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Time" + "'", str55.equals("Time"));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 35L + "'", long58 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem60);
        org.junit.Assert.assertNotNull(timeSeries61);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 35L + "'", long63 == 35L);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 35L + "'", long65 == 35L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
        org.junit.Assert.assertNotNull(class68);
        org.junit.Assert.assertNull(inputStream69);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.previous();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem16.getPeriod();
        boolean boolean18 = day11.equals((java.lang.Object) regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        java.util.Date date23 = year17.getEnd();
        int int24 = year17.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1969 + "'", int24 == 1969);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean17 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        int int23 = fixedMillisecond20.compareTo((java.lang.Object) 100L);
        java.util.Date date24 = fixedMillisecond20.getStart();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        int int26 = spreadsheetDate16.compare(serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long33 = fixedMillisecond32.getMiddleMillisecond();
        java.util.Date date34 = fixedMillisecond32.getEnd();
        java.util.Date date35 = fixedMillisecond32.getStart();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date35);
        boolean boolean37 = spreadsheetDate29.isOnOrBefore(serialDate36);
        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean39 = spreadsheetDate3.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-May-1927" + "'", str12.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-15569) + "'", int26 == (-15569));
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 35L + "'", long33 == 35L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str14 = timeSeries13.getDomainDescription();
        int int15 = timeSeries13.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean18 = timeSeries17.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries17.removeChangeListener(seriesChangeListener24);
        timeSeries17.setNotify(true);
        java.lang.Class<?> wildcardClass28 = timeSeries17.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long31 = fixedMillisecond30.getMiddleMillisecond();
        java.util.Date date32 = fixedMillisecond30.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        long long34 = year33.getLastMillisecond();
        timeSeries17.setKey((java.lang.Comparable) year33);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str38 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long41 = fixedMillisecond40.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Date date45 = year33.getEnd();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year33);
        timeSeries1.setDescription("June 2019");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28799999L + "'", long34 == 28799999L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeSeries46);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str5 = timeSeries4.getDomainDescription();
        int int6 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        timeSeries8.setKey((java.lang.Comparable) year24);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long32 = fixedMillisecond31.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond31.getLastMillisecond(calendar36);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond31.getLastMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-460));
        try {
            org.jfree.data.time.TimeSeries timeSeries44 = timeSeries1.createCopy((int) '4', (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 35L + "'", long39 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.String str7 = fixedMillisecond5.toString();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) str7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        timeSeries10.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean24 = timeSeries23.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long30 = fixedMillisecond29.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long37 = fixedMillisecond36.getFirstMillisecond();
        java.util.Date date38 = fixedMillisecond36.getTime();
        timeSeries23.setKey((java.lang.Comparable) fixedMillisecond36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 0L);
        try {
            timeSeries10.add(timeSeriesDataItem41, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "", "ClassContext", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) '4');
        java.lang.String str23 = day4.toString();
        long long24 = day4.getLastMillisecond();
        long long25 = day4.getSerialIndex();
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day4.getLastMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "17-May-1927" + "'", str23.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1345132800001L) + "'", long24 == (-1345132800001L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9999L + "'", long25 == 9999L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long17 = fixedMillisecond16.getMiddleMillisecond();
        java.util.Date date18 = fixedMillisecond16.getEnd();
        java.util.Date date19 = fixedMillisecond16.getStart();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        boolean boolean21 = spreadsheetDate13.isOnOrBefore(serialDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean28 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.lang.String str29 = spreadsheetDate25.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean34 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate31, (org.jfree.data.time.SerialDate) spreadsheetDate33);
        boolean boolean35 = spreadsheetDate23.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long38 = fixedMillisecond37.getFirstMillisecond();
        int int40 = fixedMillisecond37.compareTo((java.lang.Object) 100L);
        java.util.Date date41 = fixedMillisecond37.getStart();
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date41);
        int int43 = spreadsheetDate33.compare(serialDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long50 = fixedMillisecond49.getMiddleMillisecond();
        java.util.Date date51 = fixedMillisecond49.getEnd();
        java.util.Date date52 = fixedMillisecond49.getStart();
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(date52);
        boolean boolean54 = spreadsheetDate46.isOnOrBefore(serialDate53);
        org.jfree.data.time.SerialDate serialDate55 = spreadsheetDate33.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate46);
        boolean boolean57 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate33, 1927);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "17-May-1927" + "'", str29.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 35L + "'", long38 == 35L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-15569) + "'", int43 == (-15569));
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 35L + "'", long50 == 35L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries1.createCopy(5, 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(timeSeries7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) ' ');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean13 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str14 = spreadsheetDate10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean19 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean25 = spreadsheetDate22.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        java.lang.String str26 = spreadsheetDate22.toString();
        boolean boolean27 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean29 = spreadsheetDate22.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean31 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean32 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "17-May-1927" + "'", str14.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "17-May-1927" + "'", str26.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean24 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long28 = fixedMillisecond27.getFirstMillisecond();
        int int30 = fixedMillisecond27.compareTo((java.lang.Object) 100L);
        java.util.Date date31 = fixedMillisecond27.getStart();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        int int33 = spreadsheetDate23.compare(serialDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long40 = fixedMillisecond39.getMiddleMillisecond();
        java.util.Date date41 = fixedMillisecond39.getEnd();
        java.util.Date date42 = fixedMillisecond39.getStart();
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date42);
        boolean boolean44 = spreadsheetDate36.isOnOrBefore(serialDate43);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate23.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean50 = spreadsheetDate47.isOn((org.jfree.data.time.SerialDate) spreadsheetDate49);
        java.lang.String str51 = spreadsheetDate47.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean56 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate55);
        int int57 = spreadsheetDate47.compare((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean59 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, (org.jfree.data.time.SerialDate) spreadsheetDate47, (int) (byte) 0);
        int int60 = spreadsheetDate47.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-15569) + "'", int33 == (-15569));
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 35L + "'", long40 == 35L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 17 + "'", int60 == 17);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            month0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        int int6 = spreadsheetDate1.getYYYY();
        int int7 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1927 + "'", int6 == 1927);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9999 + "'", int7 == 9999);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        boolean boolean20 = spreadsheetDate11.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate21 = null;
        try {
            org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate15.getEndOfCurrentMonth(serialDate21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getYear();
        int int8 = day6.getMonth();
        java.util.Calendar calendar9 = null;
        try {
            day6.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean24 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean30 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = spreadsheetDate27.toString();
        boolean boolean32 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean39 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.lang.String str40 = spreadsheetDate36.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean45 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean46 = spreadsheetDate34.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean51 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        java.lang.String str52 = spreadsheetDate48.toString();
        boolean boolean53 = spreadsheetDate44.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean55 = spreadsheetDate48.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long58 = fixedMillisecond57.getFirstMillisecond();
        int int60 = fixedMillisecond57.compareTo((java.lang.Object) 100L);
        java.util.Date date61 = fixedMillisecond57.getStart();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
        int int63 = spreadsheetDate48.compare(serialDate62);
        boolean boolean65 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate62, 1927);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean72 = spreadsheetDate69.isOn((org.jfree.data.time.SerialDate) spreadsheetDate71);
        java.lang.String str73 = spreadsheetDate69.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean78 = spreadsheetDate69.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate75, (org.jfree.data.time.SerialDate) spreadsheetDate77);
        boolean boolean79 = spreadsheetDate67.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate77);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate81 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate83 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean84 = spreadsheetDate81.isOn((org.jfree.data.time.SerialDate) spreadsheetDate83);
        java.lang.String str85 = spreadsheetDate81.toString();
        boolean boolean86 = spreadsheetDate77.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate81);
        boolean boolean88 = spreadsheetDate81.equals((java.lang.Object) (short) 10);
        boolean boolean89 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate81);
        java.lang.String str90 = spreadsheetDate81.toString();
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addYears((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate81);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "17-May-1927" + "'", str6.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "17-May-1927" + "'", str31.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "17-May-1927" + "'", str40.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "17-May-1927" + "'", str52.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 35L + "'", long58 == 35L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-15569) + "'", int63 == (-15569));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "17-May-1927" + "'", str73.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "17-May-1927" + "'", str85.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "17-May-1927" + "'", str90.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate91);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean24 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean30 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = spreadsheetDate27.toString();
        boolean boolean32 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int33 = spreadsheetDate23.getDayOfMonth();
        boolean boolean34 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean42 = spreadsheetDate39.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
        java.lang.String str43 = spreadsheetDate39.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean48 = spreadsheetDate39.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate45, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        boolean boolean49 = spreadsheetDate37.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long52 = fixedMillisecond51.getFirstMillisecond();
        int int54 = fixedMillisecond51.compareTo((java.lang.Object) 100L);
        java.util.Date date55 = fixedMillisecond51.getStart();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        int int57 = spreadsheetDate47.compare(serialDate56);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long64 = fixedMillisecond63.getMiddleMillisecond();
        java.util.Date date65 = fixedMillisecond63.getEnd();
        java.util.Date date66 = fixedMillisecond63.getStart();
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date66);
        boolean boolean68 = spreadsheetDate60.isOnOrBefore(serialDate67);
        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate60);
        boolean boolean70 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "17-May-1927" + "'", str31.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 17 + "'", int33 == 17);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "17-May-1927" + "'", str43.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 35L + "'", long52 == 35L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-15569) + "'", int57 == (-15569));
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 35L + "'", long64 == 35L);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate10.toSerial();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean20 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.lang.String str21 = spreadsheetDate17.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean26 = spreadsheetDate17.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        boolean boolean27 = spreadsheetDate15.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean32 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.String str33 = spreadsheetDate29.toString();
        boolean boolean34 = spreadsheetDate25.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate29);
        int int35 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths(6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "17-May-1927" + "'", str6.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "17-May-1927" + "'", str21.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "17-May-1927" + "'", str33.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean3 = timeSeries2.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str11 = spreadsheetDate7.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean16 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        int int17 = spreadsheetDate15.toSerial();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate15);
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) day18, (double) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str23 = timeSeries22.getDomainDescription();
        int int24 = timeSeries22.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean27 = timeSeries26.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long30 = fixedMillisecond29.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries26.removeChangeListener(seriesChangeListener33);
        timeSeries26.setNotify(true);
        java.lang.Class<?> wildcardClass37 = timeSeries26.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long40 = fixedMillisecond39.getMiddleMillisecond();
        java.util.Date date41 = fixedMillisecond39.getEnd();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date41);
        long long43 = year42.getLastMillisecond();
        timeSeries26.setKey((java.lang.Comparable) year42);
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str47 = timeSeries46.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long50 = fixedMillisecond49.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) year42, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond49);
        java.util.Date date54 = year42.getEnd();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date54);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year55, (double) 'a');
        try {
            org.jfree.data.time.Month month58 = new org.jfree.data.time.Month((int) (short) 0, year55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "17-May-1927" + "'", str11.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 9999 + "'", int17 == 9999);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2147483647 + "'", int24 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 35L + "'", long40 == 35L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28799999L + "'", long43 == 28799999L);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Time" + "'", str47.equals("Time"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 35L + "'", long50 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeSeriesDataItem57);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str22 = timeSeries21.getDomainDescription();
        timeSeries21.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class25 = timeSeries21.getTimePeriodClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, class26);
        java.lang.ClassLoader classLoader28 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class26);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(classLoader28);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate9.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean19 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.lang.String str20 = spreadsheetDate16.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean25 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int26 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addDays(5, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean32 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.String str33 = spreadsheetDate29.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean38 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean45 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        java.lang.String str46 = spreadsheetDate42.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean51 = spreadsheetDate42.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate48, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean52 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean57 = spreadsheetDate54.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        java.lang.String str58 = spreadsheetDate54.toString();
        boolean boolean59 = spreadsheetDate50.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean66 = spreadsheetDate63.isOn((org.jfree.data.time.SerialDate) spreadsheetDate65);
        java.lang.String str67 = spreadsheetDate63.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean72 = spreadsheetDate63.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate69, (org.jfree.data.time.SerialDate) spreadsheetDate71);
        boolean boolean73 = spreadsheetDate61.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate71);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate77 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean78 = spreadsheetDate75.isOn((org.jfree.data.time.SerialDate) spreadsheetDate77);
        java.lang.String str79 = spreadsheetDate75.toString();
        boolean boolean80 = spreadsheetDate71.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate75);
        boolean boolean82 = spreadsheetDate75.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long85 = fixedMillisecond84.getFirstMillisecond();
        int int87 = fixedMillisecond84.compareTo((java.lang.Object) 100L);
        java.util.Date date88 = fixedMillisecond84.getStart();
        org.jfree.data.time.SerialDate serialDate89 = org.jfree.data.time.SerialDate.createInstance(date88);
        int int90 = spreadsheetDate75.compare(serialDate89);
        boolean boolean92 = spreadsheetDate35.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate50, serialDate89, 1927);
        boolean boolean93 = spreadsheetDate16.isBefore(serialDate89);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "17-May-1927" + "'", str20.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "17-May-1927" + "'", str33.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "17-May-1927" + "'", str46.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "17-May-1927" + "'", str58.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "17-May-1927" + "'", str67.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "17-May-1927" + "'", str79.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 35L + "'", long85 == 35L);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(serialDate89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-15569) + "'", int90 == (-15569));
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        timeSeries8.setKey((java.lang.Comparable) year24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getFirstMillisecond();
        int int31 = fixedMillisecond28.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (-1));
        boolean boolean34 = year24.equals((java.lang.Object) fixedMillisecond28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long37 = fixedMillisecond36.getMiddleMillisecond();
        java.util.Date date38 = fixedMillisecond36.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        long long40 = year39.getLastMillisecond();
        long long41 = year39.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) year39);
        java.lang.String str43 = timeSeries1.getRangeDescription();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28799999L + "'", long40 == 28799999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Value" + "'", str43.equals("Value"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        int int7 = month6.getYearValue();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month6.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.toSerial();
        int int6 = spreadsheetDate2.getMonth();
        java.lang.String str7 = spreadsheetDate2.toString();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9999 + "'", int5 == 9999);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems(false);
        timeSeries1.setNotify(false);
        int int7 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        timeSeries8.setKey((java.lang.Comparable) year24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getFirstMillisecond();
        int int31 = fixedMillisecond28.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (-1));
        boolean boolean34 = year24.equals((java.lang.Object) fixedMillisecond28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long37 = fixedMillisecond36.getMiddleMillisecond();
        java.util.Date date38 = fixedMillisecond36.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        long long40 = year39.getLastMillisecond();
        long long41 = year39.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long45 = fixedMillisecond44.getFirstMillisecond();
        int int47 = fixedMillisecond44.compareTo((java.lang.Object) 100L);
        java.util.Date date48 = fixedMillisecond44.getStart();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        int int50 = day49.getYear();
        java.lang.Number number51 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) day49);
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries42.removePropertyChangeListener(propertyChangeListener52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = null;
        try {
            timeSeries42.delete(regularTimePeriod54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28799999L + "'", long40 == 28799999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 35L + "'", long45 == 35L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1969 + "'", int50 == 1969);
        org.junit.Assert.assertNull(number51);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        java.lang.String str3 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Value" + "'", str3.equals("Value"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean3 = timeSeries2.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, 0.0d);
        timeSeries2.removeAgedItems((-1L), true);
        long long12 = timeSeries2.getMaximumItemAge();
        timeSeries2.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str17 = timeSeries16.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener18);
        java.util.Collection collection20 = timeSeries2.getTimePeriodsUniqueToOtherSeries(timeSeries16);
        java.lang.Class class21 = timeSeries2.getTimePeriodClass();
        java.lang.ClassLoader classLoader22 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class21);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean28 = timeSeries27.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long31 = fixedMillisecond30.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries27.removeChangeListener(seriesChangeListener34);
        timeSeries27.setNotify(true);
        java.lang.Class<?> wildcardClass38 = timeSeries27.getClass();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass38);
        java.lang.Class class40 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
        java.lang.Object obj41 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class21, (java.lang.Class) wildcardClass38);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(classLoader22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertNull(obj41);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek((-15569));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1900, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("June");
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean7 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean13 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long17 = fixedMillisecond16.getFirstMillisecond();
        int int19 = fixedMillisecond16.compareTo((java.lang.Object) 100L);
        java.util.Date date20 = fixedMillisecond16.getStart();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        int int22 = spreadsheetDate12.compare(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(7, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 7);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "17-May-1927" + "'", str8.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-15569) + "'", int22 == (-15569));
        org.junit.Assert.assertNotNull(serialDate23);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560439029577L + "'", long1 == 1560439029577L);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getLastMillisecond();
        long long5 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        boolean boolean26 = year24.equals((java.lang.Object) (short) -1);
        boolean boolean27 = year17.equals((java.lang.Object) (short) -1);
        long long28 = year17.getSerialIndex();
        java.util.Calendar calendar29 = null;
        try {
            year17.peg(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1969L + "'", long28 == 1969L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean19 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.lang.String str20 = spreadsheetDate16.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean25 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean31 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.lang.String str32 = spreadsheetDate28.toString();
        boolean boolean33 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int34 = spreadsheetDate24.getDayOfMonth();
        boolean boolean35 = spreadsheetDate8.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) 1, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "17-May-1927" + "'", str6.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "17-May-1927" + "'", str20.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "17-May-1927" + "'", str32.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 17 + "'", int34 == 17);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate36);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "", "ClassContext", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) '4');
        java.util.Calendar calendar23 = null;
        try {
            day4.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean10 = timeSeries9.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long13 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries9.removeChangeListener(seriesChangeListener16);
        timeSeries9.setNotify(true);
        java.lang.Class<?> wildcardClass20 = timeSeries9.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass20);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean28 = timeSeries27.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long31 = fixedMillisecond30.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries27.removeChangeListener(seriesChangeListener34);
        timeSeries27.setNotify(true);
        java.lang.Class<?> wildcardClass38 = timeSeries27.getClass();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long42 = fixedMillisecond41.getMiddleMillisecond();
        java.util.Date date43 = fixedMillisecond41.getEnd();
        java.util.Date date44 = fixedMillisecond41.getStart();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date44, timeZone46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long51 = fixedMillisecond50.getMiddleMillisecond();
        java.util.Date date52 = fixedMillisecond50.getEnd();
        java.util.Date date53 = fixedMillisecond50.getStart();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date53);
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(date53);
        org.jfree.data.time.Year year56 = month55.getYear();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str59 = timeSeries58.getDomainDescription();
        timeSeries58.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class62 = timeSeries58.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timeSeries58.removePropertyChangeListener(propertyChangeListener63);
        boolean boolean65 = month55.equals((java.lang.Object) timeSeries58);
        java.util.Date date66 = month55.getEnd();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date66);
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date66, timeZone68);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long72 = fixedMillisecond71.getMiddleMillisecond();
        java.util.Date date73 = fixedMillisecond71.getEnd();
        java.util.Date date74 = fixedMillisecond71.getStart();
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date74);
        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date74);
        org.jfree.data.time.Year year77 = month76.getYear();
        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str80 = timeSeries79.getDomainDescription();
        timeSeries79.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class83 = timeSeries79.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener84 = null;
        timeSeries79.removePropertyChangeListener(propertyChangeListener84);
        boolean boolean86 = month76.equals((java.lang.Object) timeSeries79);
        java.util.Date date87 = month76.getEnd();
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date87);
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date87, timeZone89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date66, timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date44, timeZone89);
        org.jfree.data.time.Month month93 = new org.jfree.data.time.Month(date3, timeZone89);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 35L + "'", long51 == 35L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(year56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Time" + "'", str59.equals("Time"));
        org.junit.Assert.assertNotNull(class62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 35L + "'", long72 == 35L);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(year77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "Time" + "'", str80.equals("Time"));
        org.junit.Assert.assertNotNull(class83);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(date87);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod92);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        java.util.Date date20 = fixedMillisecond18.getEnd();
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        try {
            timeSeries22.setMaximumItemAge((-57600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeSeries22);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean19 = timeSeries18.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries18.removeChangeListener(seriesChangeListener25);
        timeSeries18.setNotify(true);
        java.lang.Class<?> wildcardClass29 = timeSeries18.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long32 = fixedMillisecond31.getMiddleMillisecond();
        java.util.Date date33 = fixedMillisecond31.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        long long35 = year34.getLastMillisecond();
        timeSeries18.setKey((java.lang.Comparable) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, 100.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) (short) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = year34.equals((java.lang.Object) day43);
        long long45 = year34.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 28799999L + "'", long35 == 28799999L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 28799999L + "'", long45 == 28799999L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        timeSeries8.setKey((java.lang.Comparable) year24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getFirstMillisecond();
        int int31 = fixedMillisecond28.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (-1));
        boolean boolean34 = year24.equals((java.lang.Object) fixedMillisecond28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long37 = fixedMillisecond36.getMiddleMillisecond();
        java.util.Date date38 = fixedMillisecond36.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        long long40 = year39.getLastMillisecond();
        long long41 = year39.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long45 = fixedMillisecond44.getFirstMillisecond();
        int int47 = fixedMillisecond44.compareTo((java.lang.Object) 100L);
        java.util.Date date48 = fixedMillisecond44.getStart();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        int int50 = day49.getYear();
        java.lang.Number number51 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) day49);
        int int52 = day49.getMonth();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28799999L + "'", long40 == 28799999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 35L + "'", long45 == 35L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1969 + "'", int50 == 1969);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 12 + "'", int52 == 12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        int int6 = day5.getYear();
        boolean boolean8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) day5, (java.lang.Object) "ERROR : Relative To String");
        org.jfree.data.time.SerialDate serialDate9 = day5.getSerialDate();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getFirstMillisecond();
        int int24 = fixedMillisecond21.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) (-1));
        boolean boolean27 = year17.equals((java.lang.Object) fixedMillisecond21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year17.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.toSerial();
        java.lang.Object obj6 = null;
        boolean boolean7 = spreadsheetDate2.equals(obj6);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9999 + "'", int5 == 9999);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        long long17 = month6.getFirstMillisecond();
        long long18 = month6.getSerialIndex();
        org.jfree.data.time.Year year19 = month6.getYear();
        long long20 = year19.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2649600000L) + "'", long17 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 23640L + "'", long18 == 23640L);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1969L + "'", long20 == 1969L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean9 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str10 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean15 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean22 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str23 = spreadsheetDate19.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean28 = spreadsheetDate19.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate17.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean34 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.lang.String str35 = spreadsheetDate31.toString();
        boolean boolean36 = spreadsheetDate27.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean43 = spreadsheetDate40.isOn((org.jfree.data.time.SerialDate) spreadsheetDate42);
        java.lang.String str44 = spreadsheetDate40.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean49 = spreadsheetDate40.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate46, (org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean50 = spreadsheetDate38.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean55 = spreadsheetDate52.isOn((org.jfree.data.time.SerialDate) spreadsheetDate54);
        java.lang.String str56 = spreadsheetDate52.toString();
        boolean boolean57 = spreadsheetDate48.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate52);
        boolean boolean59 = spreadsheetDate52.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long62 = fixedMillisecond61.getFirstMillisecond();
        int int64 = fixedMillisecond61.compareTo((java.lang.Object) 100L);
        java.util.Date date65 = fixedMillisecond61.getStart();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date65);
        int int67 = spreadsheetDate52.compare(serialDate66);
        boolean boolean69 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, serialDate66, 1927);
        int int70 = spreadsheetDate2.compareTo((java.lang.Object) spreadsheetDate27);
        int int71 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate73);
        boolean boolean75 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate73);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(11);
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addDays((int) (byte) -1, serialDate78);
        boolean boolean80 = spreadsheetDate2.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17-May-1927" + "'", str10.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "17-May-1927" + "'", str23.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "17-May-1927" + "'", str35.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "17-May-1927" + "'", str44.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "17-May-1927" + "'", str56.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 35L + "'", long62 == 35L);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-15569) + "'", int67 == (-15569));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 9999 + "'", int71 == 9999);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        int int7 = month6.getYearValue();
        java.util.Date date8 = month6.getStart();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.String str7 = fixedMillisecond5.toString();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) str7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        timeSeries10.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.addChangeListener(seriesChangeListener22);
        timeSeries21.setMaximumItemAge(0L);
        try {
            timeSeries21.delete(31, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(timeSeries21);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries11.removeChangeListener(seriesChangeListener18);
        timeSeries11.setNotify(true);
        java.lang.Class<?> wildcardClass22 = timeSeries11.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean30 = timeSeries29.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long33 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries29.removeChangeListener(seriesChangeListener36);
        timeSeries29.setNotify(true);
        java.lang.Class<?> wildcardClass40 = timeSeries29.getClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long44 = fixedMillisecond43.getMiddleMillisecond();
        java.util.Date date45 = fixedMillisecond43.getEnd();
        java.util.Date date46 = fixedMillisecond43.getStart();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date46, timeZone48);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long53 = fixedMillisecond52.getMiddleMillisecond();
        java.util.Date date54 = fixedMillisecond52.getEnd();
        java.util.Date date55 = fixedMillisecond52.getStart();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date55);
        org.jfree.data.time.Year year58 = month57.getYear();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str61 = timeSeries60.getDomainDescription();
        timeSeries60.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class64 = timeSeries60.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timeSeries60.removePropertyChangeListener(propertyChangeListener65);
        boolean boolean67 = month57.equals((java.lang.Object) timeSeries60);
        java.util.Date date68 = month57.getEnd();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date68);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date68, timeZone70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long74 = fixedMillisecond73.getMiddleMillisecond();
        java.util.Date date75 = fixedMillisecond73.getEnd();
        java.util.Date date76 = fixedMillisecond73.getStart();
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance(date76);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.Year year79 = month78.getYear();
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str82 = timeSeries81.getDomainDescription();
        timeSeries81.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class85 = timeSeries81.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener86 = null;
        timeSeries81.removePropertyChangeListener(propertyChangeListener86);
        boolean boolean88 = month78.equals((java.lang.Object) timeSeries81);
        java.util.Date date89 = month78.getEnd();
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date89);
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date89, timeZone91);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date68, timeZone91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date46, timeZone91);
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date4, timeZone91);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 35L + "'", long33 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 35L + "'", long44 == 35L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 35L + "'", long53 == 35L);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(year58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Time" + "'", str61.equals("Time"));
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 35L + "'", long74 == 35L);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(year79);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Time" + "'", str82.equals("Time"));
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(1927);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries1.getTimePeriod(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str14 = timeSeries13.getDomainDescription();
        int int15 = timeSeries13.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean18 = timeSeries17.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries17.removeChangeListener(seriesChangeListener24);
        timeSeries17.setNotify(true);
        java.lang.Class<?> wildcardClass28 = timeSeries17.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long31 = fixedMillisecond30.getMiddleMillisecond();
        java.util.Date date32 = fixedMillisecond30.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        long long34 = year33.getLastMillisecond();
        timeSeries17.setKey((java.lang.Comparable) year33);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str38 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long41 = fixedMillisecond40.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Date date45 = year33.getEnd();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean51 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        java.lang.String str52 = spreadsheetDate48.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean57 = spreadsheetDate48.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate54, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        int int58 = spreadsheetDate56.toSerial();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate56);
        boolean boolean60 = timeSeries1.equals((java.lang.Object) day59);
        int int61 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28799999L + "'", long34 == 28799999L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "17-May-1927" + "'", str52.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 9999 + "'", int58 == 9999);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2147483647 + "'", int61 == 2147483647);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean17 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean23 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.lang.String str24 = spreadsheetDate20.toString();
        boolean boolean25 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean27 = spreadsheetDate20.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean29 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.next();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-May-1927" + "'", str12.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "17-May-1927" + "'", str24.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long3 = fixedMillisecond2.getMiddleMillisecond();
        java.util.Date date4 = fixedMillisecond2.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        boolean boolean7 = year5.equals((java.lang.Object) (short) -1);
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(0, year5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        java.lang.String str17 = month6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month6.next();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month6.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "December 1969" + "'", str17.equals("December 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean8 = timeSeries7.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long11 = fixedMillisecond10.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries7.removeChangeListener(seriesChangeListener14);
        timeSeries7.setNotify(true);
        java.lang.Class<?> wildcardClass18 = timeSeries7.getClass();
        boolean boolean19 = timeSeries1.equals((java.lang.Object) wildcardClass18);
        try {
            java.lang.Number number21 = timeSeries1.getValue(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        timeSeries1.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        java.lang.Class class20 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long23 = fixedMillisecond22.getMiddleMillisecond();
        java.util.Date date24 = fixedMillisecond22.getEnd();
        java.util.Date date25 = fixedMillisecond22.getStart();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.Year year28 = month27.getYear();
        org.jfree.data.time.Year year29 = month27.getYear();
        timeSeries1.setKey((java.lang.Comparable) year29);
        timeSeries1.removeAgedItems(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long35 = fixedMillisecond34.getMiddleMillisecond();
        java.util.Date date36 = fixedMillisecond34.getEnd();
        java.util.Date date37 = fixedMillisecond34.getStart();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        timeSeries1.setKey((java.lang.Comparable) day38);
        java.util.Calendar calendar40 = null;
        try {
            long long41 = day38.getFirstMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35L + "'", long23 == 35L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(year29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        java.lang.String str20 = timeSeries1.getDomainDescription();
        timeSeries1.setMaximumItemAge(35L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.String str7 = fixedMillisecond5.toString();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) str7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        timeSeries10.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries10);
        boolean boolean22 = timeSeries10.isEmpty();
        timeSeries10.removeAgedItems(true);
        timeSeries10.setRangeDescription("Value");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean13 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str14 = spreadsheetDate10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean19 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate16, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate8.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long23 = fixedMillisecond22.getFirstMillisecond();
        int int25 = fixedMillisecond22.compareTo((java.lang.Object) 100L);
        java.util.Date date26 = fixedMillisecond22.getStart();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        int int28 = spreadsheetDate18.compare(serialDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long35 = fixedMillisecond34.getMiddleMillisecond();
        java.util.Date date36 = fixedMillisecond34.getEnd();
        java.util.Date date37 = fixedMillisecond34.getStart();
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance(date37);
        boolean boolean39 = spreadsheetDate31.isOnOrBefore(serialDate38);
        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate40);
        boolean boolean42 = spreadsheetDate3.isOnOrAfter(serialDate40);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) 1, serialDate40);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "17-May-1927" + "'", str14.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35L + "'", long23 == 35L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-15569) + "'", int28 == (-15569));
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate43);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        boolean boolean11 = timeSeries1.getNotify();
        int int12 = timeSeries1.getMaximumItemCount();
        try {
            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries1.createCopy((-460), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond1.next();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean9 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str10 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean15 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate14.toSerial();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day17, (double) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str22 = timeSeries21.getDomainDescription();
        int int23 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean26 = timeSeries25.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries25.removeChangeListener(seriesChangeListener32);
        timeSeries25.setNotify(true);
        java.lang.Class<?> wildcardClass36 = timeSeries25.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        java.util.Date date40 = fixedMillisecond38.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        long long42 = year41.getLastMillisecond();
        timeSeries25.setKey((java.lang.Comparable) year41);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str46 = timeSeries45.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long49 = fixedMillisecond48.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) year41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Date date53 = year41.getEnd();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year54, (double) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long59 = fixedMillisecond58.getMiddleMillisecond();
        java.util.Date date60 = fixedMillisecond58.getEnd();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year61);
        java.util.Calendar calendar63 = null;
        try {
            long long64 = year61.getLastMillisecond(calendar63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17-May-1927" + "'", str10.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9999 + "'", int16 == 9999);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 35L + "'", long39 == 35L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 28799999L + "'", long42 == 28799999L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Time" + "'", str46.equals("Time"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 35L + "'", long49 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 35L + "'", long59 == 35L);
        org.junit.Assert.assertNotNull(date60);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        timeSeries1.setDomainDescription("Value");
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + 3 + "'", comparable6.equals(3));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        int int3 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean6 = timeSeries5.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.removeChangeListener(seriesChangeListener12);
        timeSeries5.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timeSeries5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        java.util.Date date20 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        timeSeries5.setKey((java.lang.Comparable) year21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str26 = timeSeries25.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond28.getLastMillisecond(calendar33);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond28.getLastMillisecond(calendar35);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond28.getFirstMillisecond(calendar37);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond28.getFirstMillisecond(calendar39);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond28.getFirstMillisecond(calendar41);
        try {
            java.lang.Object obj43 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) fixedMillisecond28);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 35L + "'", long36 == 35L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 35L + "'", long38 == 35L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 35L + "'", long40 == 35L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        timeSeries4.setNotify(true);
        java.lang.Class<?> wildcardClass15 = timeSeries4.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries16.removePropertyChangeListener(propertyChangeListener17);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeries16.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean8 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate7);
        java.lang.String str9 = spreadsheetDate5.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean14 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate11, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate3.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean20 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate19);
        java.lang.String str21 = spreadsheetDate17.toString();
        boolean boolean22 = spreadsheetDate13.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean24 = spreadsheetDate17.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        try {
            org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (short) -1, serialDate25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "17-May-1927" + "'", str9.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "17-May-1927" + "'", str21.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(serialDate25);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        java.util.Date date6 = fixedMillisecond4.getEnd();
        java.util.Date date7 = fixedMillisecond4.getStart();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7);
        java.util.Date date11 = day10.getStart();
        int int12 = fixedMillisecond1.compareTo((java.lang.Object) day10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (short) 0);
        try {
            java.lang.Number number13 = timeSeries1.getValue((-15569));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -15569");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        boolean boolean20 = spreadsheetDate11.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long27 = fixedMillisecond26.getMiddleMillisecond();
        java.util.Date date28 = fixedMillisecond26.getEnd();
        java.util.Date date29 = fixedMillisecond26.getStart();
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance(date29);
        boolean boolean31 = spreadsheetDate23.isOnOrBefore(serialDate30);
        org.jfree.data.time.SerialDate serialDate32 = spreadsheetDate15.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate23);
        int int33 = spreadsheetDate23.getMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 35L + "'", long27 == 35L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean15 = timeSeries14.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long18 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str25 = timeSeries24.getDomainDescription();
        timeSeries24.setKey((java.lang.Comparable) (-1.0f));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries24.removeChangeListener(seriesChangeListener28);
        java.lang.Object obj30 = timeSeries24.clone();
        boolean boolean31 = timeSeriesDataItem22.equals((java.lang.Object) timeSeries24);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timeSeries24.addPropertyChangeListener(propertyChangeListener32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 35L + "'", long18 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Time" + "'", str25.equals("Time"));
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -460");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (byte) 100);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (byte) 100 + "'", obj2.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=100]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + (byte) 100 + "'", obj4.equals((byte) 100));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2958465");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        long long8 = month6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        timeSeries10.removeAgedItems((-1L), true);
        long long20 = timeSeries10.getMaximumItemAge();
        java.lang.Class class21 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, class21);
        int int23 = month6.getMonth();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 23640L + "'", long8 == 23640L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 12 + "'", int23 == 12);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#', 4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems(false);
        boolean boolean6 = timeSeries1.equals((java.lang.Object) "1969");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        timeSeries8.removeAgedItems((-1L), true);
        long long18 = timeSeries8.getMaximumItemAge();
        timeSeries8.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean22 = timeSeries21.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long25 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
        timeSeries21.removeAgedItems((-1L), true);
        long long31 = timeSeries21.getMaximumItemAge();
        timeSeries21.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str36 = timeSeries35.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries35.addPropertyChangeListener(propertyChangeListener37);
        java.util.Collection collection39 = timeSeries21.getTimePeriodsUniqueToOtherSeries(timeSeries35);
        java.lang.Class class40 = timeSeries21.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long43 = fixedMillisecond42.getMiddleMillisecond();
        java.util.Date date44 = fixedMillisecond42.getEnd();
        java.util.Date date45 = fixedMillisecond42.getStart();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(date45);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date45);
        org.jfree.data.time.Year year48 = month47.getYear();
        org.jfree.data.time.Year year49 = month47.getYear();
        timeSeries21.setKey((java.lang.Comparable) year49);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year49, (java.lang.Number) 100.0d);
        try {
            timeSeries1.add(timeSeriesDataItem52);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 35L + "'", long25 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 35L + "'", long43 == 35L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertNotNull(year49);
        org.junit.Assert.assertNotNull(timeSeriesDataItem52);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean8 = timeSeries7.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long11 = fixedMillisecond10.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, 0.0d);
        timeSeries7.removeAgedItems((-1L), true);
        long long17 = timeSeries7.getMaximumItemAge();
        timeSeries7.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean21 = timeSeries20.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long24 = fixedMillisecond23.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, 0.0d);
        timeSeries20.removeAgedItems((-1L), true);
        long long30 = timeSeries20.getMaximumItemAge();
        timeSeries20.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries34.addPropertyChangeListener(propertyChangeListener36);
        java.util.Collection collection38 = timeSeries20.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        java.lang.Class class39 = timeSeries20.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long42 = fixedMillisecond41.getMiddleMillisecond();
        java.util.Date date43 = fixedMillisecond41.getEnd();
        java.util.Date date44 = fixedMillisecond41.getStart();
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(date44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date44);
        org.jfree.data.time.Year year47 = month46.getYear();
        org.jfree.data.time.Year year48 = month46.getYear();
        timeSeries20.setKey((java.lang.Comparable) year48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 100.0d);
        java.lang.Number number52 = timeSeriesDataItem51.getValue();
        try {
            timeSeries1.add(timeSeriesDataItem51);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 35L + "'", long24 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(year47);
        org.junit.Assert.assertNotNull(year48);
        org.junit.Assert.assertNotNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 0.0d + "'", number52.equals(0.0d));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 10);
        timeSeries1.removeAgedItems((long) 8, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999, 2019, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        java.lang.Object obj11 = timeSeries1.clone();
        timeSeries1.clear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 0.0f);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) (-459));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long7 = fixedMillisecond6.getMiddleMillisecond();
        java.util.Date date8 = fixedMillisecond6.getEnd();
        java.util.Date date9 = fixedMillisecond6.getStart();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year12 = month11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str15 = timeSeries14.getDomainDescription();
        timeSeries14.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = month11.equals((java.lang.Object) timeSeries14);
        long long22 = month11.getFirstMillisecond();
        long long23 = month11.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1927L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-2649600000L) + "'", long22 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-2649600000L) + "'", long23 == (-2649600000L));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.String str7 = fixedMillisecond5.toString();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) str7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        timeSeries10.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.addChangeListener(seriesChangeListener22);
        timeSeries21.setMaximumItemAge(0L);
        java.lang.String str26 = timeSeries21.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        java.util.Date date30 = fixedMillisecond28.getEnd();
        java.util.Date date31 = fixedMillisecond28.getStart();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date31);
        org.jfree.data.time.Year year34 = month33.getYear();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str37 = timeSeries36.getDomainDescription();
        timeSeries36.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class40 = timeSeries36.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries36.removePropertyChangeListener(propertyChangeListener41);
        boolean boolean43 = month33.equals((java.lang.Object) timeSeries36);
        java.util.Date date44 = month33.getEnd();
        org.jfree.data.time.Year year45 = month33.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long48 = fixedMillisecond47.getFirstMillisecond();
        int int50 = fixedMillisecond47.compareTo((java.lang.Object) 100L);
        java.util.Date date51 = fixedMillisecond47.getStart();
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date51);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance(date51);
        boolean boolean54 = month33.equals((java.lang.Object) serialDate53);
        java.lang.String str55 = month33.toString();
        try {
            timeSeries21.add((org.jfree.data.time.RegularTimePeriod) month33, (double) 1L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(year34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Time" + "'", str37.equals("Time"));
        org.junit.Assert.assertNotNull(class40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(year45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 35L + "'", long48 == 35L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "December 1969" + "'", str55.equals("December 1969"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.String str7 = fixedMillisecond5.toString();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) str7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        timeSeries10.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries10);
        boolean boolean22 = timeSeries10.getNotify();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 10);
        long long13 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        int int5 = spreadsheetDate2.toSerial();
        java.util.Date date6 = spreadsheetDate2.toDate();
        int int7 = spreadsheetDate2.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9999 + "'", int5 == 9999);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 17 + "'", int7 == 17);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        java.util.Collection collection7 = timeSeries1.getTimePeriods();
        java.util.List list8 = timeSeries1.getItems();
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy(1969, 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(collection7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        java.util.List list20 = timeSeries1.getItems();
        java.lang.Object obj21 = timeSeries1.clone();
        int int22 = timeSeries1.getItemCount();
        boolean boolean23 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        java.lang.Object obj8 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Last");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(30, 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 0.0f);
        java.lang.Object obj4 = timeSeriesDataItem3.clone();
        boolean boolean6 = timeSeriesDataItem3.equals((java.lang.Object) 10.0f);
        java.lang.Object obj7 = timeSeriesDataItem3.clone();
        java.lang.Number number8 = null;
        timeSeriesDataItem3.setValue(number8);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day2.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "17-May-1927" + "'", str3.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 0L);
        java.util.List list8 = timeSeries1.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond13.getFirstMillisecond(calendar17);
        java.lang.Number number19 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 35L + "'", long18 == 35L);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0L + "'", number19.equals(0L));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.Year year8 = month6.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long11 = fixedMillisecond10.getFirstMillisecond();
        java.util.Date date12 = fixedMillisecond10.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond10.next();
        int int14 = month6.compareTo((java.lang.Object) regularTimePeriod13);
        int int15 = month6.getMonth();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 35L + "'", long11 == 35L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        int int7 = month6.getYearValue();
        java.lang.String str8 = month6.toString();
        long long9 = month6.getLastMillisecond();
        org.jfree.data.time.Year year10 = month6.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 0.0f);
        java.lang.Object obj15 = timeSeriesDataItem14.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem14.getPeriod();
        int int17 = month6.compareTo((java.lang.Object) regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.String str7 = fixedMillisecond5.toString();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) str7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        timeSeries10.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries10);
        java.lang.Object obj22 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (9) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str5 = timeSeries4.getDomainDescription();
        timeSeries4.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class8 = timeSeries4.getTimePeriodClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize(class8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, 0.0d);
        timeSeries11.removeAgedItems((-1L), true);
        long long21 = timeSeries11.getMaximumItemAge();
        timeSeries11.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str26 = timeSeries25.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener27);
        java.util.Collection collection29 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.lang.Class class30 = timeSeries11.getTimePeriodClass();
        java.lang.Object obj31 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class8, class30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean42 = timeSeries41.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long45 = fixedMillisecond44.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries41.removeChangeListener(seriesChangeListener48);
        timeSeries41.setNotify(true);
        java.lang.Class<?> wildcardClass52 = timeSeries41.getClass();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, "", "ClassContext", (java.lang.Class) wildcardClass52);
        java.lang.Class class54 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass52);
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean61 = timeSeries60.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long64 = fixedMillisecond63.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener67 = null;
        timeSeries60.removeChangeListener(seriesChangeListener67);
        timeSeries60.setNotify(true);
        java.lang.Class<?> wildcardClass71 = timeSeries60.getClass();
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass71);
        java.io.InputStream inputStream73 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", (java.lang.Class) wildcardClass71);
        java.lang.Object obj74 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", (java.lang.Class) wildcardClass52, (java.lang.Class) wildcardClass71);
        java.lang.Object obj75 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class30, (java.lang.Class) wildcardClass52);
        java.io.InputStream inputStream76 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ClassContext", (java.lang.Class) wildcardClass52);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNotNull(class30);
        org.junit.Assert.assertNull(obj31);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 35L + "'", long45 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(class54);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 35L + "'", long64 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem66);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(inputStream73);
        org.junit.Assert.assertNull(obj74);
        org.junit.Assert.assertNull(obj75);
        org.junit.Assert.assertNull(inputStream76);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries11.removeChangeListener(seriesChangeListener18);
        timeSeries11.setNotify(true);
        java.lang.Class<?> wildcardClass22 = timeSeries11.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass22);
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean30 = timeSeries29.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long33 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries29.removeChangeListener(seriesChangeListener36);
        timeSeries29.setNotify(true);
        java.lang.Class<?> wildcardClass40 = timeSeries29.getClass();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long44 = fixedMillisecond43.getMiddleMillisecond();
        java.util.Date date45 = fixedMillisecond43.getEnd();
        java.util.Date date46 = fixedMillisecond43.getStart();
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.createInstance(date46);
        java.util.TimeZone timeZone48 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass40, date46, timeZone48);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month(date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long53 = fixedMillisecond52.getMiddleMillisecond();
        java.util.Date date54 = fixedMillisecond52.getEnd();
        java.util.Date date55 = fixedMillisecond52.getStart();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date55);
        org.jfree.data.time.Year year58 = month57.getYear();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str61 = timeSeries60.getDomainDescription();
        timeSeries60.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class64 = timeSeries60.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timeSeries60.removePropertyChangeListener(propertyChangeListener65);
        boolean boolean67 = month57.equals((java.lang.Object) timeSeries60);
        java.util.Date date68 = month57.getEnd();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date68);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date68, timeZone70);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long74 = fixedMillisecond73.getMiddleMillisecond();
        java.util.Date date75 = fixedMillisecond73.getEnd();
        java.util.Date date76 = fixedMillisecond73.getStart();
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.createInstance(date76);
        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date76);
        org.jfree.data.time.Year year79 = month78.getYear();
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str82 = timeSeries81.getDomainDescription();
        timeSeries81.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class85 = timeSeries81.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener86 = null;
        timeSeries81.removePropertyChangeListener(propertyChangeListener86);
        boolean boolean88 = month78.equals((java.lang.Object) timeSeries81);
        java.util.Date date89 = month78.getEnd();
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date89);
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date89, timeZone91);
        org.jfree.data.time.Year year93 = new org.jfree.data.time.Year(date68, timeZone91);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date46, timeZone91);
        org.jfree.data.time.Month month95 = new org.jfree.data.time.Month(date5, timeZone91);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 35L + "'", long33 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 35L + "'", long44 == 35L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 35L + "'", long53 == 35L);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(year58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Time" + "'", str61.equals("Time"));
        org.junit.Assert.assertNotNull(class64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 35L + "'", long74 == 35L);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(year79);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Time" + "'", str82.equals("Time"));
        org.junit.Assert.assertNotNull(class85);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        boolean boolean20 = spreadsheetDate11.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean22 = spreadsheetDate15.equals((java.lang.Object) (short) 10);
        spreadsheetDate15.setDescription("17-May-1927");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        long long7 = year4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-31507200000L) + "'", long7 == (-31507200000L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        timeSeries8.setKey((java.lang.Comparable) year24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getFirstMillisecond();
        int int31 = fixedMillisecond28.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (-1));
        boolean boolean34 = year24.equals((java.lang.Object) fixedMillisecond28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long37 = fixedMillisecond36.getMiddleMillisecond();
        java.util.Date date38 = fixedMillisecond36.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        long long40 = year39.getLastMillisecond();
        long long41 = year39.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) year39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long45 = fixedMillisecond44.getFirstMillisecond();
        int int47 = fixedMillisecond44.compareTo((java.lang.Object) 100L);
        java.util.Date date48 = fixedMillisecond44.getStart();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        int int50 = day49.getYear();
        java.lang.Number number51 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) day49);
        java.lang.String str52 = timeSeries42.getDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28799999L + "'", long40 == 28799999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 35L + "'", long45 == 35L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1969 + "'", int50 == 1969);
        org.junit.Assert.assertNull(number51);
        org.junit.Assert.assertNull(str52);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        timeSeries1.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        java.lang.Number number21 = timeSeries1.getValue(0);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean24 = timeSeries23.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long27 = fixedMillisecond26.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries23.removeChangeListener(seriesChangeListener30);
        timeSeries23.setNotify(true);
        java.lang.Class<?> wildcardClass34 = timeSeries23.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long37 = fixedMillisecond36.getMiddleMillisecond();
        java.util.Date date38 = fixedMillisecond36.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        long long40 = year39.getLastMillisecond();
        timeSeries23.setKey((java.lang.Comparable) year39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year39.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year39, (java.lang.Number) (short) -1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = timeSeriesDataItem44.getPeriod();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long48 = fixedMillisecond47.getMiddleMillisecond();
        java.util.Date date49 = fixedMillisecond47.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        boolean boolean52 = year50.equals((java.lang.Object) (short) -1);
        java.lang.Class<?> wildcardClass53 = year50.getClass();
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        long long55 = month54.getLastMillisecond();
        int int56 = month54.getYearValue();
        int int57 = month54.getYearValue();
        long long58 = month54.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = month54.next();
        java.lang.String str60 = month54.toString();
        boolean boolean61 = year50.equals((java.lang.Object) month54);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries1.createCopy(regularTimePeriod45, (org.jfree.data.time.RegularTimePeriod) month54);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.0d + "'", number21.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 35L + "'", long27 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28799999L + "'", long40 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 35L + "'", long48 == 35L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1561964399999L + "'", long55 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1561964399999L + "'", long58 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "June 2019" + "'", str60.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(timeSeries62);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getLastMillisecond();
        boolean boolean8 = year4.equals((java.lang.Object) 2958465);
        long long9 = year4.getSerialIndex();
        java.util.Calendar calendar10 = null;
        try {
            year4.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1969L + "'", long9 == 1969L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date4 = fixedMillisecond1.getEnd();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean17 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean23 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.lang.String str24 = spreadsheetDate20.toString();
        boolean boolean25 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean27 = spreadsheetDate20.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean29 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int34 = spreadsheetDate32.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean39 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.lang.String str40 = spreadsheetDate36.toString();
        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate32.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean47 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        java.lang.String str48 = spreadsheetDate44.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean53 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        int int54 = spreadsheetDate44.compare((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean56 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, serialDate55);
        java.util.Date date57 = spreadsheetDate36.toDate();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-May-1927" + "'", str12.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "17-May-1927" + "'", str24.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5 + "'", int34 == 5);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "17-May-1927" + "'", str40.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "17-May-1927" + "'", str48.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(date57);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        boolean boolean11 = timeSeries1.getNotify();
        int int12 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDomainDescription("31-August-1931");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean19 = timeSeries18.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries18.removeChangeListener(seriesChangeListener25);
        timeSeries18.setNotify(true);
        java.lang.Class<?> wildcardClass29 = timeSeries18.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long32 = fixedMillisecond31.getMiddleMillisecond();
        java.util.Date date33 = fixedMillisecond31.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        long long35 = year34.getLastMillisecond();
        timeSeries18.setKey((java.lang.Comparable) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, 100.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) (short) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = year34.equals((java.lang.Object) day43);
        int int45 = day43.getMonth();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean48 = timeSeries47.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long51 = fixedMillisecond50.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, 0.0d);
        timeSeries47.removeAgedItems((-1L), true);
        long long57 = timeSeries47.getMaximumItemAge();
        timeSeries47.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str62 = timeSeries61.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener63 = null;
        timeSeries61.addPropertyChangeListener(propertyChangeListener63);
        java.util.Collection collection65 = timeSeries47.getTimePeriodsUniqueToOtherSeries(timeSeries61);
        java.lang.Class class66 = timeSeries47.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long69 = fixedMillisecond68.getMiddleMillisecond();
        java.util.Date date70 = fixedMillisecond68.getEnd();
        java.util.Date date71 = fixedMillisecond68.getStart();
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance(date71);
        org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date71);
        org.jfree.data.time.Year year74 = month73.getYear();
        org.jfree.data.time.Year year75 = month73.getYear();
        timeSeries47.setKey((java.lang.Comparable) year75);
        int int77 = day43.compareTo((java.lang.Object) year75);
        org.jfree.data.time.SerialDate serialDate78 = day43.getSerialDate();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 28799999L + "'", long35 == 28799999L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 5 + "'", int45 == 5);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 35L + "'", long51 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Time" + "'", str62.equals("Time"));
        org.junit.Assert.assertNotNull(collection65);
        org.junit.Assert.assertNotNull(class66);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 35L + "'", long69 == 35L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(year74);
        org.junit.Assert.assertNotNull(year75);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(serialDate78);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        java.lang.Object obj11 = timeSeries1.clone();
        timeSeries1.clear();
        timeSeries1.clear();
        timeSeries1.setDescription("December 1969");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries1.removeChangeListener(seriesChangeListener13);
        java.lang.Comparable comparable15 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + comparable15 + "' != '" + 3 + "'", comparable15.equals(3));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        int int3 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean6 = timeSeries5.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.removeChangeListener(seriesChangeListener12);
        timeSeries5.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timeSeries5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        java.util.Date date20 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        timeSeries5.setKey((java.lang.Comparable) year21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str26 = timeSeries25.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        java.util.Date date33 = year21.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        int int35 = year34.getYear();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1969 + "'", int35 == 1969);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean19 = timeSeries18.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, 0.0d);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond21.getFirstMillisecond(calendar25);
        java.lang.String str27 = fixedMillisecond21.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str27.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertNull(timeSeriesDataItem29);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond4.previous();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean13 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str14 = spreadsheetDate10.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean19 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        int int20 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean32 = spreadsheetDate29.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.lang.String str33 = spreadsheetDate29.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean38 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate37);
        boolean boolean39 = spreadsheetDate27.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean44 = spreadsheetDate41.isOn((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.lang.String str45 = spreadsheetDate41.toString();
        boolean boolean46 = spreadsheetDate37.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean48 = spreadsheetDate41.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate41);
        boolean boolean50 = spreadsheetDate23.isOn((org.jfree.data.time.SerialDate) spreadsheetDate41);
        int int51 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long60 = fixedMillisecond59.getMiddleMillisecond();
        java.util.Date date61 = fixedMillisecond59.getEnd();
        java.util.Date date62 = fixedMillisecond59.getStart();
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance(date62);
        boolean boolean64 = spreadsheetDate56.isOnOrBefore(serialDate63);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        int int69 = spreadsheetDate67.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate73 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean74 = spreadsheetDate71.isOn((org.jfree.data.time.SerialDate) spreadsheetDate73);
        java.lang.String str75 = spreadsheetDate71.toString();
        org.jfree.data.time.SerialDate serialDate76 = spreadsheetDate67.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate71);
        int int77 = spreadsheetDate67.getDayOfWeek();
        boolean boolean78 = spreadsheetDate53.isInRange(serialDate63, (org.jfree.data.time.SerialDate) spreadsheetDate67);
        boolean boolean79 = spreadsheetDate16.isAfter(serialDate63);
        int int80 = fixedMillisecond4.compareTo((java.lang.Object) spreadsheetDate16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "17-May-1927" + "'", str14.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "17-May-1927" + "'", str33.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "17-May-1927" + "'", str45.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 35L + "'", long60 == 35L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 5 + "'", int69 == 5);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "17-May-1927" + "'", str75.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 3 + "'", int77 == 3);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (-2649600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getLastMillisecond();
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.setMaximumItemAge((long) 3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        int int3 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean6 = timeSeries5.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.removeChangeListener(seriesChangeListener12);
        timeSeries5.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timeSeries5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        java.util.Date date20 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        timeSeries5.setKey((java.lang.Comparable) year21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str26 = timeSeries25.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond28.getLastMillisecond(calendar33);
        java.util.Calendar calendar35 = null;
        long long36 = fixedMillisecond28.getLastMillisecond(calendar35);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond28.getFirstMillisecond(calendar37);
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond28.getFirstMillisecond(calendar39);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond28.getFirstMillisecond(calendar41);
        java.util.Date date43 = fixedMillisecond28.getStart();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 35L + "'", long36 == 35L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 35L + "'", long38 == 35L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 35L + "'", long40 == 35L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
        org.junit.Assert.assertNotNull(date43);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean9 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str10 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean15 = spreadsheetDate12.isOn((org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int18 = spreadsheetDate2.compare(serialDate17);
        try {
            org.jfree.data.time.SerialDate serialDate20 = spreadsheetDate2.getNearestDayOfWeek((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17-May-1927" + "'", str10.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-9999) + "'", int18 == (-9999));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str6 = timeSeries5.getDomainDescription();
        int int7 = timeSeries5.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean10 = timeSeries9.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long13 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries9.removeChangeListener(seriesChangeListener16);
        timeSeries9.setNotify(true);
        java.lang.Class<?> wildcardClass20 = timeSeries9.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long23 = fixedMillisecond22.getMiddleMillisecond();
        java.util.Date date24 = fixedMillisecond22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        long long26 = year25.getLastMillisecond();
        timeSeries9.setKey((java.lang.Comparable) year25);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str30 = timeSeries29.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long33 = fixedMillisecond32.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) year25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        int int37 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        java.lang.Comparable comparable38 = timeSeries1.getKey();
        timeSeries1.setDescription("Last");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35L + "'", long23 == 35L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28799999L + "'", long26 == 28799999L);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Time" + "'", str30.equals("Time"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 35L + "'", long33 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + comparable38 + "' != '" + 3 + "'", comparable38.equals(3));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '4', 1900, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate9.toSerial();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        long long13 = day12.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9999 + "'", int11 == 9999);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9999L + "'", long13 == 9999L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long16 = fixedMillisecond15.getFirstMillisecond();
        int int18 = fixedMillisecond15.compareTo((java.lang.Object) 100L);
        java.util.Date date19 = fixedMillisecond15.getStart();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        int int21 = spreadsheetDate11.compare(serialDate20);
        int int22 = spreadsheetDate11.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean29 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate28);
        java.lang.String str30 = spreadsheetDate26.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean35 = spreadsheetDate26.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate32, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate24.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate34);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean41 = spreadsheetDate38.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.lang.String str42 = spreadsheetDate38.toString();
        boolean boolean43 = spreadsheetDate34.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.lang.String str44 = spreadsheetDate38.toString();
        boolean boolean45 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.util.Date date46 = spreadsheetDate38.toDate();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-15569) + "'", int21 == (-15569));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9999 + "'", int22 == 9999);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "17-May-1927" + "'", str30.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "17-May-1927" + "'", str42.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "17-May-1927" + "'", str44.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems((long) 2147483647, false);
        timeSeries1.setMaximumItemCount(6);
        java.lang.String str10 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean9 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str10 = spreadsheetDate6.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean15 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        int int16 = spreadsheetDate14.toSerial();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate14);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day17, (double) (byte) -1);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str22 = timeSeries21.getDomainDescription();
        int int23 = timeSeries21.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean26 = timeSeries25.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries25.removeChangeListener(seriesChangeListener32);
        timeSeries25.setNotify(true);
        java.lang.Class<?> wildcardClass36 = timeSeries25.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        java.util.Date date40 = fixedMillisecond38.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        long long42 = year41.getLastMillisecond();
        timeSeries25.setKey((java.lang.Comparable) year41);
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str46 = timeSeries45.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long49 = fixedMillisecond48.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) year41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
        java.util.Date date53 = year41.getEnd();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year54, (double) 'a');
        long long57 = year54.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year54.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17-May-1927" + "'", str10.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9999 + "'", int16 == 9999);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 35L + "'", long39 == 35L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 28799999L + "'", long42 == 28799999L);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Time" + "'", str46.equals("Time"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 35L + "'", long49 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeSeriesDataItem56);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1969L + "'", long57 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "", "ClassContext", (java.lang.Class) wildcardClass19);
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day4.getMiddleMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean5 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate4);
        java.lang.String str6 = spreadsheetDate2.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate10.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean19 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.lang.String str20 = spreadsheetDate16.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean25 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getFirstMillisecond();
        int int31 = fixedMillisecond28.compareTo((java.lang.Object) 100L);
        java.util.Date date32 = fixedMillisecond28.getStart();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        int int34 = spreadsheetDate24.compare(serialDate33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(100, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str38 = spreadsheetDate10.getDescription();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "17-May-1927" + "'", str6.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9999 + "'", int12 == 9999);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "17-May-1927" + "'", str20.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-15569) + "'", int34 == (-15569));
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNull(str38);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        int int3 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean6 = timeSeries5.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.removeChangeListener(seriesChangeListener12);
        timeSeries5.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timeSeries5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        java.util.Date date20 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        timeSeries5.setKey((java.lang.Comparable) year21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str26 = timeSeries25.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        java.util.Date date33 = year21.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        long long35 = year34.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-31507200000L) + "'", long35 == (-31507200000L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        timeSeries1.setMaximumItemAge((long) 1927);
        java.lang.String str14 = timeSeries1.getRangeDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long17 = fixedMillisecond16.getMiddleMillisecond();
        java.util.Date date18 = fixedMillisecond16.getEnd();
        java.util.Date date19 = fixedMillisecond16.getStart();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date19);
        org.jfree.data.time.Year year22 = month21.getYear();
        org.jfree.data.time.Year year23 = month21.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long26 = fixedMillisecond25.getFirstMillisecond();
        java.util.Date date27 = fixedMillisecond25.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond25.next();
        int int29 = month21.compareTo((java.lang.Object) regularTimePeriod28);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month21, (double) 13, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(year22);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        java.lang.String str4 = timeSeries1.getDescription();
        java.lang.Class class5 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
        java.lang.Number number7 = null;
        try {
            timeSeries1.add(regularTimePeriod6, number7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date4 = fixedMillisecond1.getEnd();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond1.getMiddleMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (-1));
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean10 = timeSeries9.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long13 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 0.0d);
        timeSeries9.removeAgedItems((-1L), true);
        long long19 = timeSeries9.getMaximumItemAge();
        java.lang.Class class20 = timeSeries9.getTimePeriodClass();
        boolean boolean21 = timeSeriesDataItem6.equals((java.lang.Object) class20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        java.lang.String str17 = timeSeries9.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Value" + "'", str17.equals("Value"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        java.lang.String str20 = year17.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException24);
        int int26 = year17.compareTo((java.lang.Object) timePeriodFormatException24);
        java.lang.String str27 = timePeriodFormatException24.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str27.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long4 = fixedMillisecond3.getFirstMillisecond();
        int int6 = fixedMillisecond3.compareTo((java.lang.Object) 100L);
        java.util.Date date7 = fixedMillisecond3.getStart();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(date7);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate9);
        serialDate9.setDescription("Nearest");
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.lang.String str7 = fixedMillisecond5.toString();
        boolean boolean8 = timeSeries1.equals((java.lang.Object) str7);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries10.removeChangeListener(seriesChangeListener17);
        timeSeries10.setNotify(true);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries1.addAndOrUpdate(timeSeries10);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.addChangeListener(seriesChangeListener22);
        timeSeries21.setMaximumItemAge(0L);
        java.lang.Class class26 = timeSeries21.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertNotNull(class26);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (short) 0);
        int int12 = timeSeries1.getItemCount();
        try {
            timeSeries1.delete(2, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean3 = timeSeries2.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries2.removeChangeListener(seriesChangeListener9);
        timeSeries2.setNotify(true);
        java.lang.Class<?> wildcardClass13 = timeSeries2.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long16 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Date date17 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        long long19 = year18.getLastMillisecond();
        timeSeries2.setKey((java.lang.Comparable) year18);
        java.lang.String str21 = year18.toString();
        java.util.Date date22 = year18.getEnd();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(6, year18);
        java.util.Calendar calendar24 = null;
        try {
            month23.peg(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969" + "'", str21.equals("1969"));
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str4 = timeSeries3.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long7 = fixedMillisecond6.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond6.previous();
        java.util.Date date11 = fixedMillisecond6.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond6.next();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long7 = fixedMillisecond6.getFirstMillisecond();
        int int9 = fixedMillisecond6.compareTo((java.lang.Object) 100L);
        java.util.Date date10 = fixedMillisecond6.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 9999L, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str22 = timeSeries21.getDomainDescription();
        timeSeries21.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class25 = timeSeries21.getTimePeriodClass();
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize(class25);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year17, class26);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str32 = timeSeries31.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long35 = fixedMillisecond34.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond34.previous();
        java.util.Date date39 = fixedMillisecond34.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries29.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        long long41 = fixedMillisecond34.getFirstMillisecond();
        long long42 = fixedMillisecond34.getLastMillisecond();
        timeSeries27.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        java.util.Date date11 = fixedMillisecond9.getEnd();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) date11);
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("17-May-1927");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, 100.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        int int24 = year17.compareTo((java.lang.Object) '#');
        java.lang.Class<?> wildcardClass25 = year17.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int14 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        int int3 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean6 = timeSeries5.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.removeChangeListener(seriesChangeListener12);
        timeSeries5.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timeSeries5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        java.util.Date date20 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        timeSeries5.setKey((java.lang.Comparable) year21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str26 = timeSeries25.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        long long33 = year21.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1969L + "'", long33 == 1969L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("December 1969");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        java.lang.Class class12 = timeSeries1.getTimePeriodClass();
        java.lang.String str13 = timeSeries1.getDomainDescription();
        timeSeries1.setMaximumItemCount(8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            timeSeries1.add(regularTimePeriod16, (java.lang.Number) 100.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 100, (int) (byte) 10, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        java.util.Date date17 = month6.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.Date date19 = year18.getStart();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date19);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean10 = timeSeries9.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long13 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries9.removeChangeListener(seriesChangeListener16);
        timeSeries9.setNotify(true);
        java.lang.Class<?> wildcardClass20 = timeSeries9.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day5, "", "ClassContext", (java.lang.Class) wildcardClass20);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize(class22);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("June 2019", class22);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNull(uRL24);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean7 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean13 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long17 = fixedMillisecond16.getFirstMillisecond();
        int int19 = fixedMillisecond16.compareTo((java.lang.Object) 100L);
        java.util.Date date20 = fixedMillisecond16.getStart();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        int int22 = spreadsheetDate12.compare(serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(7, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.util.Date date24 = spreadsheetDate12.toDate();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "17-May-1927" + "'", str8.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-15569) + "'", int22 == (-15569));
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean17 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean23 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.lang.String str24 = spreadsheetDate20.toString();
        boolean boolean25 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean27 = spreadsheetDate20.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate20);
        boolean boolean29 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int34 = spreadsheetDate32.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean39 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.lang.String str40 = spreadsheetDate36.toString();
        org.jfree.data.time.SerialDate serialDate41 = spreadsheetDate32.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean47 = spreadsheetDate44.isOn((org.jfree.data.time.SerialDate) spreadsheetDate46);
        java.lang.String str48 = spreadsheetDate44.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean53 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        int int54 = spreadsheetDate44.compare((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays(9999, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean56 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, serialDate55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long59 = fixedMillisecond58.getMiddleMillisecond();
        java.util.Date date60 = fixedMillisecond58.getEnd();
        java.util.Date date61 = fixedMillisecond58.getStart();
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date61);
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(date61);
        org.jfree.data.time.Year year64 = month63.getYear();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str67 = timeSeries66.getDomainDescription();
        timeSeries66.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class70 = timeSeries66.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener71 = null;
        timeSeries66.removePropertyChangeListener(propertyChangeListener71);
        boolean boolean73 = month63.equals((java.lang.Object) timeSeries66);
        long long74 = month63.getFirstMillisecond();
        java.lang.String str75 = month63.toString();
        java.lang.Class<?> wildcardClass76 = month63.getClass();
        try {
            int int77 = spreadsheetDate36.compareTo((java.lang.Object) wildcardClass76);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Class cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-May-1927" + "'", str12.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "17-May-1927" + "'", str24.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5 + "'", int34 == 5);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "17-May-1927" + "'", str40.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "17-May-1927" + "'", str48.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 35L + "'", long59 == 35L);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(year64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Time" + "'", str67.equals("Time"));
        org.junit.Assert.assertNotNull(class70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-2649600000L) + "'", long74 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "December 1969" + "'", str75.equals("December 1969"));
        org.junit.Assert.assertNotNull(wildcardClass76);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean3 = timeSeries2.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long6 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries2.removeChangeListener(seriesChangeListener9);
        timeSeries2.setNotify(true);
        java.lang.Class<?> wildcardClass13 = timeSeries2.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long16 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Date date17 = fixedMillisecond15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        long long19 = year18.getLastMillisecond();
        timeSeries2.setKey((java.lang.Comparable) year18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year18.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year18.previous();
        try {
            org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(1900, year18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        int int6 = spreadsheetDate1.getYYYY();
        java.util.Date date7 = spreadsheetDate1.toDate();
        int int8 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1927 + "'", int6 == 1927);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1969);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17 + "'", int1 == 17);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(31, (int) ' ', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean19 = timeSeries18.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries18.removeChangeListener(seriesChangeListener25);
        timeSeries18.setNotify(true);
        java.lang.Class<?> wildcardClass29 = timeSeries18.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long32 = fixedMillisecond31.getMiddleMillisecond();
        java.util.Date date33 = fixedMillisecond31.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date33);
        long long35 = year34.getLastMillisecond();
        timeSeries18.setKey((java.lang.Comparable) year34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year34, 100.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year34, (java.lang.Number) (short) 1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = year34.equals((java.lang.Object) day43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year34.previous();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 28799999L + "'", long35 == 28799999L);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1969, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        int int7 = month6.getYearValue();
        java.lang.String str8 = month6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, 0.0d);
        timeSeries11.removeAgedItems((-1L), true);
        long long21 = timeSeries11.getMaximumItemAge();
        timeSeries11.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean25 = timeSeries24.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long28 = fixedMillisecond27.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 100.0f);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        timeSeries34.setKey((java.lang.Comparable) (-1.0f));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries34.removeChangeListener(seriesChangeListener38);
        java.lang.Object obj40 = timeSeries34.clone();
        boolean boolean41 = timeSeriesDataItem32.equals((java.lang.Object) timeSeries34);
        boolean boolean42 = month6.equals((java.lang.Object) timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long45 = fixedMillisecond44.getMiddleMillisecond();
        java.util.Date date46 = fixedMillisecond44.getEnd();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        long long48 = year47.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year47.previous();
        long long50 = year47.getSerialIndex();
        long long51 = year47.getMiddleMillisecond();
        boolean boolean52 = month6.equals((java.lang.Object) long51);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 35L + "'", long45 == 35L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 28799999L + "'", long48 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1969L + "'", long50 == 1969L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-15739200001L) + "'", long51 == (-15739200001L));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        int int3 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean6 = timeSeries5.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.removeChangeListener(seriesChangeListener12);
        timeSeries5.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timeSeries5.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        java.util.Date date20 = fixedMillisecond18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        long long22 = year21.getLastMillisecond();
        timeSeries5.setKey((java.lang.Comparable) year21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str26 = timeSeries25.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
        java.util.Calendar calendar33 = null;
        long long34 = fixedMillisecond28.getLastMillisecond(calendar33);
        long long35 = fixedMillisecond28.getSerialIndex();
        java.util.Calendar calendar36 = null;
        fixedMillisecond28.peg(calendar36);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 28799999L + "'", long22 == 28799999L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(5, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "May" + "'", str2.equals("May"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str5 = timeSeries4.getDomainDescription();
        int int6 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        timeSeries8.setKey((java.lang.Comparable) year24);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long32 = fixedMillisecond31.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond31.getLastMillisecond(calendar36);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond31.getLastMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-460));
        timeSeries1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str46 = timeSeries45.getDomainDescription();
        timeSeries45.setKey((java.lang.Comparable) (-1.0f));
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries45.addPropertyChangeListener(propertyChangeListener49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long53 = fixedMillisecond52.getFirstMillisecond();
        int int55 = fixedMillisecond52.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str58 = timeSeries57.getDomainDescription();
        int int59 = timeSeries57.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean62 = timeSeries61.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long65 = fixedMillisecond64.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener68 = null;
        timeSeries61.removeChangeListener(seriesChangeListener68);
        timeSeries61.setNotify(true);
        java.lang.Class<?> wildcardClass72 = timeSeries61.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long75 = fixedMillisecond74.getMiddleMillisecond();
        java.util.Date date76 = fixedMillisecond74.getEnd();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
        long long78 = year77.getLastMillisecond();
        timeSeries61.setKey((java.lang.Comparable) year77);
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str82 = timeSeries81.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long85 = fixedMillisecond84.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries81.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond84, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries57.createCopy((org.jfree.data.time.RegularTimePeriod) year77, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond84);
        java.util.Date date89 = year77.getEnd();
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, (org.jfree.data.time.RegularTimePeriod) year77);
        java.util.Date date91 = year77.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = year77.previous();
        timeSeries1.update(regularTimePeriod92, (java.lang.Number) 1561964399999L);
        java.lang.String str95 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 35L + "'", long39 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Time" + "'", str46.equals("Time"));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 35L + "'", long53 == 35L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Time" + "'", str58.equals("Time"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2147483647 + "'", int59 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 35L + "'", long65 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem67);
        org.junit.Assert.assertNotNull(wildcardClass72);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 35L + "'", long75 == 35L);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 28799999L + "'", long78 == 28799999L);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "Time" + "'", str82.equals("Time"));
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 35L + "'", long85 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem87);
        org.junit.Assert.assertNotNull(timeSeries88);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(timeSeries90);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(regularTimePeriod92);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str95.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int6 = spreadsheetDate4.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean17 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean24 = spreadsheetDate21.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        java.lang.String str25 = spreadsheetDate21.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean30 = spreadsheetDate21.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean31 = spreadsheetDate19.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean36 = spreadsheetDate33.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
        java.lang.String str37 = spreadsheetDate33.toString();
        boolean boolean38 = spreadsheetDate29.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean45 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        java.lang.String str46 = spreadsheetDate42.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean51 = spreadsheetDate42.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate48, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        boolean boolean52 = spreadsheetDate40.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean57 = spreadsheetDate54.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        java.lang.String str58 = spreadsheetDate54.toString();
        boolean boolean59 = spreadsheetDate50.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate54);
        boolean boolean61 = spreadsheetDate54.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long64 = fixedMillisecond63.getFirstMillisecond();
        int int66 = fixedMillisecond63.compareTo((java.lang.Object) 100L);
        java.util.Date date67 = fixedMillisecond63.getStart();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(date67);
        int int69 = spreadsheetDate54.compare(serialDate68);
        boolean boolean71 = spreadsheetDate14.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate29, serialDate68, 1927);
        int int72 = spreadsheetDate4.compareTo((java.lang.Object) spreadsheetDate29);
        int int73 = spreadsheetDate4.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate75 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate75);
        boolean boolean77 = spreadsheetDate4.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate75);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addDays((-1), (org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 0, serialDate78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-May-1927" + "'", str12.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "17-May-1927" + "'", str25.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "17-May-1927" + "'", str37.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "17-May-1927" + "'", str46.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "17-May-1927" + "'", str58.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 35L + "'", long64 == 35L);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-15569) + "'", int69 == (-15569));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 9999 + "'", int73 == 9999);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(serialDate78);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        java.lang.String str3 = day2.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) (-15739200001L));
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        int int9 = timeSeries7.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean12 = timeSeries11.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries11.removeChangeListener(seriesChangeListener18);
        timeSeries11.setNotify(true);
        java.lang.Class<?> wildcardClass22 = timeSeries11.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long25 = fixedMillisecond24.getMiddleMillisecond();
        java.util.Date date26 = fixedMillisecond24.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
        long long28 = year27.getLastMillisecond();
        timeSeries11.setKey((java.lang.Comparable) year27);
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str32 = timeSeries31.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long35 = fixedMillisecond34.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries31.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        int int39 = timeSeriesDataItem5.compareTo((java.lang.Object) year27);
        java.lang.Object obj40 = timeSeriesDataItem5.clone();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "17-May-1927" + "'", str3.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 35L + "'", long25 == 35L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 28799999L + "'", long28 == 28799999L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Time" + "'", str32.equals("Time"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(timeSeries38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(obj40);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 10);
        java.lang.Comparable comparable13 = null;
        try {
            timeSeries1.setKey(comparable13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        java.lang.Object obj7 = timeSeries1.clone();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean10 = timeSeries9.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long13 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 0.0d);
        timeSeries9.removeAgedItems((-1L), true);
        java.lang.Object obj19 = timeSeries9.clone();
        timeSeries9.clear();
        timeSeries9.clear();
        boolean boolean22 = timeSeries9.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 35L + "'", long13 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int6 = spreadsheetDate5.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate9.getMonth();
        boolean boolean12 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate5, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1927 + "'", int6 == 1927);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        java.util.List list20 = timeSeries1.getItems();
        java.lang.Object obj21 = timeSeries1.clone();
        timeSeries1.setRangeDescription("October");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean23 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.lang.String str24 = spreadsheetDate20.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean29 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean30 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean35 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        java.lang.String str36 = spreadsheetDate32.toString();
        boolean boolean37 = spreadsheetDate28.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean39 = spreadsheetDate32.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean41 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int42 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean50 = spreadsheetDate47.isOn((org.jfree.data.time.SerialDate) spreadsheetDate49);
        java.lang.String str51 = spreadsheetDate47.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean56 = spreadsheetDate47.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate53, (org.jfree.data.time.SerialDate) spreadsheetDate55);
        boolean boolean57 = spreadsheetDate45.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long60 = fixedMillisecond59.getFirstMillisecond();
        int int62 = fixedMillisecond59.compareTo((java.lang.Object) 100L);
        java.util.Date date63 = fixedMillisecond59.getStart();
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(date63);
        int int65 = spreadsheetDate55.compare(serialDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long72 = fixedMillisecond71.getMiddleMillisecond();
        java.util.Date date73 = fixedMillisecond71.getEnd();
        java.util.Date date74 = fixedMillisecond71.getStart();
        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date74);
        boolean boolean76 = spreadsheetDate68.isOnOrBefore(serialDate75);
        org.jfree.data.time.SerialDate serialDate77 = spreadsheetDate55.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate68);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addYears((int) (short) -1, serialDate77);
        int int79 = spreadsheetDate7.compare(serialDate78);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "17-May-1927" + "'", str24.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "17-May-1927" + "'", str36.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "17-May-1927" + "'", str51.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 35L + "'", long60 == 35L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-15569) + "'", int65 == (-15569));
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 35L + "'", long72 == 35L);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 351 + "'", int79 == 351);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long7 = fixedMillisecond6.getMiddleMillisecond();
        java.util.Date date8 = fixedMillisecond6.getEnd();
        java.util.Date date9 = fixedMillisecond6.getStart();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.Year year12 = month11.getYear();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str15 = timeSeries14.getDomainDescription();
        timeSeries14.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries14.removePropertyChangeListener(propertyChangeListener19);
        boolean boolean21 = month11.equals((java.lang.Object) timeSeries14);
        java.util.Date date22 = month11.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date22, timeZone24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long28 = fixedMillisecond27.getMiddleMillisecond();
        java.util.Date date29 = fixedMillisecond27.getEnd();
        java.util.Date date30 = fixedMillisecond27.getStart();
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.Year year33 = month32.getYear();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str36 = timeSeries35.getDomainDescription();
        timeSeries35.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class39 = timeSeries35.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timeSeries35.removePropertyChangeListener(propertyChangeListener40);
        boolean boolean42 = month32.equals((java.lang.Object) timeSeries35);
        java.util.Date date43 = month32.getEnd();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date43, timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date22, timeZone45);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date4, timeZone45);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(year12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(year33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Time" + "'", str36.equals("Time"));
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        long long13 = timeSeries1.getMaximumItemAge();
        java.lang.String str14 = timeSeries1.getDescription();
        java.util.Collection collection15 = timeSeries1.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long18 = fixedMillisecond17.getMiddleMillisecond();
        java.util.Date date19 = fixedMillisecond17.getEnd();
        java.util.Date date20 = fixedMillisecond17.getStart();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        org.jfree.data.time.Year year23 = month22.getYear();
        long long24 = month22.getSerialIndex();
        long long25 = month22.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 10.0f);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean39 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.lang.String str40 = spreadsheetDate36.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean45 = spreadsheetDate36.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate42, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean46 = spreadsheetDate34.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean51 = spreadsheetDate48.isOn((org.jfree.data.time.SerialDate) spreadsheetDate50);
        java.lang.String str52 = spreadsheetDate48.toString();
        boolean boolean53 = spreadsheetDate44.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean55 = spreadsheetDate48.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean57 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate48);
        boolean boolean58 = timeSeriesDataItem27.equals((java.lang.Object) boolean57);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 35L + "'", long18 == 35L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 23640L + "'", long24 == 23640L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 23640L + "'", long25 == 23640L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "17-May-1927" + "'", str40.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "17-May-1927" + "'", str52.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str5 = timeSeries4.getDomainDescription();
        int int6 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        timeSeries8.setKey((java.lang.Comparable) year24);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long32 = fixedMillisecond31.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond31.getLastMillisecond(calendar36);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond31.getLastMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-460));
        java.util.Calendar calendar42 = null;
        long long43 = fixedMillisecond31.getMiddleMillisecond(calendar42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 35L + "'", long39 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 35L + "'", long43 == 35L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getYear();
        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
        java.util.Calendar calendar9 = null;
        try {
            day6.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getFirstMillisecond();
        int int9 = day6.compareTo((java.lang.Object) 2958465);
        java.lang.String str10 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-57600000L) + "'", long7 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        java.lang.Class class12 = timeSeries1.getTimePeriodClass();
        java.lang.String str13 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("ThreadContext");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str18 = timeSeries17.getDomainDescription();
        int int19 = timeSeries17.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean22 = timeSeries21.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long25 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries21.removeChangeListener(seriesChangeListener28);
        timeSeries21.setNotify(true);
        java.lang.Class<?> wildcardClass32 = timeSeries21.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long35 = fixedMillisecond34.getMiddleMillisecond();
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        long long38 = year37.getLastMillisecond();
        timeSeries21.setKey((java.lang.Comparable) year37);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str42 = timeSeries41.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long45 = fixedMillisecond44.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries41.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) year37, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
        java.util.Date date49 = year37.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date49);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year50, (java.lang.Number) 1.0d, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 35L + "'", long25 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28799999L + "'", long38 == 28799999L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Time" + "'", str42.equals("Time"));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 35L + "'", long45 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, "", "ClassContext", (java.lang.Class) wildcardClass19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (double) '4');
        java.lang.String str23 = day4.toString();
        int int24 = day4.getMonth();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "17-May-1927" + "'", str23.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("ClassContext");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        java.lang.String str8 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ClassContext" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: ClassContext"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        long long17 = month6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month6.next();
        long long19 = month6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2649600000L) + "'", long17 == (-2649600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-2649600000L) + "'", long19 == (-2649600000L));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean7 = timeSeries6.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long10 = fixedMillisecond9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries6.removeChangeListener(seriesChangeListener13);
        timeSeries6.setNotify(true);
        java.lang.Class<?> wildcardClass17 = timeSeries6.getClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getMiddleMillisecond();
        java.util.Date date22 = fixedMillisecond20.getEnd();
        java.util.Date date23 = fixedMillisecond20.getStart();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date23, timeZone25);
        java.lang.Object obj27 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("1969", (java.lang.Class) wildcardClass17);
        java.net.URL uRL28 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNull(obj27);
        org.junit.Assert.assertNotNull(uRL28);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timeSeries1.getDomainDescription();
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        java.util.Date date20 = fixedMillisecond18.getEnd();
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        long long23 = fixedMillisecond14.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35L + "'", long23 == 35L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) fixedMillisecond4);
        long long9 = fixedMillisecond4.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long16 = fixedMillisecond15.getFirstMillisecond();
        int int18 = fixedMillisecond15.compareTo((java.lang.Object) 100L);
        java.util.Date date19 = fixedMillisecond15.getStart();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date19);
        int int21 = spreadsheetDate11.compare(serialDate20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate11);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day22.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-15569) + "'", int21 == (-15569));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean6 = timeSeries5.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.removeChangeListener(seriesChangeListener12);
        timeSeries5.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timeSeries5.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 30, (java.lang.Class) wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class18);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 1, 6, (-15569));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.removeAgedItems((long) 2147483647, false);
        timeSeries1.setMaximumItemCount(6);
        java.lang.Class class10 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Year year20 = month19.getYear();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str23 = timeSeries22.getDomainDescription();
        timeSeries22.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class26 = timeSeries22.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener27);
        boolean boolean29 = month19.equals((java.lang.Object) timeSeries22);
        java.util.Date date30 = month19.getEnd();
        org.jfree.data.time.Year year31 = month19.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long34 = fixedMillisecond33.getMiddleMillisecond();
        java.util.Date date35 = fixedMillisecond33.getEnd();
        java.util.Date date36 = fixedMillisecond33.getStart();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36);
        org.jfree.data.time.Year year39 = month38.getYear();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str42 = timeSeries41.getDomainDescription();
        timeSeries41.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class45 = timeSeries41.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries41.removePropertyChangeListener(propertyChangeListener46);
        boolean boolean48 = month38.equals((java.lang.Object) timeSeries41);
        java.util.Date date49 = month38.getEnd();
        org.jfree.data.time.Year year50 = month38.getYear();
        java.lang.String str51 = year50.toString();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year50);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        int int54 = month53.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month53.previous();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) (-9999));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Time" + "'", str42.equals("Time"));
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1969" + "'", str51.equals("1969"));
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean7 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean13 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean19 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.lang.String str20 = spreadsheetDate16.toString();
        boolean boolean21 = spreadsheetDate12.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.lang.String str22 = spreadsheetDate16.toString();
        boolean boolean23 = year0.equals((java.lang.Object) str22);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "17-May-1927" + "'", str8.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "17-May-1927" + "'", str20.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "17-May-1927" + "'", str22.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 0L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str13 = day12.toString();
        int int14 = day12.getMonth();
        int int15 = day12.getMonth();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 1L);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener18);
        java.lang.String str20 = timeSeries1.getDomainDescription();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeries1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "17-May-1927" + "'", str13.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
        int int9 = day6.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1969 + "'", int9 == 1969);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        timeSeries1.setMaximumItemAge((long) 1927);
        java.lang.String str14 = timeSeries1.getRangeDescription();
        timeSeries1.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        int int3 = timeSeries1.getMaximumItemCount();
        long long4 = timeSeries1.getMaximumItemAge();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean17 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        int int23 = fixedMillisecond20.compareTo((java.lang.Object) 100L);
        java.util.Date date24 = fixedMillisecond20.getStart();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        int int26 = spreadsheetDate16.compare(serialDate25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        long long28 = day27.getFirstMillisecond();
        java.lang.Number number29 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-May-1927" + "'", str12.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-15569) + "'", int26 == (-15569));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1345219200000L) + "'", long28 == (-1345219200000L));
        org.junit.Assert.assertNull(number29);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("December 1969");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean4 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long7 = fixedMillisecond6.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        timeSeries3.setNotify(true);
        java.lang.Class<?> wildcardClass14 = timeSeries3.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long17 = fixedMillisecond16.getMiddleMillisecond();
        java.util.Date date18 = fixedMillisecond16.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        long long20 = year19.getLastMillisecond();
        timeSeries3.setKey((java.lang.Comparable) year19);
        java.lang.String str22 = year19.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException24 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException24.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        int int28 = year19.compareTo((java.lang.Object) timePeriodFormatException26);
        java.lang.Throwable[] throwableArray29 = timePeriodFormatException26.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        java.lang.Throwable[] throwableArray31 = timePeriodFormatException26.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28799999L + "'", long20 == 28799999L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "1969" + "'", str22.equals("1969"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean24 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean30 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = spreadsheetDate27.toString();
        boolean boolean32 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int33 = spreadsheetDate23.getDayOfMonth();
        boolean boolean34 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long38 = fixedMillisecond37.getMiddleMillisecond();
        java.util.Date date39 = fixedMillisecond37.getEnd();
        java.util.Date date40 = fixedMillisecond37.getStart();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.Year year43 = month42.getYear();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str46 = timeSeries45.getDomainDescription();
        timeSeries45.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class49 = timeSeries45.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries45.removePropertyChangeListener(propertyChangeListener50);
        boolean boolean52 = month42.equals((java.lang.Object) timeSeries45);
        java.util.Date date53 = month42.getEnd();
        org.jfree.data.time.Year year54 = month42.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long57 = fixedMillisecond56.getFirstMillisecond();
        int int59 = fixedMillisecond56.compareTo((java.lang.Object) 100L);
        java.util.Date date60 = fixedMillisecond56.getStart();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance(date60);
        boolean boolean63 = month42.equals((java.lang.Object) serialDate62);
        boolean boolean64 = spreadsheetDate23.isOn(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "17-May-1927" + "'", str31.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 17 + "'", int33 == 17);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 35L + "'", long38 == 35L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(year43);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Time" + "'", str46.equals("Time"));
        org.junit.Assert.assertNotNull(class49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 35L + "'", long57 == 35L);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.setMaximumItemAge((long) 3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.lang.String str3 = fixedMillisecond1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str11 = spreadsheetDate7.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean16 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        boolean boolean17 = spreadsheetDate5.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean22 = spreadsheetDate19.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.String str23 = spreadsheetDate19.toString();
        boolean boolean24 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        boolean boolean26 = spreadsheetDate19.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getFirstMillisecond();
        int int31 = fixedMillisecond28.compareTo((java.lang.Object) 100L);
        java.util.Date date32 = fixedMillisecond28.getStart();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(date32);
        int int34 = spreadsheetDate19.compare(serialDate33);
        serialDate33.setDescription("Nearest");
        boolean boolean37 = fixedMillisecond1.equals((java.lang.Object) serialDate33);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str3.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "17-May-1927" + "'", str11.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "17-May-1927" + "'", str23.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-15569) + "'", int34 == (-15569));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("31-December-1969", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        timeSeries1.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        java.lang.Class class20 = timeSeries1.getTimePeriodClass();
        java.lang.ClassLoader classLoader21 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class20);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader21);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader21);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(classLoader21);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.Comparable comparable0 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str5 = timeSeries4.getDomainDescription();
        timeSeries4.setKey((java.lang.Comparable) (-1.0f));
        boolean boolean9 = timeSeries4.equals((java.lang.Object) false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries4.removeChangeListener(seriesChangeListener10);
        java.lang.Class class12 = timeSeries4.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries(comparable0, "hi!", "org.jfree.data.general.SeriesChangeEvent[source=100]", class12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        timeSeries4.setNotify(true);
        java.lang.Class<?> wildcardClass15 = timeSeries4.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        java.util.Date date20 = fixedMillisecond18.getEnd();
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(date21);
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date21, timeZone23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date21);
        int int26 = month25.getYearValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        java.lang.Object obj4 = null;
        boolean boolean5 = spreadsheetDate2.equals(obj4);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        int int7 = month6.getYearValue();
        java.lang.String str8 = month6.toString();
        long long9 = month6.getLastMillisecond();
        org.jfree.data.time.Year year10 = month6.getYear();
        long long11 = year10.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "December 1969" + "'", str8.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-31507200000L) + "'", long11 == (-31507200000L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
        java.lang.String str9 = serialDate8.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31-December-1969" + "'", str9.equals("31-December-1969"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        java.util.Date date17 = month6.getEnd();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = month6.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        java.lang.Class class12 = timeSeries1.getTimePeriodClass();
        java.lang.String str13 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean16 = timeSeries15.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long19 = fixedMillisecond18.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries15.removeChangeListener(seriesChangeListener22);
        timeSeries15.setNotify(true);
        java.lang.Class<?> wildcardClass26 = timeSeries15.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        java.util.Date date30 = fixedMillisecond28.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        long long32 = year31.getLastMillisecond();
        timeSeries15.setKey((java.lang.Comparable) year31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long36 = fixedMillisecond35.getMiddleMillisecond();
        java.util.Date date37 = fixedMillisecond35.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        boolean boolean40 = year38.equals((java.lang.Object) (short) -1);
        boolean boolean41 = year31.equals((java.lang.Object) (short) -1);
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year31);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str45 = timeSeries44.getDomainDescription();
        boolean boolean46 = timeSeries44.isEmpty();
        java.lang.Object obj47 = timeSeries44.clone();
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries44.addPropertyChangeListener(propertyChangeListener48);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean52 = timeSeries51.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long55 = fixedMillisecond54.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
        timeSeries51.removeChangeListener(seriesChangeListener58);
        timeSeries51.setNotify(true);
        java.lang.Class<?> wildcardClass62 = timeSeries51.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long65 = fixedMillisecond64.getMiddleMillisecond();
        java.util.Date date66 = fixedMillisecond64.getEnd();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date66);
        long long68 = year67.getLastMillisecond();
        timeSeries51.setKey((java.lang.Comparable) year67);
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long72 = fixedMillisecond71.getFirstMillisecond();
        int int74 = fixedMillisecond71.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (java.lang.Number) (-1));
        boolean boolean77 = year67.equals((java.lang.Object) fixedMillisecond71);
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long80 = fixedMillisecond79.getMiddleMillisecond();
        java.util.Date date81 = fixedMillisecond79.getEnd();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date81);
        long long83 = year82.getLastMillisecond();
        long long84 = year82.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, (org.jfree.data.time.RegularTimePeriod) year82);
        org.jfree.data.time.TimeSeries timeSeries86 = timeSeries1.addAndOrUpdate(timeSeries44);
        org.jfree.data.time.TimeSeries timeSeries88 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean89 = timeSeries88.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener90 = null;
        timeSeries88.addPropertyChangeListener(propertyChangeListener90);
        java.util.Collection collection92 = timeSeries44.getTimePeriodsUniqueToOtherSeries(timeSeries88);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 35L + "'", long19 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28799999L + "'", long32 == 28799999L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 35L + "'", long36 == 35L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Time" + "'", str45.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 35L + "'", long55 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem57);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 35L + "'", long65 == 35L);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 28799999L + "'", long68 == 28799999L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 35L + "'", long72 == 35L);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 35L + "'", long80 == 35L);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 28799999L + "'", long83 == 28799999L);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 28799999L + "'", long84 == 28799999L);
        org.junit.Assert.assertNotNull(timeSeries85);
        org.junit.Assert.assertNotNull(timeSeries86);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(collection92);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1561964399999L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries1.removeChangeListener(seriesChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) (short) 0);
        timeSeries1.clear();
        timeSeries1.setDomainDescription("January");
        timeSeries1.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        boolean boolean3 = timeSeries1.isEmpty();
        java.lang.Object obj4 = timeSeries1.clone();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        timeSeries8.setKey((java.lang.Comparable) year24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getFirstMillisecond();
        int int31 = fixedMillisecond28.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (-1));
        boolean boolean34 = year24.equals((java.lang.Object) fixedMillisecond28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long37 = fixedMillisecond36.getMiddleMillisecond();
        java.util.Date date38 = fixedMillisecond36.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        long long40 = year39.getLastMillisecond();
        long long41 = year39.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) year39);
        boolean boolean43 = timeSeries42.getNotify();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 28799999L + "'", long40 == 28799999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        long long17 = month6.getFirstMillisecond();
        long long18 = month6.getSerialIndex();
        org.jfree.data.time.Year year19 = month6.getYear();
        long long20 = year19.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2649600000L) + "'", long17 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 23640L + "'", long18 == 23640L);
        org.junit.Assert.assertNotNull(year19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1969L + "'", long20 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 10);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond7.getMiddleMillisecond(calendar13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean24 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate13.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean30 = spreadsheetDate27.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.String str31 = spreadsheetDate27.toString();
        boolean boolean32 = spreadsheetDate23.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate27);
        int int33 = spreadsheetDate23.getDayOfMonth();
        boolean boolean34 = spreadsheetDate7.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean39 = spreadsheetDate36.isOn((org.jfree.data.time.SerialDate) spreadsheetDate38);
        java.lang.String str40 = spreadsheetDate36.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean45 = spreadsheetDate42.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        int int46 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate42);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean53 = spreadsheetDate50.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        java.lang.String str54 = spreadsheetDate50.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean59 = spreadsheetDate50.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate56, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        boolean boolean60 = spreadsheetDate48.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean65 = spreadsheetDate62.isOn((org.jfree.data.time.SerialDate) spreadsheetDate64);
        java.lang.String str66 = spreadsheetDate62.toString();
        boolean boolean67 = spreadsheetDate58.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate62);
        int int68 = spreadsheetDate58.getDayOfMonth();
        boolean boolean69 = spreadsheetDate42.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate58);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int71 = day70.getMonth();
        boolean boolean72 = spreadsheetDate23.equals((java.lang.Object) day70);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean79 = spreadsheetDate76.isOn((org.jfree.data.time.SerialDate) spreadsheetDate78);
        java.lang.String str80 = spreadsheetDate76.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate84 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean85 = spreadsheetDate76.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate82, (org.jfree.data.time.SerialDate) spreadsheetDate84);
        boolean boolean86 = spreadsheetDate74.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate84);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate88 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate90 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean91 = spreadsheetDate88.isOn((org.jfree.data.time.SerialDate) spreadsheetDate90);
        java.lang.String str92 = spreadsheetDate88.toString();
        boolean boolean93 = spreadsheetDate84.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate88);
        boolean boolean95 = spreadsheetDate88.equals((java.lang.Object) (short) 10);
        spreadsheetDate88.setDescription("17-May-1927");
        boolean boolean98 = day70.equals((java.lang.Object) spreadsheetDate88);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "17-May-1927" + "'", str31.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 17 + "'", int33 == 17);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "17-May-1927" + "'", str40.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "17-May-1927" + "'", str54.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "17-May-1927" + "'", str66.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 17 + "'", int68 == 17);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 5 + "'", int71 == 5);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "17-May-1927" + "'", str80.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "17-May-1927" + "'", str92.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond4.previous();
        java.util.Calendar calendar9 = null;
        fixedMillisecond4.peg(calendar9);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean13 = timeSeries12.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long16 = fixedMillisecond15.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries12.removeChangeListener(seriesChangeListener19);
        timeSeries12.setNotify(true);
        java.lang.Class<?> wildcardClass23 = timeSeries12.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long26 = fixedMillisecond25.getMiddleMillisecond();
        java.util.Date date27 = fixedMillisecond25.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        long long29 = year28.getLastMillisecond();
        timeSeries12.setKey((java.lang.Comparable) year28);
        java.lang.String str31 = year28.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException35);
        int int37 = year28.compareTo((java.lang.Object) timePeriodFormatException35);
        boolean boolean38 = fixedMillisecond4.equals((java.lang.Object) int37);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28799999L + "'", long29 == 28799999L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        java.lang.String str3 = timeSeries1.getDomainDescription();
        java.lang.String str4 = timeSeries1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = day7.toString();
        long long9 = day7.getSerialIndex();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2);
        java.util.Calendar calendar12 = null;
        try {
            day7.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Time" + "'", str3.equals("Time"));
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "17-May-1927" + "'", str8.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9999L + "'", long9 == 9999L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean24 = spreadsheetDate15.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate21, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        boolean boolean25 = spreadsheetDate11.isOn((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate7, (org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate9.toSerial();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean19 = spreadsheetDate16.isOn((org.jfree.data.time.SerialDate) spreadsheetDate18);
        java.lang.String str20 = spreadsheetDate16.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean25 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate22, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate14.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean31 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate30);
        java.lang.String str32 = spreadsheetDate28.toString();
        boolean boolean33 = spreadsheetDate24.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate28);
        int int34 = spreadsheetDate9.compare((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long37 = fixedMillisecond36.getFirstMillisecond();
        int int39 = fixedMillisecond36.compareTo((java.lang.Object) 100L);
        java.util.Date date40 = fixedMillisecond36.getStart();
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(date40);
        boolean boolean42 = spreadsheetDate9.isBefore(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9999 + "'", int11 == 9999);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "17-May-1927" + "'", str20.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "17-May-1927" + "'", str32.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean9 = spreadsheetDate6.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        java.lang.String str10 = spreadsheetDate6.toString();
        org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.util.Date date12 = spreadsheetDate6.toDate();
        int int13 = spreadsheetDate6.getYYYY();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17-May-1927" + "'", str10.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1927 + "'", int13 == 1927);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean17 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        int int23 = fixedMillisecond20.compareTo((java.lang.Object) 100L);
        java.util.Date date24 = fixedMillisecond20.getStart();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        int int26 = spreadsheetDate16.compare(serialDate25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean34 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.lang.String str35 = spreadsheetDate31.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean40 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean41 = spreadsheetDate29.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean46 = spreadsheetDate43.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
        java.lang.String str47 = spreadsheetDate43.toString();
        boolean boolean48 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean50 = spreadsheetDate43.equals((java.lang.Object) (short) 10);
        boolean boolean51 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean57 = spreadsheetDate54.isOn((org.jfree.data.time.SerialDate) spreadsheetDate56);
        java.lang.String str58 = spreadsheetDate54.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean63 = spreadsheetDate60.isOn((org.jfree.data.time.SerialDate) spreadsheetDate62);
        int int64 = spreadsheetDate54.compare((org.jfree.data.time.SerialDate) spreadsheetDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate66 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate70 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean71 = spreadsheetDate68.isOn((org.jfree.data.time.SerialDate) spreadsheetDate70);
        java.lang.String str72 = spreadsheetDate68.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate76 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean77 = spreadsheetDate68.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate74, (org.jfree.data.time.SerialDate) spreadsheetDate76);
        boolean boolean78 = spreadsheetDate66.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate80 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate82 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean83 = spreadsheetDate80.isOn((org.jfree.data.time.SerialDate) spreadsheetDate82);
        java.lang.String str84 = spreadsheetDate80.toString();
        boolean boolean85 = spreadsheetDate76.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate80);
        int int86 = spreadsheetDate76.getDayOfMonth();
        boolean boolean87 = spreadsheetDate60.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.jfree.data.time.Day day88 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate76);
        int int89 = spreadsheetDate43.compare((org.jfree.data.time.SerialDate) spreadsheetDate76);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-May-1927" + "'", str12.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-15569) + "'", int26 == (-15569));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "17-May-1927" + "'", str35.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "17-May-1927" + "'", str47.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "17-May-1927" + "'", str58.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "17-May-1927" + "'", str72.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "17-May-1927" + "'", str84.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 17 + "'", int86 == 17);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4);
        long long8 = day7.getSerialIndex();
        long long9 = day7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 25568L + "'", long8 == 25568L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 25568L + "'", long9 == 25568L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=100]");
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        long long17 = month6.getFirstMillisecond();
        java.lang.String str18 = month6.toString();
        java.lang.Class<?> wildcardClass19 = month6.getClass();
        org.jfree.data.time.Year year20 = month6.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-2649600000L) + "'", long17 == (-2649600000L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "December 1969" + "'", str18.equals("December 1969"));
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(year20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean6 = timeSeries5.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries5.removeChangeListener(seriesChangeListener12);
        timeSeries5.setNotify(true);
        java.lang.Class<?> wildcardClass16 = timeSeries5.getClass();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass16);
        java.lang.Class class18 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        java.io.InputStream inputStream20 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.time.TimePeriodFormatException: ClassContext", (java.lang.Class) wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNull(inputStream20);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((-15569));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str10 = timeSeries9.getDomainDescription();
        timeSeries9.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class13 = timeSeries9.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = month6.equals((java.lang.Object) timeSeries9);
        java.util.Date date17 = month6.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long23 = fixedMillisecond22.getMiddleMillisecond();
        java.util.Date date24 = fixedMillisecond22.getEnd();
        java.util.Date date25 = fixedMillisecond22.getStart();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.Year year28 = month27.getYear();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str31 = timeSeries30.getDomainDescription();
        timeSeries30.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class34 = timeSeries30.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries30.removePropertyChangeListener(propertyChangeListener35);
        boolean boolean37 = month27.equals((java.lang.Object) timeSeries30);
        java.util.Date date38 = month27.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date38, timeZone40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date17, timeZone40);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35L + "'", long23 == 35L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Time" + "'", str31.equals("Time"));
        org.junit.Assert.assertNotNull(class34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(serialDate43);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        java.lang.Class class12 = timeSeries1.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries1.removeChangeListener(seriesChangeListener13);
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        int int4 = fixedMillisecond1.compareTo((java.lang.Object) 100L);
        java.util.Date date5 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        int int7 = day6.getMonth();
        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str6 = timeSeries5.getDomainDescription();
        timeSeries5.setKey((java.lang.Comparable) (-1.0f));
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.removeChangeListener(seriesChangeListener9);
        java.lang.Object obj11 = timeSeries5.clone();
        int int12 = fixedMillisecond1.compareTo(obj11);
        java.util.Calendar calendar13 = null;
        fixedMillisecond1.peg(calendar13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 10);
        java.lang.String str13 = timeSeries1.getDescription();
        java.lang.Object obj14 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        timeSeries4.setNotify(true);
        java.lang.Class<?> wildcardClass15 = timeSeries4.getClass();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9223372036854775807L, "Time", "1969", (java.lang.Class) wildcardClass15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond((long) '#');
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 0.0f);
        java.lang.Object obj21 = timeSeriesDataItem20.clone();
        boolean boolean23 = timeSeriesDataItem20.equals((java.lang.Object) 10.0f);
        try {
            timeSeries16.add(timeSeriesDataItem20, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.TimeSeries.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getFirstMillisecond();
        java.util.Date date16 = fixedMillisecond14.getTime();
        timeSeries1.setKey((java.lang.Comparable) fixedMillisecond14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) 0L);
        java.lang.Number number20 = null;
        timeSeriesDataItem19.setValue(number20);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean24 = timeSeries23.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long27 = fixedMillisecond26.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, 0.0d);
        timeSeries23.removeAgedItems((-1L), true);
        long long33 = timeSeries23.getMaximumItemAge();
        timeSeries23.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean37 = timeSeries36.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long40 = fixedMillisecond39.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 0.0d);
        timeSeries36.removeAgedItems((-1L), true);
        long long46 = timeSeries36.getMaximumItemAge();
        timeSeries36.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str51 = timeSeries50.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timeSeries50.addPropertyChangeListener(propertyChangeListener52);
        java.util.Collection collection54 = timeSeries36.getTimePeriodsUniqueToOtherSeries(timeSeries50);
        java.lang.Class class55 = timeSeries36.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long58 = fixedMillisecond57.getMiddleMillisecond();
        java.util.Date date59 = fixedMillisecond57.getEnd();
        java.util.Date date60 = fixedMillisecond57.getStart();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance(date60);
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date60);
        org.jfree.data.time.Year year63 = month62.getYear();
        org.jfree.data.time.Year year64 = month62.getYear();
        timeSeries36.setKey((java.lang.Comparable) year64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year64, (java.lang.Number) 100.0d);
        boolean boolean68 = timeSeriesDataItem19.equals((java.lang.Object) timeSeriesDataItem67);
        timeSeriesDataItem19.setValue((java.lang.Number) 12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 35L + "'", long27 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 35L + "'", long40 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(class55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 35L + "'", long58 == 35L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(year63);
        org.junit.Assert.assertNotNull(year64);
        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int11 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean23 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.lang.String str24 = spreadsheetDate20.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean29 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean30 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean35 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        java.lang.String str36 = spreadsheetDate32.toString();
        boolean boolean37 = spreadsheetDate28.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean39 = spreadsheetDate32.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate32);
        boolean boolean41 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate32);
        int int42 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long51 = fixedMillisecond50.getMiddleMillisecond();
        java.util.Date date52 = fixedMillisecond50.getEnd();
        java.util.Date date53 = fixedMillisecond50.getStart();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(date53);
        boolean boolean55 = spreadsheetDate47.isOnOrBefore(serialDate54);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate59 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int60 = spreadsheetDate58.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean65 = spreadsheetDate62.isOn((org.jfree.data.time.SerialDate) spreadsheetDate64);
        java.lang.String str66 = spreadsheetDate62.toString();
        org.jfree.data.time.SerialDate serialDate67 = spreadsheetDate58.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate62);
        int int68 = spreadsheetDate58.getDayOfWeek();
        boolean boolean69 = spreadsheetDate44.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        boolean boolean70 = spreadsheetDate7.isAfter(serialDate54);
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long74 = fixedMillisecond73.getFirstMillisecond();
        int int76 = fixedMillisecond73.compareTo((java.lang.Object) 100L);
        java.util.Date date77 = fixedMillisecond73.getStart();
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance(date77);
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, serialDate78);
        boolean boolean80 = spreadsheetDate7.isOnOrAfter(serialDate79);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "17-May-1927" + "'", str24.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "17-May-1927" + "'", str36.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 35L + "'", long51 == 35L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5 + "'", int60 == 5);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "17-May-1927" + "'", str66.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 35L + "'", long74 == 35L);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        int int8 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) (short) -1);
        java.lang.String str23 = year17.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1969" + "'", str23.equals("1969"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean7 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean8 = spreadsheetDate1.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        java.lang.String str20 = year17.toString();
        java.util.Date date21 = year17.getEnd();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
        long long24 = year23.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28799999L + "'", long24 == 28799999L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        boolean boolean6 = timeSeries1.equals((java.lang.Object) false);
        timeSeries1.setRangeDescription("ThreadContext");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getFirstMillisecond();
        java.util.Date date3 = fixedMillisecond1.getTime();
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 35L + "'", long6 == 35L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean11 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str12 = spreadsheetDate8.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean17 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate6.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        int int23 = fixedMillisecond20.compareTo((java.lang.Object) 100L);
        java.util.Date date24 = fixedMillisecond20.getStart();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        int int26 = spreadsheetDate16.compare(serialDate25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean34 = spreadsheetDate31.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        java.lang.String str35 = spreadsheetDate31.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean40 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate37, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean41 = spreadsheetDate29.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean46 = spreadsheetDate43.isOn((org.jfree.data.time.SerialDate) spreadsheetDate45);
        java.lang.String str47 = spreadsheetDate43.toString();
        boolean boolean48 = spreadsheetDate39.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        boolean boolean50 = spreadsheetDate43.equals((java.lang.Object) (short) 10);
        boolean boolean51 = spreadsheetDate16.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate43);
        org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate43);
        try {
            org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate2.getPreviousDayOfWeek(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "17-May-1927" + "'", str12.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-15569) + "'", int26 == (-15569));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "17-May-1927" + "'", str35.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "17-May-1927" + "'", str47.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(serialDate52);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str5 = timeSeries4.getDomainDescription();
        int int6 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean9 = timeSeries8.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long12 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries8.removeChangeListener(seriesChangeListener15);
        timeSeries8.setNotify(true);
        java.lang.Class<?> wildcardClass19 = timeSeries8.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        java.util.Date date23 = fixedMillisecond21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        long long25 = year24.getLastMillisecond();
        timeSeries8.setKey((java.lang.Comparable) year24);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long32 = fixedMillisecond31.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) year24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Calendar calendar36 = null;
        long long37 = fixedMillisecond31.getLastMillisecond(calendar36);
        java.util.Calendar calendar38 = null;
        long long39 = fixedMillisecond31.getLastMillisecond(calendar38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) (-460));
        java.util.Calendar calendar42 = null;
        fixedMillisecond31.peg(calendar42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 35L + "'", long32 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 35L + "'", long37 == 35L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 35L + "'", long39 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean7 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate6);
        java.lang.String str8 = spreadsheetDate4.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean13 = spreadsheetDate4.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long17 = fixedMillisecond16.getFirstMillisecond();
        int int19 = fixedMillisecond16.compareTo((java.lang.Object) 100L);
        java.util.Date date20 = fixedMillisecond16.getStart();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
        int int22 = spreadsheetDate12.compare(serialDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long29 = fixedMillisecond28.getMiddleMillisecond();
        java.util.Date date30 = fixedMillisecond28.getEnd();
        java.util.Date date31 = fixedMillisecond28.getStart();
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date31);
        boolean boolean33 = spreadsheetDate25.isOnOrBefore(serialDate32);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        int int35 = spreadsheetDate12.getMonth();
        java.lang.String str36 = spreadsheetDate12.toString();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addDays(1969, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "17-May-1927" + "'", str8.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-15569) + "'", int22 == (-15569));
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 35L + "'", long29 == 35L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 5 + "'", int35 == 5);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "17-May-1927" + "'", str36.equals("17-May-1927"));
        org.junit.Assert.assertNotNull(serialDate37);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean5 = timeSeries4.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long8 = fixedMillisecond7.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 10);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str15 = timeSeries14.getDomainDescription();
        boolean boolean16 = timeSeries14.isEmpty();
        java.lang.Object obj17 = timeSeries14.clone();
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean22 = timeSeries21.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long25 = fixedMillisecond24.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries21.removeChangeListener(seriesChangeListener28);
        timeSeries21.setNotify(true);
        java.lang.Class<?> wildcardClass32 = timeSeries21.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long35 = fixedMillisecond34.getMiddleMillisecond();
        java.util.Date date36 = fixedMillisecond34.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        long long38 = year37.getLastMillisecond();
        timeSeries21.setKey((java.lang.Comparable) year37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long42 = fixedMillisecond41.getFirstMillisecond();
        int int44 = fixedMillisecond41.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) (-1));
        boolean boolean47 = year37.equals((java.lang.Object) fixedMillisecond41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long50 = fixedMillisecond49.getMiddleMillisecond();
        java.util.Date date51 = fixedMillisecond49.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
        long long53 = year52.getLastMillisecond();
        long long54 = year52.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) year52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long58 = fixedMillisecond57.getFirstMillisecond();
        int int60 = fixedMillisecond57.compareTo((java.lang.Object) 100L);
        java.util.Date date61 = fixedMillisecond57.getStart();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        int int63 = day62.getYear();
        java.lang.Number number64 = timeSeries55.getValue((org.jfree.data.time.RegularTimePeriod) day62);
        java.lang.String str65 = timeSeries55.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries1.addAndOrUpdate(timeSeries55);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 35L + "'", long25 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 35L + "'", long35 == 35L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28799999L + "'", long38 == 28799999L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 35L + "'", long50 == 35L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 28799999L + "'", long53 == 28799999L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 28799999L + "'", long54 == 28799999L);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 35L + "'", long58 == 35L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1969 + "'", int63 == 1969);
        org.junit.Assert.assertNull(number64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Time" + "'", str65.equals("Time"));
        org.junit.Assert.assertNotNull(timeSeries66);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-459));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-460), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 0L);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate10);
        java.lang.String str13 = day12.toString();
        int int14 = day12.getMonth();
        int int15 = day12.getMonth();
        timeSeries1.update((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 1L);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries1.removeChangeListener(seriesChangeListener18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "17-May-1927" + "'", str13.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5 + "'", int15 == 5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        org.jfree.data.time.Year year8 = month6.getYear();
        java.lang.String str9 = year8.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(year8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond6.previous();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond6.getLastMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean6 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.lang.String str7 = spreadsheetDate3.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean12 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        boolean boolean13 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean18 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.lang.String str19 = spreadsheetDate15.toString();
        boolean boolean20 = spreadsheetDate11.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate15);
        try {
            int int22 = spreadsheetDate11.compareTo((java.lang.Object) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17-May-1927" + "'", str7.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "17-May-1927" + "'", str19.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        int int5 = spreadsheetDate3.getMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean10 = spreadsheetDate7.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        java.lang.String str11 = spreadsheetDate7.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean16 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean23 = spreadsheetDate20.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        java.lang.String str24 = spreadsheetDate20.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean29 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate26, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        boolean boolean30 = spreadsheetDate18.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean35 = spreadsheetDate32.isOn((org.jfree.data.time.SerialDate) spreadsheetDate34);
        java.lang.String str36 = spreadsheetDate32.toString();
        boolean boolean37 = spreadsheetDate28.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate43 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean44 = spreadsheetDate41.isOn((org.jfree.data.time.SerialDate) spreadsheetDate43);
        java.lang.String str45 = spreadsheetDate41.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean50 = spreadsheetDate41.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate47, (org.jfree.data.time.SerialDate) spreadsheetDate49);
        boolean boolean51 = spreadsheetDate39.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean56 = spreadsheetDate53.isOn((org.jfree.data.time.SerialDate) spreadsheetDate55);
        java.lang.String str57 = spreadsheetDate53.toString();
        boolean boolean58 = spreadsheetDate49.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate53);
        boolean boolean60 = spreadsheetDate53.equals((java.lang.Object) (short) 10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long63 = fixedMillisecond62.getFirstMillisecond();
        int int65 = fixedMillisecond62.compareTo((java.lang.Object) 100L);
        java.util.Date date66 = fixedMillisecond62.getStart();
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance(date66);
        int int68 = spreadsheetDate53.compare(serialDate67);
        boolean boolean70 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate28, serialDate67, 1927);
        int int71 = spreadsheetDate3.compareTo((java.lang.Object) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addDays(31, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "17-May-1927" + "'", str11.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "17-May-1927" + "'", str24.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "17-May-1927" + "'", str36.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "17-May-1927" + "'", str45.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "17-May-1927" + "'", str57.equals("17-May-1927"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 35L + "'", long63 == 35L);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-15569) + "'", int68 == (-15569));
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(serialDate72);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        long long18 = year17.getLastMillisecond();
        timeSeries1.setKey((java.lang.Comparable) year17);
        java.util.List list20 = timeSeries1.getItems();
        timeSeries1.setMaximumItemCount(3);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.SerialDate serialDate6 = day5.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek((-456));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        java.lang.Class class12 = timeSeries1.getTimePeriodClass();
        java.lang.String str13 = timeSeries1.getDomainDescription();
        timeSeries1.setDomainDescription("ThreadContext");
        java.lang.Comparable comparable16 = timeSeries1.getKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 3 + "'", comparable16.equals(3));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        java.lang.String str6 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str6.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean4 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long7 = fixedMillisecond6.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, 0.0d);
        timeSeries3.removeAgedItems((-1L), true);
        long long13 = timeSeries3.getMaximumItemAge();
        timeSeries3.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str18 = timeSeries17.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        java.util.Collection collection21 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.lang.Class class22 = timeSeries3.getTimePeriodClass();
        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("17-May-1927", class22);
        java.net.URL uRL24 = org.jfree.chart.util.ObjectUtilities.getResource("Last", class22);
        java.lang.ClassLoader classLoader25 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class22);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(class22);
        org.junit.Assert.assertNull(inputStream23);
        org.junit.Assert.assertNull(uRL24);
        org.junit.Assert.assertNotNull(classLoader25);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        long long7 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1969L + "'", long7 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Year year7 = month6.getYear();
        long long8 = month6.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long14 = fixedMillisecond13.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, 0.0d);
        timeSeries10.removeAgedItems((-1L), true);
        long long20 = timeSeries10.getMaximumItemAge();
        java.lang.Class class21 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month6, class21);
        java.lang.Class<?> wildcardClass23 = month6.getClass();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 23640L + "'", long8 == 23640L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        timeSeries1.setMaximumItemAge((long) 1927);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries15.addPropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        java.lang.Class class20 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long23 = fixedMillisecond22.getMiddleMillisecond();
        java.util.Date date24 = fixedMillisecond22.getEnd();
        java.util.Date date25 = fixedMillisecond22.getStart();
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(date25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.Year year28 = month27.getYear();
        org.jfree.data.time.Year year29 = month27.getYear();
        timeSeries1.setKey((java.lang.Comparable) year29);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = year29.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 35L + "'", long23 == 35L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertNotNull(year29);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        timeSeries1.removeAgedItems((-1L), true);
        long long11 = timeSeries1.getMaximumItemAge();
        timeSeries1.setMaximumItemAge((long) 1927);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long16 = fixedMillisecond15.getMiddleMillisecond();
        java.util.Date date17 = fixedMillisecond15.getEnd();
        boolean boolean18 = timeSeries1.equals((java.lang.Object) fixedMillisecond15);
        timeSeries1.setMaximumItemAge((long) 9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 35L + "'", long16 == 35L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener3);
        timeSeries1.setMaximumItemAge((long) 3);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timeSeries1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str14 = timeSeries13.getDomainDescription();
        int int15 = timeSeries13.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean18 = timeSeries17.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries17.removeChangeListener(seriesChangeListener24);
        timeSeries17.setNotify(true);
        java.lang.Class<?> wildcardClass28 = timeSeries17.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long31 = fixedMillisecond30.getMiddleMillisecond();
        java.util.Date date32 = fixedMillisecond30.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        long long34 = year33.getLastMillisecond();
        timeSeries17.setKey((java.lang.Comparable) year33);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str38 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long41 = fixedMillisecond40.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Date date45 = year33.getEnd();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
        long long47 = year46.getLastMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year46, (java.lang.Number) 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28799999L + "'", long34 == 28799999L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 28799999L + "'", long47 == 28799999L);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str2 = timeSeries1.getDomainDescription();
        timeSeries1.setKey((java.lang.Comparable) (-1.0f));
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long9 = fixedMillisecond8.getFirstMillisecond();
        int int11 = fixedMillisecond8.compareTo((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str14 = timeSeries13.getDomainDescription();
        int int15 = timeSeries13.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean18 = timeSeries17.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries17.removeChangeListener(seriesChangeListener24);
        timeSeries17.setNotify(true);
        java.lang.Class<?> wildcardClass28 = timeSeries17.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long31 = fixedMillisecond30.getMiddleMillisecond();
        java.util.Date date32 = fixedMillisecond30.getEnd();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
        long long34 = year33.getLastMillisecond();
        timeSeries17.setKey((java.lang.Comparable) year33);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str38 = timeSeries37.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long41 = fixedMillisecond40.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) year33, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
        java.util.Date date45 = year33.getEnd();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) year33);
        java.lang.Class<?> wildcardClass47 = timeSeries46.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long50 = fixedMillisecond49.getMiddleMillisecond();
        java.util.Date date51 = fixedMillisecond49.getEnd();
        java.util.Date date52 = fixedMillisecond49.getStart();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long56 = fixedMillisecond55.getMiddleMillisecond();
        java.util.Date date57 = fixedMillisecond55.getEnd();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date57);
        long long59 = year58.getLastMillisecond();
        int int60 = day53.compareTo((java.lang.Object) long59);
        java.lang.Number number61 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day53);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Time" + "'", str2.equals("Time"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Time" + "'", str14.equals("Time"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28799999L + "'", long34 == 28799999L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 35L + "'", long41 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 35L + "'", long50 == 35L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 35L + "'", long56 == 35L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 28799999L + "'", long59 == 28799999L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNull(number61);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date3 = fixedMillisecond1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str7 = timeSeries6.getDomainDescription();
        timeSeries6.setKey((java.lang.Comparable) (-1.0f));
        timeSeries6.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean14 = timeSeries13.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long17 = fixedMillisecond16.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, 0.0d);
        timeSeries13.removeAgedItems((-1L), true);
        long long23 = timeSeries13.getMaximumItemAge();
        timeSeries13.setMaximumItemAge((long) 1927);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long28 = fixedMillisecond27.getMiddleMillisecond();
        java.util.Date date29 = fixedMillisecond27.getEnd();
        boolean boolean30 = timeSeries13.equals((java.lang.Object) fixedMillisecond27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) (-1345219200000L));
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        int int36 = timeSeries34.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean39 = timeSeries38.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long42 = fixedMillisecond41.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries38.removeChangeListener(seriesChangeListener45);
        timeSeries38.setNotify(true);
        java.lang.Class<?> wildcardClass49 = timeSeries38.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long52 = fixedMillisecond51.getMiddleMillisecond();
        java.util.Date date53 = fixedMillisecond51.getEnd();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
        long long55 = year54.getLastMillisecond();
        timeSeries38.setKey((java.lang.Comparable) year54);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str59 = timeSeries58.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long62 = fixedMillisecond61.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (java.lang.Number) 0L);
        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) year54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond61);
        java.util.Calendar calendar66 = null;
        long long67 = fixedMillisecond61.getLastMillisecond(calendar66);
        java.util.Calendar calendar68 = null;
        long long69 = fixedMillisecond61.getLastMillisecond(calendar68);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries6.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond61, (double) 35L);
        boolean boolean72 = fixedMillisecond1.equals((java.lang.Object) 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 35L + "'", long28 == 35L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 35L + "'", long42 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 35L + "'", long52 == 35L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 28799999L + "'", long55 == 28799999L);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Time" + "'", str59.equals("Time"));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 35L + "'", long62 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem64);
        org.junit.Assert.assertNotNull(timeSeries65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 35L + "'", long67 == 35L);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 35L + "'", long69 == 35L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-9999), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long10 = fixedMillisecond9.getMiddleMillisecond();
        java.util.Date date11 = fixedMillisecond9.getEnd();
        boolean boolean12 = timeSeries1.equals((java.lang.Object) date11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str15 = timeSeries14.getDomainDescription();
        timeSeries14.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class18 = timeSeries14.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long21 = fixedMillisecond20.getMiddleMillisecond();
        java.util.Date date22 = fixedMillisecond20.getEnd();
        java.util.Date date23 = fixedMillisecond20.getStart();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23);
        int int26 = month25.getYearValue();
        java.lang.String str27 = month25.toString();
        org.jfree.data.time.Year year28 = month25.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long31 = fixedMillisecond30.getMiddleMillisecond();
        java.util.Date date32 = fixedMillisecond30.getEnd();
        java.util.Date date33 = fixedMillisecond30.getStart();
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance(date33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33);
        int int36 = month35.getYearValue();
        java.lang.String str37 = month35.toString();
        long long38 = month35.getLastMillisecond();
        org.jfree.data.time.Year year39 = month35.getYear();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) month25, (org.jfree.data.time.RegularTimePeriod) month35);
        timeSeries1.setKey((java.lang.Comparable) month25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(class18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 35L + "'", long21 == 35L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1969 + "'", int26 == 1969);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "December 1969" + "'", str27.equals("December 1969"));
        org.junit.Assert.assertNotNull(year28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 35L + "'", long31 == 35L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "December 1969" + "'", str37.equals("December 1969"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28799999L + "'", long38 == 28799999L);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertNotNull(timeSeries40);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long5 = fixedMillisecond4.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries1.removeChangeListener(seriesChangeListener8);
        timeSeries1.setNotify(true);
        java.lang.Class<?> wildcardClass12 = timeSeries1.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long15 = fixedMillisecond14.getMiddleMillisecond();
        java.util.Date date16 = fixedMillisecond14.getEnd();
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Year year20 = month19.getYear();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str23 = timeSeries22.getDomainDescription();
        timeSeries22.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class26 = timeSeries22.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener27);
        boolean boolean29 = month19.equals((java.lang.Object) timeSeries22);
        java.util.Date date30 = month19.getEnd();
        org.jfree.data.time.Year year31 = month19.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond((long) '#');
        long long34 = fixedMillisecond33.getMiddleMillisecond();
        java.util.Date date35 = fixedMillisecond33.getEnd();
        java.util.Date date36 = fixedMillisecond33.getStart();
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36);
        org.jfree.data.time.Year year39 = month38.getYear();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 3);
        java.lang.String str42 = timeSeries41.getDomainDescription();
        timeSeries41.setKey((java.lang.Comparable) (-1.0f));
        java.lang.Class class45 = timeSeries41.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries41.removePropertyChangeListener(propertyChangeListener46);
        boolean boolean48 = month38.equals((java.lang.Object) timeSeries41);
        java.util.Date date49 = month38.getEnd();
        org.jfree.data.time.Year year50 = month38.getYear();
        java.lang.String str51 = year50.toString();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year50);
        java.util.Date date53 = year50.getStart();
        java.lang.Class class56 = null;
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year50, "Last", "Last", class56);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 35L + "'", long5 == 35L);
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 35L + "'", long15 == 35L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(year31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(year39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Time" + "'", str42.equals("Time"));
        org.junit.Assert.assertNotNull(class45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(year50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1969" + "'", str51.equals("1969"));
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(date53);
    }
}

