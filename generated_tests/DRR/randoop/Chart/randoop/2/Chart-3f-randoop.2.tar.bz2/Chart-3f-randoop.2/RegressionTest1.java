import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries5.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (double) 1560182469650L, true);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(0, (int) (short) 0);
//        int int21 = timeSeries17.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
//        boolean boolean48 = fixedMillisecond44.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond44.previous();
//        boolean boolean50 = fixedMillisecond29.equals((java.lang.Object) regularTimePeriod49);
//        java.util.Date date51 = fixedMillisecond29.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date51);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = day55.previous();
//        int int57 = day55.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener63 = null;
//        timeSeries62.addChangeListener(seriesChangeListener63);
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries62.getDataItem((org.jfree.data.time.RegularTimePeriod) year66);
//        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month((int) (byte) 10, year66);
//        long long69 = month68.getLastMillisecond();
//        long long70 = month68.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = month68.next();
//        long long72 = month68.getMiddleMillisecond();
//        boolean boolean73 = day55.equals((java.lang.Object) long72);
//        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182471559L, "hi!", "");
//        int int78 = day55.compareTo((java.lang.Object) "");
//        long long79 = day55.getLastMillisecond();
//        int int80 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day55);
//        long long81 = day55.getLastMillisecond();
//        int int82 = day55.getMonth();
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNull(number30);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182543217L + "'", long40 == 1560182543217L);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182543218L + "'", long46 == 1560182543218L);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-62109475200001L) + "'", long69 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-62112153600000L) + "'", long70 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-62110814400001L) + "'", long72 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560236399999L + "'", long79 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560236399999L + "'", long81 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 6 + "'", int82 == 6);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "October 1", "Value");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        timeSeries3.removeAgedItems(false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = fixedMillisecond27.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 1560182489614L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeriesDataItem35.getPeriod();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182543496L + "'", long17 == 1560182543496L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182543497L + "'", long29 == 1560182543497L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond15.peg(calendar30);
//        long long32 = fixedMillisecond15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 1560182496213L);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem34);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = seriesChangeEvent35.getSummary();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182543565L + "'", long26 == 1560182543565L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182543564L + "'", long32 == 1560182543564L);
//        org.junit.Assert.assertNull(seriesChangeInfo36);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        long long12 = month10.getLastMillisecond();
        int int14 = month10.compareTo((java.lang.Object) 1560182537017L);
        long long15 = month10.getLastMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62109475200001L) + "'", long12 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62109475200001L) + "'", long15 == (-62109475200001L));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        long long12 = month10.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 22L + "'", long12 == 22L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, 0);
        long long3 = month2.getSerialIndex();
        int int4 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        java.util.Calendar calendar41 = null;
//        try {
//            long long42 = month40.getFirstMillisecond(calendar41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182543666L + "'", long26 == 1560182543666L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182543667L + "'", long32 == 1560182543667L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
//        boolean boolean23 = fixedMillisecond19.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond19.previous();
//        int int25 = timeSeries12.getIndex(regularTimePeriod24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = null;
//        try {
//            timeSeries12.add(timeSeriesDataItem26, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560182543682L + "'", long21 == 1560182543682L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond27.peg(calendar33);
//        long long35 = fixedMillisecond27.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182543695L + "'", long17 == 1560182543695L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182543700L + "'", long29 == 1560182543700L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182543700L + "'", long35 == 1560182543700L);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(false);
        java.util.List list8 = timeSeries3.getItems();
        long long9 = timeSeries3.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries16.addChangeListener(seriesChangeListener17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 10, year20);
        long long23 = month22.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = month22.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62112153600000L) + "'", long23 == (-62112153600000L));
        org.junit.Assert.assertNull(timeSeriesDataItem24);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.String str6 = timeSeries3.getDomainDescription();
//        java.util.List list7 = timeSeries3.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond8.getMiddleMillisecond(calendar9);
//        boolean boolean12 = fixedMillisecond8.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date13 = fixedMillisecond8.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, 0.0d);
//        java.lang.Comparable comparable16 = timeSeries3.getKey();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
//        boolean boolean21 = fixedMillisecond17.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date22 = fixedMillisecond17.getTime();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
//        boolean boolean26 = month23.equals((java.lang.Object) 10);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560182485211L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182543750L + "'", long10 == 1560182543750L);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 0.0f + "'", comparable16.equals(0.0f));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182543751L + "'", long19 == 1560182543751L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond15.getMiddleMillisecond(calendar33);
//        java.util.Calendar calendar35 = null;
//        fixedMillisecond15.peg(calendar35);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond15.next();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182543766L + "'", long17 == 1560182543766L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182543766L + "'", long29 == 1560182543766L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182543766L + "'", long34 == 1560182543766L);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond24.next();
//        java.util.Date date31 = fixedMillisecond24.getEnd();
//        long long32 = fixedMillisecond24.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182543814L + "'", long26 == 1560182543814L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182543814L + "'", long32 == 1560182543814L);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.String str33 = timeSeries32.getDescription();
//        java.util.List list34 = timeSeries32.getItems();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182543874L + "'", long17 == 1560182543874L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182543878L + "'", long29 == 1560182543878L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertNotNull(list34);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.removeAgedItems((long) '#', false);
        boolean boolean9 = timeSeries3.isEmpty();
        java.lang.Comparable comparable10 = timeSeries3.getKey();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560182480608L);
        int int14 = month11.getYearValue();
        long long15 = month11.getFirstMillisecond();
        java.util.Date date16 = month11.getEnd();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertNotNull(date16);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(0, (int) (short) 0);
//        int int8 = timeSeries4.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        java.lang.Class<?> wildcardClass31 = timeSeries4.getClass();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries37.addChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year41, (double) 1560182469650L, true);
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year41, (double) (short) 100);
//        java.lang.String str48 = year41.toString();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month((int) (byte) 1, year41);
//        boolean boolean51 = month49.equals((java.lang.Object) 1560182468443L);
//        long long52 = month49.getLastMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560182543950L + "'", long27 == 1560182543950L);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-62133062400001L) + "'", long52 == (-62133062400001L));
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond7.getLastMillisecond(calendar12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        boolean boolean18 = fixedMillisecond14.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date19 = fixedMillisecond14.getTime();
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
//        long long21 = month20.getLastMillisecond();
//        boolean boolean22 = fixedMillisecond7.equals((java.lang.Object) month20);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182544035L + "'", long9 == 1560182544035L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182544035L + "'", long13 == 1560182544035L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560182544038L + "'", long16 == 1560182544038L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
//        boolean boolean35 = fixedMillisecond31.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond31.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries42.createCopy(0, (int) (short) 0);
//        int int46 = timeSeries42.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries50.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number55 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries59.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond63.getLastMillisecond(calendar64);
//        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
//        java.lang.Class<?> wildcardClass69 = timeSeries42.getClass();
//        long long70 = timeSeries42.getMaximumItemAge();
//        java.util.Collection collection71 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries42);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182544066L + "'", long26 == 1560182544066L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560182544067L + "'", long33 == 1560182544067L);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertNotNull(timeSeries62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560182544069L + "'", long65 == 1560182544069L);
//        org.junit.Assert.assertNotNull(timeSeries68);
//        org.junit.Assert.assertNotNull(wildcardClass69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 9223372036854775807L + "'", long70 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection71);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries12);
        timeSeries12.setNotify(true);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Class<?> wildcardClass7 = seriesException6.getClass();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.String str3 = year1.toString();
        java.lang.String str4 = year1.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.String str33 = timeSeries32.getDescription();
//        java.lang.String str34 = timeSeries32.getRangeDescription();
//        timeSeries32.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
//        boolean boolean40 = fixedMillisecond36.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date41 = fixedMillisecond36.getTime();
//        timeSeries32.setKey((java.lang.Comparable) date41);
//        try {
//            timeSeries32.delete(12, (int) (byte) 1, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182544478L + "'", long17 == 1560182544478L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182544478L + "'", long29 == 1560182544478L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560182544480L + "'", long38 == 1560182544480L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(date41);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182535017L, seriesChangeInfo1);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener30);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.addChangeListener(seriesChangeListener37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 10, year40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month42.previous();
//        long long44 = month42.getLastMillisecond();
//        org.jfree.data.time.Year year45 = month42.getYear();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year45);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries50.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number55 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
//        boolean boolean57 = year45.equals((java.lang.Object) fixedMillisecond54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year45.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year45.previous();
//        java.lang.Object obj60 = null;
//        int int61 = year45.compareTo(obj60);
//        java.util.Calendar calendar62 = null;
//        try {
//            long long63 = year45.getLastMillisecond(calendar62);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182544503L + "'", long26 == 1560182544503L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62109475200001L) + "'", long44 == (-62109475200001L));
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469812L);
//        double double2 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        timeSeries6.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        long long36 = timeSeries6.getMaximumItemAge();
//        java.lang.Object obj37 = timeSeries6.clone();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries41.createCopy(0, (int) (short) 0);
//        int int45 = timeSeries41.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries49.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number54 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries58.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
//        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar69 = null;
//        long long70 = fixedMillisecond68.getMiddleMillisecond(calendar69);
//        boolean boolean72 = fixedMillisecond68.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = fixedMillisecond68.previous();
//        boolean boolean74 = fixedMillisecond53.equals((java.lang.Object) regularTimePeriod73);
//        java.util.Date date75 = fixedMillisecond53.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond(date75);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date75);
//        java.util.Date date78 = year77.getEnd();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year77, (java.lang.Number) 1560182484284L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year77);
//        boolean boolean82 = timeSeries1.getNotify();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo83 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent84 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1, seriesChangeInfo83);
//        java.lang.String str85 = timeSeries1.getRangeDescription();
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560182544528L + "'", long20 == 1560182544528L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182544529L + "'", long32 == 1560182544529L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertNull(number54);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560182544532L + "'", long64 == 1560182544532L);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560182544532L + "'", long70 == 1560182544532L);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNull(timeSeriesDataItem81);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "Value" + "'", str85.equals("Value"));
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (-2));
        double double14 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((int) (byte) 0);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-2.0d) + "'", double14 == (-2.0d));
        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries6.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month((int) (byte) 10, year10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.previous();
        java.lang.String str14 = regularTimePeriod13.toString();
        timeSeries1.add(regularTimePeriod13, (double) 1560182485879L, true);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182485879L, seriesChangeInfo18);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "September 1" + "'", str14.equals("September 1"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(false);
        java.util.List list8 = timeSeries3.getItems();
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 0.0f + "'", comparable9.equals(0.0f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries3.getDomainDescription();
        java.util.List list7 = timeSeries3.getItems();
        timeSeries3.setDescription("Value");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo10);
        timeSeries3.setDescription("June 2019");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(list7);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.Number number34 = null;
//        try {
//            timeSeries3.update((int) '#', number34);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182545090L + "'", long17 == 1560182545090L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182545091L + "'", long29 == 1560182545091L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182473743L);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1560182473743]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=1560182473743]"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182471559L, "hi!", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 1560182471559L + "'", comparable4.equals(1560182471559L));
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469812L);
//        double double2 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        timeSeries6.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getLastMillisecond(calendar19);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        long long36 = timeSeries6.getMaximumItemAge();
//        java.lang.Object obj37 = timeSeries6.clone();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries41.createCopy(0, (int) (short) 0);
//        int int45 = timeSeries41.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries49.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number54 = timeSeries49.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries58.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
//        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar69 = null;
//        long long70 = fixedMillisecond68.getMiddleMillisecond(calendar69);
//        boolean boolean72 = fixedMillisecond68.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = fixedMillisecond68.previous();
//        boolean boolean74 = fixedMillisecond53.equals((java.lang.Object) regularTimePeriod73);
//        java.util.Date date75 = fixedMillisecond53.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond(date75);
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date75);
//        java.util.Date date78 = year77.getEnd();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year77, (java.lang.Number) 1560182484284L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year77);
//        org.jfree.data.time.TimeSeries timeSeries85 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener86 = null;
//        timeSeries85.addChangeListener(seriesChangeListener86);
//        timeSeries85.removeAgedItems((long) '#', false);
//        boolean boolean91 = timeSeries85.isEmpty();
//        java.lang.Comparable comparable92 = timeSeries85.getKey();
//        org.jfree.data.time.Month month93 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem95 = timeSeries85.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month93, (java.lang.Number) 1560182480608L);
//        int int96 = month93.getYearValue();
//        try {
//            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month93, (java.lang.Number) 1560182513290L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560182545316L + "'", long20 == 1560182545316L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182545319L + "'", long32 == 1560182545319L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 9223372036854775807L + "'", long36 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj37);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertNull(number54);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560182545322L + "'", long64 == 1560182545322L);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560182545323L + "'", long70 == 1560182545323L);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertNull(timeSeriesDataItem81);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
//        org.junit.Assert.assertTrue("'" + comparable92 + "' != '" + 0.0f + "'", comparable92.equals(0.0f));
//        org.junit.Assert.assertNull(timeSeriesDataItem95);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 2019 + "'", int96 == 2019);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener12);
//        timeSeries6.fireSeriesChanged();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries6.removePropertyChangeListener(propertyChangeListener15);
//        try {
//            java.lang.Number number18 = timeSeries6.getValue((int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182545343L + "'", long9 == 1560182545343L);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond15.peg(calendar30);
//        long long32 = fixedMillisecond15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 1560182496213L);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem34);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
//        seriesChangeEvent35.setSummary(seriesChangeInfo36);
//        java.lang.Object obj38 = seriesChangeEvent35.getSource();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo39 = seriesChangeEvent35.getSummary();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182545356L + "'", long26 == 1560182545356L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182545355L + "'", long32 == 1560182545355L);
//        org.junit.Assert.assertNotNull(obj38);
//        org.junit.Assert.assertNull(seriesChangeInfo39);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, (int) (byte) 10);
        java.util.Calendar calendar3 = null;
        try {
            month2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond15.getMiddleMillisecond(calendar33);
//        int int36 = fixedMillisecond15.compareTo((java.lang.Object) 1560182497633L);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182545428L + "'", long17 == 1560182545428L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182545429L + "'", long29 == 1560182545429L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182545428L + "'", long34 == 1560182545428L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 1560182469272L);
//        timeSeries3.setMaximumItemAge(0L);
//        java.beans.PropertyChangeListener propertyChangeListener24 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener24);
//        int int26 = timeSeries3.getMaximumItemCount();
//        java.lang.Object obj27 = timeSeries3.clone();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182545465L + "'", long17 == 1560182545465L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2147483647 + "'", int26 == 2147483647);
//        org.junit.Assert.assertNotNull(obj27);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(1560182485349L);
        long long12 = fixedMillisecond11.getMiddleMillisecond();
        java.lang.Number number13 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182485349L + "'", long12 == 1560182485349L);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 1560182476123L);
        timeSeriesDataItem12.setValue((java.lang.Number) (-9999));
        java.lang.Number number15 = timeSeriesDataItem12.getValue();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-9999) + "'", number15.equals((-9999)));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.next();
//        java.lang.String str44 = day41.toString();
//        int int45 = day41.getDayOfMonth();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182545530L + "'", long26 == 1560182545530L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182545531L + "'", long32 == 1560182545531L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.addChangeListener(seriesChangeListener37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year40);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year40, (double) 1560182469650L, true);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year40, (double) (short) 100);
//        java.lang.String str47 = year40.toString();
//        int int49 = year40.compareTo((java.lang.Object) 1560182530842L);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182545667L + "'", long26 == 1560182545667L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        long long7 = month6.getLastMillisecond();
//        java.util.Calendar calendar8 = null;
//        try {
//            month6.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182545739L + "'", long2 == 1560182545739L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((-1L));
        long long2 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(12, year44);
//        int int46 = month45.getMonth();
//        long long47 = month45.getFirstMillisecond();
//        int int48 = day41.compareTo((java.lang.Object) long47);
//        long long49 = day41.getSerialIndex();
//        int int50 = day41.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day41.previous();
//        java.lang.String str52 = day41.toString();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182545982L + "'", long26 == 1560182545982L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182545983L + "'", long32 == 1560182545983L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62106883200000L) + "'", long47 == (-62106883200000L));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "10-June-2019" + "'", str52.equals("10-June-2019"));
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        double double9 = timeSeries3.getMinY();
//        timeSeries3.removeAgedItems(1560182491841L, false);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries16.addChangeListener(seriesChangeListener17);
//        java.lang.String str19 = timeSeries16.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        int int27 = timeSeries23.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number36 = timeSeries31.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries40.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond44.getLastMillisecond(calendar45);
//        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond50.getMiddleMillisecond(calendar51);
//        boolean boolean54 = fixedMillisecond50.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = fixedMillisecond50.previous();
//        boolean boolean56 = fixedMillisecond35.equals((java.lang.Object) regularTimePeriod55);
//        java.util.Date date57 = fixedMillisecond35.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date57);
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date57);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date57);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date57);
//        org.jfree.data.time.SerialDate serialDate62 = day61.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = day61.previous();
//        timeSeries16.add(regularTimePeriod63, (double) 1560182540256L, false);
//        timeSeries3.add(regularTimePeriod63, (java.lang.Number) 1560182481520L);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182546129L + "'", long46 == 1560182546129L);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560182546130L + "'", long52 == 1560182546130L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1560182513290L);
        long long14 = month10.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62112153600000L) + "'", long14 == (-62112153600000L));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(12, year2);
        java.lang.String str4 = month3.toString();
        java.lang.String str5 = month3.toString();
        long long6 = month3.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December 1" + "'", str4.equals("December 1"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 1" + "'", str5.equals("December 1"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62104204800001L) + "'", long6 == (-62104204800001L));
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        long long33 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries38.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (byte) 10, year42);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) 8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year42.next();
//        long long48 = year42.getLastMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182546746L + "'", long17 == 1560182546746L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182546750L + "'", long29 == 1560182546750L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62104204800001L) + "'", long48 == (-62104204800001L));
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: ");
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(12, year44);
//        int int46 = month45.getMonth();
//        long long47 = month45.getFirstMillisecond();
//        int int48 = day41.compareTo((java.lang.Object) long47);
//        long long49 = day41.getLastMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182546830L + "'", long26 == 1560182546830L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182546831L + "'", long32 == 1560182546831L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62106883200000L) + "'", long47 == (-62106883200000L));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560236399999L + "'", long49 == 1560236399999L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.String str6 = timeSeries3.getDomainDescription();
//        java.util.List list7 = timeSeries3.getItems();
//        timeSeries3.removeAgedItems(1560182473166L, false);
//        double double11 = timeSeries3.getMaxY();
//        java.lang.Class<?> wildcardClass12 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries16.addChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries29.createCopy(0, (int) (short) 0);
//        int int33 = timeSeries29.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries37.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number42 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries46.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        java.lang.Class<?> wildcardClass56 = timeSeries29.getClass();
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener62 = null;
//        timeSeries61.addChangeListener(seriesChangeListener62);
//        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries61.getDataItem((org.jfree.data.time.RegularTimePeriod) year65);
//        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month((int) (byte) 10, year65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month67.previous();
//        java.lang.Number number69 = timeSeries29.getValue(regularTimePeriod68);
//        boolean boolean70 = timeSeries16.equals((java.lang.Object) timeSeries29);
//        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries3.addAndOrUpdate(timeSeries29);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182546987L + "'", long24 == 1560182546987L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNull(number42);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560182546989L + "'", long52 == 1560182546989L);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNull(timeSeriesDataItem66);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNull(number69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNotNull(timeSeries71);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 1560182469272L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        boolean boolean26 = fixedMillisecond22.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date27 = fixedMillisecond22.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1560182472661L);
//        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(1);
//        timeSeries3.setKey((java.lang.Comparable) year31);
//        java.lang.Comparable comparable33 = timeSeries3.getKey();
//        try {
//            timeSeries3.delete(100, (int) (byte) -1, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182547291L + "'", long17 == 1560182547291L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182547291L + "'", long24 == 1560182547291L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(comparable33);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182501107L, "Mon Jun 10 09:01:47 PDT 2019", "org.jfree.data.event.SeriesChangeEvent[source=0.0]");
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries12);
        try {
            timeSeries12.delete(10, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        int int30 = timeSeries3.getItemCount();
//        timeSeries3.setDomainDescription("Mon Jun 10 09:01:27 PDT 2019");
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182547558L + "'", long26 == 1560182547558L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(12, year2);
        long long4 = year2.getLastMillisecond();
        int int5 = year2.getYear();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800001L) + "'", long4 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182518691L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.removeAgedItems((long) '#', false);
        boolean boolean9 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) (byte) 10);
        java.lang.Object obj13 = timeSeriesDataItem12.clone();
        timeSeries3.add(timeSeriesDataItem12);
        int int16 = timeSeriesDataItem12.compareTo((java.lang.Object) 1560182535653L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        java.lang.String str12 = regularTimePeriod11.toString();
        java.util.Date date13 = regularTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "September 1" + "'", str12.equals("September 1"));
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("hi!");
        java.lang.String str10 = timeSeries3.getDescription();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        long long33 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries38.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (byte) 10, year42);
//        long long45 = month44.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 1560182470866L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month44.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month44);
//        boolean boolean50 = timeSeries3.isEmpty();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182547742L + "'", long17 == 1560182547742L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182547743L + "'", long29 == 1560182547743L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62109475200001L) + "'", long45 == (-62109475200001L));
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.removeChangeListener(seriesChangeListener2);
        int int4 = timeSeries1.getItemCount();
        java.lang.Class<?> wildcardClass5 = timeSeries1.getClass();
        java.lang.Object obj6 = timeSeries1.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries37.addChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (byte) 10, year41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.previous();
//        timeSeries32.delete(regularTimePeriod44);
//        java.lang.Object obj46 = null;
//        boolean boolean47 = timeSeries32.equals(obj46);
//        timeSeries32.setRangeDescription("hi!");
//        timeSeries32.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=1560182473743]");
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182548054L + "'", long17 == 1560182548054L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182548055L + "'", long29 == 1560182548055L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.String str33 = timeSeries32.getDescription();
//        java.lang.String str34 = timeSeries32.getRangeDescription();
//        timeSeries32.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
//        boolean boolean40 = fixedMillisecond36.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date41 = fixedMillisecond36.getTime();
//        timeSeries32.setKey((java.lang.Comparable) date41);
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener43);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182548117L + "'", long17 == 1560182548117L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182548118L + "'", long29 == 1560182548118L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560182548122L + "'", long38 == 1560182548122L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(date41);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.util.Date date30 = fixedMillisecond24.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182548172L + "'", long26 == 1560182548172L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(date30);
//    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182548247L + "'", long26 == 1560182548247L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182548247L + "'", long32 == 1560182548247L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
//        long long8 = month6.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        int int16 = timeSeries12.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number25 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries29.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond33.next();
//        java.lang.String str40 = regularTimePeriod39.toString();
//        boolean boolean41 = month6.equals((java.lang.Object) regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182548623L + "'", long2 == 1560182548623L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182548626L + "'", long35 == 1560182548626L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Mon Jun 10 09:02:28 PDT 2019" + "'", str40.equals("Mon Jun 10 09:02:28 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Class<?> wildcardClass4 = seriesException3.getClass();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        boolean boolean15 = timeSeries9.equals((java.lang.Object) timePeriodFormatException14);
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray17 = timePeriodFormatException14.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        boolean boolean10 = timeSeries3.equals((java.lang.Object) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries15.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 10, year19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.previous();
        long long23 = month21.getLastMillisecond();
        int int25 = month21.compareTo((java.lang.Object) 1560182537017L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 1560182519395L);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62109475200001L) + "'", long23 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(12, year44);
//        int int46 = month45.getMonth();
//        long long47 = month45.getFirstMillisecond();
//        int int48 = day41.compareTo((java.lang.Object) long47);
//        long long49 = day41.getSerialIndex();
//        int int50 = day41.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day41.previous();
//        int int52 = day41.getYear();
//        java.util.Calendar calendar53 = null;
//        try {
//            day41.peg(calendar53);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182548796L + "'", long26 == 1560182548796L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182548797L + "'", long32 == 1560182548797L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62106883200000L) + "'", long47 == (-62106883200000L));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        java.lang.Object obj7 = timeSeries3.clone();
        try {
            timeSeries3.delete(1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=1560182473743]");
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        long long12 = month10.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long12);
        timeSeries13.removeAgedItems(false);
        double double16 = timeSeries13.getMaxY();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62109475200001L) + "'", long12 == (-62109475200001L));
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.Date date33 = fixedMillisecond27.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date33);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182548852L + "'", long17 == 1560182548852L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182548853L + "'", long29 == 1560182548853L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(date33);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str2.equals("org.jfree.data.general.SeriesException: 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str3.equals("org.jfree.data.general.SeriesException: 2019"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (-2));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            timeSeries3.add(regularTimePeriod14, (double) 1560182509746L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.String str33 = timeSeries32.getDescription();
//        java.lang.String str34 = timeSeries32.getRangeDescription();
//        timeSeries32.clear();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries39.createCopy(0, (int) (short) 0);
//        int int43 = timeSeries39.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries47.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries56.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond60.getLastMillisecond(calendar61);
//        timeSeries59.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar67 = null;
//        long long68 = fixedMillisecond66.getMiddleMillisecond(calendar67);
//        boolean boolean70 = fixedMillisecond66.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond66.previous();
//        boolean boolean72 = fixedMillisecond51.equals((java.lang.Object) regularTimePeriod71);
//        java.util.Date date73 = fixedMillisecond51.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond(date73);
//        org.jfree.data.time.Year year75 = new org.jfree.data.time.Year(date73);
//        org.jfree.data.time.Month month76 = new org.jfree.data.time.Month(date73);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = day77.previous();
//        int int79 = day77.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener85 = null;
//        timeSeries84.addChangeListener(seriesChangeListener85);
//        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries84.getDataItem((org.jfree.data.time.RegularTimePeriod) year88);
//        org.jfree.data.time.Month month90 = new org.jfree.data.time.Month((int) (byte) 10, year88);
//        long long91 = month90.getLastMillisecond();
//        long long92 = month90.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = month90.next();
//        long long94 = month90.getMiddleMillisecond();
//        boolean boolean95 = day77.equals((java.lang.Object) long94);
//        int int96 = day77.getDayOfMonth();
//        int int97 = day77.getMonth();
//        long long98 = day77.getFirstMillisecond();
//        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) day77);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182548953L + "'", long17 == 1560182548953L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182548954L + "'", long29 == 1560182548954L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560182548957L + "'", long62 == 1560182548957L);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560182548961L + "'", long68 == 1560182548961L);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(date73);
//        org.junit.Assert.assertNotNull(regularTimePeriod78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 6 + "'", int79 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem89);
//        org.junit.Assert.assertTrue("'" + long91 + "' != '" + (-62109475200001L) + "'", long91 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long92 + "' != '" + (-62112153600000L) + "'", long92 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//        org.junit.Assert.assertTrue("'" + long94 + "' != '" + (-62110814400001L) + "'", long94 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 10 + "'", int96 == 10);
//        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 6 + "'", int97 == 6);
//        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 1560150000000L + "'", long98 == 1560150000000L);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: hi!");
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond7.previous();
        java.util.Calendar calendar10 = null;
        fixedMillisecond7.peg(calendar10);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 10, year39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
//        java.lang.Number number43 = timeSeries3.getValue(regularTimePeriod42);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries3.createCopy(8, (int) (short) 10);
//        timeSeries46.fireSeriesChanged();
//        long long48 = timeSeries46.getMaximumItemAge();
//        timeSeries46.setRangeDescription("org.jfree.data.general.SeriesException: 2019");
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182549828L + "'", long26 == 1560182549828L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 9223372036854775807L + "'", long48 == 9223372036854775807L);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries37.addChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (byte) 10, year41);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries47.addChangeListener(seriesChangeListener48);
//        timeSeries47.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries55.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond59.getLastMillisecond(calendar60);
//        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries67.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar72 = null;
//        long long73 = fixedMillisecond71.getLastMillisecond(calendar72);
//        timeSeries70.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond71);
//        java.lang.Number number77 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, number77);
//        boolean boolean79 = month43.equals((java.lang.Object) fixedMillisecond71);
//        java.lang.String str80 = month43.toString();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.Year year83 = month43.getYear();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182549950L + "'", long17 == 1560182549950L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182549950L + "'", long29 == 1560182549950L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560182549953L + "'", long61 == 1560182549953L);
//        org.junit.Assert.assertNotNull(timeSeries70);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560182549953L + "'", long73 == 1560182549953L);
//        org.junit.Assert.assertNotNull(timeSeries76);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "October 1" + "'", str80.equals("October 1"));
//        org.junit.Assert.assertNotNull(year83);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 10, year52);
//        long long55 = month54.getLastMillisecond();
//        long long56 = month54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month54.next();
//        long long58 = month54.getMiddleMillisecond();
//        boolean boolean59 = day41.equals((java.lang.Object) long58);
//        int int60 = day41.getDayOfMonth();
//        int int61 = day41.getDayOfMonth();
//        int int63 = day41.compareTo((java.lang.Object) 1560182481345L);
//        int int64 = day41.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = day41.previous();
//        long long66 = day41.getLastMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182550350L + "'", long26 == 1560182550350L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182550351L + "'", long32 == 1560182550351L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62109475200001L) + "'", long55 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62112153600000L) + "'", long56 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62110814400001L) + "'", long58 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560236399999L + "'", long66 == 1560236399999L);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 10, year39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
//        java.lang.Number number43 = timeSeries3.getValue(regularTimePeriod42);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries3.createCopy(8, (int) (short) 10);
//        java.lang.String str47 = timeSeries3.getDescription();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries3.getDataItem(5);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182550540L + "'", long26 == 1560182550540L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNull(str47);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "hi!", "");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) (byte) 10);
//        java.lang.Object obj9 = timeSeriesDataItem8.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem8.getPeriod();
//        timeSeries5.add(timeSeriesDataItem8, true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem8.getPeriod();
//        boolean boolean14 = day0.equals((java.lang.Object) regularTimePeriod13);
//        int int15 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNotNull(obj9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        int int7 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.fireSeriesChanged();
        java.util.Collection collection11 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.addChangeListener(seriesChangeListener18);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year21, (double) 1560182469650L, true);
        double double26 = timeSeries13.getMaxY();
        java.lang.String str27 = timeSeries13.getRangeDescription();
        java.lang.Object obj28 = timeSeries13.clone();
        timeSeries13.clear();
        java.util.Collection collection30 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        boolean boolean31 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.56018246965E12d + "'", double26 == 1.56018246965E12d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Value" + "'", str27.equals("Value"));
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        long long33 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries38.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (byte) 10, year42);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) 8);
//        int int47 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries51.createCopy(0, (int) (short) 0);
//        java.lang.Object obj55 = timeSeries51.clone();
//        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries51);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182550626L + "'", long17 == 1560182550626L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182550627L + "'", long29 == 1560182550627L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2147483647 + "'", int47 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertNotNull(obj55);
//        org.junit.Assert.assertNotNull(collection56);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener12);
//        timeSeries6.setDescription("");
//        java.lang.Comparable comparable16 = timeSeries6.getKey();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182550775L + "'", long9 == 1560182550775L);
//        org.junit.Assert.assertTrue("'" + comparable16 + "' != '" + 0.0f + "'", comparable16.equals(0.0f));
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.Date date33 = fixedMillisecond27.getTime();
//        java.lang.Class<?> wildcardClass34 = fixedMillisecond27.getClass();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries38.createCopy(0, (int) (short) 0);
//        int int42 = timeSeries38.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries46.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number51 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries55.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond59.getLastMillisecond(calendar60);
//        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
//        java.util.Date date65 = fixedMillisecond59.getEnd();
//        java.util.TimeZone timeZone66 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date65, timeZone66);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182550791L + "'", long17 == 1560182550791L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182550792L + "'", long29 == 1560182550792L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNull(number51);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560182550794L + "'", long61 == 1560182550794L);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 10, year52);
//        long long55 = month54.getLastMillisecond();
//        long long56 = month54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month54.next();
//        long long58 = month54.getMiddleMillisecond();
//        boolean boolean59 = day41.equals((java.lang.Object) long58);
//        int int60 = day41.getDayOfMonth();
//        int int61 = day41.getDayOfMonth();
//        int int63 = day41.compareTo((java.lang.Object) 1560182481345L);
//        int int64 = day41.getMonth();
//        java.util.Calendar calendar65 = null;
//        try {
//            long long66 = day41.getLastMillisecond(calendar65);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182551049L + "'", long26 == 1560182551049L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182551049L + "'", long32 == 1560182551049L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62109475200001L) + "'", long55 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62112153600000L) + "'", long56 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62110814400001L) + "'", long58 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(12, year2);
//        int int4 = month3.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries9.createCopy(0, (int) (short) 0);
//        int int13 = timeSeries9.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number22 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        java.lang.Class<?> wildcardClass36 = timeSeries9.getClass();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
//        timeSeries42.addChangeListener(seriesChangeListener43);
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries42.getDataItem((org.jfree.data.time.RegularTimePeriod) year46);
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) year46, (double) 1560182469650L, true);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year46, (double) (short) 100);
//        java.lang.String str53 = year46.toString();
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 1, year46);
//        long long55 = month54.getSerialIndex();
//        int int57 = month54.compareTo((java.lang.Object) 1560182485608L);
//        long long58 = month54.getLastMillisecond();
//        java.lang.String str59 = month54.toString();
//        boolean boolean60 = month3.equals((java.lang.Object) str59);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
//        org.junit.Assert.assertNotNull(timeSeries12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182551072L + "'", long32 == 1560182551072L);
//        org.junit.Assert.assertNotNull(timeSeries35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "1" + "'", str53.equals("1"));
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 13L + "'", long55 == 13L);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62133062400001L) + "'", long58 == (-62133062400001L));
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "January 1" + "'", str59.equals("January 1"));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.removeAgedItems((long) '#', false);
        boolean boolean9 = timeSeries3.isEmpty();
        java.lang.Comparable comparable10 = timeSeries3.getKey();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560182480608L);
        int int14 = month11.getYearValue();
        long long15 = month11.getFirstMillisecond();
        int int16 = month11.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560182539525L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182497767L);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 10, year52);
//        long long55 = month54.getLastMillisecond();
//        long long56 = month54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month54.next();
//        long long58 = month54.getMiddleMillisecond();
//        boolean boolean59 = day41.equals((java.lang.Object) long58);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182471559L, "hi!", "");
//        int int64 = day41.compareTo((java.lang.Object) "");
//        long long65 = day41.getLastMillisecond();
//        long long66 = day41.getSerialIndex();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182551200L + "'", long26 == 1560182551200L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182551201L + "'", long32 == 1560182551201L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62109475200001L) + "'", long55 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62112153600000L) + "'", long56 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62110814400001L) + "'", long58 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560236399999L + "'", long65 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 43626L + "'", long66 == 43626L);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.removeAgedItems((long) '#', false);
        boolean boolean9 = timeSeries3.isEmpty();
        java.lang.Comparable comparable10 = timeSeries3.getKey();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560182480608L);
        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("December 1");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.String str6 = timeSeries3.getDomainDescription();
//        double double7 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries11.addChangeListener(seriesChangeListener12);
//        timeSeries11.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries19.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
//        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener46 = null;
//        timeSeries45.addChangeListener(seriesChangeListener46);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries45.getDataItem((org.jfree.data.time.RegularTimePeriod) year49);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month((int) (byte) 10, year49);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener56 = null;
//        timeSeries55.addChangeListener(seriesChangeListener56);
//        timeSeries55.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries63.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar68 = null;
//        long long69 = fixedMillisecond67.getLastMillisecond(calendar68);
//        timeSeries66.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries75 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries75.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar80 = null;
//        long long81 = fixedMillisecond79.getLastMillisecond(calendar80);
//        timeSeries78.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond79, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries55.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond79);
//        java.lang.Number number85 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond79, number85);
//        boolean boolean87 = month51.equals((java.lang.Object) fixedMillisecond79);
//        java.lang.String str88 = month51.toString();
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem92 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month51, (double) 1560182475266L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = month51.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem95 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) 1560182510014L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem97 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month51, (java.lang.Number) 1560182548054L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560182551783L + "'", long25 == 1560182551783L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560182551784L + "'", long37 == 1560182551784L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560182551786L + "'", long69 == 1560182551786L);
//        org.junit.Assert.assertNotNull(timeSeries78);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560182551787L + "'", long81 == 1560182551787L);
//        org.junit.Assert.assertNotNull(timeSeries84);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "October 1" + "'", str88.equals("October 1"));
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//        org.junit.Assert.assertNull(timeSeriesDataItem97);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
//        timeSeries4.addChangeListener(seriesChangeListener5);
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
//        long long12 = month10.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long12);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(0, (int) (short) 0);
//        int int21 = timeSeries17.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar45 = null;
//        long long46 = fixedMillisecond44.getMiddleMillisecond(calendar45);
//        boolean boolean48 = fixedMillisecond44.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond44.previous();
//        boolean boolean50 = fixedMillisecond29.equals((java.lang.Object) regularTimePeriod49);
//        java.util.Date date51 = fixedMillisecond29.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date51);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51);
//        java.util.Date date54 = year53.getEnd();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year53, (java.lang.Number) 1560182491183L);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener61 = null;
//        timeSeries60.addChangeListener(seriesChangeListener61);
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries60.getDataItem((org.jfree.data.time.RegularTimePeriod) year64);
//        java.util.Date date66 = year64.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond(date66);
//        java.lang.Number number68 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
//        org.junit.Assert.assertNull(timeSeriesDataItem9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62109475200001L) + "'", long12 == (-62109475200001L));
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNull(number30);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182552115L + "'", long40 == 1560182552115L);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182552116L + "'", long46 == 1560182552116L);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 1560182491183L + "'", number68.equals(1560182491183L));
//    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.next();
//        long long44 = day41.getLastMillisecond();
//        java.lang.String str45 = day41.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day41.previous();
//        java.lang.String str47 = day41.toString();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182552563L + "'", long26 == 1560182552563L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182552564L + "'", long32 == 1560182552564L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "10-June-2019" + "'", str47.equals("10-June-2019"));
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.removeAgedItems((long) '#', false);
        boolean boolean9 = timeSeries3.isEmpty();
        java.lang.Comparable comparable10 = timeSeries3.getKey();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560182480608L);
        int int14 = month11.getYearValue();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = month11.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.Date date33 = fixedMillisecond27.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond34.next();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182552720L + "'", long17 == 1560182552720L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182552721L + "'", long29 == 1560182552721L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 10, year52);
//        long long55 = month54.getLastMillisecond();
//        long long56 = month54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month54.next();
//        long long58 = month54.getMiddleMillisecond();
//        boolean boolean59 = day41.equals((java.lang.Object) long58);
//        int int60 = day41.getDayOfMonth();
//        int int61 = day41.getDayOfMonth();
//        int int63 = day41.compareTo((java.lang.Object) 1560182481345L);
//        java.util.Calendar calendar64 = null;
//        try {
//            long long65 = day41.getLastMillisecond(calendar64);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182552787L + "'", long26 == 1560182552787L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182552788L + "'", long32 == 1560182552788L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62109475200001L) + "'", long55 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62112153600000L) + "'", long56 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62110814400001L) + "'", long58 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries7.addChangeListener(seriesChangeListener8);
//        timeSeries7.setNotify(false);
//        java.util.List list12 = timeSeries7.getItems();
//        long long13 = timeSeries7.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) year24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month((int) (byte) 10, year24);
//        long long27 = month26.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month26.next();
//        int int31 = fixedMillisecond0.compareTo((java.lang.Object) regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182552811L + "'", long2 == 1560182552811L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182552811L + "'", long3 == 1560182552811L);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223372036854775807L + "'", long13 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62112153600000L) + "'", long27 == (-62112153600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (-1.0d), seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        java.lang.Object obj6 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo7);
        java.lang.Object obj9 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertNull(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (-1.0d) + "'", obj6.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + obj9 + "' != '" + (-1.0d) + "'", obj9.equals((-1.0d)));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        long long11 = month10.getLastMillisecond();
        long long12 = month10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        int int15 = month10.compareTo((java.lang.Object) 1560182480467L);
        org.jfree.data.time.Year year16 = month10.getYear();
        java.util.Calendar calendar17 = null;
        try {
            year16.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62109475200001L) + "'", long11 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62112153600000L) + "'", long12 == (-62112153600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(year16);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=Mon Jun 10 09:01:28 PDT 2019]");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        long long31 = timeSeries3.getMaximumItemAge();
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.setMaximumItemAge(1560182477025L);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries39.createCopy(0, (int) (short) 0);
//        int int43 = timeSeries39.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries47.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries56.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond60.getLastMillisecond(calendar61);
//        timeSeries59.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        java.util.Date date66 = fixedMillisecond60.getEnd();
//        java.util.Date date67 = fixedMillisecond60.getEnd();
//        int int68 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent69 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        int int70 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year((int) (short) 0);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year72, (java.lang.Number) 1560182522257L);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182553492L + "'", long26 == 1560182553492L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560182553495L + "'", long62 == 1560182553495L);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 2147483647 + "'", int70 == 2147483647);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.removeAgedItems((long) '#', false);
//        boolean boolean9 = timeSeries3.isEmpty();
//        java.lang.Comparable comparable10 = timeSeries3.getKey();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560182480608L);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy(0, (int) (short) 0);
//        int int22 = timeSeries18.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number31 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries35.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getLastMillisecond(calendar40);
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        java.lang.Class<?> wildcardClass45 = timeSeries18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries51.addChangeListener(seriesChangeListener52);
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries51.getDataItem((org.jfree.data.time.RegularTimePeriod) year55);
//        timeSeries47.add((org.jfree.data.time.RegularTimePeriod) year55, (double) 1560182469650L, true);
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) year55, (double) (short) 100);
//        java.lang.String str62 = year55.toString();
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month((int) (byte) 1, year55);
//        long long64 = month63.getSerialIndex();
//        int int66 = month63.compareTo((java.lang.Object) 1560182485608L);
//        long long67 = month63.getLastMillisecond();
//        java.lang.Number number68 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month63);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560182553794L + "'", long41 == 1560182553794L);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1" + "'", str62.equals("1"));
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 13L + "'", long64 == 13L);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + (-62133062400001L) + "'", long67 == (-62133062400001L));
//        org.junit.Assert.assertNull(number68);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.previous();
//        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(serialDate44);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182554133L + "'", long26 == 1560182554133L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182554134L + "'", long32 == 1560182554134L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(serialDate44);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond19.getMiddleMillisecond(calendar20);
//        boolean boolean23 = fixedMillisecond19.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond19.previous();
//        int int25 = timeSeries12.getIndex(regularTimePeriod24);
//        timeSeries12.setMaximumItemCount(0);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560182554409L + "'", long21 == 1560182554409L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182475067L);
        java.lang.Class<?> wildcardClass2 = fixedMillisecond1.getClass();
        long long3 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182475067L + "'", long3 == 1560182475067L);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        double double9 = timeSeries3.getMinY();
//        timeSeries3.removeAgedItems(1560182491841L, false);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(0, (int) (short) 0);
//        int int20 = timeSeries16.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries24.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries33.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getLastMillisecond(calendar38);
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
//        java.lang.Class<?> wildcardClass43 = timeSeries16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener50 = null;
//        timeSeries49.addChangeListener(seriesChangeListener50);
//        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries49.getDataItem((org.jfree.data.time.RegularTimePeriod) year53);
//        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) year53, (double) 1560182469650L, true);
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year53, (double) (short) 100);
//        java.lang.String str60 = year53.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = year53.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod61, (java.lang.Number) 1560182476250L);
//        timeSeriesDataItem63.setValue((java.lang.Number) 1560182470204L);
//        timeSeries3.add(timeSeriesDataItem63);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560182554453L + "'", long39 == 1560182554453L);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "1" + "'", str60.equals("1"));
//        org.junit.Assert.assertNotNull(regularTimePeriod61);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond15.peg(calendar30);
//        long long32 = fixedMillisecond15.getFirstMillisecond();
//        java.util.Date date33 = fixedMillisecond15.getTime();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182554627L + "'", long26 == 1560182554627L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182554626L + "'", long32 == 1560182554626L);
//        org.junit.Assert.assertNotNull(date33);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        java.lang.String str12 = timeSeries6.getRangeDescription();
//        try {
//            timeSeries6.removeAgedItems(1560182510811L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182554687L + "'", long9 == 1560182554687L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        int int7 = timeSeries3.getItemCount();
        double double8 = timeSeries3.getMinY();
        java.util.List list9 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "hi!", "");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (double) (byte) 10);
        java.lang.Object obj17 = timeSeriesDataItem16.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem16.getPeriod();
        timeSeries13.add(timeSeriesDataItem16, true);
        java.lang.Number number21 = timeSeriesDataItem16.getValue();
        timeSeries3.add(timeSeriesDataItem16, false);
        int int25 = timeSeriesDataItem16.compareTo((java.lang.Object) 1560182489685L);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0d + "'", number21.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, (int) '#');
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (-2));
//        double double14 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((int) (byte) 0);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.addChangeListener(seriesChangeListener21);
//        java.lang.String str23 = timeSeries20.getDomainDescription();
//        java.util.List list24 = timeSeries20.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        boolean boolean29 = fixedMillisecond25.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date30 = fixedMillisecond25.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, 0.0d);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 1560182523599L);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries40.addChangeListener(seriesChangeListener41);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries40.getDataItem((org.jfree.data.time.RegularTimePeriod) year44);
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) year44, (double) 1560182469650L, true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (double) 1560182472016L);
//        long long51 = year44.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year44);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-2.0d) + "'", double14 == (-2.0d));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
//        org.junit.Assert.assertNotNull(list24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560182554868L + "'", long27 == 1560182554868L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(timeSeriesDataItem32);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-62104204800001L) + "'", long51 == (-62104204800001L));
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        java.util.Calendar calendar41 = null;
//        try {
//            month40.peg(calendar41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182554963L + "'", long26 == 1560182554963L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182554964L + "'", long32 == 1560182554964L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182485349L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        java.lang.String str6 = timeSeries3.getDomainDescription();
//        double double7 = timeSeries3.getMinY();
//        long long8 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        int int16 = timeSeries12.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number25 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries29.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getMiddleMillisecond(calendar40);
//        boolean boolean43 = fixedMillisecond39.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = fixedMillisecond39.previous();
//        boolean boolean45 = fixedMillisecond24.equals((java.lang.Object) regularTimePeriod44);
//        java.util.Date date46 = fixedMillisecond24.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date46);
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date46);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day50.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day50.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries3.addOrUpdate(regularTimePeriod52, (double) 1560182547391L);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182554988L + "'", long35 == 1560182554988L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560182554989L + "'", long41 == 1560182554989L);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        long long12 = month10.getLastMillisecond();
        org.jfree.data.time.Year year13 = month10.getYear();
        long long14 = year13.getSerialIndex();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62109475200001L) + "'", long12 == (-62109475200001L));
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        java.lang.String str9 = timeSeries3.getDomainDescription();
        timeSeries3.removeAgedItems((long) 6, false);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182513184L, "", "org.jfree.data.time.TimePeriodFormatException: ");
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        long long11 = month10.getLastMillisecond();
        long long12 = month10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = month10.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62109475200001L) + "'", long11 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62112153600000L) + "'", long12 == (-62112153600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries12);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener19);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries26.addChangeListener(seriesChangeListener27);
//        timeSeries26.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries46.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timeSeries26.removePropertyChangeListener(propertyChangeListener56);
//        timeSeries26.removeAgedItems(true);
//        timeSeries26.removeAgedItems(false);
//        boolean boolean62 = timeSeries26.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries3.addAndOrUpdate(timeSeries26);
//        java.beans.PropertyChangeListener propertyChangeListener64 = null;
//        timeSeries63.addPropertyChangeListener(propertyChangeListener64);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182555253L + "'", long40 == 1560182555253L);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560182555254L + "'", long52 == 1560182555254L);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(timeSeries63);
//    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 10, year39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
//        java.lang.Number number43 = timeSeries3.getValue(regularTimePeriod42);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries3.createCopy(8, (int) (short) 10);
//        java.lang.Object obj47 = timeSeries3.clone();
//        boolean boolean48 = timeSeries3.isEmpty();
//        timeSeries3.setNotify(true);
//        timeSeries3.setDescription("June 2019");
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182555349L + "'", long26 == 1560182555349L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNotNull(obj47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
//        boolean boolean10 = fixedMillisecond6.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date11 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
//        int int13 = fixedMillisecond0.compareTo((java.lang.Object) month12);
//        long long14 = month12.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182555469L + "'", long2 == 1560182555469L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182555470L + "'", long8 == 1560182555470L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1561964399999L + "'", long14 == 1561964399999L);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        long long33 = timeSeries3.getMaximumItemAge();
//        java.lang.Object obj34 = timeSeries3.clone();
//        java.beans.PropertyChangeListener propertyChangeListener35 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener35);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(1560182483175L);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries42.createCopy(0, (int) (short) 0);
//        int int46 = timeSeries42.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries50.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number55 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries59.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond63.getLastMillisecond(calendar64);
//        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar70 = null;
//        long long71 = fixedMillisecond69.getMiddleMillisecond(calendar70);
//        boolean boolean73 = fixedMillisecond69.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = fixedMillisecond69.previous();
//        boolean boolean75 = fixedMillisecond54.equals((java.lang.Object) regularTimePeriod74);
//        java.util.Date date76 = fixedMillisecond54.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond(date76);
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date76);
//        java.util.Date date79 = year78.getEnd();
//        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (org.jfree.data.time.RegularTimePeriod) year78);
//        long long81 = timeSeries3.getMaximumItemAge();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182555489L + "'", long17 == 1560182555489L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182555490L + "'", long29 == 1560182555490L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertNotNull(timeSeries62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560182555493L + "'", long65 == 1560182555493L);
//        org.junit.Assert.assertNotNull(timeSeries68);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560182555496L + "'", long71 == 1560182555496L);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertNotNull(timeSeries80);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 9223372036854775807L + "'", long81 == 9223372036854775807L);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        int int2 = day0.getDayOfMonth();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182484284L);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        boolean boolean13 = fixedMillisecond9.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date14 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month15.next();
//        int int17 = fixedMillisecond7.compareTo((java.lang.Object) regularTimePeriod16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond7.previous();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182555802L + "'", long11 == 1560182555802L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener30);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.addChangeListener(seriesChangeListener37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 10, year40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month42.previous();
//        long long44 = month42.getLastMillisecond();
//        org.jfree.data.time.Year year45 = month42.getYear();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year45);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries50.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number55 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = fixedMillisecond54.previous();
//        boolean boolean57 = year45.equals((java.lang.Object) fixedMillisecond54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year45.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year45.previous();
//        java.lang.Object obj60 = null;
//        int int61 = year45.compareTo(obj60);
//        boolean boolean63 = year45.equals((java.lang.Object) 1560182468982L);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182556037L + "'", long26 == 1560182556037L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62109475200001L) + "'", long44 == (-62109475200001L));
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        double double9 = timeSeries3.getMinY();
        boolean boolean11 = timeSeries3.equals((java.lang.Object) 1560182481933L);
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        timeSeries29.setMaximumItemAge((long) (byte) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond32.peg(calendar33);
//        long long35 = fixedMillisecond32.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560182513292L);
//        boolean boolean39 = fixedMillisecond32.equals((java.lang.Object) 1560182497262L);
//        boolean boolean41 = fixedMillisecond32.equals((java.lang.Object) 1560182503612L);
//        java.lang.String str42 = fixedMillisecond32.toString();
//        try {
//            timeSeries29.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560182498950L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182556239L + "'", long26 == 1560182556239L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182556240L + "'", long35 == 1560182556240L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Mon Jun 10 09:02:36 PDT 2019" + "'", str42.equals("Mon Jun 10 09:02:36 PDT 2019"));
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        long long33 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries38.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month((int) (byte) 10, year42);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year42, (java.lang.Number) 8);
//        int int47 = timeSeries3.getMaximumItemCount();
//        boolean boolean48 = timeSeries3.getNotify();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries3.addChangeListener(seriesChangeListener49);
//        java.util.List list51 = timeSeries3.getItems();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182556256L + "'", long17 == 1560182556256L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182556257L + "'", long29 == 1560182556257L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2147483647 + "'", int47 == 2147483647);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(list51);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 10, year39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
//        java.lang.Number number43 = timeSeries3.getValue(regularTimePeriod42);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries3.createCopy(8, (int) (short) 10);
//        java.lang.String str47 = timeSeries3.getDescription();
//        java.util.List list48 = timeSeries3.getItems();
//        timeSeries3.removeAgedItems(false);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182556368L + "'", long26 == 1560182556368L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNull(str47);
//        org.junit.Assert.assertNotNull(list48);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        long long11 = month10.getLastMillisecond();
        long long12 = month10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        int int15 = month10.compareTo((java.lang.Object) 1560182480467L);
        org.jfree.data.time.Year year16 = month10.getYear();
        long long17 = month10.getSerialIndex();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62109475200001L) + "'", long11 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62112153600000L) + "'", long12 == (-62112153600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(year16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 22L + "'", long17 == 22L);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
//        java.lang.Class<?> wildcardClass2 = seriesException1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries6.addChangeListener(seriesChangeListener7);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year10);
//        java.util.Date date12 = year10.getStart();
//        java.util.Date date13 = year10.getEnd();
//        java.util.TimeZone timeZone14 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date13, timeZone14);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries19.addChangeListener(seriesChangeListener20);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) year23);
//        java.util.Date date25 = year23.getStart();
//        java.util.Date date26 = year23.getEnd();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date26, timeZone29);
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries35.createCopy(0, (int) (short) 0);
//        int int39 = timeSeries35.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries43.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number48 = timeSeries43.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries52.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond56.getLastMillisecond(calendar57);
//        timeSeries55.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond56, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries35.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = fixedMillisecond56.next();
//        java.util.Date date63 = fixedMillisecond56.getEnd();
//        java.util.TimeZone timeZone64 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date63, timeZone64);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560182556531L + "'", long58 == 1560182556531L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 10, year39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
//        java.lang.Number number43 = timeSeries3.getValue(regularTimePeriod42);
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener44);
//        java.lang.Class class46 = timeSeries3.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries50.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number55 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond56.getMiddleMillisecond(calendar57);
//        boolean boolean60 = fixedMillisecond56.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date61 = fixedMillisecond56.getTime();
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(date61);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month62.next();
//        int int64 = fixedMillisecond54.compareTo((java.lang.Object) regularTimePeriod63);
//        timeSeries3.add(regularTimePeriod63, (java.lang.Number) 1560182481001L, true);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener68 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener68);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182556937L + "'", long26 == 1560182556937L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNull(class46);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560182556941L + "'", long58 == 1560182556941L);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener33);
//        timeSeries3.removeAgedItems(true);
//        timeSeries3.removeAgedItems(false);
//        java.lang.Class class39 = timeSeries3.getTimePeriodClass();
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener40);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182557113L + "'", long17 == 1560182557113L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182557113L + "'", long29 == 1560182557113L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(class39);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        java.util.List list8 = timeSeries3.getItems();
//        long long9 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy(0, (int) (short) 0);
//        int int18 = timeSeries14.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number27 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        java.lang.Class<?> wildcardClass41 = timeSeries14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries47.addChangeListener(seriesChangeListener48);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) year51);
//        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) year51, (double) 1560182469650L, true);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year51, (double) (short) 100);
//        java.lang.String str58 = year51.toString();
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month((int) (byte) 1, year51);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year51, (double) 1560182495367L, false);
//        java.util.Calendar calendar63 = null;
//        try {
//            long long64 = year51.getFirstMillisecond(calendar63);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560182557149L + "'", long37 == 1560182557149L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1" + "'", str58.equals("1"));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=-1.0]");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.removeAgedItems(false);
        timeSeries3.setKey((java.lang.Comparable) 1560182478518L);
        java.lang.Object obj10 = null;
        boolean boolean11 = timeSeries3.equals(obj10);
        java.lang.Comparable comparable12 = timeSeries3.getKey();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 1560182478518L + "'", comparable12.equals(1560182478518L));
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        long long31 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries35.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getLastMillisecond(calendar40);
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 0.0d);
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener44);
//        timeSeries38.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries50.addChangeListener(seriesChangeListener51);
//        timeSeries50.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries58.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
//        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries70.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar75 = null;
//        long long76 = fixedMillisecond74.getLastMillisecond(calendar75);
//        timeSeries73.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries79 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond74);
//        java.lang.Number number80 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond74, number80);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = timeSeriesDataItem81.getPeriod();
//        java.lang.Object obj83 = timeSeriesDataItem81.clone();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries38.addOrUpdate(timeSeriesDataItem81);
//        boolean boolean85 = timeSeriesDataItem81.isSelected();
//        java.lang.Number number86 = timeSeriesDataItem81.getValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = timeSeries3.addOrUpdate(timeSeriesDataItem81);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182557196L + "'", long26 == 1560182557196L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560182557197L + "'", long41 == 1560182557197L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560182557199L + "'", long64 == 1560182557199L);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560182557200L + "'", long76 == 1560182557200L);
//        org.junit.Assert.assertNotNull(timeSeries79);
//        org.junit.Assert.assertNotNull(regularTimePeriod82);
//        org.junit.Assert.assertNotNull(obj83);
//        org.junit.Assert.assertNull(timeSeriesDataItem84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNull(number86);
//        org.junit.Assert.assertNull(timeSeriesDataItem87);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries12);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener19);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries26.addChangeListener(seriesChangeListener27);
//        timeSeries26.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries46.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timeSeries26.removePropertyChangeListener(propertyChangeListener56);
//        timeSeries26.removeAgedItems(true);
//        timeSeries26.removeAgedItems(false);
//        boolean boolean62 = timeSeries26.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries3.addAndOrUpdate(timeSeries26);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = timeSeries26.getTimePeriod(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182557596L + "'", long40 == 1560182557596L);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560182557597L + "'", long52 == 1560182557597L);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(timeSeries63);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(false);
        java.util.List list8 = timeSeries3.getItems();
        long long9 = timeSeries3.getMaximumItemAge();
        try {
            java.lang.Number number11 = timeSeries3.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond24.next();
//        long long31 = fixedMillisecond24.getLastMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182557623L + "'", long26 == 1560182557623L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560182557623L + "'", long31 == 1560182557623L);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getLastMillisecond(calendar10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries16.createCopy(0, (int) (short) 0);
//        int int20 = timeSeries16.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries24.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number29 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries33.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getLastMillisecond(calendar38);
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
//        java.lang.Class<?> wildcardClass43 = timeSeries16.getClass();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 10, year52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = month54.previous();
//        java.lang.Number number56 = timeSeries16.getValue(regularTimePeriod55);
//        boolean boolean57 = timeSeries3.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(6, 3);
//        java.lang.String str61 = month60.toString();
//        java.lang.Number number62 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month60, number62);
//        org.junit.Assert.assertNull(timeSeriesDataItem8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182557674L + "'", long11 == 1560182557674L);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560182557676L + "'", long39 == 1560182557676L);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//        org.junit.Assert.assertNull(number56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "June 3" + "'", str61.equals("June 3"));
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(false);
        boolean boolean8 = timeSeries3.isEmpty();
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        long long11 = month10.getLastMillisecond();
        long long12 = month10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        int int15 = month10.compareTo((java.lang.Object) 1560182480467L);
        long long16 = month10.getSerialIndex();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62109475200001L) + "'", long11 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62112153600000L) + "'", long12 == (-62112153600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 22L + "'", long16 == 22L);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener12);
//        timeSeries6.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries18.addChangeListener(seriesChangeListener19);
//        timeSeries18.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getLastMillisecond(calendar31);
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries38.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getLastMillisecond(calendar43);
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
//        java.lang.Number number48 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, number48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem49.getPeriod();
//        java.lang.Object obj51 = timeSeriesDataItem49.clone();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries6.addOrUpdate(timeSeriesDataItem49);
//        java.lang.Object obj53 = timeSeriesDataItem49.clone();
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener58 = null;
//        timeSeries57.addChangeListener(seriesChangeListener58);
//        timeSeries57.setNotify(false);
//        java.util.List list62 = timeSeries57.getItems();
//        long long63 = timeSeries57.getMaximumItemAge();
//        int int64 = timeSeriesDataItem49.compareTo((java.lang.Object) long63);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182557889L + "'", long9 == 1560182557889L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182557891L + "'", long32 == 1560182557891L);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560182557892L + "'", long44 == 1560182557892L);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(obj53);
//        org.junit.Assert.assertNotNull(list62);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 9223372036854775807L + "'", long63 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number33);
//        java.util.Date date35 = fixedMillisecond27.getEnd();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182558023L + "'", long17 == 1560182558023L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182558024L + "'", long29 == 1560182558024L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(date35);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        timeSeries3.setRangeDescription("hi!");
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (-2));
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries17.addChangeListener(seriesChangeListener18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) year21);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy(0, (int) (short) 0);
//        int int30 = timeSeries26.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number39 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries43.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar48 = null;
//        long long49 = fixedMillisecond47.getLastMillisecond(calendar48);
//        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        java.lang.Class<?> wildcardClass53 = timeSeries26.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getMiddleMillisecond(calendar55);
//        boolean boolean58 = fixedMillisecond54.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond54.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, 0.0d);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent62 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 0.0d);
//        int int63 = year21.compareTo((java.lang.Object) seriesChangeEvent62);
//        long long64 = year21.getLastMillisecond();
//        java.lang.Number number65 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year21);
//        int int66 = year21.getYear();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNull(number39);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560182558091L + "'", long49 == 1560182558091L);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560182558092L + "'", long56 == 1560182558092L);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertNull(timeSeriesDataItem61);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-62104204800001L) + "'", long64 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + number65 + "' != '" + (-2.0d) + "'", number65.equals((-2.0d)));
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        java.util.List list8 = timeSeries3.getItems();
//        long long9 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries16.addChangeListener(seriesChangeListener17);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year20);
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month((int) (byte) 10, year20);
//        long long23 = month22.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month22.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month22.next();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries30.addChangeListener(seriesChangeListener31);
//        timeSeries30.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries38.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getLastMillisecond(calendar43);
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries50.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getLastMillisecond(calendar55);
//        timeSeries53.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        java.lang.String str60 = timeSeries59.getDescription();
//        java.lang.String str61 = timeSeries59.getRangeDescription();
//        timeSeries59.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond63.getMiddleMillisecond(calendar64);
//        boolean boolean67 = fixedMillisecond63.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date68 = fixedMillisecond63.getTime();
//        timeSeries59.setKey((java.lang.Comparable) date68);
//        int int70 = month22.compareTo((java.lang.Object) timeSeries59);
//        timeSeries59.clear();
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-62112153600000L) + "'", long23 == (-62112153600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560182558248L + "'", long44 == 1560182558248L);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560182558249L + "'", long56 == 1560182558249L);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertNull(str60);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560182558250L + "'", long65 == 1560182558250L);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
//        timeSeries35.addChangeListener(seriesChangeListener36);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year39);
//        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month((int) (byte) 10, year39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
//        java.lang.Number number43 = timeSeries3.getValue(regularTimePeriod42);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries3.createCopy(8, (int) (short) 10);
//        java.lang.String str47 = timeSeries3.getDescription();
//        int int48 = timeSeries3.getItemCount();
//        java.util.Collection collection49 = timeSeries3.getTimePeriods();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182558376L + "'", long26 == 1560182558376L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNull(str47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertNotNull(collection49);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "1");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries5.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getLastMillisecond(calendar12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy(0, (int) (short) 0);
//        int int22 = timeSeries18.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries26.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number31 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries35.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getLastMillisecond(calendar40);
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        java.lang.Class<?> wildcardClass45 = timeSeries18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries50.addChangeListener(seriesChangeListener51);
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries50.getDataItem((org.jfree.data.time.RegularTimePeriod) year54);
//        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month((int) (byte) 10, year54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month56.previous();
//        java.lang.Number number58 = timeSeries18.getValue(regularTimePeriod57);
//        boolean boolean59 = timeSeries5.equals((java.lang.Object) timeSeries18);
//        double double60 = timeSeries5.getMinY();
//        boolean boolean61 = timeSeries1.equals((java.lang.Object) double60);
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries65.createCopy(0, (int) (short) 0);
//        int int69 = timeSeries65.getItemCount();
//        timeSeries65.setRangeDescription("hi!");
//        timeSeries65.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries65.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (double) (-2));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182558525L + "'", long13 == 1560182558525L);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560182558529L + "'", long41 == 1560182558529L);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertNotNull(timeSeries68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem76);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getLastMillisecond(calendar1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond0.previous();
//        long long4 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182558775L + "'", long2 == 1560182558775L);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560182558775L + "'", long4 == 1560182558775L);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 1560182469272L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        boolean boolean26 = fixedMillisecond22.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date27 = fixedMillisecond22.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1560182472661L);
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener30);
//        timeSeries3.setMaximumItemAge(1560182496751L);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182558785L + "'", long17 == 1560182558785L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182558786L + "'", long24 == 1560182558786L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNull(timeSeriesDataItem29);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.Date date9 = year7.getStart();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date10);
        java.util.TimeZone timeZone13 = null;
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10, timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, "", "Value");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        boolean boolean4 = fixedMillisecond0.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182558848L + "'", long2 == 1560182558848L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.addChangeListener(seriesChangeListener37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year40);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) year40, (double) 1560182469650L, true);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year40, (double) (short) 100);
//        java.lang.String str47 = year40.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year40.previous();
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries52.createCopy(0, (int) (short) 0);
//        int int56 = timeSeries52.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries60.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number65 = timeSeries60.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
//        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries69.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar74 = null;
//        long long75 = fixedMillisecond73.getLastMillisecond(calendar74);
//        timeSeries72.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries78 = timeSeries52.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener79 = null;
//        timeSeries52.removeChangeListener(seriesChangeListener79);
//        double double81 = timeSeries52.getMaxY();
//        int int82 = year40.compareTo((java.lang.Object) timeSeries52);
//        java.util.Calendar calendar83 = null;
//        try {
//            long long84 = year40.getMiddleMillisecond(calendar83);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182558864L + "'", long26 == 1560182558864L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1" + "'", str47.equals("1"));
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertNull(number65);
//        org.junit.Assert.assertNotNull(timeSeries72);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1560182558869L + "'", long75 == 1560182558869L);
//        org.junit.Assert.assertNotNull(timeSeries78);
//        org.junit.Assert.assertEquals((double) double81, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.Date date33 = fixedMillisecond27.getTime();
//        long long34 = fixedMillisecond27.getLastMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182558885L + "'", long17 == 1560182558885L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182558886L + "'", long29 == 1560182558886L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182558886L + "'", long34 == 1560182558886L);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        java.util.List list12 = timeSeries6.getItems();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy(11, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182558932L + "'", long9 == 1560182558932L);
//        org.junit.Assert.assertNotNull(list12);
//    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(0, (int) (short) 0);
//        int int8 = timeSeries4.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        java.lang.Class<?> wildcardClass31 = timeSeries4.getClass();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.addChangeListener(seriesChangeListener37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 10, year40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month42.previous();
//        java.lang.Number number44 = timeSeries4.getValue(regularTimePeriod43);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries4.createCopy(8, (int) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries51.createCopy(0, (int) (short) 0);
//        int int55 = timeSeries51.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries59.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number64 = timeSeries59.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries68.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar73 = null;
//        long long74 = fixedMillisecond72.getLastMillisecond(calendar73);
//        timeSeries71.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond72, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond72);
//        java.lang.Class<?> wildcardClass78 = timeSeries51.getClass();
//        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener85 = null;
//        timeSeries84.addChangeListener(seriesChangeListener85);
//        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries84.getDataItem((org.jfree.data.time.RegularTimePeriod) year88);
//        timeSeries80.add((org.jfree.data.time.RegularTimePeriod) year88, (double) 1560182469650L, true);
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) year88, (double) (short) 100);
//        java.lang.String str95 = year88.toString();
//        java.lang.Number number96 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) year88);
//        org.jfree.data.time.Month month97 = new org.jfree.data.time.Month((int) (byte) 10, year88);
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560182558952L + "'", long27 == 1560182558952L);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNull(number44);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
//        org.junit.Assert.assertNotNull(timeSeries62);
//        org.junit.Assert.assertNull(number64);
//        org.junit.Assert.assertNotNull(timeSeries71);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560182558960L + "'", long74 == 1560182558960L);
//        org.junit.Assert.assertNotNull(timeSeries77);
//        org.junit.Assert.assertNotNull(wildcardClass78);
//        org.junit.Assert.assertNull(timeSeriesDataItem89);
//        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "1" + "'", str95.equals("1"));
//        org.junit.Assert.assertNull(number96);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 10, year52);
//        long long55 = month54.getLastMillisecond();
//        long long56 = month54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month54.next();
//        long long58 = month54.getMiddleMillisecond();
//        boolean boolean59 = day41.equals((java.lang.Object) long58);
//        int int60 = day41.getDayOfMonth();
//        int int61 = day41.getDayOfMonth();
//        int int63 = day41.compareTo((java.lang.Object) 1560182481345L);
//        long long64 = day41.getLastMillisecond();
//        int int65 = day41.getDayOfMonth();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182559412L + "'", long26 == 1560182559412L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182559412L + "'", long32 == 1560182559412L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62109475200001L) + "'", long55 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62112153600000L) + "'", long56 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62110814400001L) + "'", long58 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560236399999L + "'", long64 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 10 + "'", int65 == 10);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (double) 1560182469650L, true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (double) 1560182472016L);
        long long16 = year9.getLastMillisecond();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year9.getLastMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-62104204800001L) + "'", long16 == (-62104204800001L));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(false);
        java.util.List list8 = timeSeries3.getItems();
        long long9 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) year18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month((int) (byte) 10, year18);
        java.util.Date date21 = year18.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year18.next();
        int int23 = timeSeries3.getIndex(regularTimePeriod22);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener33);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries38.addChangeListener(seriesChangeListener39);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) year42);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries47.createCopy(0, (int) (short) 0);
//        int int51 = timeSeries47.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries55.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number60 = timeSeries55.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries64.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar69 = null;
//        long long70 = fixedMillisecond68.getLastMillisecond(calendar69);
//        timeSeries67.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
//        java.lang.Class<?> wildcardClass74 = timeSeries47.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar76 = null;
//        long long77 = fixedMillisecond75.getMiddleMillisecond(calendar76);
//        boolean boolean79 = fixedMillisecond75.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = fixedMillisecond75.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, 0.0d);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent83 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 0.0d);
//        int int84 = year42.compareTo((java.lang.Object) seriesChangeEvent83);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year42);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182559792L + "'", long17 == 1560182559792L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182559793L + "'", long29 == 1560182559793L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertNull(number60);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1560182559797L + "'", long70 == 1560182559797L);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertNotNull(wildcardClass74);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560182559798L + "'", long77 == 1560182559798L);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod80);
//        org.junit.Assert.assertNull(timeSeriesDataItem82);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        java.lang.Object obj7 = timeSeries3.clone();
        int int8 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        long long33 = fixedMillisecond15.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182560194L + "'", long17 == 1560182560194L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182560195L + "'", long29 == 1560182560195L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560182560194L + "'", long33 == 1560182560194L);
//    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number33);
//        long long35 = fixedMillisecond27.getLastMillisecond();
//        java.util.Date date36 = fixedMillisecond27.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond37.getMiddleMillisecond(calendar38);
//        boolean boolean41 = fixedMillisecond37.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond37.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond43.getMiddleMillisecond(calendar44);
//        boolean boolean47 = fixedMillisecond43.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date48 = fixedMillisecond43.getTime();
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date48);
//        int int50 = fixedMillisecond37.compareTo((java.lang.Object) month49);
//        boolean boolean51 = fixedMillisecond27.equals((java.lang.Object) fixedMillisecond37);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182560239L + "'", long17 == 1560182560239L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182560239L + "'", long29 == 1560182560239L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182560239L + "'", long35 == 1560182560239L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560182560241L + "'", long39 == 1560182560241L);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560182560242L + "'", long45 == 1560182560242L);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.lang.Class<?> wildcardClass30 = timeSeries3.getClass();
//        long long31 = timeSeries3.getMaximumItemAge();
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.fireSeriesChanged();
//        timeSeries3.setMaximumItemAge(1560182477025L);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries39.createCopy(0, (int) (short) 0);
//        int int43 = timeSeries39.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries47.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries56.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar61 = null;
//        long long62 = fixedMillisecond60.getLastMillisecond(calendar61);
//        timeSeries59.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries65 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        java.util.Date date66 = fixedMillisecond60.getEnd();
//        java.util.Date date67 = fixedMillisecond60.getEnd();
//        int int68 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60);
//        timeSeries3.setDescription("");
//        java.lang.Object obj71 = timeSeries3.clone();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182560444L + "'", long26 == 1560182560444L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560182560449L + "'", long62 == 1560182560449L);
//        org.junit.Assert.assertNotNull(timeSeries65);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
//        org.junit.Assert.assertNotNull(obj71);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        int int7 = timeSeries3.getItemCount();
        double double8 = timeSeries3.getMinY();
        double double9 = timeSeries3.getMinY();
        int int10 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.lang.String str3 = year1.toString();
        int int5 = year1.compareTo((java.lang.Object) 1560182508525L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        long long11 = month10.getLastMillisecond();
        long long12 = month10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        long long14 = month10.getMiddleMillisecond();
        org.jfree.data.time.Year year15 = month10.getYear();
        java.util.Calendar calendar16 = null;
        try {
            year15.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62109475200001L) + "'", long11 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62112153600000L) + "'", long12 == (-62112153600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-62110814400001L) + "'", long14 == (-62110814400001L));
        org.junit.Assert.assertNotNull(year15);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = timeSeries4.createCopy(0, (int) (short) 0);
//        int int8 = timeSeries4.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries21.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getLastMillisecond(calendar26);
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
//        java.lang.Class<?> wildcardClass31 = timeSeries4.getClass();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries37.addChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year41, (double) 1560182469650L, true);
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year41, (double) (short) 100);
//        java.lang.String str48 = year41.toString();
//        try {
//            org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(0, year41);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560182560925L + "'", long27 == 1560182560925L);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "1" + "'", str48.equals("1"));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(12, year2);
        java.lang.String str4 = month3.toString();
        long long5 = month3.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            month3.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "December 1" + "'", str4.equals("December 1"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62106883200000L) + "'", long5 == (-62106883200000L));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 09:02:28 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 10, year52);
//        long long55 = month54.getLastMillisecond();
//        long long56 = month54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month54.next();
//        long long58 = month54.getMiddleMillisecond();
//        boolean boolean59 = day41.equals((java.lang.Object) long58);
//        int int60 = day41.getDayOfMonth();
//        int int61 = day41.getDayOfMonth();
//        int int62 = day41.getYear();
//        int int63 = day41.getMonth();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182561128L + "'", long26 == 1560182561128L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182561129L + "'", long32 == 1560182561129L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62109475200001L) + "'", long55 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62112153600000L) + "'", long56 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62110814400001L) + "'", long58 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2019 + "'", int62 == 2019);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 6 + "'", int63 == 6);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(false);
        timeSeries3.setKey((java.lang.Comparable) 1560182468443L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.addChangeListener(seriesChangeListener10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.removeChangeListener(seriesChangeListener12);
        double double14 = timeSeries3.getMinY();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182543112L, "January 1", "");
//        boolean boolean41 = fixedMillisecond15.equals((java.lang.Object) "");
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182561310L + "'", long26 == 1560182561310L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182561311L + "'", long32 == 1560182561311L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod11, 0.0d);
        timeSeriesDataItem13.setSelected(true);
        boolean boolean17 = timeSeriesDataItem13.equals((java.lang.Object) 1560182504624L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        java.util.Calendar calendar30 = null;
//        fixedMillisecond15.peg(calendar30);
//        long long32 = fixedMillisecond15.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 1560182496213L);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem34);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo36 = null;
//        seriesChangeEvent35.setSummary(seriesChangeInfo36);
//        java.lang.String str38 = seriesChangeEvent35.toString();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182561392L + "'", long26 == 1560182561392L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182561391L + "'", long32 == 1560182561391L);
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "hi!", "");
//        java.lang.Class class4 = timeSeries3.getTimePeriodClass();
//        timeSeries3.setKey((java.lang.Comparable) 1560182513870L);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
//        timeSeries10.addChangeListener(seriesChangeListener11);
//        timeSeries10.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries18.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getLastMillisecond(calendar23);
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries30.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getLastMillisecond(calendar35);
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        java.lang.Number number40 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, number40);
//        java.util.Date date42 = fixedMillisecond34.getEnd();
//        long long43 = fixedMillisecond34.getFirstMillisecond();
//        int int44 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        try {
//            timeSeries3.delete((int) '#', (int) '4', true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(class4);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182561450L + "'", long24 == 1560182561450L);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182561451L + "'", long36 == 1560182561451L);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560182561451L + "'", long43 == 1560182561451L);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "October 1", "Value");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener4);
        java.util.List list6 = timeSeries3.getItems();
        timeSeries3.setMaximumItemAge(1560182532991L);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries3.removeChangeListener(seriesChangeListener19);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(false);
        timeSeries3.setKey((java.lang.Comparable) 1560182468443L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.addChangeListener(seriesChangeListener10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.removeChangeListener(seriesChangeListener12);
        timeSeries3.setMaximumItemAge(1560182540819L);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries37.addChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries37.getDataItem((org.jfree.data.time.RegularTimePeriod) year41);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month((int) (byte) 10, year41);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries47.addChangeListener(seriesChangeListener48);
//        timeSeries47.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries55.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond59.getLastMillisecond(calendar60);
//        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries67.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar72 = null;
//        long long73 = fixedMillisecond71.getLastMillisecond(calendar72);
//        timeSeries70.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond71);
//        java.lang.Number number77 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond71, number77);
//        boolean boolean79 = month43.equals((java.lang.Object) fixedMillisecond71);
//        java.lang.String str80 = month43.toString();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month43, (double) 1560182475266L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = month43.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem87 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 1560182510014L);
//        boolean boolean88 = timeSeriesDataItem87.isSelected();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182561549L + "'", long17 == 1560182561549L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182561550L + "'", long29 == 1560182561550L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560182561552L + "'", long61 == 1560182561552L);
//        org.junit.Assert.assertNotNull(timeSeries70);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560182561553L + "'", long73 == 1560182561553L);
//        org.junit.Assert.assertNotNull(timeSeries76);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "October 1" + "'", str80.equals("October 1"));
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(12, year44);
//        int int46 = month45.getMonth();
//        long long47 = month45.getFirstMillisecond();
//        int int48 = day41.compareTo((java.lang.Object) long47);
//        long long49 = day41.getSerialIndex();
//        int int50 = day41.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = day41.previous();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries55.createCopy(0, (int) (short) 0);
//        int int59 = timeSeries55.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries63.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number68 = timeSeries63.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67);
//        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries75 = timeSeries72.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar77 = null;
//        long long78 = fixedMillisecond76.getLastMillisecond(calendar77);
//        timeSeries75.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond76, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries55.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond67, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond76);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar83 = null;
//        long long84 = fixedMillisecond82.getMiddleMillisecond(calendar83);
//        boolean boolean86 = fixedMillisecond82.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = fixedMillisecond82.previous();
//        boolean boolean88 = fixedMillisecond67.equals((java.lang.Object) regularTimePeriod87);
//        java.util.Date date89 = fixedMillisecond67.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond90 = new org.jfree.data.time.FixedMillisecond(date89);
//        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date89);
//        org.jfree.data.time.Month month92 = new org.jfree.data.time.Month(date89);
//        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date89);
//        org.jfree.data.time.SerialDate serialDate94 = day93.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod95 = day93.previous();
//        org.jfree.data.time.SerialDate serialDate96 = day93.getSerialDate();
//        boolean boolean97 = day41.equals((java.lang.Object) day93);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182561892L + "'", long26 == 1560182561892L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182561893L + "'", long32 == 1560182561893L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 12 + "'", int46 == 12);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-62106883200000L) + "'", long47 == (-62106883200000L));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43626L + "'", long49 == 43626L);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertNull(number68);
//        org.junit.Assert.assertNotNull(timeSeries75);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560182561915L + "'", long78 == 1560182561915L);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560182561916L + "'", long84 == 1560182561916L);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertNotNull(serialDate94);
//        org.junit.Assert.assertNotNull(regularTimePeriod95);
//        org.junit.Assert.assertNotNull(serialDate96);
//        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 10, year52);
//        long long55 = month54.getLastMillisecond();
//        long long56 = month54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month54.next();
//        long long58 = month54.getMiddleMillisecond();
//        boolean boolean59 = day41.equals((java.lang.Object) long58);
//        int int60 = day41.getDayOfMonth();
//        int int61 = day41.getMonth();
//        java.util.Calendar calendar62 = null;
//        try {
//            day41.peg(calendar62);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182562944L + "'", long26 == 1560182562944L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182562945L + "'", long32 == 1560182562945L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62109475200001L) + "'", long55 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62112153600000L) + "'", long56 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62110814400001L) + "'", long58 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (double) 1560182469650L, true);
        double double14 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        java.lang.String str21 = timeSeries18.getDomainDescription();
        java.util.List list22 = timeSeries18.getItems();
        java.util.Collection collection23 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        timeSeries1.removeAgedItems(1560182497633L, false);
        timeSeries1.update(0, (java.lang.Number) 1560182541786L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.56018246965E12d + "'", double14 == 1.56018246965E12d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(collection23);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries12);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener19);
        java.lang.Class<?> wildcardClass21 = timeSeries3.getClass();
        org.junit.Assert.assertNotNull(timeSeries6);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries5.addChangeListener(seriesChangeListener6);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (double) 1560182469650L, true);
//        double double14 = timeSeries1.getMaxY();
//        java.lang.String str15 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries19.createCopy(0, (int) (short) 0);
//        int int23 = timeSeries19.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries27.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number32 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries36.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getLastMillisecond(calendar41);
//        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond40);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
//        boolean boolean50 = fixedMillisecond46.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = fixedMillisecond46.previous();
//        boolean boolean52 = fixedMillisecond31.equals((java.lang.Object) regularTimePeriod51);
//        java.util.Date date53 = fixedMillisecond31.getTime();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date53);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year54, (double) 22L, true);
//        timeSeries1.fireSeriesChanged();
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.56018246965E12d + "'", double14 == 1.56018246965E12d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Value" + "'", str15.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNull(number32);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182563053L + "'", long42 == 1560182563053L);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560182563053L + "'", long48 == 1560182563053L);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(date53);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener30);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.addChangeListener(seriesChangeListener37);
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) year40);
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month((int) (byte) 10, year40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month42.previous();
//        long long44 = month42.getLastMillisecond();
//        org.jfree.data.time.Year year45 = month42.getYear();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year45);
//        java.lang.String str47 = timeSeries3.getDomainDescription();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182563166L + "'", long26 == 1560182563166L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-62109475200001L) + "'", long44 == (-62109475200001L));
//        org.junit.Assert.assertNotNull(year45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.Date date33 = fixedMillisecond27.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener39 = null;
//        timeSeries38.addChangeListener(seriesChangeListener39);
//        timeSeries38.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries46.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries61 = timeSeries58.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond62.getLastMillisecond(calendar63);
//        timeSeries61.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond62, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond62);
//        java.beans.PropertyChangeListener propertyChangeListener68 = null;
//        timeSeries38.removePropertyChangeListener(propertyChangeListener68);
//        timeSeries38.removeAgedItems(true);
//        timeSeries38.removeAgedItems(false);
//        boolean boolean74 = timeSeries38.getNotify();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        long long76 = day75.getFirstMillisecond();
//        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) day75);
//        long long78 = day75.getLastMillisecond();
//        boolean boolean79 = fixedMillisecond34.equals((java.lang.Object) long78);
//        java.util.Calendar calendar80 = null;
//        long long81 = fixedMillisecond34.getLastMillisecond(calendar80);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182563578L + "'", long17 == 1560182563578L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182563579L + "'", long29 == 1560182563579L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560182563581L + "'", long52 == 1560182563581L);
//        org.junit.Assert.assertNotNull(timeSeries61);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560182563582L + "'", long64 == 1560182563582L);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560150000000L + "'", long76 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560236399999L + "'", long78 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560182563579L + "'", long81 == 1560182563579L);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        java.util.List list8 = timeSeries3.getItems();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        int int16 = timeSeries12.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number25 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries29.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getLastMillisecond(calendar34);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond33.next();
//        timeSeries3.add(regularTimePeriod39, (java.lang.Number) 1560182469649L, false);
//        java.lang.Comparable comparable43 = timeSeries3.getKey();
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182563768L + "'", long35 == 1560182563768L);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + 0.0f + "'", comparable43.equals(0.0f));
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(12, year2);
        int int4 = month3.getMonth();
        long long5 = month3.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            month3.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62105544000001L) + "'", long5 == (-62105544000001L));
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        java.util.Calendar calendar43 = null;
//        try {
//            long long44 = day41.getFirstMillisecond(calendar43);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182563873L + "'", long26 == 1560182563873L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182563874L + "'", long32 == 1560182563874L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        int int30 = timeSeries3.getItemCount();
//        java.util.List list31 = timeSeries3.getItems();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = timeSeries3.getTimePeriod((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182563906L + "'", long26 == 1560182563906L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(list31);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.next();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62104204800001L) + "'", long9 == (-62104204800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.next();
//        long long44 = day41.getLastMillisecond();
//        java.lang.String str45 = day41.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day41.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day41.next();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182564087L + "'", long26 == 1560182564087L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182564088L + "'", long32 == 1560182564088L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("September 1");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number8 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries12.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number17 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
//        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries12);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener19);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener21);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries26.addChangeListener(seriesChangeListener27);
//        timeSeries26.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries46.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar51 = null;
//        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries26.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        java.beans.PropertyChangeListener propertyChangeListener56 = null;
//        timeSeries26.removePropertyChangeListener(propertyChangeListener56);
//        timeSeries26.removeAgedItems(true);
//        timeSeries26.removeAgedItems(false);
//        boolean boolean62 = timeSeries26.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries3.addAndOrUpdate(timeSeries26);
//        java.lang.String str64 = timeSeries3.getDescription();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182564400L + "'", long40 == 1560182564400L);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560182564401L + "'", long52 == 1560182564401L);
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(timeSeries63);
//        org.junit.Assert.assertNull(str64);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month10.previous();
        long long12 = month10.getSerialIndex();
        java.lang.String str13 = month10.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 1560182539890L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 22L + "'", long12 == 22L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "October 1" + "'", str13.equals("October 1"));
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day41.next();
//        java.lang.String str44 = day41.toString();
//        org.jfree.data.time.SerialDate serialDate45 = day41.getSerialDate();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182564569L + "'", long26 == 1560182564569L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182564570L + "'", long32 == 1560182564570L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate45);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 09:01:59 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year8.next();
        java.lang.String str13 = year8.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Class<?> wildcardClass4 = seriesException3.getClass();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.addChangeListener(seriesChangeListener10);
        java.lang.String str12 = timeSeries9.getDomainDescription();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("");
        boolean boolean15 = timeSeries9.equals((java.lang.Object) timePeriodFormatException14);
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable[] throwableArray17 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        long long33 = timeSeries3.getMaximumItemAge();
//        java.lang.Object obj34 = timeSeries3.clone();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries38.createCopy(0, (int) (short) 0);
//        int int42 = timeSeries38.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries46.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number51 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries55.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar60 = null;
//        long long61 = fixedMillisecond59.getLastMillisecond(calendar60);
//        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries64 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar66 = null;
//        long long67 = fixedMillisecond65.getMiddleMillisecond(calendar66);
//        boolean boolean69 = fixedMillisecond65.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond65.previous();
//        boolean boolean71 = fixedMillisecond50.equals((java.lang.Object) regularTimePeriod70);
//        java.util.Date date72 = fixedMillisecond50.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond(date72);
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date72);
//        java.util.Date date75 = year74.getEnd();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year74, (java.lang.Number) 1560182484284L);
//        java.util.Calendar calendar78 = null;
//        try {
//            long long79 = year74.getFirstMillisecond(calendar78);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182564884L + "'", long17 == 1560182564884L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182564889L + "'", long29 == 1560182564889L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 9223372036854775807L + "'", long33 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNull(number51);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560182564893L + "'", long61 == 1560182564893L);
//        org.junit.Assert.assertNotNull(timeSeries64);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560182564894L + "'", long67 == 1560182564894L);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(date75);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener30);
//        double double32 = timeSeries3.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries36.addChangeListener(seriesChangeListener37);
//        java.lang.String str39 = timeSeries36.getDomainDescription();
//        java.util.List list40 = timeSeries36.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        boolean boolean45 = fixedMillisecond41.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date46 = fixedMillisecond41.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, 0.0d);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 1560182469940L, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = fixedMillisecond41.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod52, (double) 1560182548172L);
//        boolean boolean55 = timeSeriesDataItem54.isSelected();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182564917L + "'", long26 == 1560182564917L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertNotNull(list40);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560182564919L + "'", long43 == 1560182564919L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = timeSeriesDataItem34.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries39.addChangeListener(seriesChangeListener40);
//        timeSeries39.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries47.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond51.getLastMillisecond(calendar52);
//        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries59.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar64 = null;
//        long long65 = fixedMillisecond63.getLastMillisecond(calendar64);
//        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond63);
//        java.lang.Number number69 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond63, number69);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = timeSeriesDataItem70.getPeriod();
//        boolean boolean72 = timeSeriesDataItem34.equals((java.lang.Object) timeSeriesDataItem70);
//        timeSeriesDataItem34.setValue((java.lang.Number) 1560182475350L);
//        java.lang.Object obj75 = null;
//        int int76 = timeSeriesDataItem34.compareTo(obj75);
//        java.lang.Object obj77 = timeSeriesDataItem34.clone();
//        java.lang.Class<?> wildcardClass78 = timeSeriesDataItem34.getClass();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182565030L + "'", long17 == 1560182565030L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182565031L + "'", long29 == 1560182565031L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560182565033L + "'", long53 == 1560182565033L);
//        org.junit.Assert.assertNotNull(timeSeries62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560182565034L + "'", long65 == 1560182565034L);
//        org.junit.Assert.assertNotNull(timeSeries68);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertNotNull(obj77);
//        org.junit.Assert.assertNotNull(wildcardClass78);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.String str33 = timeSeries32.getDescription();
//        java.lang.String str34 = timeSeries32.getRangeDescription();
//        timeSeries32.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getMiddleMillisecond(calendar37);
//        boolean boolean40 = fixedMillisecond36.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date41 = fixedMillisecond36.getTime();
//        timeSeries32.setKey((java.lang.Comparable) date41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date41);
//        java.util.TimeZone timeZone44 = null;
//        try {
//            org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date41, timeZone44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182565317L + "'", long17 == 1560182565317L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182565318L + "'", long29 == 1560182565318L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560182565319L + "'", long38 == 1560182565319L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(date41);
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (java.lang.Number) 1560182469272L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        boolean boolean26 = fixedMillisecond22.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date27 = fixedMillisecond22.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1560182472661L);
//        java.lang.Class<?> wildcardClass30 = fixedMillisecond22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.createCopy(0, (int) (short) 0);
//        int int38 = timeSeries34.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries42.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number47 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries51.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond55.getLastMillisecond(calendar56);
//        timeSeries54.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries60 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond61.getMiddleMillisecond(calendar62);
//        boolean boolean65 = fixedMillisecond61.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = fixedMillisecond61.previous();
//        boolean boolean67 = fixedMillisecond46.equals((java.lang.Object) regularTimePeriod66);
//        java.util.Date date68 = fixedMillisecond46.getTime();
//        java.util.TimeZone timeZone69 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date68, timeZone69);
//        java.util.TimeZone timeZone71 = null;
//        java.util.Locale locale72 = null;
//        try {
//            org.jfree.data.time.Month month73 = new org.jfree.data.time.Month(date68, timeZone71, locale72);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182565344L + "'", long17 == 1560182565344L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182565344L + "'", long24 == 1560182565344L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertNull(number47);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182565352L + "'", long57 == 1560182565352L);
//        org.junit.Assert.assertNotNull(timeSeries60);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560182565353L + "'", long63 == 1560182565353L);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertNull(regularTimePeriod70);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year9, (double) 1560182469650L, true);
        double double14 = timeSeries1.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.addChangeListener(seriesChangeListener19);
        java.lang.String str21 = timeSeries18.getDomainDescription();
        java.util.List list22 = timeSeries18.getItems();
        java.util.Collection collection23 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        timeSeries1.removeAgedItems(1560182494186L, true);
        timeSeries1.removeAgedItems(0L, false);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.56018246965E12d + "'", double14 == 1.56018246965E12d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(collection23);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.Number number33 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, number33);
//        long long35 = fixedMillisecond27.getLastMillisecond();
//        java.util.Date date36 = fixedMillisecond27.getStart();
//        long long37 = fixedMillisecond27.getSerialIndex();
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182565399L + "'", long17 == 1560182565399L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182565400L + "'", long29 == 1560182565400L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182565400L + "'", long35 == 1560182565400L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560182565400L + "'", long37 == 1560182565400L);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        timeSeries3.removeAgedItems((long) '#', false);
        boolean boolean9 = timeSeries3.isEmpty();
        java.lang.Comparable comparable10 = timeSeries3.getKey();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) 1560182480608L);
        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
        try {
            timeSeries3.delete((int) (short) -1, (-1), false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 0.0f + "'", comparable10.equals(0.0f));
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(class14);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        long long39 = fixedMillisecond38.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long39);
//        java.lang.Object obj41 = timeSeries40.clone();
//        boolean boolean42 = timeSeries40.isEmpty();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182565480L + "'", long26 == 1560182565480L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182565481L + "'", long32 == 1560182565481L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560182565479L + "'", long39 == 1560182565479L);
//        org.junit.Assert.assertNotNull(obj41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) 100, "October 1", "Value");
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = day0.compareTo((java.lang.Object) timeSeries5);
//        try {
//            timeSeries5.update((int) (short) 100, (java.lang.Number) 1560182531830L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560150000000L + "'", long1 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getLastMillisecond(calendar8);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener12);
//        timeSeries6.fireSeriesChanged();
//        java.lang.Class class15 = timeSeries6.getTimePeriodClass();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182565606L + "'", long9 == 1560182565606L);
//        org.junit.Assert.assertNotNull(class15);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182503170L);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        long long39 = fixedMillisecond38.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long39);
//        timeSeries40.removeAgedItems(true);
//        java.lang.Class class43 = timeSeries40.getTimePeriodClass();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(12, year46);
//        long long48 = year46.getFirstMillisecond();
//        timeSeries40.delete((org.jfree.data.time.RegularTimePeriod) year46);
//        java.util.Calendar calendar50 = null;
//        try {
//            long long51 = year46.getLastMillisecond(calendar50);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182565636L + "'", long26 == 1560182565636L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182565637L + "'", long32 == 1560182565637L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560182565632L + "'", long39 == 1560182565632L);
//        org.junit.Assert.assertNull(class43);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-62135740800000L) + "'", long48 == (-62135740800000L));
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond30.getMiddleMillisecond(calendar31);
//        boolean boolean34 = fixedMillisecond30.equals((java.lang.Object) 1560182468132L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond30.previous();
//        boolean boolean36 = fixedMillisecond15.equals((java.lang.Object) regularTimePeriod35);
//        java.util.Date date37 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date37);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date37);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        int int43 = day41.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
//        timeSeries48.addChangeListener(seriesChangeListener49);
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.getDataItem((org.jfree.data.time.RegularTimePeriod) year52);
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month((int) (byte) 10, year52);
//        long long55 = month54.getLastMillisecond();
//        long long56 = month54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = month54.next();
//        long long58 = month54.getMiddleMillisecond();
//        boolean boolean59 = day41.equals((java.lang.Object) long58);
//        int int60 = day41.getDayOfMonth();
//        long long61 = day41.getMiddleMillisecond();
//        long long62 = day41.getFirstMillisecond();
//        long long63 = day41.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182565655L + "'", long26 == 1560182565655L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182565656L + "'", long32 == 1560182565656L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-62109475200001L) + "'", long55 == (-62109475200001L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-62112153600000L) + "'", long56 == (-62112153600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62110814400001L) + "'", long58 == (-62110814400001L));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 10 + "'", int60 == 10);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560193199999L + "'", long61 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560150000000L + "'", long62 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560150000000L + "'", long63 == 1560150000000L);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test231");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getFirstMillisecond(calendar3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182489919L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182565918L + "'", long2 == 1560182565918L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560182565918L + "'", long4 == 1560182565918L);
//    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test232");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "hi!", "");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (double) (byte) 10);
//        java.lang.Object obj7 = timeSeriesDataItem6.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeriesDataItem6.getPeriod();
//        timeSeries3.add(timeSeriesDataItem6, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (byte) 10);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries17.createCopy(0, (int) (short) 0);
//        int int21 = timeSeries17.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries25.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number30 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries34.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar39 = null;
//        long long40 = fixedMillisecond38.getLastMillisecond(calendar39);
//        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries17.removeChangeListener(seriesChangeListener44);
//        double double46 = timeSeries17.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries50.addChangeListener(seriesChangeListener51);
//        java.lang.String str53 = timeSeries50.getDomainDescription();
//        java.util.List list54 = timeSeries50.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar56 = null;
//        long long57 = fixedMillisecond55.getMiddleMillisecond(calendar56);
//        boolean boolean59 = fixedMillisecond55.equals((java.lang.Object) 1560182468132L);
//        java.util.Date date60 = fixedMillisecond55.getTime();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, 0.0d);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (double) 1560182469940L, false);
//        int int66 = timeSeriesDataItem13.compareTo((java.lang.Object) 1560182469940L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries3.addOrUpdate(timeSeriesDataItem13);
//        java.lang.Object obj68 = timeSeriesDataItem13.clone();
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNull(number30);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182565933L + "'", long40 == 1560182565933L);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
//        org.junit.Assert.assertNotNull(list54);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182565936L + "'", long57 == 1560182565936L);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNotNull(obj68);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        long long11 = month10.getFirstMillisecond();
        boolean boolean13 = month10.equals((java.lang.Object) 1560182483177L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62112153600000L) + "'", long11 == (-62112153600000L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        java.util.List list8 = timeSeries3.getItems();
//        long long9 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy(0, (int) (short) 0);
//        int int18 = timeSeries14.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries22.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number27 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries31.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getLastMillisecond(calendar36);
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        java.lang.Class<?> wildcardClass41 = timeSeries14.getClass();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
//        timeSeries47.addChangeListener(seriesChangeListener48);
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) year51);
//        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) year51, (double) 1560182469650L, true);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) year51, (double) (short) 100);
//        java.lang.String str58 = year51.toString();
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month((int) (byte) 1, year51);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year51, (double) 1560182495367L, false);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year51.next();
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560182566379L + "'", long37 == 1560182566379L);
//        org.junit.Assert.assertNotNull(timeSeries40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "1" + "'", str58.equals("1"));
//        org.junit.Assert.assertNotNull(regularTimePeriod63);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
//        timeSeries3.addChangeListener(seriesChangeListener4);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getLastMillisecond(calendar16);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        timeSeries32.setMaximumItemAge(1560182539039L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = null;
//        try {
//            timeSeries32.add(regularTimePeriod35, (double) 1560182497032L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182566626L + "'", long17 == 1560182566626L);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182566627L + "'", long29 == 1560182566627L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        long long2 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        java.lang.String str6 = timeSeries3.getDomainDescription();
        java.util.List list7 = timeSeries3.getItems();
        timeSeries3.removeAgedItems(1560182473166L, false);
        timeSeries3.setMaximumItemAge(1560182480788L);
        boolean boolean13 = timeSeries3.isEmpty();
        double double14 = timeSeries3.getMinY();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182485349L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182485349L + "'", long3 == 1560182485349L);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(0, (int) (short) 0);
//        int int7 = timeSeries3.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries11.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number16 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries20.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getLastMillisecond(calendar25);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond24.next();
//        java.util.Calendar calendar31 = null;
//        long long32 = fixedMillisecond24.getLastMillisecond(calendar31);
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond24.getFirstMillisecond(calendar33);
//        org.junit.Assert.assertNotNull(timeSeries6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182566791L + "'", long26 == 1560182566791L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182566791L + "'", long32 == 1560182566791L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182566791L + "'", long34 == 1560182566791L);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 10, year8);
        long long11 = month10.getLastMillisecond();
        long long12 = month10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        int int14 = month10.getYearValue();
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62109475200001L) + "'", long11 == (-62109475200001L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62112153600000L) + "'", long12 == (-62112153600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469812L);
//        double double2 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries6.createCopy(0, (int) (short) 0);
//        int int10 = timeSeries6.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries14.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.Number number19 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries23.createCopy(0, (int) (short) 0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getLastMillisecond(calendar28);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.lang.Class<?> wildcardClass33 = timeSeries6.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182469272L);
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries39.addChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries39.getDataItem((org.jfree.data.time.RegularTimePeriod) year43);
//        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) year43, (double) 1560182469650L, true);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year43, (double) (short) 100);
//        java.lang.String str50 = year43.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year43.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod51, (java.lang.Number) 1560182476250L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries1.addOrUpdate(timeSeriesDataItem53);
//        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182566936L + "'", long29 == 1560182566936L);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNull(timeSeriesDataItem44);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1" + "'", str50.equals("1"));
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertNull(timeSeriesDataItem54);
//    }
//}

