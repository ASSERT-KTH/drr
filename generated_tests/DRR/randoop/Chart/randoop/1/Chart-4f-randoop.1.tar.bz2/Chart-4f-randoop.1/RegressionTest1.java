import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape1, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "");
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity7 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart5, "Rotation.CLOCKWISE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        boolean boolean4 = legendItem3.isShapeFilled();
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem3.setOutlinePaint(paint5);
        java.awt.Stroke stroke7 = legendItem3.getLineStroke();
        boolean boolean8 = projectInfo0.equals((java.lang.Object) legendItem3);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape10 = defaultDrawingSupplier9.getNextShape();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis15.getCategoryLabelPositions();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color21 = java.awt.Color.GRAY;
        int int22 = color21.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("", font20, (java.awt.Paint) color21);
        categoryAxis15.setLabelFont(font20);
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        double double26 = piePlot25.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextPaint();
        piePlot25.setLabelLinkPaint(paint28);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape31 = defaultDrawingSupplier30.getNextShape();
        java.awt.Shape shape32 = defaultDrawingSupplier30.getNextShape();
        java.awt.Shape shape33 = defaultDrawingSupplier30.getNextShape();
        piePlot25.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font20, (org.jfree.chart.plot.Plot) piePlot25, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity37 = new org.jfree.chart.entity.JFreeChartEntity(shape10, jFreeChart36);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        java.awt.image.BufferedImage bufferedImage43 = jFreeChart36.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo42);
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        piePlot44.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator47 = piePlot44.getLegendLabelToolTipGenerator();
        java.awt.Stroke stroke48 = piePlot44.getLabelOutlineStroke();
        jFreeChart36.setBorderStroke(stroke48);
        legendItem3.setOutlineStroke(stroke48);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 128 + "'", int22 == 128);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 90.0d + "'", double26 == 90.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(bufferedImage43);
        org.junit.Assert.assertNull(pieSectionLabelGenerator47);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = legendItem2.getFillPaintTransformer();
        int int4 = legendItem2.getSeriesIndex();
        java.lang.Object obj5 = legendItem2.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        combinedRangeXYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            org.jfree.data.time.TimeSeries timeSeries4 = timeSeriesCollection1.getSeries(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        blockContainer1.clear();
        blockContainer1.clear();
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Image image6 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo10 = new org.jfree.chart.ui.ProjectInfo("", "DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", image6, "Nearest", "0%", "0%");
        java.lang.String str11 = projectInfo10.getLicenceText();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape13 = defaultDrawingSupplier12.getNextShape();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape13, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = categoryAxis18.getCategoryLabelPositions();
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color24 = java.awt.Color.GRAY;
        int int25 = color24.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("", font23, (java.awt.Paint) color24);
        categoryAxis18.setLabelFont(font23);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        double double29 = piePlot28.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextPaint();
        piePlot28.setLabelLinkPaint(paint31);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape34 = defaultDrawingSupplier33.getNextShape();
        java.awt.Shape shape35 = defaultDrawingSupplier33.getNextShape();
        java.awt.Shape shape36 = defaultDrawingSupplier33.getNextShape();
        piePlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier33);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font23, (org.jfree.chart.plot.Plot) piePlot28, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity40 = new org.jfree.chart.entity.JFreeChartEntity(shape13, jFreeChart39);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = null;
        java.awt.image.BufferedImage bufferedImage46 = jFreeChart39.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo45);
        projectInfo10.setLogo((java.awt.Image) bufferedImage46);
        org.jfree.chart.ui.ProjectInfo projectInfo51 = new org.jfree.chart.ui.ProjectInfo("DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", "ThreadContext", (java.awt.Image) bufferedImage46, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "Size2D[width=0.0, height=0.0]", "Nearest");
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0%" + "'", str11.equals("0%"));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 128 + "'", int25 == 128);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 90.0d + "'", double29 == 90.0d);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(bufferedImage46);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis0.drawTickMarks(graphics2D4, (double) (short) 100, rectangle2D6, rectangleEdge7, axisState9);
        java.awt.Paint paint12 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 4.0d);
        java.lang.String str13 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean6 = barRenderer3D0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer3D0.getSeriesToolTipGenerator((int) ' ');
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color11 = java.awt.Color.GRAY;
        int int12 = color11.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color11);
        barRenderer3D0.setBaseItemLabelFont(font10, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = null;
        try {
            barRenderer3D0.setLegendItemLabelGenerator(categorySeriesLabelGenerator16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 128 + "'", int12 == 128);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeFilled();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setOutlinePaint(paint4);
        java.awt.Paint paint6 = legendItem2.getFillPaint();
        java.lang.String str7 = legendItem2.getDescription();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYLineAndShapeRenderer3.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer3.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYLineAndShapeRenderer3.setSeriesURLGenerator(0, xYURLGenerator11, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        xYLineAndShapeRenderer3.setLegendItemToolTipGenerator(xYSeriesLabelGenerator14);
        boolean boolean16 = xYLineAndShapeRenderer3.getBaseItemLabelsVisible();
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer3.lookupSeriesStroke((int) (short) 1);
        barRenderer3D0.setBaseStroke(stroke18, false);
        java.lang.Boolean boolean22 = barRenderer3D0.getSeriesCreateEntities(100);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot29.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot29.setDomainAxes(valueAxisArray31);
        combinedRangeXYPlot29.clearRangeAxes();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection35 = new org.jfree.data.time.TimeSeriesCollection(timeZone34);
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection35);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection35, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState40 = xYStepAreaRenderer26.initialise(graphics2D27, rectangle2D28, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot29, (org.jfree.data.xy.XYDataset) timeSeriesCollection35, plotRenderingInfo39);
        java.awt.Paint paint42 = xYStepAreaRenderer26.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer26);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = null;
        org.jfree.chart.util.Size2D size2D46 = legendTitle43.arrange(graphics2D44, rectangleConstraint45);
        java.awt.geom.Rectangle2D rectangle2D47 = legendTitle43.getBounds();
        try {
            barRenderer3D0.drawBackground(graphics2D23, categoryPlot24, rectangle2D47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(xYItemRendererState40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(rectangle2D47);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month((int) (byte) 10, year4);
        int int6 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) year4);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year4.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        xYStepAreaRenderer1.setBaseSeriesVisible(false);
        xYStepAreaRenderer1.clearSeriesPaints(true);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.util.LogFormat logFormat3 = new org.jfree.chart.util.LogFormat((double) 1L, "java.awt.Color[r=128,g=128,b=128]", false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Nearest");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator5 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat6 = standardPieToolTipGenerator5.getPercentFormat();
        boolean boolean7 = textAnchor3.equals((java.lang.Object) numberFormat6);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        boolean boolean9 = textAnchor3.equals((java.lang.Object) defaultDrawingSupplier8);
        try {
            float float10 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer3D0.getLegendItems();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer3D0.getSeriesItemLabelGenerator(128);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer3D0.setBaseURLGenerator(categoryURLGenerator8, false);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        logAxis1.setMinorTickCount(0);
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend4 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) logAxis1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            boolean boolean3 = xYSeriesCollection0.isSelected((int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis0.drawTickMarks(graphics2D4, (double) (short) 100, rectangle2D6, rectangleEdge7, axisState9);
        org.jfree.chart.plot.Plot plot11 = categoryAxis0.getPlot();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) '4');
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(plot11);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Multiple Pie Plot", graphics2D1, (float) 128, 0.0f, 0.0d, (-1.0f), (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot6.getDataset();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        boolean boolean13 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        combinedRangeXYPlot6.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        timeSeries5.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year16);
        java.util.TimeZone timeZone21 = periodAxis20.getTimeZone();
        periodAxis20.setLabel("January");
        java.lang.Class class24 = periodAxis20.getMajorTickTimePeriodClass();
        java.io.InputStream inputStream25 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.UnknownKeyException: DateTickMarkPosition.MIDDLE", class24);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNull(inputStream25);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.awt.Color color0 = java.awt.Color.white;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.Range range0 = null;
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, (org.jfree.data.Range) dateRange1);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange(range2);
        org.junit.Assert.assertNotNull(range2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj3 = xYSeries2.clone();
        boolean boolean5 = xYSeries2.equals((java.lang.Object) (short) 10);
        int int6 = xYSeriesCollection0.indexOf(xYSeries2);
        try {
            xYSeriesCollection0.removeSeries((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setDrawBarOutline(true);
        boolean boolean3 = barRenderer3D0.isDrawBarOutline();
        java.awt.Stroke stroke7 = barRenderer3D0.getItemOutlineStroke((-4145152), (int) '#', false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Shape shape1 = barRenderer3D0.getBaseLegendShape();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.data.Range range4 = barRenderer3D0.findRangeBounds(categoryDataset2, true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        boolean boolean15 = xYAreaRenderer0.getPlotArea();
        xYAreaRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.awt.Color color6 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color6);
        boolean boolean8 = legendItem7.isShapeFilled();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem7.setOutlinePaint(paint9);
        java.awt.Stroke stroke11 = legendItem7.getLineStroke();
        combinedRangeXYPlot0.setRangeZeroBaselineStroke(stroke11);
        java.awt.Paint paint13 = combinedRangeXYPlot0.getRangeGridlinePaint();
        boolean boolean14 = combinedRangeXYPlot0.canSelectByPoint();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        java.lang.StringBuffer stringBuffer4 = logFormat0.format((double) (short) 10, stringBuffer2, fieldPosition3);
        org.jfree.chart.util.LogFormat logFormat6 = new org.jfree.chart.util.LogFormat();
        java.lang.StringBuffer stringBuffer8 = null;
        java.text.FieldPosition fieldPosition9 = null;
        java.lang.StringBuffer stringBuffer10 = logFormat6.format((double) (short) 10, stringBuffer8, fieldPosition9);
        java.text.FieldPosition fieldPosition11 = null;
        java.lang.StringBuffer stringBuffer12 = logFormat0.format((double) 100, stringBuffer10, fieldPosition11);
        org.junit.Assert.assertNotNull(stringBuffer4);
        org.junit.Assert.assertNotNull(stringBuffer10);
        org.junit.Assert.assertNotNull(stringBuffer12);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeFilled();
        legendItem2.setLineVisible(true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarksVisible(true);
        boolean boolean24 = periodAxis19.isVerticalTickLabels();
        org.jfree.data.time.DateRange dateRange25 = new org.jfree.data.time.DateRange();
        periodAxis19.setRange((org.jfree.data.Range) dateRange25);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        combinedRangeXYPlot4.setRangePannable(true);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot4);
        org.jfree.chart.axis.AxisSpace axisSpace9 = combinedRangeXYPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        combinedRangeXYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D10);
        numberAxis3D10.setLowerBound((double) 10L);
        java.awt.Shape shape14 = numberAxis3D10.getRightArrow();
        boolean boolean15 = numberAxis3D10.getAutoRangeIncludesZero();
        java.awt.Paint paint16 = numberAxis3D10.getTickLabelPaint();
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend17 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) numberAxis3D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setShadowXOffset(0.0d);
        java.awt.Stroke stroke3 = piePlot0.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        org.jfree.data.general.DatasetGroup datasetGroup19 = timeSeriesCollection15.getGroup();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeriesCollection15.removeSeries(timeSeries21);
        try {
            java.lang.Number number24 = timeSeries21.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNotNull(datasetGroup19);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean11 = xYLineAndShapeRenderer2.getUseOutlinePaint();
        java.awt.Paint paint15 = xYLineAndShapeRenderer2.getItemPaint((int) (byte) 10, (-1), true);
        xYLineAndShapeRenderer2.setDrawSeriesLineAsPath(false);
        boolean boolean18 = xYLineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis0.setDownArrow(shape6);
        boolean boolean8 = numberAxis0.isNegativeArrowVisible();
        java.awt.Paint paint9 = numberAxis0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range1 = numberAxis0.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(range1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle18.arrange(graphics2D19, rectangleConstraint20);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle18.getSources();
        boolean boolean23 = legendTitle18.isVisible();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickCount((int) (byte) 10);
        boolean boolean22 = periodAxis19.isMinorTickMarksVisible();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.lang.Object obj1 = barRenderer3D0.clone();
        double double2 = barRenderer3D0.getShadowYOffset();
        double double3 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer3D0.getLegendItems();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = barRenderer3D0.getLegendItemURLGenerator();
        barRenderer3D0.setMaximumBarWidth((double) (-2208960000000L));
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot9.getRangeAxisLocation();
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape23 = defaultDrawingSupplier22.getNextShape();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot27.clearDomainMarkers();
        combinedRangeXYPlot27.setRangePannable(true);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        combinedRangeXYPlot27.drawBackgroundImage(graphics2D31, rectangle2D32);
        java.awt.Color color34 = java.awt.Color.GRAY;
        combinedRangeXYPlot27.setRangeGridlinePaint((java.awt.Paint) color34);
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color38 = java.awt.Color.GRAY;
        int int39 = color38.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("", font37, (java.awt.Paint) color38);
        combinedRangeXYPlot27.setRangeTickBandPaint((java.awt.Paint) color38);
        java.awt.Color color42 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer45 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = xYLineAndShapeRenderer45.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer45.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator53 = null;
        xYLineAndShapeRenderer45.setSeriesURLGenerator(0, xYURLGenerator53, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator56 = null;
        xYLineAndShapeRenderer45.setLegendItemToolTipGenerator(xYSeriesLabelGenerator56);
        boolean boolean58 = xYLineAndShapeRenderer45.getBaseItemLabelsVisible();
        java.awt.Stroke stroke60 = xYLineAndShapeRenderer45.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = piePlot61.getLabelPadding();
        double double64 = rectangleInsets62.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder65 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color42, stroke60, rectangleInsets62);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer67 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot70 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot70.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot70.setDomainAxes(valueAxisArray72);
        combinedRangeXYPlot70.clearRangeAxes();
        java.util.TimeZone timeZone75 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection76 = new org.jfree.data.time.TimeSeriesCollection(timeZone75);
        boolean boolean77 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection76);
        org.jfree.data.Range range79 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection76, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState81 = xYStepAreaRenderer67.initialise(graphics2D68, rectangle2D69, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot70, (org.jfree.data.xy.XYDataset) timeSeriesCollection76, plotRenderingInfo80);
        java.awt.Paint paint83 = xYStepAreaRenderer67.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem84 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape26, (java.awt.Paint) color38, stroke60, paint83);
        org.jfree.chart.plot.IntervalMarker intervalMarker85 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint83);
        org.jfree.chart.util.Layer layer86 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean87 = combinedRangeXYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker85, layer86);
        java.lang.String str88 = layer86.toString();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 128 + "'", int39 == 128);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(itemLabelPosition49);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.0d + "'", double64 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNull(range79);
        org.junit.Assert.assertNotNull(xYItemRendererState81);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(layer86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "Layer.FOREGROUND" + "'", str88.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.util.StrokeMap strokeMap0 = new org.jfree.chart.util.StrokeMap();
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        java.lang.StringBuffer stringBuffer4 = logFormat0.format((double) (short) 10, stringBuffer2, fieldPosition3);
        boolean boolean5 = logFormat0.isGroupingUsed();
        java.text.NumberFormat numberFormat6 = logFormat0.getExponentFormat();
        int int7 = numberFormat6.getMaximumIntegerDigits();
        numberFormat6.setMinimumFractionDigits(1);
        org.junit.Assert.assertNotNull(stringBuffer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year2.next();
        java.util.Date date21 = year2.getStart();
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Locale locale23 = null;
        try {
            org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone22, locale23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year2);
        org.jfree.data.time.Year year4 = month3.getYear();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYLineAndShapeRenderer7.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer7.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = null;
        xYLineAndShapeRenderer7.setSeriesURLGenerator(0, xYURLGenerator15, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator18 = null;
        xYLineAndShapeRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator18);
        java.lang.Boolean boolean21 = xYLineAndShapeRenderer7.getSeriesVisible(7);
        java.awt.Font font22 = xYLineAndShapeRenderer7.getBaseItemLabelFont();
        java.awt.Paint paint23 = xYLineAndShapeRenderer7.getBasePaint();
        xYLineAndShapeRenderer7.setUseOutlinePaint(false);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer27 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean28 = xYBarRenderer27.getShadowsVisible();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke36 = xYLineAndShapeRenderer32.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot37.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray39 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot37.setDomainAxes(valueAxisArray39);
        combinedRangeXYPlot37.clearRangeAxes();
        java.awt.Stroke stroke42 = combinedRangeXYPlot37.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot43 = combinedRangeXYPlot37.getRootPlot();
        xYLineAndShapeRenderer32.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot37);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.awt.Paint paint48 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot49 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator50 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot49.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator50);
        double double52 = piePlot49.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer55 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke59 = xYLineAndShapeRenderer55.getItemOutlineStroke((int) 'a', 0, false);
        piePlot49.setBaseSectionOutlineStroke(stroke59);
        xYBarRenderer27.drawDomainLine(graphics2D29, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot37, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, rectangle2D46, (double) (byte) -1, paint48, stroke59);
        double double62 = xYBarRenderer27.getBarAlignmentFactor();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer65 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition69 = xYLineAndShapeRenderer65.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        org.jfree.chart.text.TextAnchor textAnchor70 = itemLabelPosition69.getRotationAnchor();
        xYBarRenderer27.setPositiveItemLabelPositionFallback(itemLabelPosition69);
        xYLineAndShapeRenderer7.setBaseNegativeItemLabelPosition(itemLabelPosition69, false);
        int int74 = month3.compareTo((java.lang.Object) itemLabelPosition69);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(boolean21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(valueAxisArray39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(plot43);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + (-1.0d) + "'", double62 == (-1.0d));
        org.junit.Assert.assertNotNull(itemLabelPosition69);
        org.junit.Assert.assertNotNull(textAnchor70);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.String str0 = org.jfree.chart.labels.StandardPieSectionLabelGenerator.DEFAULT_SECTION_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot9.getRangeAxisLocation();
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation13, false);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot22.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot22.setDomainAxes(valueAxisArray24);
        org.jfree.data.xy.XYDataset xYDataset26 = combinedRangeXYPlot22.getDataset();
        java.util.TimeZone timeZone27 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection(timeZone27);
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection28);
        combinedRangeXYPlot22.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection28);
        timeSeries21.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection28);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) year32, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis36 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year19, (org.jfree.data.time.RegularTimePeriod) year32);
        periodAxis36.setLabelToolTip("hi!");
        combinedRangeXYPlot0.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) periodAxis36);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNull(xYDataset26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj2 = xYSeries1.clone();
        org.jfree.data.xy.XYDataItem xYDataItem3 = null;
        try {
            xYSeries1.add(xYDataItem3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}: ({1}, {2})" + "'", str0.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        numberFormat0.setMaximumIntegerDigits(3);
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getLabelPadding();
        boolean boolean2 = piePlot0.getSimpleLabels();
        piePlot0.setNoDataMessage("February");
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot33.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot33.setDomainAxes(valueAxisArray35);
        combinedRangeXYPlot33.clearRangeAxes();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeZone38);
        boolean boolean40 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection39, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState44 = xYStepAreaRenderer30.initialise(graphics2D31, rectangle2D32, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot33, (org.jfree.data.xy.XYDataset) timeSeriesCollection39, plotRenderingInfo43);
        java.awt.Paint paint46 = xYStepAreaRenderer30.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer30);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = null;
        org.jfree.chart.util.Size2D size2D50 = legendTitle47.arrange(graphics2D48, rectangleConstraint49);
        jFreeChart27.addSubtitle((org.jfree.chart.title.Title) legendTitle47);
        float float52 = jFreeChart27.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(valueAxisArray35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(xYItemRendererState44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 0.5f + "'", float52 == 0.5f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("DateTickMarkPosition.MIDDLE");
        java.lang.String str2 = unknownKeyException1.toString();
        java.lang.Throwable[] throwableArray3 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: DateTickMarkPosition.MIDDLE" + "'", str2.equals("org.jfree.data.UnknownKeyException: DateTickMarkPosition.MIDDLE"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYLineAndShapeRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer2.getSeriesVisible(7);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator17 = xYLineAndShapeRenderer2.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNull(xYItemLabelGenerator17);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj3 = xYSeries2.clone();
        boolean boolean5 = xYSeries2.equals((java.lang.Object) (short) 10);
        int int6 = xYSeriesCollection0.indexOf(xYSeries2);
        xYSeries2.add((double) 4, (java.lang.Number) (short) 1, true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        combinedRangeXYPlot11.setRangePannable(true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        combinedRangeXYPlot11.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        combinedRangeXYPlot11.setRangeGridlinePaint((java.awt.Paint) color18);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color22 = java.awt.Color.GRAY;
        int int23 = color22.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color22);
        combinedRangeXYPlot11.setRangeTickBandPaint((java.awt.Paint) color22);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYLineAndShapeRenderer29.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer29.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        xYLineAndShapeRenderer29.setSeriesURLGenerator(0, xYURLGenerator37, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator40 = null;
        xYLineAndShapeRenderer29.setLegendItemToolTipGenerator(xYSeriesLabelGenerator40);
        boolean boolean42 = xYLineAndShapeRenderer29.getBaseItemLabelsVisible();
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer29.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = piePlot45.getLabelPadding();
        double double48 = rectangleInsets46.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color26, stroke44, rectangleInsets46);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot54.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot54.setDomainAxes(valueAxisArray56);
        combinedRangeXYPlot54.clearRangeAxes();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeZone59);
        boolean boolean61 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState65 = xYStepAreaRenderer51.initialise(graphics2D52, rectangle2D53, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot54, (org.jfree.data.xy.XYDataset) timeSeriesCollection60, plotRenderingInfo64);
        java.awt.Paint paint67 = xYStepAreaRenderer51.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape10, (java.awt.Paint) color22, stroke44, paint67);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint67);
        java.awt.Color color71 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color71);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer73 = legendItem72.getFillPaintTransformer();
        intervalMarker69.setGradientPaintTransformer(gradientPaintTransformer73);
        java.awt.Paint paint75 = intervalMarker69.getPaint();
        java.awt.Paint paint76 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_PAINT;
        boolean boolean77 = intervalMarker69.equals((java.lang.Object) paint76);
        intervalMarker69.setStartValue(1.0E10d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 128 + "'", int23 == 128);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNotNull(xYItemRendererState65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(gradientPaintTransformer73);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        org.jfree.data.general.DatasetGroup datasetGroup2 = piePlot0.getDatasetGroup();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) (short) -1);
        java.lang.String str5 = numberTickUnit4.toString();
        java.lang.String str6 = numberTickUnit4.toString();
        piePlot0.setExplodePercent((java.lang.Comparable) str6, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[size=-1]" + "'", str5.equals("[size=-1]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[size=-1]" + "'", str6.equals("[size=-1]"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.lang.String str19 = legendTitle18.getID();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        piePlot0.setOutlineVisible(false);
        java.awt.Color color6 = java.awt.Color.white;
        piePlot0.setLabelBackgroundPaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYLineAndShapeRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer2.getSeriesVisible(7);
        java.awt.Font font17 = xYLineAndShapeRenderer2.getBaseItemLabelFont();
        xYLineAndShapeRenderer2.setBaseLinesVisible(false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        try {
            java.lang.Number number2 = numberFormat0.parse("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Unparseable number: \"ThreadContext\"");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        int int19 = combinedRangeXYPlot5.getSeriesCount();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot25.setDomainAxes(valueAxisArray27);
        combinedRangeXYPlot25.clearRangeAxes();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeZone30);
        boolean boolean32 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection31, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState36 = xYStepAreaRenderer22.initialise(graphics2D23, rectangle2D24, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot25, (org.jfree.data.xy.XYDataset) timeSeriesCollection31, plotRenderingInfo35);
        java.awt.Paint paint38 = xYStepAreaRenderer22.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer22);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = null;
        org.jfree.chart.util.Size2D size2D42 = legendTitle39.arrange(graphics2D40, rectangleConstraint41);
        java.awt.geom.Rectangle2D rectangle2D43 = legendTitle39.getBounds();
        try {
            combinedRangeXYPlot5.drawOutline(graphics2D20, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(xYItemRendererState36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangle2D43);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape6 = defaultDrawingSupplier5.getNextShape();
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        combinedRangeXYPlot10.setRangePannable(true);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        combinedRangeXYPlot10.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Color color17 = java.awt.Color.GRAY;
        combinedRangeXYPlot10.setRangeGridlinePaint((java.awt.Paint) color17);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color21 = java.awt.Color.GRAY;
        int int22 = color21.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("", font20, (java.awt.Paint) color21);
        combinedRangeXYPlot10.setRangeTickBandPaint((java.awt.Paint) color21);
        java.awt.Color color25 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = xYLineAndShapeRenderer28.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer28.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator36 = null;
        xYLineAndShapeRenderer28.setSeriesURLGenerator(0, xYURLGenerator36, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator39 = null;
        xYLineAndShapeRenderer28.setLegendItemToolTipGenerator(xYSeriesLabelGenerator39);
        boolean boolean41 = xYLineAndShapeRenderer28.getBaseItemLabelsVisible();
        java.awt.Stroke stroke43 = xYLineAndShapeRenderer28.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot44 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = piePlot44.getLabelPadding();
        double double47 = rectangleInsets45.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder48 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color25, stroke43, rectangleInsets45);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer50 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot53.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray55 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot53.setDomainAxes(valueAxisArray55);
        combinedRangeXYPlot53.clearRangeAxes();
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection59 = new org.jfree.data.time.TimeSeriesCollection(timeZone58);
        boolean boolean60 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection59);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection59, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState64 = xYStepAreaRenderer50.initialise(graphics2D51, rectangle2D52, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot53, (org.jfree.data.xy.XYDataset) timeSeriesCollection59, plotRenderingInfo63);
        java.awt.Paint paint66 = xYStepAreaRenderer50.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape9, (java.awt.Paint) color21, stroke43, paint66);
        boolean boolean68 = rangeType0.equals((java.lang.Object) "java.awt.Color[r=128,g=128,b=128]");
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 128 + "'", int22 == 128);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNull(range62);
        org.junit.Assert.assertNotNull(xYItemRendererState64);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.CrosshairState crosshairState12 = new org.jfree.chart.plot.CrosshairState(false);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        crosshairState12.setAnchor(point2D15);
        try {
            combinedRangeXYPlot0.zoomDomainAxes(10.0d, (double) 2147483647, plotRenderingInfo10, point2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(point2D15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        piePlot0.setLabelLinkPaint(paint3);
        double double5 = piePlot0.getStartAngle();
        piePlot0.setAutoPopulateSectionOutlinePaint(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean11 = xYLineAndShapeRenderer2.getUseOutlinePaint();
        java.awt.Paint paint15 = xYLineAndShapeRenderer2.getItemPaint((int) (byte) 10, (-1), true);
        xYLineAndShapeRenderer2.setDrawSeriesLineAsPath(false);
        java.lang.Boolean boolean19 = xYLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(boolean19);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        categoryAxis1.setLabelFont(font6);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextPaint();
        piePlot11.setLabelLinkPaint(paint14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape18 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape19 = defaultDrawingSupplier16.getNextShape();
        piePlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font6, (org.jfree.chart.plot.Plot) piePlot11, false);
        piePlot11.clearSectionOutlineStrokes(false);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator25 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj26 = standardPieSectionLabelGenerator25.clone();
        java.lang.Object obj27 = standardPieSectionLabelGenerator25.clone();
        piePlot11.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator25);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions9);
        org.jfree.chart.entity.AxisEntity axisEntity11 = new org.jfree.chart.entity.AxisEntity(shape1, (org.jfree.chart.axis.Axis) categoryAxis5);
        java.lang.Object obj12 = axisEntity11.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", image3, "Nearest", "0%", "0%");
        java.awt.Image image11 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo15 = new org.jfree.chart.ui.ProjectInfo("", "DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", image11, "Nearest", "0%", "0%");
        java.lang.String str16 = projectInfo15.getLicenceText();
        projectInfo7.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0%" + "'", str16.equals("0%"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getLabelPadding();
        boolean boolean2 = piePlot0.getSimpleLabels();
        org.jfree.chart.plot.Plot plot3 = piePlot0.getRootPlot();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(plot3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        java.lang.StringBuffer stringBuffer4 = logFormat0.format((double) (short) 10, stringBuffer2, fieldPosition3);
        boolean boolean5 = logFormat0.isGroupingUsed();
        java.text.NumberFormat numberFormat6 = logFormat0.getExponentFormat();
        int int7 = numberFormat6.getMaximumIntegerDigits();
        numberFormat6.setParseIntegerOnly(true);
        org.junit.Assert.assertNotNull(stringBuffer4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot7.setDomainAxes(valueAxisArray9);
        combinedRangeXYPlot7.clearRangeAxes();
        java.awt.Stroke stroke12 = combinedRangeXYPlot7.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot13 = combinedRangeXYPlot7.getRootPlot();
        xYLineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot7);
        combinedRangeXYPlot7.configureRangeAxes();
        double double16 = combinedRangeXYPlot7.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.String str2 = standardPieSectionLabelGenerator1.getLabelFormat();
        boolean boolean3 = textAnchor0.equals((java.lang.Object) standardPieSectionLabelGenerator1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getRootPlot();
        xYLineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot23.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        double double26 = piePlot23.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer29.getItemOutlineStroke((int) 'a', 0, false);
        piePlot23.setBaseSectionOutlineStroke(stroke33);
        xYBarRenderer1.drawDomainLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, paint22, stroke33);
        double double36 = xYBarRenderer1.getBarAlignmentFactor();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = xYLineAndShapeRenderer39.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        org.jfree.chart.text.TextAnchor textAnchor44 = itemLabelPosition43.getRotationAnchor();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition43);
        org.jfree.chart.LegendItem legendItem48 = xYBarRenderer1.getLegendItem(100, (int) (byte) -1);
        java.awt.Stroke stroke49 = xYBarRenderer1.getBaseStroke();
        java.lang.Object obj50 = xYBarRenderer1.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36 == (-1.0d));
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(textAnchor44);
        org.junit.Assert.assertNull(legendItem48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = combinedRangeXYPlot0.getDomainAxisEdge();
        combinedRangeXYPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        piePlot0.setOutlineVisible(false);
        java.awt.Paint paint6 = piePlot0.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYLineAndShapeRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer2.getSeriesVisible(7);
        xYLineAndShapeRenderer2.setSeriesLinesVisible((int) '4', true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator20 = null;
        xYLineAndShapeRenderer2.setBaseItemLabelGenerator(xYItemLabelGenerator20, true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.lang.Object obj19 = legendTitle18.clone();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot25.setDomainAxes(valueAxisArray27);
        combinedRangeXYPlot25.clearRangeAxes();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeZone30);
        boolean boolean32 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection31, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState36 = xYStepAreaRenderer22.initialise(graphics2D23, rectangle2D24, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot25, (org.jfree.data.xy.XYDataset) timeSeriesCollection31, plotRenderingInfo35);
        java.awt.Paint paint38 = xYStepAreaRenderer22.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer22);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = null;
        org.jfree.chart.util.Size2D size2D42 = legendTitle39.arrange(graphics2D40, rectangleConstraint41);
        java.awt.geom.Rectangle2D rectangle2D43 = legendTitle39.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double45 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D43, rectangleEdge44);
        try {
            legendTitle18.draw(graphics2D20, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(xYItemRendererState36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setMinorTickCount(0);
        float float3 = logAxis0.getMinorTickMarkInsideLength();
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator6 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat7 = standardPieToolTipGenerator6.getPercentFormat();
        boolean boolean8 = textAnchor4.equals((java.lang.Object) numberFormat7);
        java.math.RoundingMode roundingMode9 = numberFormat7.getRoundingMode();
        logAxis0.setNumberFormatOverride(numberFormat7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode9.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        int int3 = timeSeriesCollection1.indexOf((java.lang.Comparable) (byte) 0);
        try {
            org.jfree.data.time.TimeSeries timeSeries5 = timeSeriesCollection1.getSeries((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", dateFormat1, dateFormat2);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) "1,500%");
        java.awt.Paint paint4 = multiplePiePlot1.getAggregatedItemsPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = legendItem2.getFillPaintTransformer();
        int int4 = legendItem2.getSeriesIndex();
        legendItem2.setToolTipText("Nearest");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 1);
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYLineAndShapeRenderer2.setSeriesItemLabelFont(1, font16, true);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYLineAndShapeRenderer2.setBaseOutlineStroke(stroke19);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        boolean boolean10 = combinedRangeXYPlot0.equals((java.lang.Object) 10.0f);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot11.getRangeAxisLocation();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        combinedRangeXYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate20 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        double double21 = intervalXYDelegate20.getIntervalPositionFactor();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5d + "'", double21 == 0.5d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape3 = defaultDrawingSupplier2.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, (double) 0.0f, (double) 'a');
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        multiplePiePlot1.setLegendItemShape(shape6);
        java.lang.Comparable comparable9 = multiplePiePlot1.getAggregatedItemsKey();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + "Other" + "'", comparable9.equals("Other"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray10);
        org.jfree.data.xy.XYDataset xYDataset12 = combinedRangeXYPlot8.getDataset();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeZone13);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        combinedRangeXYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.entity.XYItemEntity xYItemEntity21 = new org.jfree.chart.entity.XYItemEntity(shape6, (org.jfree.data.xy.XYDataset) timeSeriesCollection14, 0, (int) (short) 1, "DateTickMarkPosition.MIDDLE", "");
        xYItemEntity21.setSeriesIndex(255);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        combinedRangeXYPlot2.setRangePannable(true);
        boolean boolean6 = combinedRangeXYPlot2.isRangeZoomable();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = xYLineAndShapeRenderer9.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer9.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator17 = null;
        xYLineAndShapeRenderer9.setSeriesURLGenerator(0, xYURLGenerator17, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator20 = null;
        xYLineAndShapeRenderer9.setLegendItemToolTipGenerator(xYSeriesLabelGenerator20);
        boolean boolean22 = xYLineAndShapeRenderer9.getBaseItemLabelsVisible();
        java.awt.Stroke stroke24 = xYLineAndShapeRenderer9.lookupSeriesStroke((int) (short) 1);
        combinedRangeXYPlot2.setDomainZeroBaselineStroke(stroke24);
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint27 = lineBorder26.getPaint();
        java.awt.Stroke stroke28 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f), paint1, stroke24, paint27, stroke28, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        java.awt.Stroke stroke5 = piePlot0.getSectionOutlineStroke((java.lang.Comparable) (-1L));
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot0.getLegendItems();
        piePlot0.setSimpleLabels(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(legendItemCollection6);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        barRenderer3D0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.clearDomainMarkers();
        combinedRangeXYPlot7.setRangePannable(true);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        combinedRangeXYPlot7.drawBackgroundImage(graphics2D11, rectangle2D12);
        java.awt.Color color14 = java.awt.Color.GRAY;
        combinedRangeXYPlot7.setRangeGridlinePaint((java.awt.Paint) color14);
        combinedRangeXYPlot7.setRangeCrosshairLockedOnData(false);
        boolean boolean18 = barRenderer3D0.hasListener((java.util.EventListener) combinedRangeXYPlot7);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        org.jfree.data.general.DatasetGroup datasetGroup19 = timeSeriesCollection15.getGroup();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeriesCollection15.removeSeries(timeSeries21);
        timeSeries21.setKey((java.lang.Comparable) (short) 10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNotNull(datasetGroup19);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getPlotType();
        java.lang.String str3 = waferMapPlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "WMAP_Plot" + "'", str2.equals("WMAP_Plot"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer12.setUseFillPaint(false);
        boolean boolean15 = xYAreaRenderer12.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot18.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot18.setDomainAxes(valueAxisArray20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYAreaRenderer12.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.data.xy.XYDataset) timeSeriesCollection23, plotRenderingInfo25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = combinedRangeXYPlot18.getInsets();
        java.lang.String str28 = rectangleInsets27.toString();
        piePlot0.setSimpleLabelOffset(rectangleInsets27);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.clearDomainMarkers();
        combinedRangeXYPlot30.setRangePannable(true);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        combinedRangeXYPlot30.drawBackgroundImage(graphics2D34, rectangle2D35);
        java.awt.Color color37 = java.awt.Color.GRAY;
        combinedRangeXYPlot30.setRangeGridlinePaint((java.awt.Paint) color37);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot39.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation43 = combinedRangeXYPlot39.getRangeAxisLocation();
        combinedRangeXYPlot30.setRangeAxisLocation(axisLocation43, false);
        piePlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot30);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        java.awt.Paint paint48 = null;
        piePlot0.setOutlinePaint(paint48);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str28.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(axisLocation43);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        double double3 = timeSeries1.getMinY();
        try {
            timeSeries1.update(0, (java.lang.Number) (-2208960000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState2 = state1.getCrosshairState();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer3.setUseFillPaint(false);
        boolean boolean6 = xYAreaRenderer3.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot9.setDomainAxes(valueAxisArray11);
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeZone13);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState17 = xYAreaRenderer3.initialise(graphics2D7, rectangle2D8, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9, (org.jfree.data.xy.XYDataset) timeSeriesCollection14, plotRenderingInfo16);
        java.lang.Number number18 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        try {
            state1.startSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection14, (int) ' ', (int) '#', (int) (short) 0, 15, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYCrosshairState2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(valueAxisArray11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState17);
        org.junit.Assert.assertNull(number18);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        xYStepAreaRenderer1.setShapesFilled(false);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYStepAreaRenderer1.setSeriesOutlineStroke(2, stroke5, false);
        xYStepAreaRenderer1.setRangeBase(0.0d);
        boolean boolean10 = xYStepAreaRenderer1.getShapesVisible();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart27.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo33);
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        piePlot35.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator38 = piePlot35.getLegendLabelToolTipGenerator();
        java.awt.Stroke stroke39 = piePlot35.getLabelOutlineStroke();
        jFreeChart27.setBorderStroke(stroke39);
        org.jfree.chart.event.ChartProgressListener chartProgressListener41 = null;
        jFreeChart27.removeProgressListener(chartProgressListener41);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(bufferedImage34);
        org.junit.Assert.assertNull(pieSectionLabelGenerator38);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 1);
        java.awt.Font font16 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYLineAndShapeRenderer2.setSeriesItemLabelFont(1, font16, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer19.setUseFillPaint(false);
        boolean boolean22 = xYAreaRenderer19.getBaseSeriesVisible();
        java.awt.Paint paint26 = xYAreaRenderer19.getItemLabelPaint(0, 255, true);
        xYLineAndShapeRenderer2.setBaseLegendTextPaint(paint26);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeFilled();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setOutlinePaint(paint4);
        java.awt.Paint paint6 = legendItem2.getFillPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer7.setUseFillPaint(false);
        boolean boolean10 = xYAreaRenderer7.getBaseSeriesVisible();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = xYAreaRenderer7.getGradientTransformer();
        legendItem2.setFillPaintTransformer(gradientPaintTransformer11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setSeriesLinesVisible(0, false);
        boolean boolean12 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean11 = xYLineAndShapeRenderer2.getUseOutlinePaint();
        java.awt.Shape shape12 = xYLineAndShapeRenderer2.getLegendLine();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        java.awt.Color color3 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color3);
        combinedRangeXYPlot0.setOutlinePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, (double) 0.0f, (double) 'a');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone(shape10);
        boolean boolean12 = color3.equals((java.lang.Object) shape10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("Nearest");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name Nearest, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color11 = java.awt.Color.GRAY;
        int int12 = color11.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color11);
        combinedRangeXYPlot0.setRangeTickBandPaint((java.awt.Paint) color11);
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) 7);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape17, "", "");
        boolean boolean21 = color11.equals((java.lang.Object) chartEntity20);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 128 + "'", int12 == 128);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("Value", timeZone1);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot10.getDataset();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        combinedRangeXYPlot10.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        timeSeries9.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection16);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year7.next();
        java.util.Date date26 = year7.getStart();
        dateAxis4.setMinimumDate(date26);
        org.jfree.data.Range range28 = null;
        org.jfree.data.Range range30 = org.jfree.data.Range.expandToInclude(range28, (double) 0L);
        double double31 = range30.getLength();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange(range30);
        java.util.Date date33 = dateRange32.getUpperDate();
        dateAxis4.setMinimumDate(date33);
        dateAxis4.setVisible(true);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray10);
        org.jfree.data.xy.XYDataset xYDataset12 = combinedRangeXYPlot8.getDataset();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeZone13);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        combinedRangeXYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.entity.XYItemEntity xYItemEntity21 = new org.jfree.chart.entity.XYItemEntity(shape6, (org.jfree.data.xy.XYDataset) timeSeriesCollection14, 0, (int) (short) 1, "DateTickMarkPosition.MIDDLE", "");
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection14, false);
        java.lang.Object obj24 = timeSeriesCollection14.clone();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        combinedRangeXYPlot0.setDomainCrosshairPaint(paint10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray14);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, 128);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            combinedRangeXYPlot0.handleClick((int) (short) -1, (int) (byte) 10, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        numberAxis3D0.setAutoRangeMinimumSize((double) 15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYLineAndShapeRenderer10.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer10.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        xYLineAndShapeRenderer10.setSeriesURLGenerator(0, xYURLGenerator18, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = null;
        xYLineAndShapeRenderer10.setLegendItemToolTipGenerator(xYSeriesLabelGenerator21);
        java.lang.Boolean boolean24 = xYLineAndShapeRenderer10.getSeriesVisible(7);
        java.awt.Font font25 = xYLineAndShapeRenderer10.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 10L, (double) 2, (double) 7, (double) 1L, font25);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = numberAxis3D0.getTickUnit();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke34 = xYLineAndShapeRenderer30.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator36 = xYLineAndShapeRenderer30.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer30.setUseFillPaint(false);
        java.awt.Shape shape39 = xYLineAndShapeRenderer30.getBaseLegendShape();
        boolean boolean40 = numberTickUnit27.equals((java.lang.Object) xYLineAndShapeRenderer30);
        java.awt.Font font42 = xYLineAndShapeRenderer30.getLegendTextFont(15);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(numberTickUnit27);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(xYURLGenerator36);
        org.junit.Assert.assertNull(shape39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(font42);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        combinedRangeXYPlot0.setDomainCrosshairPaint(paint10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke12);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        float float2 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle18.arrange(graphics2D19, rectangleConstraint20);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray22 = legendTitle18.getSources();
        org.jfree.chart.block.BlockContainer blockContainer23 = legendTitle18.getWrapper();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = legendTitle18.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(legendItemSourceArray22);
        org.junit.Assert.assertNull(blockContainer23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("Value", timeZone1);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot10.getDataset();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        combinedRangeXYPlot10.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        timeSeries9.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection16);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year7.next();
        java.util.Date date26 = year7.getStart();
        dateAxis4.setMinimumDate(date26);
        org.jfree.data.Range range28 = null;
        org.jfree.data.Range range30 = org.jfree.data.Range.expandToInclude(range28, (double) 0L);
        double double31 = range30.getLength();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange(range30);
        java.util.Date date33 = dateRange32.getUpperDate();
        dateAxis4.setMinimumDate(date33);
        java.util.Date date35 = null;
        try {
            org.jfree.data.time.DateRange dateRange36 = new org.jfree.data.time.DateRange(date33, date35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        java.awt.Paint paint24 = periodAxis19.getMinorTickMarkPaint();
        org.jfree.data.Range range25 = null;
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) 0L);
        double double28 = range27.getLength();
        periodAxis19.setRange(range27, true, false);
        periodAxis19.setMinorTickMarksVisible(true);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) '#');
        try {
            org.jfree.data.xy.XYDataset xYDataset6 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, Double.NaN, (double) 0L, 1900, (java.lang.Comparable) year5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        int int19 = combinedRangeXYPlot5.getSeriesCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        combinedRangeXYPlot5.panRangeAxes((double) ' ', plotRenderingInfo21, point2D22);
        org.jfree.data.xy.XYDataset xYDataset24 = combinedRangeXYPlot5.getDataset();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(xYDataset24);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        labelBlock4.setHeight(0.0d);
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        boolean boolean9 = labelBlock4.equals((java.lang.Object) color7);
        java.awt.Paint paint10 = labelBlock4.getPaint();
        labelBlock4.setMargin((double) 1.0f, (double) 1.0f, (double) 15, 6.0d);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer16.setUseFillPaint(false);
        boolean boolean19 = xYAreaRenderer16.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot22.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot22.setDomainAxes(valueAxisArray24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection(timeZone26);
        boolean boolean28 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState30 = xYAreaRenderer16.initialise(graphics2D20, rectangle2D21, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot22, (org.jfree.data.xy.XYDataset) timeSeriesCollection27, plotRenderingInfo29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = combinedRangeXYPlot22.getInsets();
        labelBlock4.setPadding(rectangleInsets31);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        java.util.List list8 = combinedRangeXYPlot4.getSubplots();
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D2, rectangle2D3, list8);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = combinedRangeXYPlot0.getRangeAxisForDataset((-4145152));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -4145152 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setInverted(false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("NO_CHANGE");
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYLineAndShapeRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer2.getSeriesVisible(7);
        java.awt.Font font17 = xYLineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint18 = xYLineAndShapeRenderer2.getBasePaint();
        xYLineAndShapeRenderer2.setUseOutlinePaint(false);
        java.lang.Object obj21 = xYLineAndShapeRenderer2.clone();
        java.awt.Shape shape23 = xYLineAndShapeRenderer2.getLegendShape(128);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(shape23);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot15.setDomainAxes(valueAxisArray17);
        org.jfree.data.xy.XYDataset xYDataset19 = combinedRangeXYPlot15.getDataset();
        combinedRangeXYPlot6.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot6.getRangeMarkers(layer21);
        combinedRangeXYPlot6.clearSelection();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator25 = new org.jfree.chart.urls.StandardXYURLGenerator("DateTickMarkPosition.MIDDLE");
        boolean boolean26 = combinedRangeXYPlot6.equals((java.lang.Object) "DateTickMarkPosition.MIDDLE");
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = combinedRangeXYPlot6.getDomainMarkers((int) (short) -1, layer28);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(collection29);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        timeSeries1.setDescription("Rotation.CLOCKWISE");
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        xYStepAreaRenderer1.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator23 = xYStepAreaRenderer1.getURLGenerator((int) (byte) 1, (int) (short) 1, true);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNull(xYURLGenerator23);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        timeSeries1.setDescription("[size=-1]");
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.DateFormat dateFormat1 = standardXYToolTipGenerator0.getYDateFormat();
        java.text.DateFormat dateFormat2 = standardXYToolTipGenerator0.getYDateFormat();
        java.lang.Object obj3 = standardXYToolTipGenerator0.clone();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape1 = xYStepRenderer0.getLegendLine();
        java.util.Collection collection2 = xYStepRenderer0.getAnnotations();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(collection2);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace5 = new org.jfree.chart.axis.AxisSpace();
        double double6 = axisSpace5.getRight();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean8 = axisSpace5.equals((java.lang.Object) itemLabelAnchor7);
        axisSpace5.setRight(0.2d);
        combinedRangeXYPlot0.setFixedDomainAxisSpace(axisSpace5, false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedRangeXYPlot0.setDrawingSupplier(drawingSupplier13, true);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        axisSpace0.setBottom((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        combinedRangeXYPlot0.setGap((double) 255);
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        combinedRangeXYPlot0.setOutlinePaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeStickyZero();
        double double2 = numberAxis0.getFixedAutoRange();
        numberAxis0.setInverted(true);
        numberAxis0.setUpperBound((-1.0d));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        xYStepAreaRenderer23.setShapesFilled(false);
        xYStepAreaRenderer23.setSeriesCreateEntities((int) '4', (java.lang.Boolean) true);
        java.awt.Font font30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color31 = java.awt.Color.GRAY;
        int int32 = color31.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock33 = new org.jfree.chart.block.LabelBlock("", font30, (java.awt.Paint) color31);
        xYStepAreaRenderer23.setBaseFillPaint((java.awt.Paint) color31, false);
        periodAxis19.setTickLabelPaint((java.awt.Paint) color31);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 128 + "'", int32 == 128);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        xYSeries1.setMaximumItemCount((int) (short) 0);
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.addOrUpdate(0.2d, (double) 0);
        boolean boolean8 = xYSeries1.isEmpty();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        boolean boolean4 = legendItem3.isShapeFilled();
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem3.setOutlinePaint(paint5);
        java.awt.Stroke stroke7 = legendItem3.getLineStroke();
        boolean boolean8 = projectInfo0.equals((java.lang.Object) legendItem3);
        java.awt.Stroke stroke9 = legendItem3.getLineStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        textTitle1.setURLText("1,500%");
        boolean boolean4 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        java.awt.Paint paint10 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        jFreeChart11.removeLegend();
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        try {
            jFreeChart11.addSubtitle(4, (org.jfree.chart.title.Title) textTitle14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj3 = xYSeries2.clone();
        boolean boolean5 = xYSeries2.equals((java.lang.Object) (short) 10);
        int int6 = xYSeriesCollection0.indexOf(xYSeries2);
        xYSeriesCollection0.removeAllSeries();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate1 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        try {
            java.lang.Number number4 = intervalXYDelegate1.getEndX(0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape6 = defaultDrawingSupplier5.getNextShape();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis4.setDownArrow(shape10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray14);
        org.jfree.data.xy.XYDataset xYDataset16 = combinedRangeXYPlot12.getDataset();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        boolean boolean19 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        combinedRangeXYPlot12.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.chart.entity.XYItemEntity xYItemEntity25 = new org.jfree.chart.entity.XYItemEntity(shape10, (org.jfree.data.xy.XYDataset) timeSeriesCollection18, 0, (int) (short) 1, "DateTickMarkPosition.MIDDLE", "");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke27 = defaultDrawingSupplier26.getNextStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions31 = categoryAxis28.getCategoryLabelPositions();
        categoryAxis28.setCategoryLabelPositionOffset(0);
        double double34 = categoryAxis28.getCategoryMargin();
        java.awt.Font font36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color37 = java.awt.Color.GRAY;
        int int38 = color37.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock39 = new org.jfree.chart.block.LabelBlock("", font36, (java.awt.Paint) color37);
        categoryAxis28.setAxisLinePaint((java.awt.Paint) color37);
        try {
            org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem(attributedString0, "Pie Plot", "Rotation.CLOCKWISE", "February", shape10, stroke27, (java.awt.Paint) color37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(categoryLabelPositions31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.2d + "'", double34 == 0.2d);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 128 + "'", int38 == 128);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color7);
        combinedRangeXYPlot4.setOutlinePaint((java.awt.Paint) color7);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(0.4d, 1.0E10d, (double) 10.0f, (double) 255, (java.awt.Paint) color7);
        float[] floatArray11 = new float[] {};
        try {
            float[] floatArray12 = color7.getColorComponents(floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        int int5 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        numberAxis3D4.setAutoRangeStickyZero(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        legendItem2.setToolTipText("hi!");
        java.awt.Paint paint5 = legendItem2.getFillPaint();
        java.lang.Comparable comparable6 = legendItem2.getSeriesKey();
        legendItem2.setSeriesKey((java.lang.Comparable) 6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(comparable6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle18.arrange(graphics2D19, rectangleConstraint20);
        java.awt.geom.Rectangle2D rectangle2D22 = legendTitle18.getBounds();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = categoryAxis24.getCategoryLabelPositions();
        java.awt.Font font29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color30 = java.awt.Color.GRAY;
        int int31 = color30.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("", font29, (java.awt.Paint) color30);
        categoryAxis24.setLabelFont(font29);
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        double double35 = piePlot34.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint37 = defaultDrawingSupplier36.getNextPaint();
        piePlot34.setLabelLinkPaint(paint37);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape40 = defaultDrawingSupplier39.getNextShape();
        java.awt.Shape shape41 = defaultDrawingSupplier39.getNextShape();
        java.awt.Shape shape42 = defaultDrawingSupplier39.getNextShape();
        piePlot34.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font29, (org.jfree.chart.plot.Plot) piePlot34, false);
        legendTitle18.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart45);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 128 + "'", int31 == 128);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 90.0d + "'", double35 == 90.0d);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(shape42);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=128]");
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        piePlot1.setIgnoreNullValues(true);
        boolean boolean7 = rotation0.equals((java.lang.Object) true);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) rotation0, seriesChangeInfo8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = seriesChangeEvent9.getSummary();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(seriesChangeInfo10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getGreen();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray5 = new float[] { 2147483647, 255 };
        try {
            float[] floatArray6 = color0.getColorComponents(colorSpace2, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        boolean boolean3 = axisLocation0.equals((java.lang.Object) numberAxis3D2);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", image3, "Nearest", "0%", "0%");
        projectInfo7.setInfo("");
        java.lang.String str10 = projectInfo7.toString();
        java.lang.String str11 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " version DateTickMarkPosition.MIDDLE.\nNearest.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n0%" + "'", str10.equals(" version DateTickMarkPosition.MIDDLE.\nNearest.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n0%"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Nearest" + "'", str11.equals("Nearest"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate1 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        java.lang.Object obj2 = intervalXYDelegate1.clone();
        try {
            double double5 = intervalXYDelegate1.getEndXValue((int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis0.drawTickMarks(graphics2D4, (double) (short) 100, rectangle2D6, rectangleEdge7, axisState9);
        double double11 = axisState9.getCursor();
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.awt.Stroke stroke9 = combinedRangeXYPlot4.getDomainZeroBaselineStroke();
        combinedRangeXYPlot4.setBackgroundAlpha((float) (-1));
        java.awt.geom.Point2D point2D12 = combinedRangeXYPlot4.getQuadrantOrigin();
        try {
            combinedDomainXYPlot0.zoomRangeAxes((double) 0.5f, 90.0d, plotRenderingInfo3, point2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(point2D12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYLineAndShapeRenderer2.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor4 = itemLabelPosition3.getRotationAnchor();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.clearDomainMarkers();
        combinedRangeXYPlot3.setRangePannable(true);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedRangeXYPlot3.getFixedRangeAxisSpace();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        combinedRangeXYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D9);
        numberAxis3D9.setLowerBound((double) 10L);
        java.awt.Shape shape13 = numberAxis3D9.getRightArrow();
        boolean boolean14 = numberAxis3D9.getAutoRangeIncludesZero();
        org.jfree.data.general.PieDataset pieDataset15 = null;
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot(pieDataset15);
        org.jfree.chart.plot.PiePlot piePlot17 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot17.getLabelPadding();
        piePlot16.setSimpleLabelOffset(rectangleInsets18);
        double double21 = rectangleInsets18.extendWidth((double) 2);
        numberAxis3D9.setLabelInsets(rectangleInsets18, true);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 6.0d + "'", double21 == 6.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        org.jfree.data.xy.XYDataItem xYDataItem4 = new org.jfree.data.xy.XYDataItem(0.0d, (double) (-1.0f));
        xYSeries1.add(xYDataItem4, false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape10 = defaultDrawingSupplier9.getNextShape();
        java.awt.Shape shape13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis15.getCategoryLabelPositions();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color21 = java.awt.Color.GRAY;
        int int22 = color21.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("", font20, (java.awt.Paint) color21);
        categoryAxis15.setLabelFont(font20);
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        double double26 = piePlot25.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextPaint();
        piePlot25.setLabelLinkPaint(paint28);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape31 = defaultDrawingSupplier30.getNextShape();
        java.awt.Shape shape32 = defaultDrawingSupplier30.getNextShape();
        java.awt.Shape shape33 = defaultDrawingSupplier30.getNextShape();
        piePlot25.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier30);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font20, (org.jfree.chart.plot.Plot) piePlot25, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity37 = new org.jfree.chart.entity.JFreeChartEntity(shape10, jFreeChart36);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo42 = null;
        java.awt.image.BufferedImage bufferedImage43 = jFreeChart36.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo42);
        jFreeChart36.setTextAntiAlias(true);
        combinedRangeXYPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart36);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 128 + "'", int22 == 128);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 90.0d + "'", double26 == 90.0d);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(bufferedImage43);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        java.awt.Stroke stroke5 = combinedRangeXYPlot0.getDomainZeroBaselineStroke();
        java.awt.Paint paint6 = combinedRangeXYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot7.getRangeAxisLocation();
        java.awt.Color color13 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color13);
        boolean boolean15 = legendItem14.isShapeFilled();
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem14.setOutlinePaint(paint16);
        java.awt.Stroke stroke18 = legendItem14.getLineStroke();
        combinedRangeXYPlot7.setRangeZeroBaselineStroke(stroke18);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot25.setDomainAxes(valueAxisArray27);
        org.jfree.data.xy.XYDataset xYDataset29 = combinedRangeXYPlot25.getDataset();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeZone30);
        boolean boolean32 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        combinedRangeXYPlot25.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        timeSeries24.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection31);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis39 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year22, (org.jfree.data.time.RegularTimePeriod) year35);
        periodAxis39.setMinorTickMarkInsideLength(0.0f);
        periodAxis39.setMinorTickMarksVisible(true);
        java.awt.Stroke stroke44 = periodAxis39.getAxisLineStroke();
        combinedRangeXYPlot7.setDomainAxis((org.jfree.chart.axis.ValueAxis) periodAxis39);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer49 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot52.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot52.setDomainAxes(valueAxisArray54);
        combinedRangeXYPlot52.clearRangeAxes();
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        boolean boolean59 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection58);
        org.jfree.data.Range range61 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection58, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState63 = xYStepAreaRenderer49.initialise(graphics2D50, rectangle2D51, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot52, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, plotRenderingInfo62);
        java.awt.Paint paint65 = xYStepAreaRenderer49.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer49);
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = null;
        org.jfree.chart.util.Size2D size2D69 = legendTitle66.arrange(graphics2D67, rectangleConstraint68);
        java.awt.geom.Rectangle2D rectangle2D70 = legendTitle66.getBounds();
        try {
            combinedRangeXYPlot0.drawOutline(graphics2D47, rectangle2D70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertNull(xYDataset29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(valueAxisArray54);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNull(range61);
        org.junit.Assert.assertNotNull(xYItemRendererState63);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(size2D69);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        boolean boolean10 = combinedRangeXYPlot0.equals((java.lang.Object) 10.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape20 = defaultDrawingSupplier19.getNextShape();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape20, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot24.clearDomainMarkers();
        combinedRangeXYPlot24.setRangePannable(true);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        combinedRangeXYPlot24.drawBackgroundImage(graphics2D28, rectangle2D29);
        java.awt.Color color31 = java.awt.Color.GRAY;
        combinedRangeXYPlot24.setRangeGridlinePaint((java.awt.Paint) color31);
        java.awt.Font font34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color35 = java.awt.Color.GRAY;
        int int36 = color35.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("", font34, (java.awt.Paint) color35);
        combinedRangeXYPlot24.setRangeTickBandPaint((java.awt.Paint) color35);
        java.awt.Color color39 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = xYLineAndShapeRenderer42.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer42.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator50 = null;
        xYLineAndShapeRenderer42.setSeriesURLGenerator(0, xYURLGenerator50, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator53 = null;
        xYLineAndShapeRenderer42.setLegendItemToolTipGenerator(xYSeriesLabelGenerator53);
        boolean boolean55 = xYLineAndShapeRenderer42.getBaseItemLabelsVisible();
        java.awt.Stroke stroke57 = xYLineAndShapeRenderer42.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot58 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = piePlot58.getLabelPadding();
        double double61 = rectangleInsets59.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder62 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color39, stroke57, rectangleInsets59);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer64 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot67 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot67.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray69 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot67.setDomainAxes(valueAxisArray69);
        combinedRangeXYPlot67.clearRangeAxes();
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection73 = new org.jfree.data.time.TimeSeriesCollection(timeZone72);
        boolean boolean74 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection73);
        org.jfree.data.Range range76 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection73, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState78 = xYStepAreaRenderer64.initialise(graphics2D65, rectangle2D66, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot67, (org.jfree.data.xy.XYDataset) timeSeriesCollection73, plotRenderingInfo77);
        java.awt.Paint paint80 = xYStepAreaRenderer64.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem81 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape23, (java.awt.Paint) color35, stroke57, paint80);
        org.jfree.chart.plot.IntervalMarker intervalMarker82 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint80);
        java.awt.Color color84 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color84);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer86 = legendItem85.getFillPaintTransformer();
        intervalMarker82.setGradientPaintTransformer(gradientPaintTransformer86);
        java.awt.Paint paint88 = intervalMarker82.getPaint();
        boolean boolean89 = chartChangeEventType12.equals((java.lang.Object) intervalMarker82);
        plotChangeEvent11.setType(chartChangeEventType12);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 128 + "'", int36 == 128);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.0d + "'", double61 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray69);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNull(range76);
        org.junit.Assert.assertNotNull(xYItemRendererState78);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertNotNull(gradientPaintTransformer86);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        java.awt.Paint paint5 = combinedRangeXYPlot0.getRangeTickBandPaint();
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot0.getDataset(5);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = combinedRangeXYPlot0.getOrientation();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        xYSeries1.setMaximumItemCount((int) (short) 0);
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.addOrUpdate(0.2d, (double) 0);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        java.util.List list9 = xYSeriesCollection8.getSeries();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        xYSeries1.setMaximumItemCount((int) (short) 0);
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.addOrUpdate(0.2d, (double) 0);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection(xYSeries1);
        try {
            xYSeries1.delete((int) (byte) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 98");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color2 = color1.brighter();
        org.jfree.chart.title.LegendGraphic legendGraphic3 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        java.awt.Paint paint4 = legendGraphic3.getFillPaint();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("Nearest", font1, paint3);
        org.jfree.chart.text.TextFragment textFragment5 = textLine4.getFirstTextFragment();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textFragment5.draw(graphics2D6, (float) 0, (float) (short) 1, textAnchor9, (float) 100L, 0.5f, (double) 128);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textFragment5);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot6.getDataset();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        boolean boolean13 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        combinedRangeXYPlot6.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        timeSeries5.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month((int) (byte) 10, year16);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year16.getMiddleMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMaxY();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = labelBlock4.getTextAnchor();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 10L, (float) 10L, (float) (short) 1);
        boolean boolean12 = rectangleAnchor5.equals((java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        piePlot0.setLabelLinkPaint(paint3);
        double double5 = piePlot0.getStartAngle();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        piePlot0.setDataset(pieDataset6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection3 = chartRenderingInfo0.getEntityCollection();
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertNotNull(entityCollection2);
        org.junit.Assert.assertNotNull(entityCollection3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getRootPlot();
        xYLineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot23.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        double double26 = piePlot23.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer29.getItemOutlineStroke((int) 'a', 0, false);
        piePlot23.setBaseSectionOutlineStroke(stroke33);
        xYBarRenderer1.drawDomainLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, paint22, stroke33);
        boolean boolean36 = combinedRangeXYPlot11.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot37.clearDomainMarkers();
        combinedRangeXYPlot37.setRangePannable(true);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        combinedRangeXYPlot37.drawBackgroundImage(graphics2D41, rectangle2D42);
        java.awt.Color color44 = java.awt.Color.GRAY;
        combinedRangeXYPlot37.setRangeGridlinePaint((java.awt.Paint) color44);
        boolean boolean47 = combinedRangeXYPlot37.equals((java.lang.Object) 10.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent48 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot37);
        combinedRangeXYPlot11.notifyListeners(plotChangeEvent48);
        boolean boolean50 = combinedRangeXYPlot11.isDomainGridlinesVisible();
        combinedRangeXYPlot11.clearDomainMarkers(4);
        java.util.List list53 = combinedRangeXYPlot11.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(list53);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Paint paint7 = xYAreaRenderer0.getItemLabelPaint(0, 255, true);
        boolean boolean8 = xYAreaRenderer0.getPlotArea();
        boolean boolean9 = xYAreaRenderer0.getPlotArea();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean3 = axisSpace0.equals((java.lang.Object) itemLabelAnchor2);
        double double4 = axisSpace0.getRight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Color color2 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color2);
        boolean boolean4 = legendItem3.isShapeFilled();
        java.awt.Paint paint5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem3.setOutlinePaint(paint5);
        java.awt.Stroke stroke7 = legendItem3.getLineStroke();
        boolean boolean8 = projectInfo0.equals((java.lang.Object) legendItem3);
        java.lang.String str9 = legendItem3.getURLText();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 1.0f, (double) '4');
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D0.setDrawBarOutline(true);
        barRenderer3D0.clearSeriesPaints(true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.xy.XYSeries xYSeries0 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection(xYSeries0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        boolean boolean9 = xYLineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Paint paint10 = xYLineAndShapeRenderer2.getBaseFillPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        numberAxis3D0.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Color color1 = java.awt.Color.getColor("WMAP_Plot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean3 = axisSpace0.equals((java.lang.Object) itemLabelAnchor2);
        double double4 = axisSpace0.getBottom();
        axisSpace0.setBottom((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot9.getRangeAxisLocation();
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation13, false);
        boolean boolean16 = combinedRangeXYPlot0.isDomainZoomable();
        java.awt.Stroke stroke17 = combinedRangeXYPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setSeriesLinesVisible(0, false);
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement12);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.GRAY;
        int int17 = color16.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("", font15, (java.awt.Paint) color16);
        java.lang.Object obj19 = null;
        columnArrangement12.add((org.jfree.chart.block.Block) labelBlock18, obj19);
        columnArrangement12.clear();
        org.jfree.chart.block.Arrangement arrangement22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer2, (org.jfree.chart.block.Arrangement) columnArrangement12, arrangement22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = legendTitle23.getLegendItemGraphicPadding();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 128 + "'", int17 == 128);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator13 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot0.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator13);
        boolean boolean15 = piePlot0.getIgnoreZeroValues();
        java.awt.Color color16 = java.awt.Color.LIGHT_GRAY;
        boolean boolean17 = piePlot0.equals((java.lang.Object) color16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        int int19 = color18.getGreen();
        int int20 = color18.getGreen();
        piePlot0.setLabelPaint((java.awt.Paint) color18);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 128 + "'", int19 == 128);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 128 + "'", int20 == 128);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis0.setDownArrow(shape6);
        boolean boolean8 = numberAxis0.isNegativeArrowVisible();
        numberAxis0.setAutoRangeIncludesZero(true);
        java.awt.Paint paint11 = numberAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer12.setUseFillPaint(false);
        boolean boolean15 = xYAreaRenderer12.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot18.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot18.setDomainAxes(valueAxisArray20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYAreaRenderer12.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.data.xy.XYDataset) timeSeriesCollection23, plotRenderingInfo25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = combinedRangeXYPlot18.getInsets();
        java.lang.String str28 = rectangleInsets27.toString();
        piePlot0.setSimpleLabelOffset(rectangleInsets27);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.clearDomainMarkers();
        combinedRangeXYPlot30.setRangePannable(true);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        combinedRangeXYPlot30.drawBackgroundImage(graphics2D34, rectangle2D35);
        java.awt.Color color37 = java.awt.Color.GRAY;
        combinedRangeXYPlot30.setRangeGridlinePaint((java.awt.Paint) color37);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot39.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation43 = combinedRangeXYPlot39.getRangeAxisLocation();
        combinedRangeXYPlot30.setRangeAxisLocation(axisLocation43, false);
        piePlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot30);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        java.awt.Paint paint48 = piePlot0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str28.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        boolean boolean15 = xYAreaRenderer0.getPlotLines();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = xYAreaRenderer0.getGradientTransformer();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        java.awt.Stroke stroke5 = combinedRangeXYPlot0.getOutlineStroke();
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot6.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        double double9 = piePlot6.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke16 = xYLineAndShapeRenderer12.getItemOutlineStroke((int) 'a', 0, false);
        piePlot6.setBaseSectionOutlineStroke(stroke16);
        combinedRangeXYPlot0.setRangeGridlineStroke(stroke16);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color2 = color1.brighter();
        org.jfree.chart.title.LegendGraphic legendGraphic3 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        try {
            legendGraphic3.setShapeAnchor(rectangleAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = xYBarRenderer1.getGradientPaintTransformer();
        xYBarRenderer1.setShadowXOffset(100.0d);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        try {
            double double21 = timeSeriesCollection15.getStartYValue((int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        combinedRangeXYPlot0.setDomainCrosshairPaint(paint10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray14);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, 128);
        combinedRangeXYPlot0.zoom(0.05d);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        xYSeries1.setMaximumItemCount((int) (short) 0);
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.addOrUpdate(0.2d, (double) 0);
        java.lang.Comparable comparable8 = xYSeries1.getKey();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem10 = xYSeries1.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + true + "'", comparable8.equals(true));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray10);
        org.jfree.data.xy.XYDataset xYDataset12 = combinedRangeXYPlot8.getDataset();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeZone13);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        combinedRangeXYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.entity.XYItemEntity xYItemEntity21 = new org.jfree.chart.entity.XYItemEntity(shape6, (org.jfree.data.xy.XYDataset) timeSeriesCollection14, 0, (int) (short) 1, "DateTickMarkPosition.MIDDLE", "");
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection14, false);
        try {
            java.lang.Number number26 = timeSeriesCollection14.getEndX(255, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer7.setUseFillPaint(false);
        boolean boolean10 = xYAreaRenderer7.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        boolean boolean19 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYAreaRenderer7.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, (org.jfree.data.xy.XYDataset) timeSeriesCollection18, plotRenderingInfo20);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        double double23 = piePlot22.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextPaint();
        piePlot22.setLabelLinkPaint(paint25);
        timeSeriesCollection18.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot22);
        int int28 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        combinedRangeXYPlot0.zoomRangeAxes((double) (short) 100, plotRenderingInfo30, point2D31);
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke41 = xYLineAndShapeRenderer37.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot42.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot42.setDomainAxes(valueAxisArray44);
        combinedRangeXYPlot42.clearRangeAxes();
        java.awt.Stroke stroke47 = combinedRangeXYPlot42.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot48 = combinedRangeXYPlot42.getRootPlot();
        xYLineAndShapeRenderer37.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot42);
        combinedRangeXYPlot42.clearAnnotations();
        org.jfree.chart.util.Layer layer51 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection52 = combinedRangeXYPlot42.getDomainMarkers(layer51);
        try {
            boolean boolean53 = combinedRangeXYPlot0.removeRangeMarker(2, marker34, layer51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 90.0d + "'", double23 == 90.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(valueAxisArray44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(plot48);
        org.junit.Assert.assertNotNull(layer51);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Pie Plot");
        java.awt.Paint paint2 = standardChartTheme1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setShadowXOffset((double) ' ');
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) 7);
        piePlot0.setLegendItemShape(shape5);
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape5, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        java.awt.geom.Point2D point2D4 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D2, rectangleAnchor3);
        crosshairState1.setAnchor(point2D4);
        crosshairState1.setCrosshairDistance(4.0d);
        int int8 = crosshairState1.getRangeAxisIndex();
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot7.setDomainAxes(valueAxisArray9);
        org.jfree.data.xy.XYDataset xYDataset11 = combinedRangeXYPlot7.getDataset();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeZone12);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year4, (org.jfree.data.time.RegularTimePeriod) year17);
        java.util.TimeZone timeZone22 = periodAxis21.getTimeZone();
        periodAxis21.setLabel("January");
        java.lang.Class class25 = periodAxis21.getMajorTickTimePeriodClass();
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.UnknownKeyException: DateTickMarkPosition.MIDDLE", class25);
        java.io.InputStream inputStream27 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("January", class25);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(class25);
        org.junit.Assert.assertNull(inputStream26);
        org.junit.Assert.assertNull(inputStream27);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setUseFillPaint(false);
        boolean boolean11 = xYLineAndShapeRenderer2.getUseOutlinePaint();
        org.jfree.chart.LegendItem legendItem14 = xYLineAndShapeRenderer2.getLegendItem((int) (short) -1, (int) (short) 10);
        java.awt.Paint paint16 = xYLineAndShapeRenderer2.getSeriesItemLabelPaint((int) (short) 10);
        xYLineAndShapeRenderer2.setBaseLinesVisible(true);
        org.jfree.chart.LegendItem legendItem21 = xYLineAndShapeRenderer2.getLegendItem((int) (byte) 10, 0);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(legendItem14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNull(legendItem21);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = categoryAxis5.getCategoryLabelPositions();
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color11 = java.awt.Color.GRAY;
        int int12 = color11.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("", font10, (java.awt.Paint) color11);
        categoryAxis5.setLabelFont(font10);
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot();
        double double16 = piePlot15.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint18 = defaultDrawingSupplier17.getNextPaint();
        piePlot15.setLabelLinkPaint(paint18);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape21 = defaultDrawingSupplier20.getNextShape();
        java.awt.Shape shape22 = defaultDrawingSupplier20.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier20.getNextShape();
        piePlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20);
        org.jfree.chart.JFreeChart jFreeChart26 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font10, (org.jfree.chart.plot.Plot) piePlot15, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener27 = null;
        jFreeChart26.addProgressListener(chartProgressListener27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection33 = chartRenderingInfo32.getEntityCollection();
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart26.createBufferedImage((int) (byte) 10, (int) '4', (int) (short) 1, chartRenderingInfo32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = chartRenderingInfo32.getPlotInfo();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot36 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot36.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot36.setDomainAxes(valueAxisArray38);
        combinedRangeXYPlot36.clearRangeAxes();
        java.awt.Stroke stroke41 = combinedRangeXYPlot36.getDomainZeroBaselineStroke();
        combinedRangeXYPlot36.setBackgroundAlpha((float) (-1));
        java.awt.geom.Point2D point2D44 = combinedRangeXYPlot36.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot45 = combinedDomainXYPlot3.findSubplot(plotRenderingInfo35, point2D44);
        try {
            combinedRangeXYPlot0.zoomDomainAxes(4.0d, plotRenderingInfo2, point2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 128 + "'", int12 == 128);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 90.0d + "'", double16 == 90.0d);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(entityCollection33);
        org.junit.Assert.assertNotNull(bufferedImage34);
        org.junit.Assert.assertNotNull(plotRenderingInfo35);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertNull(xYPlot45);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        java.util.TimeZone timeZone20 = periodAxis19.getTimeZone();
        periodAxis19.setLabel("January");
        java.lang.Class class23 = periodAxis19.getMajorTickTimePeriodClass();
        double double24 = periodAxis19.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0E-8d + "'", double24 == 1.0E-8d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Color color2 = java.awt.Color.getColor("{0}", 9999);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, (float) (byte) 0, (float) 100, (double) 7);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint12 = defaultDrawingSupplier11.getNextPaint();
        org.jfree.chart.text.TextLine textLine13 = new org.jfree.chart.text.TextLine("Nearest", font10, paint12);
        org.jfree.chart.text.TextFragment textFragment14 = textLine13.getFirstTextFragment();
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("Nearest");
        java.lang.String str17 = textFragment16.getText();
        textLine13.addFragment(textFragment16);
        textBlock0.addLine(textLine13);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(textFragment14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Nearest" + "'", str17.equals("Nearest"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.lang.Object obj1 = barRenderer3D0.clone();
        double double2 = barRenderer3D0.getShadowYOffset();
        double double3 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = barRenderer3D0.getLegendItems();
        java.awt.Stroke stroke8 = barRenderer3D0.getItemOutlineStroke((int) (byte) 100, (int) (byte) 10, false);
        boolean boolean10 = barRenderer3D0.isSeriesItemLabelsVisible((int) ' ');
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        java.awt.Paint paint10 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = piePlot11.getLabelPadding();
        double double14 = rectangleInsets12.calculateTopOutset((double) (short) -1);
        combinedRangeXYPlot0.setInsets(rectangleInsets12);
        combinedRangeXYPlot0.clearDomainMarkers(100);
        int int18 = combinedRangeXYPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(100.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        java.awt.Paint paint4 = piePlot0.getSectionPaint((java.lang.Comparable) (short) 10);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        categoryAxis1.setLabelFont(font6);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextPaint();
        piePlot11.setLabelLinkPaint(paint14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape18 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape19 = defaultDrawingSupplier16.getNextShape();
        piePlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font6, (org.jfree.chart.plot.Plot) piePlot11, false);
        java.awt.Shape shape23 = piePlot11.getLegendItemShape();
        piePlot11.setAutoPopulateSectionOutlinePaint(false);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setShadowXOffset((double) ' ');
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) 7);
        piePlot0.setLegendItemShape(shape5);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        java.awt.Shape shape9 = defaultDrawingSupplier7.getNextShape();
        piePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier7);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot1.clearDomainMarkers();
        combinedRangeXYPlot1.setRangePannable(true);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        combinedRangeXYPlot1.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Color color8 = java.awt.Color.GRAY;
        combinedRangeXYPlot1.setRangeGridlinePaint((java.awt.Paint) color8);
        combinedRangeXYPlot1.setRangeCrosshairLockedOnData(false);
        boolean boolean12 = lengthAdjustmentType0.equals((java.lang.Object) combinedRangeXYPlot1);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Other");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        java.awt.Stroke stroke5 = combinedRangeXYPlot0.getDomainZeroBaselineStroke();
        java.awt.Paint paint6 = combinedRangeXYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation7 = null;
        try {
            boolean boolean9 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color2 = color1.brighter();
        org.jfree.chart.title.LegendGraphic legendGraphic3 = new org.jfree.chart.title.LegendGraphic(shape0, (java.awt.Paint) color1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendGraphic3.getShapeLocation();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.title.LegendTitle legendTitle29 = jFreeChart27.getLegend();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(legendTitle29);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray24 = periodAxis19.getLabelInfo();
        float float25 = periodAxis19.getTickMarkInsideLength();
        periodAxis19.setMinorTickMarkOutsideLength(10.0f);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray24);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = labelBlock4.getTextAnchor();
        labelBlock4.setToolTipText("January");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarksVisible(true);
        boolean boolean24 = periodAxis19.isVerticalTickLabels();
        boolean boolean25 = periodAxis19.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        int int18 = timeSeriesCollection16.indexOf((java.lang.Comparable) "Other");
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.DateFormat dateFormat2 = standardXYToolTipGenerator1.getYDateFormat();
        java.text.DateFormat dateFormat3 = standardXYToolTipGenerator1.getYDateFormat();
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator4 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(9999, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator4);
        double double6 = xYStepAreaRenderer5.getRangeBase();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle18.arrange(graphics2D19, rectangleConstraint20);
        java.lang.String str22 = size2D21.toString();
        size2D21.width = 3;
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str22.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        xYStepAreaRenderer1.setShapesFilled(false);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYStepAreaRenderer1.setSeriesOutlineStroke(2, stroke5, false);
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke5, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        labelBlock4.setHeight(0.0d);
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        boolean boolean9 = labelBlock4.equals((java.lang.Object) color7);
        java.awt.Color color10 = color7.darker();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color13 = java.awt.Color.GRAY;
        int int14 = color13.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("", font12, (java.awt.Paint) color13);
        labelBlock15.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        labelBlock15.setTextAnchor(rectangleAnchor18);
        boolean boolean20 = color10.equals((java.lang.Object) rectangleAnchor18);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.lang.Object obj19 = legendTitle18.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getItemLabelPadding();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = legendTitle18.getPosition();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        xYBarRenderer1.setBarAlignmentFactor((double) 0);
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        org.jfree.data.Range range7 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer9.setUseFillPaint(false);
        boolean boolean12 = xYAreaRenderer9.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot15.setDomainAxes(valueAxisArray17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection(timeZone19);
        boolean boolean21 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYAreaRenderer9.initialise(graphics2D13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.data.xy.XYDataset) timeSeriesCollection20, plotRenderingInfo22);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState24 = xYItemRendererState23.getCrosshairState();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot29.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot29.setDomainAxes(valueAxisArray31);
        combinedRangeXYPlot29.clearRangeAxes();
        java.util.TimeZone timeZone34 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection35 = new org.jfree.data.time.TimeSeriesCollection(timeZone34);
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection35);
        org.jfree.data.Range range38 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection35, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState40 = xYStepAreaRenderer26.initialise(graphics2D27, rectangle2D28, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot29, (org.jfree.data.xy.XYDataset) timeSeriesCollection35, plotRenderingInfo39);
        java.awt.Paint paint42 = xYStepAreaRenderer26.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer26);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = null;
        org.jfree.chart.util.Size2D size2D46 = legendTitle43.arrange(graphics2D44, rectangleConstraint45);
        java.awt.geom.Rectangle2D rectangle2D47 = legendTitle43.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double49 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D47, rectangleEdge48);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot50 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        numberAxis51.setUpperBound(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean55 = numberAxis54.getAutoRangeStickyZero();
        numberAxis54.zoomRange((-1.0d), (double) 9223372036854775807L);
        numberAxis54.setTickLabelsVisible(false);
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        try {
            xYBarRenderer1.drawItem(graphics2D8, xYItemRendererState23, rectangle2D47, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot50, (org.jfree.chart.axis.ValueAxis) numberAxis51, (org.jfree.chart.axis.ValueAxis) numberAxis54, xYDataset61, (int) (short) -1, 1900, false, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNull(xYCrosshairState24);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(xYItemRendererState40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj1 = numberAxis3D0.clone();
        numberAxis3D0.setAutoRangeMinimumSize((double) 15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYLineAndShapeRenderer10.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer10.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        xYLineAndShapeRenderer10.setSeriesURLGenerator(0, xYURLGenerator18, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = null;
        xYLineAndShapeRenderer10.setLegendItemToolTipGenerator(xYSeriesLabelGenerator21);
        java.lang.Boolean boolean24 = xYLineAndShapeRenderer10.getSeriesVisible(7);
        java.awt.Font font25 = xYLineAndShapeRenderer10.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D0, (double) 10L, (double) 2, (double) 7, (double) 1L, font25);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = numberAxis3D0.getTickUnit();
        double double28 = numberTickUnit27.getSize();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(numberTickUnit27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.START" + "'", str1.equals("DateTickMarkPosition.START"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean6 = barRenderer3D0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer3D0.setSeriesToolTipGenerator(0, categoryToolTipGenerator8);
        java.awt.Paint paint13 = barRenderer3D0.getItemOutlinePaint(5, 1, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = barRenderer3D0.getSeriesToolTipGenerator(5);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator17 = null;
        barRenderer3D0.setSeriesItemLabelGenerator(128, categoryItemLabelGenerator17);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 0L);
        double double3 = range2.getLength();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(range2);
        long long5 = dateRange4.getUpperMillis();
        org.jfree.data.Range range7 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange4, 0.0d);
        double double8 = range7.getLength();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", image3, "Nearest", "0%", "0%");
        projectInfo7.setLicenceName("LengthConstraintType.FIXED");
        projectInfo7.setCopyright("hi!");
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        org.jfree.data.Range range6 = timeSeriesCollection1.getDomainBounds(true);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertEquals((double) number7, Double.NaN, 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setSeriesLinesVisible(0, false);
        org.jfree.chart.plot.XYPlot xYPlot12 = xYLineAndShapeRenderer2.getPlot();
        xYLineAndShapeRenderer2.setSeriesShapesFilled(0, true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNull(xYPlot12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape9 = defaultDrawingSupplier8.getNextShape();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        combinedRangeXYPlot13.setRangePannable(true);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        combinedRangeXYPlot13.drawBackgroundImage(graphics2D17, rectangle2D18);
        java.awt.Color color20 = java.awt.Color.GRAY;
        combinedRangeXYPlot13.setRangeGridlinePaint((java.awt.Paint) color20);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color24 = java.awt.Color.GRAY;
        int int25 = color24.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("", font23, (java.awt.Paint) color24);
        combinedRangeXYPlot13.setRangeTickBandPaint((java.awt.Paint) color24);
        java.awt.Color color28 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = xYLineAndShapeRenderer31.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer31.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator39 = null;
        xYLineAndShapeRenderer31.setSeriesURLGenerator(0, xYURLGenerator39, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator42 = null;
        xYLineAndShapeRenderer31.setLegendItemToolTipGenerator(xYSeriesLabelGenerator42);
        boolean boolean44 = xYLineAndShapeRenderer31.getBaseItemLabelsVisible();
        java.awt.Stroke stroke46 = xYLineAndShapeRenderer31.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot47 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = piePlot47.getLabelPadding();
        double double50 = rectangleInsets48.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder51 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color28, stroke46, rectangleInsets48);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer53 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot56.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray58 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot56.setDomainAxes(valueAxisArray58);
        combinedRangeXYPlot56.clearRangeAxes();
        java.util.TimeZone timeZone61 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection62 = new org.jfree.data.time.TimeSeriesCollection(timeZone61);
        boolean boolean63 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection62);
        org.jfree.data.Range range65 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection62, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState67 = xYStepAreaRenderer53.initialise(graphics2D54, rectangle2D55, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot56, (org.jfree.data.xy.XYDataset) timeSeriesCollection62, plotRenderingInfo66);
        java.awt.Paint paint69 = xYStepAreaRenderer53.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem70 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape12, (java.awt.Paint) color24, stroke46, paint69);
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("Size2D[width=0.2, height=100.0]", "{0}: ({1}, {2})", "", "{0}", shape12, (java.awt.Paint) color71);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 128 + "'", int25 == 128);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.0d + "'", double50 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(range65);
        org.junit.Assert.assertNotNull(xYItemRendererState67);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(color71);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        boolean boolean2 = timeSeries1.isEmpty();
        boolean boolean3 = timeSeries1.getNotify();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean5 = timeSeries1.equals((java.lang.Object) rectangleAnchor4);
        timeSeries1.setRangeDescription("JFreeChartEntity: tooltip = null");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        org.jfree.data.xy.XYDataset xYDataset17 = combinedRangeXYPlot13.getDataset();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeZone18);
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        combinedRangeXYPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        timeSeries12.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year23);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        combinedRangeXYPlot5.clearRangeAxes();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState16 = xYStepAreaRenderer2.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        combinedRangeXYPlot5.panRangeAxes((-1.0d), plotRenderingInfo18, point2D19);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color23 = java.awt.Color.GRAY;
        int int24 = color23.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font22, (java.awt.Paint) color23);
        labelBlock25.setHeight(0.0d);
        java.awt.Color color28 = java.awt.Color.GRAY;
        int int29 = color28.getGreen();
        boolean boolean30 = labelBlock25.equals((java.lang.Object) color28);
        java.awt.Paint paint31 = labelBlock25.getPaint();
        combinedRangeXYPlot5.setDomainCrosshairPaint(paint31);
        combinedDomainXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, 128);
        org.jfree.chart.plot.Plot plot35 = combinedDomainXYPlot0.getParent();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(xYItemRendererState16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 128 + "'", int24 == 128);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 128 + "'", int29 == 128);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(plot35);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("DateTickUnitType.HOUR");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape3 = defaultDrawingSupplier2.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape3, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = categoryAxis8.getCategoryLabelPositions();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color14 = java.awt.Color.GRAY;
        int int15 = color14.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("", font13, (java.awt.Paint) color14);
        categoryAxis8.setLabelFont(font13);
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        double double19 = piePlot18.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint21 = defaultDrawingSupplier20.getNextPaint();
        piePlot18.setLabelLinkPaint(paint21);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape24 = defaultDrawingSupplier23.getNextShape();
        java.awt.Shape shape25 = defaultDrawingSupplier23.getNextShape();
        java.awt.Shape shape26 = defaultDrawingSupplier23.getNextShape();
        piePlot18.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier23);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font13, (org.jfree.chart.plot.Plot) piePlot18, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity30 = new org.jfree.chart.entity.JFreeChartEntity(shape3, jFreeChart29);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        java.awt.image.BufferedImage bufferedImage36 = jFreeChart29.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo35);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer37 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer37.setUseFillPaint(false);
        boolean boolean40 = xYAreaRenderer37.getBaseSeriesVisible();
        java.awt.Paint paint44 = xYAreaRenderer37.getItemLabelPaint(0, 255, true);
        jFreeChart29.setBackgroundPaint(paint44);
        standardChartTheme1.setShadowPaint(paint44);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 128 + "'", int15 == 128);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 90.0d + "'", double19 == 90.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(bufferedImage36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor1 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator3);
        double double5 = piePlot2.getMaximumLabelWidth();
        boolean boolean6 = piePlot2.getIgnoreNullValues();
        boolean boolean7 = itemLabelAnchor1.equals((java.lang.Object) boolean6);
        org.jfree.chart.axis.TickType tickType8 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick(tickType8, (double) 100L, "1,500%", textAnchor12, textAnchor14, (-1.0d));
        org.jfree.data.xy.XYDataItem xYDataItem19 = new org.jfree.data.xy.XYDataItem(0.0d, (double) (-1.0f));
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        int int21 = xYDataItem19.compareTo((java.lang.Object) textAnchor20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor1, textAnchor12, textAnchor20, (double) 10);
        boolean boolean24 = itemLabelAnchor0.equals((java.lang.Object) itemLabelAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(itemLabelAnchor1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.14d + "'", double5 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        boolean boolean2 = timeSeries1.isEmpty();
        boolean boolean3 = timeSeries1.getNotify();
        try {
            timeSeries1.delete(1, (-4145152));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        java.lang.String str1 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Rotation.CLOCKWISE" + "'", str1.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedRangeXYPlot5.getRangeAxisLocation();
        combinedRangeXYPlot0.setDomainAxisLocation(100, axisLocation9, false);
        combinedRangeXYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder14 = combinedRangeXYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(datasetRenderingOrder14);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.util.TableOrder tableOrder2 = multiplePiePlot1.getDataExtractOrder();
        double double3 = multiplePiePlot1.getLimit();
        org.junit.Assert.assertNotNull(tableOrder2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Pie Plot");
        java.awt.Font font2 = standardChartTheme1.getRegularFont();
        java.awt.Paint paint3 = standardChartTheme1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getRootPlot();
        xYLineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot23.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        double double26 = piePlot23.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer29.getItemOutlineStroke((int) 'a', 0, false);
        piePlot23.setBaseSectionOutlineStroke(stroke33);
        xYBarRenderer1.drawDomainLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, paint22, stroke33);
        double double36 = xYBarRenderer1.getBarAlignmentFactor();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions41 = categoryAxis38.getCategoryLabelPositions();
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color44 = java.awt.Color.GRAY;
        int int45 = color44.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock46 = new org.jfree.chart.block.LabelBlock("", font43, (java.awt.Paint) color44);
        categoryAxis38.setLabelFont(font43);
        xYBarRenderer1.setLegendTextFont((int) '#', font43);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape50 = xYBarRenderer1.getLegendBar();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36 == (-1.0d));
        org.junit.Assert.assertNotNull(categoryLabelPositions41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 128 + "'", int45 == 128);
        org.junit.Assert.assertNull(itemLabelPosition49);
        org.junit.Assert.assertNotNull(shape50);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        boolean boolean4 = timeSeries3.isEmpty();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        boolean boolean7 = timeSeries3.equals((java.lang.Object) rectangleAnchor6);
        timeSeries3.setRangeDescription("JFreeChartEntity: tooltip = null");
        java.util.List list10 = timeSeries3.getItems();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = combinedRangeXYPlot11.getDomainAxisEdge();
        org.jfree.data.Range range17 = null;
        org.jfree.data.Range range19 = org.jfree.data.Range.expandToInclude(range17, (double) 0L);
        double double20 = range19.getLength();
        org.jfree.data.time.DateRange dateRange21 = new org.jfree.data.time.DateRange(range19);
        boolean boolean22 = rectangleEdge16.equals((java.lang.Object) range19);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list10, range19, false);
        org.junit.Assert.assertNotNull(timeZone0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(range24);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        java.lang.String str1 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_RIGHT" + "'", str1.equals("TextBlockAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean6 = barRenderer3D0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer3D0.getSeriesToolTipGenerator((int) ' ');
        barRenderer3D0.setMaximumBarWidth(6.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot4.getRangeAxisLocation();
        java.awt.Color color10 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color10);
        boolean boolean12 = legendItem11.isShapeFilled();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem11.setOutlinePaint(paint13);
        java.awt.Stroke stroke15 = legendItem11.getLineStroke();
        combinedRangeXYPlot4.setRangeZeroBaselineStroke(stroke15);
        java.awt.Paint paint17 = combinedRangeXYPlot4.getRangeGridlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder(1.0E-8d, (double) (byte) 1, (double) '#', (double) (-1), paint17);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart27.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo33);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer35 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer35.setUseFillPaint(false);
        boolean boolean38 = xYAreaRenderer35.getBaseSeriesVisible();
        java.awt.Paint paint42 = xYAreaRenderer35.getItemLabelPaint(0, 255, true);
        jFreeChart27.setBackgroundPaint(paint42);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection47 = chartRenderingInfo46.getEntityCollection();
        org.jfree.chart.plot.PiePlot piePlot48 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator49 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot48.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator49);
        double double51 = piePlot48.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer54 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke58 = xYLineAndShapeRenderer54.getItemOutlineStroke((int) 'a', 0, false);
        piePlot48.setBaseSectionOutlineStroke(stroke58);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator61 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot48.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator61);
        boolean boolean63 = piePlot48.getIgnoreZeroValues();
        java.awt.Font font64 = piePlot48.getNoDataMessageFont();
        boolean boolean65 = chartRenderingInfo46.equals((java.lang.Object) piePlot48);
        org.jfree.chart.RenderingSource renderingSource66 = chartRenderingInfo46.getRenderingSource();
        try {
            java.awt.image.BufferedImage bufferedImage67 = jFreeChart27.createBufferedImage(100, (-4145152), chartRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (100) and height (-4145152) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(bufferedImage34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(entityCollection47);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(renderingSource66);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        combinedRangeXYPlot11.setRangePannable(true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        combinedRangeXYPlot11.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        combinedRangeXYPlot11.setRangeGridlinePaint((java.awt.Paint) color18);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color22 = java.awt.Color.GRAY;
        int int23 = color22.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color22);
        combinedRangeXYPlot11.setRangeTickBandPaint((java.awt.Paint) color22);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYLineAndShapeRenderer29.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer29.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        xYLineAndShapeRenderer29.setSeriesURLGenerator(0, xYURLGenerator37, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator40 = null;
        xYLineAndShapeRenderer29.setLegendItemToolTipGenerator(xYSeriesLabelGenerator40);
        boolean boolean42 = xYLineAndShapeRenderer29.getBaseItemLabelsVisible();
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer29.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = piePlot45.getLabelPadding();
        double double48 = rectangleInsets46.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color26, stroke44, rectangleInsets46);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot54.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot54.setDomainAxes(valueAxisArray56);
        combinedRangeXYPlot54.clearRangeAxes();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeZone59);
        boolean boolean61 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState65 = xYStepAreaRenderer51.initialise(graphics2D52, rectangle2D53, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot54, (org.jfree.data.xy.XYDataset) timeSeriesCollection60, plotRenderingInfo64);
        java.awt.Paint paint67 = xYStepAreaRenderer51.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape10, (java.awt.Paint) color22, stroke44, paint67);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint67);
        java.awt.Color color71 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color71);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer73 = legendItem72.getFillPaintTransformer();
        intervalMarker69.setGradientPaintTransformer(gradientPaintTransformer73);
        java.awt.Paint paint75 = intervalMarker69.getPaint();
        org.jfree.chart.text.TextAnchor textAnchor76 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        intervalMarker69.setLabelTextAnchor(textAnchor76);
        java.awt.Paint paint78 = null;
        try {
            intervalMarker69.setLabelPaint(paint78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 128 + "'", int23 == 128);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNotNull(xYItemRendererState65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(gradientPaintTransformer73);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(textAnchor76);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        barRenderer3D0.setAutoPopulateSeriesFillPaint(false);
        double double7 = barRenderer3D0.getMaximumBarWidth();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer3D0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(0.2d, 100.0d);
        java.lang.String str3 = size2D2.toString();
        size2D2.height = 0.0f;
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Size2D[width=0.2, height=100.0]" + "'", str3.equals("Size2D[width=0.2, height=100.0]"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator6 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat7 = standardPieToolTipGenerator6.getPercentFormat();
        boolean boolean8 = textAnchor4.equals((java.lang.Object) numberFormat7);
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 5, (float) '4', textAnchor4, (double) '#', (float) 6, (float) 'a');
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.StandardChartTheme standardChartTheme2 = new org.jfree.chart.StandardChartTheme("Pie Plot");
        java.awt.Font font3 = standardChartTheme2.getRegularFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("Value", font3);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceName();
        java.lang.String str2 = projectInfo0.getLicenceText();
        projectInfo0.setVersion("January");
        projectInfo0.addOptionalLibrary("series");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray14);
        org.jfree.data.xy.XYDataset xYDataset16 = combinedRangeXYPlot12.getDataset();
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = combinedRangeXYPlot12.getDomainMarkers(layer17);
        double double19 = combinedRangeXYPlot12.getRangeCrosshairValue();
        timeSeriesCollection8.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot12);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color25 = java.awt.Color.GRAY;
        int int26 = color25.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock27 = new org.jfree.chart.block.LabelBlock("", font24, (java.awt.Paint) color25);
        multiplePiePlot22.setAggregatedItemsPaint((java.awt.Paint) color25);
        combinedRangeXYPlot12.setDomainMinorGridlinePaint((java.awt.Paint) color25);
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNull(xYDataset16);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 128 + "'", int26 == 128);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer7.setUseFillPaint(false);
        boolean boolean10 = xYAreaRenderer7.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        boolean boolean19 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYAreaRenderer7.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, (org.jfree.data.xy.XYDataset) timeSeriesCollection18, plotRenderingInfo20);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        double double23 = piePlot22.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextPaint();
        piePlot22.setLabelLinkPaint(paint25);
        timeSeriesCollection18.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot22);
        int int28 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        try {
            timeSeriesCollection18.removeSeries((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 90.0d + "'", double23 == 90.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeFilled();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setOutlinePaint(paint4);
        java.awt.Paint paint6 = legendItem2.getFillPaint();
        boolean boolean7 = legendItem2.isShapeVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("Pie Plot");
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        double double3 = piePlot2.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint5 = defaultDrawingSupplier4.getNextPaint();
        piePlot2.setLabelLinkPaint(paint5);
        piePlot2.setLabelLinkMargin(90.0d);
        int int9 = piePlot2.getBackgroundImageAlignment();
        boolean boolean10 = standardXYSeriesLabelGenerator1.equals((java.lang.Object) piePlot2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        piePlot0.setLabelLinkPaint(paint3);
        double double5 = piePlot0.getStartAngle();
        double double6 = piePlot0.getLabelLinkMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.025d + "'", double6 == 0.025d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = piePlot0.getLegendLabelToolTipGenerator();
        java.awt.Stroke stroke4 = piePlot0.getLabelOutlineStroke();
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.TimeZone timeZone7 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone7;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone7;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("Value", timeZone7);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot16.setDomainAxes(valueAxisArray18);
        org.jfree.data.xy.XYDataset xYDataset20 = combinedRangeXYPlot16.getDataset();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        boolean boolean23 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        combinedRangeXYPlot16.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection22);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis30 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year13, (org.jfree.data.time.RegularTimePeriod) year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year13.next();
        java.util.Date date32 = year13.getStart();
        dateAxis10.setMinimumDate(date32);
        org.jfree.data.Range range34 = null;
        org.jfree.data.Range range36 = org.jfree.data.Range.expandToInclude(range34, (double) 0L);
        double double37 = range36.getLength();
        org.jfree.data.time.DateRange dateRange38 = new org.jfree.data.time.DateRange(range36);
        java.util.Date date39 = dateRange38.getUpperDate();
        dateAxis10.setMinimumDate(date39);
        java.util.TimeZone timeZone41 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone41;
        java.util.Date date43 = dateTickUnit5.addToDate(date39, timeZone41);
        java.awt.Paint paint44 = null;
        piePlot0.setSectionOutlinePaint((java.lang.Comparable) date43, paint44);
        org.junit.Assert.assertNull(pieSectionLabelGenerator3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(date43);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        double double3 = piePlot2.getStartAngle();
        piePlot2.clearSectionOutlinePaints(true);
        boolean boolean6 = timeSeriesCollection1.hasListener((java.util.EventListener) piePlot2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 90.0d + "'", double3 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        axisSpace0.setTop(0.14d);
        axisSpace0.setLeft((-16.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("Value", timeZone1);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot10.getDataset();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        combinedRangeXYPlot10.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        timeSeries9.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection16);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis24 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) year20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year7.next();
        java.util.Date date26 = year7.getStart();
        dateAxis4.setMinimumDate(date26);
        org.jfree.data.Range range28 = null;
        org.jfree.data.Range range30 = org.jfree.data.Range.expandToInclude(range28, (double) 0L);
        double double31 = range30.getLength();
        org.jfree.data.time.DateRange dateRange32 = new org.jfree.data.time.DateRange(range30);
        java.util.Date date33 = dateRange32.getUpperDate();
        dateAxis4.setMinimumDate(date33);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition35 = dateAxis4.getTickMarkPosition();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(dateTickMarkPosition35);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot6.getDataset();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        boolean boolean13 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        combinedRangeXYPlot6.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        timeSeries5.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year16);
        java.util.TimeZone timeZone21 = periodAxis20.getTimeZone();
        periodAxis20.setLabel("January");
        java.lang.Class class24 = periodAxis20.getMajorTickTimePeriodClass();
        java.lang.Object obj25 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("{0}", class24);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNull(obj25);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, (float) (byte) 0, (float) 100, (double) 7);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        textBlock0.addLine("Pie Plot", font10, paint11);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        org.jfree.data.Range range4 = xYBarRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        java.awt.Paint paint5 = xYBarRenderer1.getBasePaint();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        java.lang.Object obj3 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        java.awt.Paint paint2 = piePlot0.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color21 = java.awt.Color.GRAY;
        int int22 = color21.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("", font20, (java.awt.Paint) color21);
        labelBlock23.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        labelBlock23.setTextAnchor(rectangleAnchor26);
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor26);
        legendTitle18.setID("January");
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis31.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions34 = categoryAxis31.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState40 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis31.drawTickMarks(graphics2D35, (double) (short) 100, rectangle2D37, rectangleEdge38, axisState40);
        legendTitle18.setLegendItemGraphicEdge(rectangleEdge38);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 128 + "'", int22 == 128);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(categoryLabelPositions34);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot16.setDomainAxes(valueAxisArray18);
        combinedRangeXYPlot16.clearRangeAxes();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        boolean boolean23 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        org.jfree.data.Range range25 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection22, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState27 = xYStepAreaRenderer13.initialise(graphics2D14, rectangle2D15, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot16, (org.jfree.data.xy.XYDataset) timeSeriesCollection22, plotRenderingInfo26);
        java.awt.Paint paint29 = xYStepAreaRenderer13.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator31 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("Pie Plot");
        xYStepAreaRenderer13.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator31);
        java.lang.Object obj33 = standardXYSeriesLabelGenerator31.clone();
        xYLineAndShapeRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator31);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(xYItemRendererState27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        java.awt.Stroke stroke5 = combinedRangeXYPlot0.getDomainZeroBaselineStroke();
        combinedRangeXYPlot0.setBackgroundAlpha((float) (-1));
        java.awt.geom.Point2D point2D8 = combinedRangeXYPlot0.getQuadrantOrigin();
        combinedRangeXYPlot0.setDomainPannable(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        java.awt.Paint paint17 = combinedRangeXYPlot11.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke18 = combinedRangeXYPlot11.getDomainMinorGridlineStroke();
        combinedRangeXYPlot0.setDomainZeroBaselineStroke(stroke18);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(point2D8);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.data.Range range5 = barRenderer3D0.findRangeBounds(categoryDataset3, true);
        barRenderer3D0.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer3D0.setSeriesToolTipGenerator(3, categoryToolTipGenerator10, true);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate1 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        java.util.List list2 = xYSeriesCollection0.getSeries();
        org.jfree.data.xy.XYSeries xYSeries4 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double5 = xYSeries4.getMinX();
        xYSeries4.setMaximumItemCount((int) (short) 0);
        int int8 = xYSeriesCollection0.indexOf(xYSeries4);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        boolean boolean10 = combinedRangeXYPlot0.equals((java.lang.Object) 10.0f);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot11.getRangeAxisLocation();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        combinedRangeXYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate20 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        org.jfree.data.Range range22 = intervalXYDelegate20.getDomainBounds(false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator3);
        double double5 = piePlot2.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke12 = xYLineAndShapeRenderer8.getItemOutlineStroke((int) 'a', 0, false);
        piePlot2.setBaseSectionOutlineStroke(stroke12);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator15 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot2.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator15);
        boolean boolean17 = piePlot2.getIgnoreZeroValues();
        java.awt.Font font18 = piePlot2.getNoDataMessageFont();
        boolean boolean19 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.RenderingSource renderingSource20 = chartRenderingInfo0.getRenderingSource();
        chartRenderingInfo0.clear();
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(renderingSource20);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.axis.LogAxis logAxis29 = new org.jfree.chart.axis.LogAxis();
        logAxis29.setMinorTickCount(0);
        float float32 = logAxis29.getMinorTickMarkInsideLength();
        double double34 = logAxis29.calculateValue((double) 10.0f);
        org.jfree.chart.entity.AxisEntity axisEntity36 = new org.jfree.chart.entity.AxisEntity(shape1, (org.jfree.chart.axis.Axis) logAxis29, "");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 0.0f + "'", float32 == 0.0f);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0E10d + "'", double34 == 1.0E10d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        int int3 = legendItem2.getSeriesIndex();
        java.awt.Shape shape4 = legendItem2.getLine();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Pie Plot");
        java.awt.Font font2 = standardChartTheme1.getExtraLargeFont();
        java.awt.Paint paint3 = standardChartTheme1.getAxisLabelPaint();
        java.lang.Object obj4 = standardChartTheme1.clone();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj1 = standardXYToolTipGenerator0.clone();
        java.text.NumberFormat numberFormat2 = standardXYToolTipGenerator0.getXFormat();
        java.lang.Object obj3 = standardXYToolTipGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        categoryAxis1.setLabelFont(font6);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextPaint();
        piePlot11.setLabelLinkPaint(paint14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape18 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape19 = defaultDrawingSupplier16.getNextShape();
        piePlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font6, (org.jfree.chart.plot.Plot) piePlot11, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener23 = null;
        jFreeChart22.addProgressListener(chartProgressListener23);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection29 = chartRenderingInfo28.getEntityCollection();
        java.awt.image.BufferedImage bufferedImage30 = jFreeChart22.createBufferedImage((int) (byte) 10, (int) '4', (int) (short) 1, chartRenderingInfo28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo28.getPlotInfo();
        org.jfree.chart.renderer.RendererState rendererState32 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo31);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(entityCollection29);
        org.junit.Assert.assertNotNull(bufferedImage30);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        numberFormat1.setMaximumIntegerDigits(10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 10.0f, numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeFilled();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setOutlinePaint(paint4);
        java.awt.Paint paint6 = legendItem2.getFillPaint();
        legendItem2.setDescription("java.awt.Color[r=128,g=128,b=128]");
        java.awt.Stroke stroke9 = legendItem2.getOutlineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D1, (float) 3, (float) 2147483647, (double) 9223372036854775807L, 10.0f, (float) 3);
        org.junit.Assert.assertNull(shape7);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        textTitle1.setURLText("1,500%");
        double double4 = textTitle1.getContentYOffset();
        java.awt.Paint paint5 = textTitle1.getBackgroundPaint();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color8 = java.awt.Color.GRAY;
        int int9 = color8.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font7, (java.awt.Paint) color8);
        textTitle1.setFont(font7);
        java.lang.String str12 = textTitle1.getText();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 128 + "'", int9 == 128);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str12.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.clearDomainMarkers();
        combinedRangeXYPlot12.setRangePannable(true);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        combinedRangeXYPlot12.drawBackgroundImage(graphics2D16, rectangle2D17);
        java.awt.Color color19 = java.awt.Color.GRAY;
        combinedRangeXYPlot12.setRangeGridlinePaint((java.awt.Paint) color19);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color23 = java.awt.Color.GRAY;
        int int24 = color23.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font22, (java.awt.Paint) color23);
        combinedRangeXYPlot12.setRangeTickBandPaint((java.awt.Paint) color23);
        java.awt.Color color27 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = xYLineAndShapeRenderer30.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer30.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = null;
        xYLineAndShapeRenderer30.setSeriesURLGenerator(0, xYURLGenerator38, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator41 = null;
        xYLineAndShapeRenderer30.setLegendItemToolTipGenerator(xYSeriesLabelGenerator41);
        boolean boolean43 = xYLineAndShapeRenderer30.getBaseItemLabelsVisible();
        java.awt.Stroke stroke45 = xYLineAndShapeRenderer30.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = piePlot46.getLabelPadding();
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder50 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color27, stroke45, rectangleInsets47);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer52 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot55 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot55.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray57 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot55.setDomainAxes(valueAxisArray57);
        combinedRangeXYPlot55.clearRangeAxes();
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection61 = new org.jfree.data.time.TimeSeriesCollection(timeZone60);
        boolean boolean62 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection61);
        org.jfree.data.Range range64 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection61, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState66 = xYStepAreaRenderer52.initialise(graphics2D53, rectangle2D54, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot55, (org.jfree.data.xy.XYDataset) timeSeriesCollection61, plotRenderingInfo65);
        java.awt.Paint paint68 = xYStepAreaRenderer52.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape11, (java.awt.Paint) color23, stroke45, paint68);
        org.jfree.chart.plot.IntervalMarker intervalMarker70 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint68);
        java.awt.Color color72 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color72);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer74 = legendItem73.getFillPaintTransformer();
        intervalMarker70.setGradientPaintTransformer(gradientPaintTransformer74);
        java.awt.Paint paint76 = intervalMarker70.getPaint();
        boolean boolean77 = chartChangeEventType0.equals((java.lang.Object) intervalMarker70);
        java.lang.String str78 = intervalMarker70.getLabel();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 128 + "'", int24 == 128);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNotNull(xYItemRendererState66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(gradientPaintTransformer74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(str78);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        timeSeries1.clear();
        timeSeries1.setRangeDescription("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        java.util.TimeZone timeZone3 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone3;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone3;
        java.util.Locale locale6 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis7 = new org.jfree.chart.axis.PeriodAxis("series", (org.jfree.data.time.RegularTimePeriod) year1, regularTimePeriod2, timeZone3, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis2.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis2.getCategoryLabelPositions();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color8 = java.awt.Color.GRAY;
        int int9 = color8.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font7, (java.awt.Paint) color8);
        categoryAxis2.setLabelFont(font7);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        double double13 = piePlot12.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint15 = defaultDrawingSupplier14.getNextPaint();
        piePlot12.setLabelLinkPaint(paint15);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape18 = defaultDrawingSupplier17.getNextShape();
        java.awt.Shape shape19 = defaultDrawingSupplier17.getNextShape();
        java.awt.Shape shape20 = defaultDrawingSupplier17.getNextShape();
        piePlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font7, (org.jfree.chart.plot.Plot) piePlot12, false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart23.addProgressListener(chartProgressListener24);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection30 = chartRenderingInfo29.getEntityCollection();
        java.awt.image.BufferedImage bufferedImage31 = jFreeChart23.createBufferedImage((int) (byte) 10, (int) '4', (int) (short) 1, chartRenderingInfo29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = chartRenderingInfo29.getPlotInfo();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot33.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot33.setDomainAxes(valueAxisArray35);
        combinedRangeXYPlot33.clearRangeAxes();
        java.awt.Stroke stroke38 = combinedRangeXYPlot33.getDomainZeroBaselineStroke();
        combinedRangeXYPlot33.setBackgroundAlpha((float) (-1));
        java.awt.geom.Point2D point2D41 = combinedRangeXYPlot33.getQuadrantOrigin();
        org.jfree.chart.plot.XYPlot xYPlot42 = combinedDomainXYPlot0.findSubplot(plotRenderingInfo32, point2D41);
        org.jfree.chart.plot.CrosshairState crosshairState44 = new org.jfree.chart.plot.CrosshairState(false);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = null;
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D45, rectangleAnchor46);
        crosshairState44.setAnchor(point2D47);
        int int49 = plotRenderingInfo32.getSubplotIndex(point2D47);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 128 + "'", int9 == 128);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 90.0d + "'", double13 == 90.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(entityCollection30);
        org.junit.Assert.assertNotNull(bufferedImage31);
        org.junit.Assert.assertNotNull(plotRenderingInfo32);
        org.junit.Assert.assertNotNull(valueAxisArray35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(point2D41);
        org.junit.Assert.assertNull(xYPlot42);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot23.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray25 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot23.setDomainAxes(valueAxisArray25);
        combinedRangeXYPlot23.clearRangeAxes();
        java.util.TimeZone timeZone28 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection29 = new org.jfree.data.time.TimeSeriesCollection(timeZone28);
        boolean boolean30 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection29, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState34 = xYStepAreaRenderer20.initialise(graphics2D21, rectangle2D22, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot23, (org.jfree.data.xy.XYDataset) timeSeriesCollection29, plotRenderingInfo33);
        xYItemRendererState18.endSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection29, 0, (int) (byte) 1, (int) '4', (int) (short) 100, (int) '#');
        java.lang.Number number41 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection29);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNotNull(valueAxisArray25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(xYItemRendererState34);
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        xYItemRendererState18.setProcessVisibleItemsOnly(true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.awt.Shape shape4 = null;
        java.awt.Color color6 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color6);
        boolean boolean8 = legendItem7.isShapeFilled();
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem7.setOutlinePaint(paint9);
        java.awt.Paint paint11 = legendItem7.getFillPaint();
        boolean boolean12 = legendItem7.isShapeFilled();
        legendItem7.setDatasetIndex((int) (short) 0);
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint16 = lineBorder15.getPaint();
        legendItem7.setLinePaint(paint16);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape19 = defaultDrawingSupplier18.getNextShape();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis24.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = categoryAxis24.getCategoryLabelPositions();
        java.awt.Font font29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color30 = java.awt.Color.GRAY;
        int int31 = color30.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock32 = new org.jfree.chart.block.LabelBlock("", font29, (java.awt.Paint) color30);
        categoryAxis24.setLabelFont(font29);
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        double double35 = piePlot34.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint37 = defaultDrawingSupplier36.getNextPaint();
        piePlot34.setLabelLinkPaint(paint37);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape40 = defaultDrawingSupplier39.getNextShape();
        java.awt.Shape shape41 = defaultDrawingSupplier39.getNextShape();
        java.awt.Shape shape42 = defaultDrawingSupplier39.getNextShape();
        piePlot34.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier39);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font29, (org.jfree.chart.plot.Plot) piePlot34, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity46 = new org.jfree.chart.entity.JFreeChartEntity(shape19, jFreeChart45);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = null;
        java.awt.image.BufferedImage bufferedImage52 = jFreeChart45.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo51);
        jFreeChart45.setTextAntiAlias(true);
        java.awt.Stroke stroke55 = jFreeChart45.getBorderStroke();
        java.awt.Color color56 = java.awt.Color.yellow;
        org.jfree.chart.LegendItem legendItem57 = new org.jfree.chart.LegendItem("Value", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "{0}", "WMAP_Plot", shape4, paint16, stroke55, (java.awt.Paint) color56);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 128 + "'", int31 == 128);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 90.0d + "'", double35 == 90.0d);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(bufferedImage52);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(color56);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        combinedRangeXYPlot0.setDomainCrosshairPaint(paint10);
        java.util.List list12 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.XYPlot xYPlot13 = null;
        try {
            combinedRangeXYPlot0.add(xYPlot13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.clearDomainMarkers();
        combinedRangeXYPlot3.setRangePannable(true);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedRangeXYPlot3.getFixedRangeAxisSpace();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        combinedRangeXYPlot3.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        double double13 = piePlot12.getStartAngle();
        piePlot12.clearSectionOutlinePaints(true);
        boolean boolean16 = rectangleEdge11.equals((java.lang.Object) piePlot12);
        boolean boolean17 = numberAxis3D9.equals((java.lang.Object) boolean16);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 90.0d + "'", double13 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        piePlot9.setShadowXOffset(0.0d);
        boolean boolean12 = timeSeriesCollection6.hasListener((java.util.EventListener) piePlot9);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = piePlot9.getLabelLinkStyle();
        boolean boolean15 = pieLabelLinkStyle13.equals((java.lang.Object) 15);
        java.lang.String str16 = pieLabelLinkStyle13.toString();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "PieLabelLinkStyle.STANDARD" + "'", str16.equals("PieLabelLinkStyle.STANDARD"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Pie Plot");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer4.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer4.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        xYLineAndShapeRenderer4.setSeriesURLGenerator(0, xYURLGenerator12, true);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer4.getSeriesShapesFilled((int) (short) 1);
        java.awt.Font font18 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYLineAndShapeRenderer4.setSeriesItemLabelFont(1, font18, true);
        boolean boolean21 = standardChartTheme1.equals((java.lang.Object) 1);
        org.jfree.chart.axis.NumberAxis numberAxis22 = null;
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint30 = defaultDrawingSupplier29.getNextPaint();
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("Nearest", font28, paint30);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis22, 0.05d, (double) 1, (double) 1L, (double) 'a', font28);
        standardChartTheme1.setSmallFont(font28);
        java.awt.Paint paint34 = standardChartTheme1.getTickLabelPaint();
        java.lang.Object obj35 = null;
        boolean boolean36 = standardChartTheme1.equals(obj35);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle37 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        standardChartTheme1.setLabelLinkStyle(pieLabelLinkStyle37);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle37);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = xYLineAndShapeRenderer2.getBaseURLGenerator();
        java.awt.Font font17 = xYLineAndShapeRenderer2.getLegendTextFont((int) (byte) 10);
        xYLineAndShapeRenderer2.setDrawSeriesLineAsPath(false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(xYURLGenerator15);
        org.junit.Assert.assertNull(font17);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke(15);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range3 = org.jfree.data.Range.expandToInclude(range1, (double) 0L);
        double double4 = range3.getLength();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange(range3);
        java.util.Date date6 = dateRange5.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) 2, (org.jfree.data.Range) dateRange5);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType8 = rectangleConstraint7.getHeightConstraintType();
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(lengthConstraintType8);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        java.lang.String str3 = dateTickUnitType2.toString();
        java.text.DateFormat dateFormat5 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 100, dateTickUnitType2, 9999, dateFormat5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnitType.HOUR" + "'", str3.equals("DateTickUnitType.HOUR"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getRootPlot();
        xYLineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot23.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        double double26 = piePlot23.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer29.getItemOutlineStroke((int) 'a', 0, false);
        piePlot23.setBaseSectionOutlineStroke(stroke33);
        xYBarRenderer1.drawDomainLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, paint22, stroke33);
        double double36 = xYBarRenderer1.getBarAlignmentFactor();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = xYLineAndShapeRenderer39.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        org.jfree.chart.text.TextAnchor textAnchor44 = itemLabelPosition43.getRotationAnchor();
        xYBarRenderer1.setPositiveItemLabelPositionFallback(itemLabelPosition43);
        xYBarRenderer1.setShadowXOffset((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36 == (-1.0d));
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(textAnchor44);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        boolean boolean9 = xYLineAndShapeRenderer2.getItemVisible(1900, (int) (byte) 100);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 1900);
        double double2 = valueMarker1.getValue();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3.getLegendLabelToolTipGenerator();
        piePlot3.setIgnoreNullValues(true);
        double double9 = piePlot3.getLabelLinkMargin();
        boolean boolean10 = valueMarker1.equals((java.lang.Object) piePlot3);
        piePlot3.setMinimumArcAngleToDraw((double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1900.0d + "'", double2 == 1900.0d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis0.drawTickMarks(graphics2D4, (double) (short) 100, rectangle2D6, rectangleEdge7, axisState9);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextPaint();
        piePlot11.setLabelLinkPaint(paint14);
        double double16 = piePlot11.getStartAngle();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor17 = piePlot11.getLabelDistributor();
        double double18 = piePlot11.getLabelGap();
        boolean boolean19 = categoryAxis0.hasListener((java.util.EventListener) piePlot11);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 90.0d + "'", double16 == 90.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.025d + "'", double18 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = itemLabelPosition2.getRotationAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.setBarAlignmentFactor((double) 9999);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.TickType tickType0 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor3, textAnchor4);
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 100L, "1,500%", textAnchor4, textAnchor6, (-1.0d));
        org.jfree.chart.text.TextAnchor textAnchor9 = numberTick8.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean11 = textAnchor9.equals((java.lang.Object) textAnchor10);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer2 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean3 = xYBarRenderer2.getShadowsVisible();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer7.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray14);
        combinedRangeXYPlot12.clearRangeAxes();
        java.awt.Stroke stroke17 = combinedRangeXYPlot12.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot18 = combinedRangeXYPlot12.getRootPlot();
        xYLineAndShapeRenderer7.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D20 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.Paint paint23 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator25 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot24.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator25);
        double double27 = piePlot24.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke34 = xYLineAndShapeRenderer30.getItemOutlineStroke((int) 'a', 0, false);
        piePlot24.setBaseSectionOutlineStroke(stroke34);
        xYBarRenderer2.drawDomainLine(graphics2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis3D20, rectangle2D21, (double) (byte) -1, paint23, stroke34);
        double double37 = xYBarRenderer2.getBarAlignmentFactor();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis39.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions42 = categoryAxis39.getCategoryLabelPositions();
        java.awt.Font font44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color45 = java.awt.Color.GRAY;
        int int46 = color45.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("", font44, (java.awt.Paint) color45);
        categoryAxis39.setLabelFont(font44);
        xYBarRenderer2.setLegendTextFont((int) '#', font44);
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape52 = defaultDrawingSupplier51.getNextShape();
        java.awt.Paint paint53 = defaultDrawingSupplier51.getNextOutlinePaint();
        boolean boolean54 = dateTickUnit50.equals((java.lang.Object) paint53);
        java.awt.Graphics2D graphics2D57 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer58 = new org.jfree.chart.text.G2TextMeasurer(graphics2D57);
        try {
            org.jfree.chart.text.TextBlock textBlock59 = org.jfree.chart.text.TextUtilities.createTextBlock("JFreeChartEntity: tooltip = null", font44, paint53, 0.0f, (int) (byte) 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(plot18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-1.0d) + "'", double37 == (-1.0d));
        org.junit.Assert.assertNotNull(categoryLabelPositions42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 128 + "'", int46 == 128);
        org.junit.Assert.assertNotNull(dateTickUnit50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Pie Plot");
        java.awt.Font font2 = standardChartTheme1.getRegularFont();
        java.awt.Paint paint3 = standardChartTheme1.getWallPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 6.0d, (java.lang.Number) 100.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer12.setUseFillPaint(false);
        boolean boolean15 = xYAreaRenderer12.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot18.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot18.setDomainAxes(valueAxisArray20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYAreaRenderer12.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.data.xy.XYDataset) timeSeriesCollection23, plotRenderingInfo25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = combinedRangeXYPlot18.getInsets();
        java.lang.String str28 = rectangleInsets27.toString();
        piePlot0.setSimpleLabelOffset(rectangleInsets27);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.clearDomainMarkers();
        combinedRangeXYPlot30.setRangePannable(true);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        combinedRangeXYPlot30.drawBackgroundImage(graphics2D34, rectangle2D35);
        java.awt.Color color37 = java.awt.Color.GRAY;
        combinedRangeXYPlot30.setRangeGridlinePaint((java.awt.Paint) color37);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot39.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation43 = combinedRangeXYPlot39.getRangeAxisLocation();
        combinedRangeXYPlot30.setRangeAxisLocation(axisLocation43, false);
        piePlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot30);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        int int48 = jFreeChart47.getBackgroundImageAlignment();
        java.awt.Image image52 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo56 = new org.jfree.chart.ui.ProjectInfo("", "DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", image52, "Nearest", "0%", "0%");
        java.lang.String str57 = projectInfo56.getLicenceText();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier58 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape59 = defaultDrawingSupplier58.getNextShape();
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape59, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis64.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions67 = categoryAxis64.getCategoryLabelPositions();
        java.awt.Font font69 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color70 = java.awt.Color.GRAY;
        int int71 = color70.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock72 = new org.jfree.chart.block.LabelBlock("", font69, (java.awt.Paint) color70);
        categoryAxis64.setLabelFont(font69);
        org.jfree.chart.plot.PiePlot piePlot74 = new org.jfree.chart.plot.PiePlot();
        double double75 = piePlot74.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier76 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint77 = defaultDrawingSupplier76.getNextPaint();
        piePlot74.setLabelLinkPaint(paint77);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier79 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape80 = defaultDrawingSupplier79.getNextShape();
        java.awt.Shape shape81 = defaultDrawingSupplier79.getNextShape();
        java.awt.Shape shape82 = defaultDrawingSupplier79.getNextShape();
        piePlot74.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier79);
        org.jfree.chart.JFreeChart jFreeChart85 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font69, (org.jfree.chart.plot.Plot) piePlot74, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity86 = new org.jfree.chart.entity.JFreeChartEntity(shape59, jFreeChart85);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo91 = null;
        java.awt.image.BufferedImage bufferedImage92 = jFreeChart85.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo91);
        projectInfo56.setLogo((java.awt.Image) bufferedImage92);
        jFreeChart47.setBackgroundImage((java.awt.Image) bufferedImage92);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str28.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 15 + "'", int48 == 15);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "0%" + "'", str57.equals("0%"));
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(categoryLabelPositions67);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 128 + "'", int71 == 128);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 90.0d + "'", double75 == 90.0d);
        org.junit.Assert.assertNotNull(paint77);
        org.junit.Assert.assertNotNull(shape80);
        org.junit.Assert.assertNotNull(shape81);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(bufferedImage92);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        double double7 = combinedRangeXYPlot0.getRangeCrosshairValue();
        java.awt.Stroke stroke8 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        barRenderer3D0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        combinedRangeXYPlot13.clearRangeAxes();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeZone18);
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection19, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = xYStepAreaRenderer10.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, (org.jfree.data.xy.XYDataset) timeSeriesCollection19, plotRenderingInfo23);
        java.awt.Paint paint26 = xYStepAreaRenderer10.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer10);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = null;
        org.jfree.chart.util.Size2D size2D30 = legendTitle27.arrange(graphics2D28, rectangleConstraint29);
        java.awt.geom.Rectangle2D rectangle2D31 = legendTitle27.getBounds();
        try {
            barRenderer3D0.drawOutline(graphics2D7, categoryPlot8, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(xYItemRendererState24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color21 = java.awt.Color.GRAY;
        int int22 = color21.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("", font20, (java.awt.Paint) color21);
        labelBlock23.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        labelBlock23.setTextAnchor(rectangleAnchor26);
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor26);
        legendTitle18.setID("January");
        org.jfree.chart.block.BlockContainer blockContainer31 = legendTitle18.getItemContainer();
        java.lang.Object obj32 = blockContainer31.clone();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 128 + "'", int22 == 128);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(blockContainer31);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj1 = standardXYToolTipGenerator0.clone();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = standardXYToolTipGenerator0.equals((java.lang.Object) xYLineAndShapeRenderer2);
        java.lang.Object obj4 = standardXYToolTipGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 0L);
        double double3 = range2.getLength();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(range2);
        java.util.Date date5 = dateRange4.getUpperDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone8;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone8;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("Value", timeZone8);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot17.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot17.setDomainAxes(valueAxisArray19);
        org.jfree.data.xy.XYDataset xYDataset21 = combinedRangeXYPlot17.getDataset();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        combinedRangeXYPlot17.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        timeSeries16.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection23);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) year27, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis31 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year14, (org.jfree.data.time.RegularTimePeriod) year27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year14.next();
        java.util.Date date33 = year14.getStart();
        dateAxis11.setMinimumDate(date33);
        org.jfree.data.Range range35 = null;
        org.jfree.data.Range range37 = org.jfree.data.Range.expandToInclude(range35, (double) 0L);
        double double38 = range37.getLength();
        org.jfree.data.time.DateRange dateRange39 = new org.jfree.data.time.DateRange(range37);
        java.util.Date date40 = dateRange39.getUpperDate();
        dateAxis11.setMinimumDate(date40);
        java.util.TimeZone timeZone42 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone42;
        java.util.Date date44 = dateTickUnit6.addToDate(date40, timeZone42);
        org.jfree.data.time.DateRange dateRange45 = new org.jfree.data.time.DateRange(date5, date44);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNull(xYDataset21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(date44);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color21 = java.awt.Color.GRAY;
        int int22 = color21.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("", font20, (java.awt.Paint) color21);
        labelBlock23.setHeight(0.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        labelBlock23.setTextAnchor(rectangleAnchor26);
        legendTitle18.setLegendItemGraphicAnchor(rectangleAnchor26);
        legendTitle18.setID("January");
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = legendTitle18.getLegendItemGraphicEdge();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 128 + "'", int22 == 128);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj2 = xYSeries1.clone();
        xYSeries1.add(0.0d, (double) 0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean6 = barRenderer3D0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer3D0.setSeriesToolTipGenerator(0, categoryToolTipGenerator8);
        java.awt.Paint paint13 = barRenderer3D0.getItemOutlinePaint(5, 1, false);
        java.awt.Paint paint14 = barRenderer3D0.getWallPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator18 = barRenderer3D0.getURLGenerator(2, 0, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        try {
            barRenderer3D0.setSeriesItemLabelGenerator((int) (byte) -1, categoryItemLabelGenerator20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryURLGenerator18);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        xYSeries1.setMaximumItemCount((int) (short) 0);
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.addOrUpdate(0.2d, (double) 0);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries1.remove((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions28 = categoryAxis25.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState34 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis25.drawTickMarks(graphics2D29, (double) (short) 100, rectangle2D31, rectangleEdge32, axisState34);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list38 = periodAxis19.refreshTicks(graphics2D24, axisState34, rectangle2D36, rectangleEdge37);
        axisState34.setCursor((double) 255);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions28);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer12.setUseFillPaint(false);
        boolean boolean15 = xYAreaRenderer12.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot18.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot18.setDomainAxes(valueAxisArray20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYAreaRenderer12.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.data.xy.XYDataset) timeSeriesCollection23, plotRenderingInfo25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = combinedRangeXYPlot18.getInsets();
        java.lang.String str28 = rectangleInsets27.toString();
        piePlot0.setSimpleLabelOffset(rectangleInsets27);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.clearDomainMarkers();
        combinedRangeXYPlot30.setRangePannable(true);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        combinedRangeXYPlot30.drawBackgroundImage(graphics2D34, rectangle2D35);
        java.awt.Color color37 = java.awt.Color.GRAY;
        combinedRangeXYPlot30.setRangeGridlinePaint((java.awt.Paint) color37);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot39.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation43 = combinedRangeXYPlot39.getRangeAxisLocation();
        combinedRangeXYPlot30.setRangeAxisLocation(axisLocation43, false);
        piePlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot30);
        org.jfree.data.general.PieDataset pieDataset47 = piePlot0.getDataset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str28.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertNull(pieDataset47);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        combinedRangeXYPlot4.panRangeAxes((-1.0d), plotRenderingInfo17, point2D18);
        java.awt.Stroke stroke20 = combinedRangeXYPlot4.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle18.arrange(graphics2D19, rectangleConstraint20);
        double double22 = size2D21.getHeight();
        java.lang.String str23 = size2D21.toString();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str23.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getRootPlot();
        xYLineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot23.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        double double26 = piePlot23.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer29.getItemOutlineStroke((int) 'a', 0, false);
        piePlot23.setBaseSectionOutlineStroke(stroke33);
        xYBarRenderer1.drawDomainLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, paint22, stroke33);
        org.jfree.chart.axis.TickUnits tickUnits36 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.Object obj38 = numberAxis3D37.clone();
        numberAxis3D37.setAutoRangeMinimumSize((double) 15);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = xYLineAndShapeRenderer47.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer47.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator55 = null;
        xYLineAndShapeRenderer47.setSeriesURLGenerator(0, xYURLGenerator55, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator58 = null;
        xYLineAndShapeRenderer47.setLegendItemToolTipGenerator(xYSeriesLabelGenerator58);
        java.lang.Boolean boolean61 = xYLineAndShapeRenderer47.getSeriesVisible(7);
        java.awt.Font font62 = xYLineAndShapeRenderer47.getBaseItemLabelFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand63 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis) numberAxis3D37, (double) 10L, (double) 2, (double) 7, (double) 1L, font62);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit64 = numberAxis3D37.getTickUnit();
        tickUnits36.add((org.jfree.chart.axis.TickUnit) numberTickUnit64);
        numberAxis3D19.setTickUnit(numberTickUnit64, false, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(itemLabelPosition51);
        org.junit.Assert.assertNull(boolean61);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(numberTickUnit64);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 1900);
        double double2 = valueMarker1.getValue();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot3.getLegendLabelToolTipGenerator();
        piePlot3.setIgnoreNullValues(true);
        double double9 = piePlot3.getLabelLinkMargin();
        boolean boolean10 = valueMarker1.equals((java.lang.Object) piePlot3);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot12.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator13);
        double double15 = piePlot12.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke22 = xYLineAndShapeRenderer18.getItemOutlineStroke((int) 'a', 0, false);
        piePlot12.setBaseSectionOutlineStroke(stroke22);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator25 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot12.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator25);
        boolean boolean27 = piePlot12.getAutoPopulateSectionOutlinePaint();
        java.awt.Paint paint28 = piePlot12.getOutlinePaint();
        piePlot3.setSectionPaint((java.lang.Comparable) 2, paint28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1900.0d + "'", double2 == 1900.0d);
        org.junit.Assert.assertNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        textTitle1.setURLText("");
        textTitle1.setExpandToFitSpace(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        int int12 = combinedRangeXYPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        combinedRangeXYPlot7.mapDatasetToRangeAxis((int) (byte) 0, 5);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = combinedRangeXYPlot7.getDomainAxisEdge((int) (byte) 100);
        combinedRangeXYPlot7.setRangeCrosshairLockedOnData(false);
        java.awt.geom.GeneralPath generalPath20 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot25.setDomainAxes(valueAxisArray27);
        combinedRangeXYPlot25.clearRangeAxes();
        java.util.TimeZone timeZone30 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection31 = new org.jfree.data.time.TimeSeriesCollection(timeZone30);
        boolean boolean32 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection31);
        org.jfree.data.Range range34 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection31, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState36 = xYStepAreaRenderer22.initialise(graphics2D23, rectangle2D24, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot25, (org.jfree.data.xy.XYDataset) timeSeriesCollection31, plotRenderingInfo35);
        java.awt.Paint paint38 = xYStepAreaRenderer22.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer22);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = null;
        org.jfree.chart.util.Size2D size2D42 = legendTitle39.arrange(graphics2D40, rectangleConstraint41);
        java.awt.geom.Rectangle2D rectangle2D43 = legendTitle39.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double45 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D43, rectangleEdge44);
        org.jfree.chart.RenderingSource renderingSource46 = null;
        combinedRangeXYPlot7.select(generalPath20, rectangle2D43, renderingSource46);
        textTitle1.draw(graphics2D6, rectangle2D43);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(xYItemRendererState36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot7.setDomainAxes(valueAxisArray9);
        combinedRangeXYPlot7.clearRangeAxes();
        java.awt.Stroke stroke12 = combinedRangeXYPlot7.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot13 = combinedRangeXYPlot7.getRootPlot();
        xYLineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot7);
        combinedRangeXYPlot7.clearAnnotations();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection19 = null;
        chartRenderingInfo18.setEntityCollection(entityCollection19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = chartRenderingInfo18.getPlotInfo();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot22.clearDomainMarkers();
        combinedRangeXYPlot22.setRangePannable(true);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        combinedRangeXYPlot22.drawBackgroundImage(graphics2D26, rectangle2D27);
        java.awt.Color color29 = java.awt.Color.GRAY;
        combinedRangeXYPlot22.setRangeGridlinePaint((java.awt.Paint) color29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot31.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation35 = combinedRangeXYPlot31.getRangeAxisLocation();
        combinedRangeXYPlot22.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        combinedRangeXYPlot22.panRangeAxes(6.0d, plotRenderingInfo39, point2D42);
        combinedRangeXYPlot7.zoomRangeAxes(0.0d, 8.0d, plotRenderingInfo21, point2D42);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNotNull(plotRenderingInfo21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(point2D42);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setLabelToolTip("hi!");
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        periodAxis19.setTimeZone(timeZone22);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month((int) (byte) 10, year26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.next();
        periodAxis19.setLast(regularTimePeriod28);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        boolean boolean10 = combinedRangeXYPlot0.equals((java.lang.Object) 10.0f);
        int int11 = combinedRangeXYPlot0.getSeriesCount();
        java.awt.Stroke stroke12 = null;
        try {
            combinedRangeXYPlot0.setRangeMinorGridlineStroke(stroke12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        numberAxis3D1.setAutoTickUnitSelection(true);
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 100L);
        numberAxis3D1.setUpArrow(shape5);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Pie Plot");
        java.awt.Font font2 = standardChartTheme1.getExtraLargeFont();
        java.awt.Paint paint3 = standardChartTheme1.getAxisLabelPaint();
        java.awt.Paint paint4 = standardChartTheme1.getPlotBackgroundPaint();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot7.setDomainAxes(valueAxisArray9);
        combinedRangeXYPlot7.clearRangeAxes();
        java.awt.Stroke stroke12 = combinedRangeXYPlot7.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot13 = combinedRangeXYPlot7.getRootPlot();
        xYLineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot7);
        combinedRangeXYPlot7.clearAnnotations();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection17 = combinedRangeXYPlot7.getDomainMarkers(layer16);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot19.clearDomainMarkers();
        combinedRangeXYPlot19.setRangePannable(true);
        boolean boolean23 = combinedRangeXYPlot19.isRangeZoomable();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot24.clearDomainMarkers();
        combinedRangeXYPlot24.setRangePannable(true);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        combinedRangeXYPlot24.drawBackgroundImage(graphics2D28, rectangle2D29);
        java.awt.Color color31 = java.awt.Color.GRAY;
        combinedRangeXYPlot24.setRangeGridlinePaint((java.awt.Paint) color31);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot33.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation37 = combinedRangeXYPlot33.getRangeAxisLocation();
        combinedRangeXYPlot24.setRangeAxisLocation(axisLocation37, false);
        combinedRangeXYPlot19.setDomainAxisLocation(axisLocation37, true);
        combinedRangeXYPlot7.setDomainAxisLocation(5, axisLocation37);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(plot13);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        xYStepAreaRenderer1.setSeriesCreateEntities(255, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.clearDomainMarkers();
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color19);
        combinedRangeXYPlot16.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        combinedRangeXYPlot16.zoomRangeAxes(0.0d, 0.0d, plotRenderingInfo24, point2D25);
        timeSeriesCollection10.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot16);
        double double28 = combinedRangeXYPlot16.getDomainCrosshairValue();
        java.awt.Paint paint30 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        try {
            combinedRangeXYPlot16.setQuadrantPaint((int) (byte) 10, paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        boolean boolean2 = timeSeries1.isEmpty();
        timeSeries1.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        combinedRangeXYPlot11.setRangePannable(true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        combinedRangeXYPlot11.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        combinedRangeXYPlot11.setRangeGridlinePaint((java.awt.Paint) color18);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color22 = java.awt.Color.GRAY;
        int int23 = color22.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color22);
        combinedRangeXYPlot11.setRangeTickBandPaint((java.awt.Paint) color22);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYLineAndShapeRenderer29.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer29.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        xYLineAndShapeRenderer29.setSeriesURLGenerator(0, xYURLGenerator37, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator40 = null;
        xYLineAndShapeRenderer29.setLegendItemToolTipGenerator(xYSeriesLabelGenerator40);
        boolean boolean42 = xYLineAndShapeRenderer29.getBaseItemLabelsVisible();
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer29.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = piePlot45.getLabelPadding();
        double double48 = rectangleInsets46.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color26, stroke44, rectangleInsets46);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot54.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot54.setDomainAxes(valueAxisArray56);
        combinedRangeXYPlot54.clearRangeAxes();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeZone59);
        boolean boolean61 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState65 = xYStepAreaRenderer51.initialise(graphics2D52, rectangle2D53, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot54, (org.jfree.data.xy.XYDataset) timeSeriesCollection60, plotRenderingInfo64);
        java.awt.Paint paint67 = xYStepAreaRenderer51.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape10, (java.awt.Paint) color22, stroke44, paint67);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint67);
        java.awt.Color color71 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color71);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer73 = legendItem72.getFillPaintTransformer();
        intervalMarker69.setGradientPaintTransformer(gradientPaintTransformer73);
        java.awt.Paint paint75 = intervalMarker69.getPaint();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer77 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer78 = xYBarRenderer77.getGradientPaintTransformer();
        intervalMarker69.setGradientPaintTransformer(gradientPaintTransformer78);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 128 + "'", int23 == 128);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNotNull(xYItemRendererState65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(gradientPaintTransformer73);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertNotNull(gradientPaintTransformer78);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getLicenceName();
        java.awt.Image image5 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo9 = new org.jfree.chart.ui.ProjectInfo("", "DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", image5, "Nearest", "0%", "0%");
        java.lang.String str10 = projectInfo9.getLicenceText();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape12 = defaultDrawingSupplier11.getNextShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis17.getCategoryLabelPositions();
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color23 = java.awt.Color.GRAY;
        int int24 = color23.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("", font22, (java.awt.Paint) color23);
        categoryAxis17.setLabelFont(font22);
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        double double28 = piePlot27.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint30 = defaultDrawingSupplier29.getNextPaint();
        piePlot27.setLabelLinkPaint(paint30);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape33 = defaultDrawingSupplier32.getNextShape();
        java.awt.Shape shape34 = defaultDrawingSupplier32.getNextShape();
        java.awt.Shape shape35 = defaultDrawingSupplier32.getNextShape();
        piePlot27.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier32);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font22, (org.jfree.chart.plot.Plot) piePlot27, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity39 = new org.jfree.chart.entity.JFreeChartEntity(shape12, jFreeChart38);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        java.awt.image.BufferedImage bufferedImage45 = jFreeChart38.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo44);
        projectInfo9.setLogo((java.awt.Image) bufferedImage45);
        projectInfo0.setLogo((java.awt.Image) bufferedImage45);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0%" + "'", str10.equals("0%"));
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 128 + "'", int24 == 128);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 90.0d + "'", double28 == 90.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(bufferedImage45);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYLineAndShapeRenderer3.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer3.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYLineAndShapeRenderer3.setSeriesURLGenerator(0, xYURLGenerator11, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        xYLineAndShapeRenderer3.setLegendItemToolTipGenerator(xYSeriesLabelGenerator14);
        java.lang.Boolean boolean17 = xYLineAndShapeRenderer3.getSeriesVisible(7);
        java.awt.Font font18 = xYLineAndShapeRenderer3.getBaseItemLabelFont();
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("ClassContext", font18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = null;
        try {
            textTitle19.setPadding(rectangleInsets20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Pie Plot");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer4.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer4.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = null;
        xYLineAndShapeRenderer4.setSeriesURLGenerator(0, xYURLGenerator12, true);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer4.getSeriesShapesFilled((int) (short) 1);
        java.awt.Font font18 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        xYLineAndShapeRenderer4.setSeriesItemLabelFont(1, font18, true);
        boolean boolean21 = standardChartTheme1.equals((java.lang.Object) 1);
        org.jfree.chart.axis.NumberAxis numberAxis22 = null;
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint30 = defaultDrawingSupplier29.getNextPaint();
        org.jfree.chart.text.TextLine textLine31 = new org.jfree.chart.text.TextLine("Nearest", font28, paint30);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis22, 0.05d, (double) 1, (double) 1L, (double) 'a', font28);
        standardChartTheme1.setSmallFont(font28);
        java.awt.Paint paint34 = standardChartTheme1.getTickLabelPaint();
        java.lang.Object obj35 = null;
        boolean boolean36 = standardChartTheme1.equals(obj35);
        org.jfree.chart.plot.PiePlot piePlot37 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot37.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator38);
        double double40 = piePlot37.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke47 = xYLineAndShapeRenderer43.getItemOutlineStroke((int) 'a', 0, false);
        piePlot37.setBaseSectionOutlineStroke(stroke47);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator50 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot37.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator50);
        boolean boolean52 = piePlot37.getAutoPopulateSectionOutlinePaint();
        java.awt.Paint paint53 = piePlot37.getOutlinePaint();
        standardChartTheme1.setWallPaint(paint53);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYLineAndShapeRenderer3.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer3.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYLineAndShapeRenderer3.setSeriesURLGenerator(0, xYURLGenerator11, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        xYLineAndShapeRenderer3.setLegendItemToolTipGenerator(xYSeriesLabelGenerator14);
        boolean boolean16 = xYLineAndShapeRenderer3.getBaseItemLabelsVisible();
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer3.lookupSeriesStroke((int) (short) 1);
        barRenderer3D0.setBaseStroke(stroke18, false);
        java.lang.Boolean boolean22 = barRenderer3D0.getSeriesCreateEntities(100);
        barRenderer3D0.setIncludeBaseInRange(true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(boolean22);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        textTitle5.setURLText("1,500%");
        double double8 = textTitle5.getContentYOffset();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot14.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot14.setDomainAxes(valueAxisArray16);
        combinedRangeXYPlot14.clearRangeAxes();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection(timeZone19);
        boolean boolean21 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection20);
        org.jfree.data.Range range23 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection20, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState25 = xYStepAreaRenderer11.initialise(graphics2D12, rectangle2D13, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot14, (org.jfree.data.xy.XYDataset) timeSeriesCollection20, plotRenderingInfo24);
        java.awt.Paint paint27 = xYStepAreaRenderer11.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer11);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = null;
        org.jfree.chart.util.Size2D size2D31 = legendTitle28.arrange(graphics2D29, rectangleConstraint30);
        java.awt.geom.Rectangle2D rectangle2D32 = legendTitle28.getBounds();
        textTitle5.draw(graphics2D9, rectangle2D32);
        org.jfree.chart.plot.PiePlot piePlot34 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator35 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot34.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator35);
        double double37 = piePlot34.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer40 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer40.getItemOutlineStroke((int) 'a', 0, false);
        piePlot34.setBaseSectionOutlineStroke(stroke44);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer46 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer46.setUseFillPaint(false);
        boolean boolean49 = xYAreaRenderer46.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot52.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray54 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot52.setDomainAxes(valueAxisArray54);
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection57 = new org.jfree.data.time.TimeSeriesCollection(timeZone56);
        boolean boolean58 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState60 = xYAreaRenderer46.initialise(graphics2D50, rectangle2D51, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot52, (org.jfree.data.xy.XYDataset) timeSeriesCollection57, plotRenderingInfo59);
        org.jfree.chart.util.RectangleInsets rectangleInsets61 = combinedRangeXYPlot52.getInsets();
        java.lang.String str62 = rectangleInsets61.toString();
        piePlot34.setSimpleLabelOffset(rectangleInsets61);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot64 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot64.clearDomainMarkers();
        combinedRangeXYPlot64.setRangePannable(true);
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        combinedRangeXYPlot64.drawBackgroundImage(graphics2D68, rectangle2D69);
        java.awt.Color color71 = java.awt.Color.GRAY;
        combinedRangeXYPlot64.setRangeGridlinePaint((java.awt.Paint) color71);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot73 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot73.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation77 = combinedRangeXYPlot73.getRangeAxisLocation();
        combinedRangeXYPlot64.setRangeAxisLocation(axisLocation77, false);
        piePlot34.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot64);
        org.jfree.chart.JFreeChart jFreeChart81 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot34);
        java.awt.Paint paint82 = piePlot34.getLabelPaint();
        try {
            org.jfree.chart.LegendItem legendItem83 = new org.jfree.chart.LegendItem(attributedString0, "DateTickMarkPosition.MIDDLE", "Pie Plot", "February", (java.awt.Shape) rectangle2D32, paint82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(xYItemRendererState25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(size2D31);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(valueAxisArray54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState60);
        org.junit.Assert.assertNotNull(rectangleInsets61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str62.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(paint82);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        java.awt.Font font7 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray10);
        combinedRangeXYPlot8.clearRangeAxes();
        java.awt.Stroke stroke13 = combinedRangeXYPlot8.getDomainZeroBaselineStroke();
        java.awt.Paint paint14 = combinedRangeXYPlot8.getRangeZeroBaselinePaint();
        xYLineAndShapeRenderer2.setPlot((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape4 = defaultDrawingSupplier3.getNextShape();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis9.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis9.getCategoryLabelPositions();
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.GRAY;
        int int16 = color15.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("", font14, (java.awt.Paint) color15);
        categoryAxis9.setLabelFont(font14);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        double double20 = piePlot19.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextPaint();
        piePlot19.setLabelLinkPaint(paint22);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape25 = defaultDrawingSupplier24.getNextShape();
        java.awt.Shape shape26 = defaultDrawingSupplier24.getNextShape();
        java.awt.Shape shape27 = defaultDrawingSupplier24.getNextShape();
        piePlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font14, (org.jfree.chart.plot.Plot) piePlot19, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity31 = new org.jfree.chart.entity.JFreeChartEntity(shape4, jFreeChart30);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        java.awt.image.BufferedImage bufferedImage37 = jFreeChart30.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo36);
        org.jfree.chart.ui.ProjectInfo projectInfo41 = new org.jfree.chart.ui.ProjectInfo("Size2D[width=0.0, height=0.0]", "", "February", (java.awt.Image) bufferedImage37, "ClassContext", "ItemLabelAnchor.INSIDE2", "0%");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 128 + "'", int16 == 128);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 90.0d + "'", double20 == 90.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(bufferedImage37);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        java.awt.Paint paint12 = piePlot0.getLabelShadowPaint();
        java.awt.Paint paint13 = piePlot0.getLabelLinkPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        categoryAxis1.setLabelFont(font6);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextPaint();
        piePlot11.setLabelLinkPaint(paint14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape18 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape19 = defaultDrawingSupplier16.getNextShape();
        piePlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font6, (org.jfree.chart.plot.Plot) piePlot11, false);
        java.awt.Paint paint23 = piePlot11.getBaseSectionOutlinePaint();
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot11);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        xYStepAreaRenderer1.setSeriesCreateEntities(0, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        xYStepAreaRenderer1.setSeriesToolTipGenerator((int) '#', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator21);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean6 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        barRenderer3D0.clearSeriesPaints(true);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.GRAY;
        int int5 = color4.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font3, (java.awt.Paint) color4);
        java.lang.Object obj7 = null;
        columnArrangement0.add((org.jfree.chart.block.Block) labelBlock6, obj7);
        java.lang.String str9 = labelBlock6.getToolTipText();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        boolean boolean4 = xYStepAreaRenderer1.getItemVisible(100, (-4145152));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        barRenderer3D0.setAutoPopulateSeriesFillPaint(false);
        double double7 = barRenderer3D0.getMaximumBarWidth();
        barRenderer3D0.setMinimumBarLength(2.0d);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean3 = axisSpace0.equals((java.lang.Object) itemLabelAnchor2);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot5.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
        double double8 = piePlot5.getMaximumLabelWidth();
        boolean boolean9 = piePlot5.getIgnoreNullValues();
        boolean boolean10 = itemLabelAnchor4.equals((java.lang.Object) boolean9);
        org.jfree.chart.axis.TickType tickType11 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor14 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor14, textAnchor15);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick(tickType11, (double) 100L, "1,500%", textAnchor15, textAnchor17, (-1.0d));
        org.jfree.data.xy.XYDataItem xYDataItem22 = new org.jfree.data.xy.XYDataItem(0.0d, (double) (-1.0f));
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        int int24 = xYDataItem22.compareTo((java.lang.Object) textAnchor23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor15, textAnchor23, (double) 10);
        org.jfree.chart.text.TextAnchor textAnchor27 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor23, textAnchor27, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.14d + "'", double8 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat3 = standardPieToolTipGenerator2.getPercentFormat();
        boolean boolean4 = textAnchor0.equals((java.lang.Object) numberFormat3);
        boolean boolean5 = numberFormat3.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot1.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot1.setDomainAxes(valueAxisArray3);
        combinedRangeXYPlot1.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = combinedRangeXYPlot1.getDomainAxisEdge();
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range9 = org.jfree.data.Range.expandToInclude(range7, (double) 0L);
        double double10 = range9.getLength();
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange(range9);
        boolean boolean12 = rectangleEdge6.equals((java.lang.Object) range9);
        org.jfree.data.Range range14 = org.jfree.data.Range.scale(range9, (double) 1L);
        org.jfree.data.Range range15 = null;
        org.jfree.data.Range range17 = org.jfree.data.Range.expandToInclude(range15, (double) 0L);
        double double18 = range17.getLength();
        org.jfree.data.time.DateRange dateRange19 = new org.jfree.data.time.DateRange(range17);
        long long20 = dateRange19.getUpperMillis();
        org.jfree.data.Range range22 = org.jfree.data.Range.expandToInclude((org.jfree.data.Range) dateRange19, 0.0d);
        boolean boolean23 = range14.intersects(range22);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = new org.jfree.chart.block.RectangleConstraint(0.4d, range22);
        org.jfree.data.Range range25 = null;
        org.jfree.data.time.DateRange dateRange26 = new org.jfree.data.time.DateRange();
        org.jfree.data.Range range27 = org.jfree.data.Range.combine(range25, (org.jfree.data.Range) dateRange26);
        org.jfree.data.time.DateRange dateRange28 = new org.jfree.data.time.DateRange((org.jfree.data.Range) dateRange26);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = rectangleConstraint24.toRangeWidth((org.jfree.data.Range) dateRange26);
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        categoryAxis1.setLabelFont(font6);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextPaint();
        piePlot11.setLabelLinkPaint(paint14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape18 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape19 = defaultDrawingSupplier16.getNextShape();
        piePlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font6, (org.jfree.chart.plot.Plot) piePlot11, false);
        java.awt.Paint paint23 = piePlot11.getBaseSectionOutlinePaint();
        java.lang.String str24 = piePlot11.getPlotType();
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Pie Plot" + "'", str24.equals("Pie Plot"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.zoomRange((-1.0d), (double) 9223372036854775807L);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range5, (double) 0.0f);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType9 = rectangleConstraint8.getWidthConstraintType();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(lengthConstraintType9);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.general.DatasetGroup datasetGroup8 = new org.jfree.data.general.DatasetGroup();
        java.lang.Object obj9 = datasetGroup8.clone();
        timeSeriesCollection6.setGroup(datasetGroup8);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getRootPlot();
        xYLineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot23.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        double double26 = piePlot23.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer29.getItemOutlineStroke((int) 'a', 0, false);
        piePlot23.setBaseSectionOutlineStroke(stroke33);
        xYBarRenderer1.drawDomainLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, paint22, stroke33);
        double double36 = xYBarRenderer1.getBarAlignmentFactor();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions41 = categoryAxis38.getCategoryLabelPositions();
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color44 = java.awt.Color.GRAY;
        int int45 = color44.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock46 = new org.jfree.chart.block.LabelBlock("", font43, (java.awt.Paint) color44);
        categoryAxis38.setLabelFont(font43);
        xYBarRenderer1.setLegendTextFont((int) '#', font43);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = xYBarRenderer1.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator50 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.NumberFormat numberFormat51 = standardXYToolTipGenerator50.getYFormat();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator50, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36 == (-1.0d));
        org.junit.Assert.assertNotNull(categoryLabelPositions41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 128 + "'", int45 == 128);
        org.junit.Assert.assertNull(itemLabelPosition49);
        org.junit.Assert.assertNotNull(numberFormat51);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj3 = xYSeries2.clone();
        boolean boolean5 = xYSeries2.equals((java.lang.Object) (short) 10);
        int int6 = xYSeriesCollection0.indexOf(xYSeries2);
        java.lang.Object obj7 = xYSeriesCollection0.clone();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate1 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        java.util.List list2 = xYSeriesCollection0.getSeries();
        xYSeriesCollection0.setIntervalWidth(0.0d);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        boolean boolean4 = combinedRangeXYPlot0.isRangeCrosshairLockedOnData();
        combinedRangeXYPlot0.setDomainCrosshairValue(1.0E-5d, true);
        java.awt.Color color9 = java.awt.Color.RED;
        try {
            combinedRangeXYPlot0.setQuadrantPaint(255, (java.awt.Paint) color9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (255) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer12.setUseFillPaint(false);
        boolean boolean15 = xYAreaRenderer12.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot18.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot18.setDomainAxes(valueAxisArray20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYAreaRenderer12.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.data.xy.XYDataset) timeSeriesCollection23, plotRenderingInfo25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = combinedRangeXYPlot18.getInsets();
        java.lang.String str28 = rectangleInsets27.toString();
        piePlot0.setSimpleLabelOffset(rectangleInsets27);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.clearDomainMarkers();
        combinedRangeXYPlot30.setRangePannable(true);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        combinedRangeXYPlot30.drawBackgroundImage(graphics2D34, rectangle2D35);
        java.awt.Color color37 = java.awt.Color.GRAY;
        combinedRangeXYPlot30.setRangeGridlinePaint((java.awt.Paint) color37);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot39.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation43 = combinedRangeXYPlot39.getRangeAxisLocation();
        combinedRangeXYPlot30.setRangeAxisLocation(axisLocation43, false);
        piePlot0.setParent((org.jfree.chart.plot.Plot) combinedRangeXYPlot30);
        org.jfree.chart.JFreeChart jFreeChart47 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        float float48 = piePlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str28.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(axisLocation43);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 1.0f + "'", float48 == 1.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.junit.Assert.assertNotNull(size2D2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = combinedRangeXYPlot6.getAxisOffset();
        combinedRangeXYPlot6.mapDatasetToDomainAxis(0, (int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke26 = xYLineAndShapeRenderer22.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator28 = xYLineAndShapeRenderer22.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer22.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false);
        combinedRangeXYPlot6.setRenderer((int) (short) 1, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer22, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(xYURLGenerator28);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        java.awt.Color color7 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color7);
        combinedRangeXYPlot4.setOutlinePaint((java.awt.Paint) color7);
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(0.4d, 1.0E10d, (double) 10.0f, (double) 255, (java.awt.Paint) color7);
        java.awt.Paint paint11 = blockBorder10.getPaint();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        boolean boolean3 = xYStepRenderer0.getItemLineVisible((int) (byte) 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.clearDomainMarkers();
        combinedRangeXYPlot3.setRangePannable(true);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        double double9 = piePlot8.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextPaint();
        piePlot8.setLabelLinkPaint(paint11);
        categoryAxis0.setAxisLinePaint(paint11);
        java.awt.Font font15 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 0.0f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 90.0d + "'", double9 == 90.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray4 = new java.lang.Number[][] { numberArray2, numberArray3 };
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "java.awt.Color[r=128,g=128,b=128]", numberArray4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset5);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        timeSeries1.clear();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        boolean boolean20 = timeSeries19.isEmpty();
        boolean boolean21 = timeSeries19.getNotify();
        java.lang.String str22 = timeSeries19.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries1.addAndOrUpdate(timeSeries19);
        try {
            timeSeries23.update((int) (short) 0, (java.lang.Number) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Value" + "'", str22.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        java.text.AttributedString attributedString0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot6 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset5);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape8 = defaultDrawingSupplier7.getNextShape();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape8, (double) 0.0f, (double) 'a');
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        multiplePiePlot6.setLegendItemShape(shape11);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint16 = defaultDrawingSupplier15.getNextPaint();
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot19.clearDomainMarkers();
        combinedRangeXYPlot19.setRangePannable(true);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        combinedRangeXYPlot19.drawBackgroundImage(graphics2D23, rectangle2D24);
        java.awt.Color color26 = java.awt.Color.GRAY;
        combinedRangeXYPlot19.setRangeGridlinePaint((java.awt.Paint) color26);
        boolean boolean29 = combinedRangeXYPlot19.equals((java.lang.Object) 10.0f);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation34 = combinedRangeXYPlot30.getRangeAxisLocation();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection36 = new org.jfree.data.time.TimeSeriesCollection(timeZone35);
        combinedRangeXYPlot30.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection36);
        combinedRangeXYPlot19.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection36);
        java.awt.Stroke stroke39 = combinedRangeXYPlot19.getDomainMinorGridlineStroke();
        java.awt.Shape shape41 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot42.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot42.setDomainAxes(valueAxisArray44);
        combinedRangeXYPlot42.clearRangeAxes();
        java.awt.Stroke stroke47 = combinedRangeXYPlot42.getDomainZeroBaselineStroke();
        java.awt.Paint paint48 = combinedRangeXYPlot42.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke49 = combinedRangeXYPlot42.getDomainMinorGridlineStroke();
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color51 = color50.brighter();
        try {
            org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem(attributedString0, "Layer.FOREGROUND", "", "WMAP_Plot", false, shape11, false, paint16, true, paint18, stroke39, false, shape41, stroke49, (java.awt.Paint) color51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(valueAxisArray44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator5 = xYBarRenderer1.getURLGenerator((int) '4', 128, true);
        xYBarRenderer1.setAutoPopulateSeriesPaint(false);
        java.awt.Paint paint8 = xYBarRenderer1.getBaseItemLabelPaint();
        org.junit.Assert.assertNull(xYURLGenerator5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        xYSeries1.setMaximumItemCount((int) (short) 0);
        org.jfree.data.xy.XYSeries xYSeries7 = xYSeries1.createCopy((int) '4', (int) (short) 10);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        xYSeries1.removePropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = xYSeries1.getAllowDuplicateXValues();
        java.lang.String str11 = xYSeries1.getDescription();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(xYSeries7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.HORIZONTAL"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone2;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone2;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("Value", timeZone2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        org.jfree.data.xy.XYDataset xYDataset15 = combinedRangeXYPlot11.getDataset();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        combinedRangeXYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        timeSeries10.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection17);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year8.next();
        java.util.Date date27 = year8.getStart();
        dateAxis5.setMinimumDate(date27);
        org.jfree.data.Range range29 = null;
        org.jfree.data.Range range31 = org.jfree.data.Range.expandToInclude(range29, (double) 0L);
        double double32 = range31.getLength();
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange(range31);
        java.util.Date date34 = dateRange33.getUpperDate();
        dateAxis5.setMinimumDate(date34);
        java.util.TimeZone timeZone36 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone36;
        java.util.Date date38 = dateTickUnit0.addToDate(date34, timeZone36);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) dateTickUnit0, "Value", "DateTickUnitType.HOUR");
        java.lang.String str42 = dateTickUnit0.toString();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DateTickUnit[DateTickUnitType.DAY, 1]" + "'", str42.equals("DateTickUnit[DateTickUnitType.DAY, 1]"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Stroke stroke4 = null;
        xYBarRenderer1.setSeriesOutlineStroke(128, stroke4, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer1.getSeriesPositiveItemLabelPosition((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        boolean boolean15 = xYAreaRenderer0.getPlotLines();
        xYAreaRenderer0.clearSeriesStrokes(true);
        xYAreaRenderer0.setSeriesVisibleInLegend((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Color color22 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int25 = color24.getAlpha();
        legendItem23.setLabelPaint((java.awt.Paint) color24);
        java.awt.Shape shape27 = legendItem23.getShape();
        xYAreaRenderer0.setLegendArea(shape27);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.clearDomainMarkers();
        combinedRangeXYPlot3.setRangePannable(true);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.axis.AxisSpace axisSpace8 = combinedRangeXYPlot3.getFixedRangeAxisSpace();
        combinedRangeXYPlot3.configureDomainAxes();
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.clearDomainMarkers();
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color19);
        combinedRangeXYPlot16.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        combinedRangeXYPlot16.zoomRangeAxes(0.0d, 0.0d, plotRenderingInfo24, point2D25);
        timeSeriesCollection10.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot16);
        double double28 = combinedRangeXYPlot16.getDomainCrosshairValue();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection31 = null;
        chartRenderingInfo30.setEntityCollection(entityCollection31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = chartRenderingInfo30.getPlotInfo();
        org.jfree.chart.plot.CrosshairState crosshairState35 = new org.jfree.chart.plot.CrosshairState(false);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = null;
        java.awt.geom.Point2D point2D38 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D36, rectangleAnchor37);
        crosshairState35.setAnchor(point2D38);
        combinedRangeXYPlot16.zoomRangeAxes((double) (byte) 1, plotRenderingInfo33, point2D38, false);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(plotRenderingInfo33);
        org.junit.Assert.assertNotNull(point2D38);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart27.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo33);
        org.jfree.chart.plot.PiePlot piePlot35 = new org.jfree.chart.plot.PiePlot();
        piePlot35.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator38 = piePlot35.getLegendLabelToolTipGenerator();
        java.awt.Stroke stroke39 = piePlot35.getLabelOutlineStroke();
        jFreeChart27.setBorderStroke(stroke39);
        java.util.List list41 = jFreeChart27.getSubtitles();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(bufferedImage34);
        org.junit.Assert.assertNull(pieSectionLabelGenerator38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", image3, "Nearest", "0%", "0%");
        projectInfo7.setInfo("");
        java.lang.String str10 = projectInfo7.toString();
        org.jfree.chart.ui.Library[] libraryArray11 = projectInfo7.getOptionalLibraries();
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + " version DateTickMarkPosition.MIDDLE.\nNearest.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n0%" + "'", str10.equals(" version DateTickMarkPosition.MIDDLE.\nNearest.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n0%"));
        org.junit.Assert.assertNotNull(libraryArray11);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.clearDomainMarkers();
        java.awt.Color color19 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color19);
        combinedRangeXYPlot16.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        combinedRangeXYPlot16.zoomRangeAxes(0.0d, 0.0d, plotRenderingInfo24, point2D25);
        timeSeriesCollection10.addChangeListener((org.jfree.data.general.DatasetChangeListener) combinedRangeXYPlot16);
        java.awt.geom.Point2D point2D28 = combinedRangeXYPlot16.getQuadrantOrigin();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(point2D28);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("Pie Plot");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        java.awt.Color color5 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color5);
        combinedRangeXYPlot2.setOutlinePaint((java.awt.Paint) color5);
        standardChartTheme1.setTickLabelPaint((java.awt.Paint) color5);
        java.awt.Paint paint9 = null;
        try {
            standardChartTheme1.setPlotBackgroundPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        java.util.TimeZone timeZone20 = periodAxis19.getTimeZone();
        periodAxis19.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone20);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean6 = barRenderer3D0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer3D0.setSeriesURLGenerator((int) ' ', categoryURLGenerator8);
        org.jfree.chart.LegendItem legendItem12 = barRenderer3D0.getLegendItem(0, 0);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(legendItem12);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setMinorTickCount(0);
        float float3 = logAxis0.getMinorTickMarkInsideLength();
        double double5 = logAxis0.calculateValue((double) 10.0f);
        boolean boolean6 = logAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E10d + "'", double5 == 1.0E10d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone2;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone2;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("Value", timeZone2);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        org.jfree.data.xy.XYDataset xYDataset15 = combinedRangeXYPlot11.getDataset();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        combinedRangeXYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        timeSeries10.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection17);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year8.next();
        java.util.Date date27 = year8.getStart();
        dateAxis5.setMinimumDate(date27);
        org.jfree.data.Range range29 = null;
        org.jfree.data.Range range31 = org.jfree.data.Range.expandToInclude(range29, (double) 0L);
        double double32 = range31.getLength();
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange(range31);
        java.util.Date date34 = dateRange33.getUpperDate();
        dateAxis5.setMinimumDate(date34);
        java.util.TimeZone timeZone36 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone36;
        java.util.Date date38 = dateTickUnit0.addToDate(date34, timeZone36);
        java.util.TimeZone timeZone40 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone40;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone40;
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("Value", timeZone40);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date34, timeZone40);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        java.beans.PropertyChangeListener propertyChangeListener3 = null;
        xYSeries1.removePropertyChangeListener(propertyChangeListener3);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj3 = xYSeries2.clone();
        boolean boolean5 = xYSeries2.equals((java.lang.Object) (short) 10);
        int int6 = xYSeriesCollection0.indexOf(xYSeries2);
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double9 = xYSeries8.getMinX();
        xYSeries8.setMaximumItemCount((int) (short) 0);
        org.jfree.data.xy.XYDataItem xYDataItem14 = xYSeries8.addOrUpdate(0.2d, (double) 0);
        xYSeriesCollection0.addSeries(xYSeries8);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem14);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.chart.text.TextFragment textFragment3 = new org.jfree.chart.text.TextFragment("Nearest");
        java.awt.Paint paint4 = textFragment3.getPaint();
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator6 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot5.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator6);
        double double8 = piePlot5.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer11.getItemOutlineStroke((int) 'a', 0, false);
        piePlot5.setBaseSectionOutlineStroke(stroke15);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator18 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot5.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator18);
        boolean boolean20 = piePlot5.getAutoPopulateSectionOutlinePaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer21.setUseFillPaint(false);
        boolean boolean24 = xYAreaRenderer21.getBaseSeriesVisible();
        java.awt.Paint paint28 = xYAreaRenderer21.getItemLabelPaint(0, 255, true);
        piePlot5.setOutlinePaint(paint28);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot33.clearDomainMarkers();
        combinedRangeXYPlot33.setRangePannable(true);
        categoryAxis30.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot33);
        org.jfree.chart.axis.AxisSpace axisSpace38 = combinedRangeXYPlot33.getFixedRangeAxisSpace();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        combinedRangeXYPlot33.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D39);
        numberAxis3D39.setLowerBound((double) 10L);
        java.awt.Shape shape43 = numberAxis3D39.getRightArrow();
        boolean boolean44 = numberAxis3D39.getAutoRangeIncludesZero();
        java.awt.Paint paint45 = numberAxis3D39.getTickLabelPaint();
        java.awt.Paint[] paintArray46 = new java.awt.Paint[] { paint4, paint28, paint45 };
        java.awt.Paint[] paintArray47 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color50 = java.awt.Color.getColor("hi!", (int) (short) 100);
        java.awt.Color color53 = java.awt.Color.getColor("hi!", (int) (short) 100);
        java.awt.Paint[] paintArray54 = new java.awt.Paint[] { color50, color53 };
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer57 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke61 = xYLineAndShapeRenderer57.getItemOutlineStroke((int) 'a', 0, false);
        java.awt.Stroke[] strokeArray62 = new java.awt.Stroke[] { stroke61 };
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer65 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke69 = xYLineAndShapeRenderer65.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer72 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke76 = xYLineAndShapeRenderer72.getItemOutlineStroke((int) 'a', 0, false);
        java.awt.Stroke[] strokeArray77 = new java.awt.Stroke[] { stroke69, stroke76 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier78 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape79 = defaultDrawingSupplier78.getNextShape();
        java.awt.Shape shape82 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) 7);
        java.awt.Shape[] shapeArray83 = new java.awt.Shape[] { shape79, shape82 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier84 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray47, paintArray54, strokeArray62, strokeArray77, shapeArray83);
        java.awt.Stroke[] strokeArray85 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray86 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier87 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray46, strokeArray77, strokeArray85, shapeArray86);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(axisSpace38);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(paintArray46);
        org.junit.Assert.assertNotNull(paintArray47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paintArray54);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(strokeArray62);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(strokeArray77);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(shapeArray83);
        org.junit.Assert.assertNotNull(strokeArray85);
        org.junit.Assert.assertNotNull(shapeArray86);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        java.util.List list17 = timeSeries1.getItems();
        boolean boolean18 = timeSeries1.isEmpty();
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateTopOutset(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.plot.PlotState plotState0 = new org.jfree.chart.plot.PlotState();
        java.util.Map map1 = plotState0.getSharedAxisStates();
        org.junit.Assert.assertNotNull(map1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean6 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer3D0.setSeriesItemLabelGenerator((int) (byte) 1, categoryItemLabelGenerator8);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer3D0.getLegendItems();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer3D0.getSeriesItemLabelGenerator(128);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) ' ');
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        combinedRangeXYPlot13.setRangePannable(true);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        combinedRangeXYPlot13.drawBackgroundImage(graphics2D17, rectangle2D18);
        java.awt.Color color20 = java.awt.Color.GRAY;
        combinedRangeXYPlot13.setRangeGridlinePaint((java.awt.Paint) color20);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color24 = java.awt.Color.GRAY;
        int int25 = color24.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("", font23, (java.awt.Paint) color24);
        combinedRangeXYPlot13.setRangeTickBandPaint((java.awt.Paint) color24);
        int int28 = combinedRangeXYPlot13.getRendererCount();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        int int35 = combinedRangeXYPlot30.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D34);
        combinedRangeXYPlot30.mapDatasetToRangeAxis((int) (byte) 0, 5);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = combinedRangeXYPlot30.getDomainAxisEdge((int) (byte) 100);
        combinedRangeXYPlot30.setRangeCrosshairLockedOnData(false);
        java.awt.geom.GeneralPath generalPath43 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer45 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot48.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray50 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot48.setDomainAxes(valueAxisArray50);
        combinedRangeXYPlot48.clearRangeAxes();
        java.util.TimeZone timeZone53 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection54 = new org.jfree.data.time.TimeSeriesCollection(timeZone53);
        boolean boolean55 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection54);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection54, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState59 = xYStepAreaRenderer45.initialise(graphics2D46, rectangle2D47, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot48, (org.jfree.data.xy.XYDataset) timeSeriesCollection54, plotRenderingInfo58);
        java.awt.Paint paint61 = xYStepAreaRenderer45.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer45);
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint64 = null;
        org.jfree.chart.util.Size2D size2D65 = legendTitle62.arrange(graphics2D63, rectangleConstraint64);
        java.awt.geom.Rectangle2D rectangle2D66 = legendTitle62.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double68 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D66, rectangleEdge67);
        org.jfree.chart.RenderingSource renderingSource69 = null;
        combinedRangeXYPlot30.select(generalPath43, rectangle2D66, renderingSource69);
        xYStepAreaRenderer11.fillDomainGridBand(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, (org.jfree.chart.axis.ValueAxis) numberAxis29, rectangle2D66, 100.0d, 0.0d);
        try {
            barRenderer3D0.drawDomainGridline(graphics2D8, categoryPlot9, rectangle2D66, 3.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 128 + "'", int25 == 128);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(valueAxisArray50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNotNull(xYItemRendererState59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(size2D65);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 1900);
        valueMarker1.setValue((double) 1L);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        combinedRangeXYPlot4.setRangePannable(true);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        combinedRangeXYPlot4.drawBackgroundImage(graphics2D8, rectangle2D9);
        java.awt.Color color11 = java.awt.Color.GRAY;
        combinedRangeXYPlot4.setRangeGridlinePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot13.getRangeAxisLocation();
        combinedRangeXYPlot4.setRangeAxisLocation(axisLocation17, false);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot26.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot26.setDomainAxes(valueAxisArray28);
        org.jfree.data.xy.XYDataset xYDataset30 = combinedRangeXYPlot26.getDataset();
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection(timeZone31);
        boolean boolean33 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection32);
        combinedRangeXYPlot26.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection32);
        timeSeries25.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection32);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis40 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) year36);
        periodAxis40.setLabelToolTip("hi!");
        combinedRangeXYPlot4.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) periodAxis40);
        boolean boolean44 = valueMarker1.equals((java.lang.Object) 5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertNull(xYDataset30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = xYBarRenderer1.getGradientPaintTransformer();
        double double3 = xYBarRenderer1.getShadowYOffset();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        int int5 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = null;
        combinedRangeXYPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot8.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator9);
        double double11 = piePlot8.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer14.getItemOutlineStroke((int) 'a', 0, false);
        piePlot8.setBaseSectionOutlineStroke(stroke18);
        combinedRangeXYPlot0.setDomainZeroBaselineStroke(stroke18);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.clearDomainMarkers();
        combinedRangeXYPlot9.setRangePannable(true);
        boolean boolean13 = combinedRangeXYPlot9.isRangeZoomable();
        java.awt.Color color15 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color15);
        boolean boolean17 = legendItem16.isShapeFilled();
        java.awt.Paint paint18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem16.setOutlinePaint(paint18);
        java.awt.Paint paint20 = legendItem16.getFillPaint();
        combinedRangeXYPlot9.setRangeCrosshairPaint(paint20);
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot9);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        java.lang.Object obj7 = null;
        boolean boolean8 = xYLineAndShapeRenderer2.equals(obj7);
        xYLineAndShapeRenderer2.setBaseShapesVisible(true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        textTitle1.setURLText("");
        java.lang.Object obj4 = null;
        boolean boolean5 = textTitle1.equals(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.GRAY;
        int int7 = color6.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("", font5, (java.awt.Paint) color6);
        categoryAxis0.setLabelFont(font5);
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = categoryAxis12.getCategoryLabelPositions();
        categoryAxis11.setCategoryLabelPositions(categoryLabelPositions15);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setRangeCrosshairValue(12.0d, false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        labelBlock4.setHeight(0.0d);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot7.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        double double10 = piePlot7.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer13.getItemOutlineStroke((int) 'a', 0, false);
        piePlot7.setBaseSectionOutlineStroke(stroke17);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer19.setUseFillPaint(false);
        boolean boolean22 = xYAreaRenderer19.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot25.setDomainAxes(valueAxisArray27);
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeZone29);
        boolean boolean31 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState33 = xYAreaRenderer19.initialise(graphics2D23, rectangle2D24, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot25, (org.jfree.data.xy.XYDataset) timeSeriesCollection30, plotRenderingInfo32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = combinedRangeXYPlot25.getInsets();
        java.lang.String str35 = rectangleInsets34.toString();
        piePlot7.setSimpleLabelOffset(rectangleInsets34);
        double double37 = rectangleInsets34.getBottom();
        labelBlock4.setPadding(rectangleInsets34);
        java.awt.Paint paint39 = labelBlock4.getPaint();
        org.jfree.chart.text.TextBlock textBlock40 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor44 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape48 = textBlock40.calculateBounds(graphics2D41, 0.0f, (float) (-1), textBlockAnchor44, (float) (byte) 0, (float) 100, (double) 7);
        labelBlock4.setContentAlignmentPoint(textBlockAnchor44);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str35.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(textBlockAnchor44);
        org.junit.Assert.assertNotNull(shape48);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        piePlot1.setIgnoreNullValues(true);
        boolean boolean7 = rotation0.equals((java.lang.Object) true);
        double double8 = rotation0.getFactor();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        boolean boolean15 = xYAreaRenderer0.getPlotLines();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot18.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot18.setDomainAxes(valueAxisArray20);
        org.jfree.data.xy.XYDataset xYDataset22 = combinedRangeXYPlot18.getDataset();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = combinedRangeXYPlot18.getDomainMarkers(layer23);
        double double25 = combinedRangeXYPlot18.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation26 = combinedRangeXYPlot18.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer27.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot32 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot32.clearDomainMarkers();
        combinedRangeXYPlot32.setRangePannable(true);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        combinedRangeXYPlot32.drawBackgroundImage(graphics2D36, rectangle2D37);
        java.awt.Color color39 = java.awt.Color.GRAY;
        combinedRangeXYPlot32.setRangeGridlinePaint((java.awt.Paint) color39);
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection(timeZone41);
        boolean boolean43 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState45 = xYAreaRenderer27.initialise(graphics2D30, rectangle2D31, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot32, (org.jfree.data.xy.XYDataset) timeSeriesCollection42, plotRenderingInfo44);
        org.jfree.data.general.DatasetGroup datasetGroup46 = timeSeriesCollection42.getGroup();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeriesCollection42.removeSeries(timeSeries48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState51 = xYAreaRenderer0.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.data.xy.XYDataset) timeSeriesCollection42, plotRenderingInfo50);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNull(xYDataset22);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState45);
        org.junit.Assert.assertNotNull(datasetGroup46);
        org.junit.Assert.assertNotNull(xYItemRendererState51);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean6 = barRenderer3D0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer3D0.setSeriesToolTipGenerator(0, categoryToolTipGenerator8);
        java.awt.Paint paint13 = barRenderer3D0.getItemOutlinePaint(5, 1, false);
        barRenderer3D0.setItemMargin((double) 1900);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer17 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean18 = xYBarRenderer17.getShadowsVisible();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke26 = xYLineAndShapeRenderer22.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot27.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot27.setDomainAxes(valueAxisArray29);
        combinedRangeXYPlot27.clearRangeAxes();
        java.awt.Stroke stroke32 = combinedRangeXYPlot27.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot33 = combinedRangeXYPlot27.getRootPlot();
        xYLineAndShapeRenderer22.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.Paint paint38 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot39 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator40 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot39.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator40);
        double double42 = piePlot39.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer45 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke49 = xYLineAndShapeRenderer45.getItemOutlineStroke((int) 'a', 0, false);
        piePlot39.setBaseSectionOutlineStroke(stroke49);
        xYBarRenderer17.drawDomainLine(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, rectangle2D36, (double) (byte) -1, paint38, stroke49);
        boolean boolean52 = combinedRangeXYPlot27.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot53.clearDomainMarkers();
        combinedRangeXYPlot53.setRangePannable(true);
        java.awt.Graphics2D graphics2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        combinedRangeXYPlot53.drawBackgroundImage(graphics2D57, rectangle2D58);
        java.awt.Color color60 = java.awt.Color.GRAY;
        combinedRangeXYPlot53.setRangeGridlinePaint((java.awt.Paint) color60);
        boolean boolean63 = combinedRangeXYPlot53.equals((java.lang.Object) 10.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent64 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot53);
        combinedRangeXYPlot27.notifyListeners(plotChangeEvent64);
        barRenderer3D0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot27);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(plot33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        java.awt.geom.Point2D point2D4 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D2, rectangleAnchor3);
        crosshairState1.setAnchor(point2D4);
        crosshairState1.setCrosshairDistance(4.0d);
        java.awt.geom.Point2D point2D8 = crosshairState1.getAnchor();
        crosshairState1.setCrosshairX((double) ' ');
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertNotNull(point2D8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.lang.Object obj19 = legendTitle18.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = legendTitle18.getItemLabelPadding();
        boolean boolean21 = legendTitle18.isVisible();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setSeriesLinesVisible(0, false);
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement12);
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.GRAY;
        int int17 = color16.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("", font15, (java.awt.Paint) color16);
        java.lang.Object obj19 = null;
        columnArrangement12.add((org.jfree.chart.block.Block) labelBlock18, obj19);
        columnArrangement12.clear();
        org.jfree.chart.block.Arrangement arrangement22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYLineAndShapeRenderer2, (org.jfree.chart.block.Arrangement) columnArrangement12, arrangement22);
        java.awt.Paint paint25 = null;
        xYLineAndShapeRenderer2.setSeriesPaint((int) (short) 10, paint25, true);
        java.lang.Boolean boolean29 = xYLineAndShapeRenderer2.getSeriesShapesVisible(9999);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 128 + "'", int17 == 128);
        org.junit.Assert.assertNull(boolean29);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        combinedRangeXYPlot11.setRangePannable(true);
        categoryAxis8.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot11);
        int int16 = categoryAxis8.getCategoryLabelPositionOffset();
        org.jfree.chart.entity.AxisEntity axisEntity17 = new org.jfree.chart.entity.AxisEntity(shape6, (org.jfree.chart.axis.Axis) categoryAxis8);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) 255);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.lang.Object obj1 = barRenderer3D0.clone();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        barRenderer3D0.setSeriesItemLabelGenerator(15, categoryItemLabelGenerator3);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot6.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator7);
        double double9 = piePlot6.getMaximumLabelWidth();
        boolean boolean10 = piePlot6.getIgnoreNullValues();
        boolean boolean11 = itemLabelAnchor5.equals((java.lang.Object) boolean10);
        org.jfree.chart.axis.TickType tickType12 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor15, textAnchor16);
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick20 = new org.jfree.chart.axis.NumberTick(tickType12, (double) 100L, "1,500%", textAnchor16, textAnchor18, (-1.0d));
        org.jfree.data.xy.XYDataItem xYDataItem23 = new org.jfree.data.xy.XYDataItem(0.0d, (double) (-1.0f));
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        int int25 = xYDataItem23.compareTo((java.lang.Object) textAnchor24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor16, textAnchor24, (double) 10);
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition27);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.14d + "'", double9 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState9 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis0.drawTickMarks(graphics2D4, (double) (short) 100, rectangle2D6, rectangleEdge7, axisState9);
        org.jfree.chart.plot.Plot plot11 = categoryAxis0.getPlot();
        java.lang.Object obj12 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        java.awt.Paint paint10 = combinedRangeXYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent12 = null;
        try {
            jFreeChart11.titleChanged(titleChangeEvent12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        piePlot0.setLabelLinkPaint(paint3);
        piePlot0.setLabelLinkMargin(90.0d);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray14);
        combinedRangeXYPlot12.clearRangeAxes();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        boolean boolean19 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection18, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState23 = xYStepAreaRenderer9.initialise(graphics2D10, rectangle2D11, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12, (org.jfree.data.xy.XYDataset) timeSeriesCollection18, plotRenderingInfo22);
        java.awt.Paint paint25 = xYStepAreaRenderer9.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer9);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = null;
        org.jfree.chart.util.Size2D size2D29 = legendTitle26.arrange(graphics2D27, rectangleConstraint28);
        java.awt.geom.Rectangle2D rectangle2D30 = legendTitle26.getBounds();
        piePlot0.drawBackgroundImage(graphics2D7, rectangle2D30);
        java.awt.Paint paint33 = piePlot0.getSectionPaint((java.lang.Comparable) "ClassContext");
        double double34 = piePlot0.getShadowYOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(xYItemRendererState23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
    }
}

