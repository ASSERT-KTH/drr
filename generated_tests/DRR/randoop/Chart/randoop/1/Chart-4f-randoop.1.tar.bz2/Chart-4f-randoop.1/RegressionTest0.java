import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound(xYDataset0, (int) (short) -1, (double) (short) 100, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            java.lang.Number number4 = timeSeriesCollection1.getY((int) ' ', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.plot.Marker marker0 = null;
        try {
            org.jfree.chart.event.MarkerChangeEvent markerChangeEvent1 = new org.jfree.chart.event.MarkerChangeEvent(marker0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            piePlot0.drawOutline(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = timeSeriesCollection1.getSeries((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (97).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor2 = null;
        try {
            timeSeriesCollection1.setXPosition(timePeriodAnchor2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int15 = color14.getAlpha();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke22 = xYLineAndShapeRenderer18.getItemOutlineStroke((int) 'a', 0, false);
        try {
            xYLineAndShapeRenderer2.drawDomainLine(graphics2D9, xYPlot10, valueAxis11, rectangle2D12, (double) '#', (java.awt.Paint) color14, stroke22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.axis.Axis axis2 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity5 = new org.jfree.chart.entity.AxisEntity(shape1, axis2, "hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.text.NumberFormat numberFormat1 = null;
        java.text.NumberFormat numberFormat2 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", numberFormat1, numberFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'numberFormat' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            double double4 = timeSeriesCollection1.getStartYValue((int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.Control control4 = null;
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("", locale1, classLoader3, control4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            double double4 = timeSeriesCollection1.getXValue((int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.axis.Axis axis2 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity4 = new org.jfree.chart.entity.AxisEntity(shape1, axis2, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Point2D point2D3 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) (short) -1, plotRenderingInfo2, point2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        try {
            combinedRangeXYPlot0.setRangeAxisLocation(0, axisLocation3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.KeyedValues keyedValues0 = null;
        try {
            org.jfree.data.general.DefaultPieDataset defaultPieDataset1 = new org.jfree.data.general.DefaultPieDataset(keyedValues0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'data' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (int) (short) 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            java.lang.Comparable comparable4 = timeSeriesCollection1.getSeriesKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setShadowXOffset((double) ' ');
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = piePlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNull(pieURLGenerator3);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.jfree.chart.axis.Axis axis2 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity3 = new org.jfree.chart.entity.AxisEntity(shape1, axis2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        java.util.List list2 = null;
        try {
            org.jfree.data.Range range4 = timeSeriesCollection1.getDomainBounds(list2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = null;
        try {
            xYAreaRenderer0.setGradientTransformer(gradientPaintTransformer4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            java.lang.Number number5 = timeSeriesCollection1.getStartX((int) (byte) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker(marker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.math.RoundingMode roundingMode1 = null;
        try {
            logFormat0.setRoundingMode(roundingMode1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.block.Arrangement arrangement0 = null;
        try {
            org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer(arrangement0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            combinedRangeXYPlot0.addRangeMarker(255, marker5, layer6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        try {
            textBlock0.setLineAlignment(horizontalAlignment1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        try {
            java.util.Currency currency1 = logFormat0.getCurrency();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        try {
            int int11 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection6, 2, (double) 100, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = null;
        java.awt.geom.Point2D point2D2 = null;
        try {
            org.jfree.chart.plot.XYPlot xYPlot3 = combinedRangeXYPlot0.findSubplot(plotRenderingInfo1, point2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        try {
            org.jfree.data.time.TimeSeries timeSeries9 = timeSeriesCollection6.getSeries((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = null;
        try {
            xYAreaRenderer0.setGradientTransformer(gradientPaintTransformer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        int int13 = xYLineAndShapeRenderer2.getPassCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation14 = null;
        boolean boolean15 = xYLineAndShapeRenderer2.removeAnnotation(xYAnnotation14);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator13 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot0.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator13);
        boolean boolean16 = standardPieToolTipGenerator13.equals((java.lang.Object) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = null;
        try {
            xYBarRenderer1.setBarPainter(xYBarPainter2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Color color4 = java.awt.Color.getColor("hi!", (int) (short) 100);
        java.awt.Color color7 = java.awt.Color.getColor("hi!", (int) (short) 100);
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, color7 };
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer11.getItemOutlineStroke((int) 'a', 0, false);
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke23 = xYLineAndShapeRenderer19.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer26.getItemOutlineStroke((int) 'a', 0, false);
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke23, stroke30 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape33 = defaultDrawingSupplier32.getNextShape();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) 7);
        java.awt.Shape[] shapeArray37 = new java.awt.Shape[] { shape33, shape36 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier38 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray8, strokeArray16, strokeArray31, shapeArray37);
        boolean boolean39 = domainOrder0.equals((java.lang.Object) strokeArray31);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shapeArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            java.lang.Comparable comparable4 = timeSeriesCollection1.getSeriesKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        java.lang.String str1 = dateTickMarkPosition0.toString();
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickMarkPosition.MIDDLE" + "'", str1.equals("DateTickMarkPosition.MIDDLE"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.Plot plot5 = combinedRangeXYPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(plot5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            blockBorder1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.io.ObjectOutputStream objectOutputStream2 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint1, objectOutputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.lang.Object obj1 = null;
        boolean boolean2 = chartChangeEventType0.equals(obj1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.lang.Comparable[] comparableArray1 = new java.lang.Comparable[] { 0.0d };
        java.lang.Comparable[] comparableArray5 = new java.lang.Comparable[] { "Nearest", 0, 0.0d };
        double[] doubleArray12 = new double[] { (-1.0f), (-1), 7, 100.0d, 100, (short) 10 };
        double[] doubleArray19 = new double[] { (-1.0f), (-1), 7, 100.0d, 100, (short) 10 };
        double[] doubleArray26 = new double[] { (-1.0f), (-1), 7, 100.0d, 100, (short) 10 };
        double[] doubleArray33 = new double[] { (-1.0f), (-1), 7, 100.0d, 100, (short) 10 };
        double[] doubleArray40 = new double[] { (-1.0f), (-1), 7, 100.0d, 100, (short) 10 };
        double[][] doubleArray41 = new double[][] { doubleArray12, doubleArray19, doubleArray26, doubleArray33, doubleArray40 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray1, comparableArray5, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray1);
        org.junit.Assert.assertNotNull(comparableArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        try {
            timeSeries1.update((int) (short) 100, (java.lang.Number) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        try {
            java.util.Collection collection5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list4);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        categoryAxis0.setLabelInsets(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray6 = new float[] { (-2208960000000L), 1L, 100.0f, 1L };
        try {
            float[] floatArray7 = color0.getColorComponents(colorSpace1, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        xYStepAreaRenderer1.setShapesFilled(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        xYStepAreaRenderer1.notifyListeners(rendererChangeEvent4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        double double4 = piePlot0.getShadowXOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        try {
            double double18 = timeSeriesCollection10.getYValue((int) (byte) 0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setShadowXOffset((double) ' ');
        java.awt.Shape shape3 = piePlot0.getLegendItemShape();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint5 = defaultDrawingSupplier4.getNextPaint();
        piePlot0.setLabelPaint(paint5);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        try {
            double double17 = timeSeriesCollection11.getXValue(100, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (-2208960000000L));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone1;
        java.util.Locale locale3 = null;
        try {
            org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date0, timeZone1, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = combinedRangeXYPlot6.getInsets();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot17.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot17.setDomainAxes(valueAxisArray19);
        java.util.List list21 = combinedRangeXYPlot17.getSubplots();
        try {
            combinedRangeXYPlot6.mapDatasetToRangeAxes((int) 'a', list21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(valueAxisArray19);
        org.junit.Assert.assertNotNull(list21);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat2 = standardPieToolTipGenerator1.getPercentFormat();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        try {
            java.lang.String str4 = numberFormat2.format((java.lang.Object) categoryAxis3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator13 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot0.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator13);
        org.jfree.data.general.PieDataset pieDataset15 = null;
        java.lang.String str17 = standardPieToolTipGenerator13.generateToolTip(pieDataset15, (java.lang.Comparable) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot15.setDomainAxes(valueAxisArray17);
        org.jfree.data.xy.XYDataset xYDataset19 = combinedRangeXYPlot15.getDataset();
        combinedRangeXYPlot6.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        try {
            boolean boolean22 = combinedRangeXYPlot6.removeAnnotation(xYAnnotation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNull(xYDataset19);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = timeSeries1.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = null;
        try {
            combinedRangeXYPlot0.setOrientation(plotOrientation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYLineAndShapeRenderer3.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer3.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYLineAndShapeRenderer3.setSeriesURLGenerator(0, xYURLGenerator11, true);
        xYLineAndShapeRenderer3.setUseOutlinePaint(false);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextPaint();
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("Nearest", font18, paint20);
        xYLineAndShapeRenderer3.setLegendTextFont(10, font18);
        java.awt.Paint paint23 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer26 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock27 = org.jfree.chart.text.TextUtilities.createTextBlock("DateTickMarkPosition.MIDDLE", font18, paint23, (float) 7, 10, textMeasurer26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        boolean boolean4 = categoryAxis0.isVisible();
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            combinedRangeXYPlot0.addAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        double double7 = combinedRangeXYPlot0.getRangeCrosshairValue();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation8 = null;
        try {
            boolean boolean10 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (short) -1);
        int int2 = numberTickUnit1.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        combinedRangeXYPlot0.setDomainCrosshairPaint(paint10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            combinedRangeXYPlot0.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = barRenderer3D0.initialise(graphics2D1, rectangle2D2, categoryPlot3, (int) (byte) 1, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        boolean boolean7 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.axis.ValueAxis valueAxis10 = combinedRangeXYPlot0.getDomainAxis((int) (byte) 0);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = combinedRangeXYPlot0.getDomainMarkers(layer8);
        org.jfree.chart.block.Arrangement arrangement10 = null;
        org.jfree.chart.block.Arrangement arrangement11 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) combinedRangeXYPlot0, arrangement10, arrangement11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.panRangeAxes((double) 255, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker(5, marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateTopOutset((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets1.createInsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.NumberAxis numberAxis1 = null;
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier8 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint9 = defaultDrawingSupplier8.getNextPaint();
        org.jfree.chart.text.TextLine textLine10 = new org.jfree.chart.text.TextLine("Nearest", font7, paint9);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis1, 0.05d, (double) 1, (double) 1L, (double) 'a', font7);
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("Nearest", font7, paint12, (float) (-1L), textMeasurer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getGreen();
        java.lang.String str2 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str2.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot15.setDomainAxes(valueAxisArray17);
        org.jfree.data.xy.XYDataset xYDataset19 = combinedRangeXYPlot15.getDataset();
        combinedRangeXYPlot6.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = combinedRangeXYPlot6.getRangeMarkers(layer21);
        java.awt.Paint paint23 = combinedRangeXYPlot6.getDomainMinorGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) ' ', (double) 0.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint4 = defaultDrawingSupplier3.getNextPaint();
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("Nearest", font2, paint4);
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer10 = new org.jfree.chart.text.G2TextMeasurer(graphics2D9);
        try {
            org.jfree.chart.text.TextBlock textBlock11 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font2, (java.awt.Paint) color6, (float) '4', 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        double double7 = combinedRangeXYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot10.getDataset();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        combinedRangeXYPlot10.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        combinedRangeXYPlot0.setDataset(0, (org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        try {
            int int23 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset) timeSeriesCollection16, (int) (byte) 0, 1.0d, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        combinedRangeXYPlot0.setDomainCrosshairPaint(paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.clearDomainMarkers();
        combinedRangeXYPlot3.setRangePannable(true);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot();
        double double9 = piePlot8.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint11 = defaultDrawingSupplier10.getNextPaint();
        piePlot8.setLabelLinkPaint(paint11);
        categoryAxis0.setAxisLinePaint(paint11);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot20.setDomainAxes(valueAxisArray22);
        combinedRangeXYPlot20.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = combinedRangeXYPlot20.getDomainAxisEdge();
        try {
            double double26 = categoryAxis0.getCategorySeriesMiddle((int) (short) 10, (int) (byte) 100, (int) 'a', (int) (byte) 0, 1.0d, rectangle2D19, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 90.0d + "'", double9 == 90.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        try {
            xYSeries1.update((java.lang.Number) 255, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 255");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer7.setUseFillPaint(false);
        boolean boolean10 = xYAreaRenderer7.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        boolean boolean19 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYAreaRenderer7.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, (org.jfree.data.xy.XYDataset) timeSeriesCollection18, plotRenderingInfo20);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        double double23 = piePlot22.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextPaint();
        piePlot22.setLabelLinkPaint(paint25);
        timeSeriesCollection18.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot22);
        int int28 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        try {
            double double31 = timeSeriesCollection18.getStartXValue(10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 90.0d + "'", double23 == 90.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        boolean boolean4 = combinedRangeXYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        try {
            combinedRangeXYPlot0.setQuadrantPaint((-1), (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            boolean boolean8 = combinedRangeXYPlot0.removeRangeMarker(0, marker5, layer6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        java.awt.Paint paint6 = barRenderer3D0.getShadowPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        xYStepAreaRenderer1.setOutline(true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        combinedRangeXYPlot0.zoom((double) '4');
        java.awt.Paint paint9 = null;
        try {
            combinedRangeXYPlot0.setRangeMinorGridlinePaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            combinedRangeXYPlot0.addRangeMarker(4, marker6, layer7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.util.TableOrder tableOrder2 = null;
        try {
            multiplePiePlot1.setDataExtractOrder(tableOrder2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.util.TimeZone timeZone1 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        java.util.Locale locale3 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", timeZone1, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, list1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYLineAndShapeRenderer3.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer3.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYLineAndShapeRenderer3.setSeriesURLGenerator(0, xYURLGenerator11, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        xYLineAndShapeRenderer3.setLegendItemToolTipGenerator(xYSeriesLabelGenerator14);
        boolean boolean16 = xYLineAndShapeRenderer3.getBaseItemLabelsVisible();
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer3.lookupSeriesStroke((int) (short) 1);
        barRenderer3D0.setBaseStroke(stroke18, false);
        java.lang.Boolean boolean22 = barRenderer3D0.getSeriesCreateEntities(100);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        try {
            barRenderer3D0.drawDomainGridline(graphics2D23, categoryPlot24, rectangle2D25, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(boolean22);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        xYStepAreaRenderer1.setShapesFilled(false);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYStepAreaRenderer1.setSeriesOutlineStroke(2, stroke5, false);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean11 = xYBarRenderer10.getShadowsVisible();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke19 = xYLineAndShapeRenderer15.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot20.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot20.setDomainAxes(valueAxisArray22);
        combinedRangeXYPlot20.clearRangeAxes();
        java.awt.Stroke stroke25 = combinedRangeXYPlot20.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot26 = combinedRangeXYPlot20.getRootPlot();
        xYLineAndShapeRenderer15.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        java.awt.Paint paint31 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot32 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator33 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot32.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator33);
        double double35 = piePlot32.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer38 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke42 = xYLineAndShapeRenderer38.getItemOutlineStroke((int) 'a', 0, false);
        piePlot32.setBaseSectionOutlineStroke(stroke42);
        xYBarRenderer10.drawDomainLine(graphics2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.chart.axis.ValueAxis) numberAxis3D28, rectangle2D29, (double) (byte) -1, paint31, stroke42);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot50 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot50.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray52 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot50.setDomainAxes(valueAxisArray52);
        org.jfree.data.xy.XYDataset xYDataset54 = combinedRangeXYPlot50.getDataset();
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection56 = new org.jfree.data.time.TimeSeriesCollection(timeZone55);
        boolean boolean57 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection56);
        combinedRangeXYPlot50.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection56);
        timeSeries49.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection56);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) year60, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis64 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year47, (org.jfree.data.time.RegularTimePeriod) year60);
        periodAxis64.setMinorTickMarkInsideLength(0.0f);
        periodAxis64.setMinorTickMarkInsideLength(0.0f);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray69 = periodAxis64.getLabelInfo();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        try {
            xYStepAreaRenderer1.drawDomainGridLine(graphics2D8, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot20, (org.jfree.chart.axis.ValueAxis) periodAxis64, rectangle2D70, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(plot26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(valueAxisArray52);
        org.junit.Assert.assertNull(xYDataset54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray69);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        combinedRangeXYPlot0.setRenderer((int) (short) 100, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer8, false);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            combinedRangeXYPlot0.setDomainAxisLocation(0, axisLocation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat2 = standardPieToolTipGenerator1.getPercentFormat();
        java.lang.String str4 = numberFormat2.format((long) (byte) 0);
        numberFormat2.setMaximumFractionDigits((int) (short) 10);
        try {
            java.lang.Object obj8 = numberFormat2.parseObject("java.awt.Color[r=128,g=128,b=128]");
            org.junit.Assert.fail("Expected exception of type java.text.ParseException; message: Format.parseObject(String) failed");
        } catch (java.text.ParseException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0%" + "'", str4.equals("0%"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = xYAreaRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation4 = null;
        try {
            xYAreaRenderer0.addAnnotation(xYAnnotation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        java.awt.Font font7 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        xYLineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 0, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        xYLineAndShapeRenderer2.setSeriesPositiveItemLabelPosition(0, itemLabelPosition12, true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape13 = textBlock5.calculateBounds(graphics2D6, 0.0f, (float) (-1), textBlockAnchor9, (float) (byte) 0, (float) 100, (double) 7);
        java.awt.Color color16 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color16);
        int int18 = color16.getRed();
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D21 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = xYLineAndShapeRenderer24.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer24.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator32 = null;
        xYLineAndShapeRenderer24.setSeriesURLGenerator(0, xYURLGenerator32, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator35 = null;
        xYLineAndShapeRenderer24.setLegendItemToolTipGenerator(xYSeriesLabelGenerator35);
        boolean boolean37 = xYLineAndShapeRenderer24.getBaseItemLabelsVisible();
        java.awt.Stroke stroke39 = xYLineAndShapeRenderer24.lookupSeriesStroke((int) (short) 1);
        barRenderer3D21.setBaseStroke(stroke39, false);
        java.awt.Shape shape43 = null;
        java.awt.Stroke stroke44 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot45.clearDomainMarkers();
        combinedRangeXYPlot45.setRangePannable(true);
        java.awt.Graphics2D graphics2D49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        combinedRangeXYPlot45.drawBackgroundImage(graphics2D49, rectangle2D50);
        java.awt.Color color52 = java.awt.Color.GRAY;
        combinedRangeXYPlot45.setRangeGridlinePaint((java.awt.Paint) color52);
        java.awt.Font font55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color56 = java.awt.Color.GRAY;
        int int57 = color56.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock58 = new org.jfree.chart.block.LabelBlock("", font55, (java.awt.Paint) color56);
        combinedRangeXYPlot45.setRangeTickBandPaint((java.awt.Paint) color56);
        try {
            org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "", "hi!", false, shape13, true, (java.awt.Paint) color16, true, paint20, stroke39, false, shape43, stroke44, (java.awt.Paint) color56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 128 + "'", int18 == 128);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 128 + "'", int57 == 128);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = xYLineAndShapeRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer3D0.setNegativeItemLabelPositionFallback(itemLabelPosition4);
        boolean boolean6 = barRenderer3D0.getBaseSeriesVisibleInLegend();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = barRenderer3D0.initialise(graphics2D7, rectangle2D8, categoryPlot9, (int) '#', plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getRootPlot();
        xYLineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot23.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        double double26 = piePlot23.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer29.getItemOutlineStroke((int) 'a', 0, false);
        piePlot23.setBaseSectionOutlineStroke(stroke33);
        xYBarRenderer1.drawDomainLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, paint22, stroke33);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot42.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot42.setDomainAxes(valueAxisArray44);
        org.jfree.data.xy.XYDataset xYDataset46 = combinedRangeXYPlot42.getDataset();
        java.util.TimeZone timeZone47 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection48 = new org.jfree.data.time.TimeSeriesCollection(timeZone47);
        boolean boolean49 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection48);
        combinedRangeXYPlot42.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection48);
        timeSeries41.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection48);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) year52, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis56 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year39, (org.jfree.data.time.RegularTimePeriod) year52);
        periodAxis56.setMinorTickMarkInsideLength(0.0f);
        periodAxis56.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis62.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions65 = categoryAxis62.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState71 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis62.drawTickMarks(graphics2D66, (double) (short) 100, rectangle2D68, rectangleEdge69, axisState71);
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list75 = periodAxis56.refreshTicks(graphics2D61, axisState71, rectangle2D73, rectangleEdge74);
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis77 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis77.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions80 = categoryAxis77.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D81 = null;
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState86 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis77.drawTickMarks(graphics2D81, (double) (short) 100, rectangle2D83, rectangleEdge84, axisState86);
        try {
            java.util.List list88 = numberAxis3D19.refreshTicks(graphics2D36, axisState71, rectangle2D76, rectangleEdge84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(valueAxisArray44);
        org.junit.Assert.assertNull(xYDataset46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions65);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(list75);
        org.junit.Assert.assertNotNull(categoryLabelPositions80);
        org.junit.Assert.assertNotNull(rectangleEdge84);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "February" + "'", str1.equals("February"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = combinedRangeXYPlot0.getDomainAxisEdge();
        org.jfree.chart.axis.AxisLocation axisLocation6 = combinedRangeXYPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator4 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat5 = standardPieToolTipGenerator4.getPercentFormat();
        boolean boolean6 = textAnchor2.equals((java.lang.Object) numberFormat5);
        java.math.RoundingMode roundingMode7 = numberFormat5.getRoundingMode();
        boolean boolean8 = multiplePiePlot1.equals((java.lang.Object) roundingMode7);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode7.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        boolean boolean10 = combinedRangeXYPlot0.equals((java.lang.Object) 10.0f);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot11.getRangeAxisLocation();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        combinedRangeXYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        try {
            double double22 = timeSeriesCollection17.getEndXValue((int) 'a', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        double double6 = categoryAxis0.getCategoryMargin();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        org.jfree.data.xy.XYDataset xYDataset17 = combinedRangeXYPlot13.getDataset();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeZone18);
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        combinedRangeXYPlot13.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        timeSeries12.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection19);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) year23, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year10, (org.jfree.data.time.RegularTimePeriod) year23);
        periodAxis27.setMinorTickMarkInsideLength(0.0f);
        periodAxis27.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = categoryAxis33.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState42 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis33.drawTickMarks(graphics2D37, (double) (short) 100, rectangle2D39, rectangleEdge40, axisState42);
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list46 = periodAxis27.refreshTicks(graphics2D32, axisState42, rectangle2D44, rectangleEdge45);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot53 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot53.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray55 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot53.setDomainAxes(valueAxisArray55);
        org.jfree.data.xy.XYDataset xYDataset57 = combinedRangeXYPlot53.getDataset();
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection59 = new org.jfree.data.time.TimeSeriesCollection(timeZone58);
        boolean boolean60 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection59);
        combinedRangeXYPlot53.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection59);
        timeSeries52.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection59);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        timeSeries52.add((org.jfree.data.time.RegularTimePeriod) year63, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis67 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year50, (org.jfree.data.time.RegularTimePeriod) year63);
        periodAxis67.setMinorTickMarkInsideLength(0.0f);
        periodAxis67.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D72 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis73.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions76 = categoryAxis73.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D77 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState82 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis73.drawTickMarks(graphics2D77, (double) (short) 100, rectangle2D79, rectangleEdge80, axisState82);
        java.awt.geom.Rectangle2D rectangle2D84 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list86 = periodAxis67.refreshTicks(graphics2D72, axisState82, rectangle2D84, rectangleEdge85);
        try {
            java.util.List list87 = categoryAxis0.refreshTicks(graphics2D7, axisState42, rectangle2D47, rectangleEdge85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNull(xYDataset17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions36);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(valueAxisArray55);
        org.junit.Assert.assertNull(xYDataset57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions76);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertNotNull(list86);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        boolean boolean13 = xYLineAndShapeRenderer2.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeFilled();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setOutlinePaint(paint4);
        java.awt.Stroke stroke6 = legendItem2.getLineStroke();
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer8 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean9 = xYBarRenderer8.getShadowsVisible();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer13.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot18.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot18.setDomainAxes(valueAxisArray20);
        combinedRangeXYPlot18.clearRangeAxes();
        java.awt.Stroke stroke23 = combinedRangeXYPlot18.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot24 = combinedRangeXYPlot18.getRootPlot();
        xYLineAndShapeRenderer13.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot18);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.Paint paint29 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot30 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator31 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot30.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator31);
        double double33 = piePlot30.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke40 = xYLineAndShapeRenderer36.getItemOutlineStroke((int) 'a', 0, false);
        piePlot30.setBaseSectionOutlineStroke(stroke40);
        xYBarRenderer8.drawDomainLine(graphics2D10, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, rectangle2D27, (double) (byte) -1, paint29, stroke40);
        legendItem2.setOutlineStroke(stroke40);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(plot24);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        xYBarRenderer1.setBarAlignmentFactor((double) 0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        try {
            xYBarRenderer1.setSeriesShape((-1), shape7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeries timeSeries16 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeries1.addAndOrUpdate(timeSeries16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        java.util.List list8 = combinedRangeXYPlot4.getSubplots();
        combinedRangeXYPlot0.drawDomainTickBands(graphics2D2, rectangle2D3, list8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.awt.geom.Point2D point2D12 = null;
        org.jfree.chart.plot.PlotState plotState13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            combinedRangeXYPlot0.draw(graphics2D10, rectangle2D11, point2D12, plotState13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setRange((double) (short) 0, (double) '#');
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot30.setDomainAxes(valueAxisArray32);
        org.jfree.data.xy.XYDataset xYDataset34 = combinedRangeXYPlot30.getDataset();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection36 = new org.jfree.data.time.TimeSeriesCollection(timeZone35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection36);
        combinedRangeXYPlot30.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection36);
        timeSeries29.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection36);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year40);
        periodAxis44.setMinorTickMarkInsideLength(0.0f);
        periodAxis44.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis50.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions53 = categoryAxis50.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState59 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis50.drawTickMarks(graphics2D54, (double) (short) 100, rectangle2D56, rectangleEdge57, axisState59);
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list63 = periodAxis44.refreshTicks(graphics2D49, axisState59, rectangle2D61, rectangleEdge62);
        try {
            double double64 = periodAxis19.valueToJava2D((double) 128, rectangle2D24, rectangleEdge62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions53);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(list63);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Stroke stroke2 = xYStepRenderer0.getSeriesStroke(0);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator4 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.lang.Object obj5 = standardXYToolTipGenerator4.clone();
        try {
            xYStepRenderer0.setSeriesToolTipGenerator((int) (byte) -1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setMinorTickCount(0);
        try {
            logAxis0.setBase(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'base' > 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, (double) 10L, (float) 10L, (float) (short) 1);
        java.io.ObjectOutputStream objectOutputStream6 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeShape(shape1, objectOutputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot1.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot1.setDomainAxes(valueAxisArray3);
        java.util.List list5 = combinedRangeXYPlot1.getSubplots();
        try {
            org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list5, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        try {
            xYSeries1.update((java.lang.Number) 255, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 255");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        java.lang.Boolean boolean10 = xYLineAndShapeRenderer2.getSeriesVisibleInLegend(255);
        java.lang.Object obj11 = xYLineAndShapeRenderer2.clone();
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        try {
            int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) timeSeriesCollection8, (int) (byte) 0, (double) (byte) 10, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, (float) (byte) 0, (float) 100, (double) 7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = null;
        try {
            textBlock0.setLineAlignment(horizontalAlignment9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        int int1 = combinedRangeXYPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Nearest");
        java.awt.Paint paint2 = textFragment1.getPaint();
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState19 = xYItemRendererState18.getCrosshairState();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNull(xYCrosshairState19);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        org.jfree.chart.block.LineBorder lineBorder4 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint5 = lineBorder4.getPaint();
        xYBarRenderer1.setSeriesFillPaint((int) (short) 0, paint5, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = null;
        try {
            timeSeries1.add(regularTimePeriod17, 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.clearDomainMarkers();
        combinedRangeXYPlot3.setRangePannable(true);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.clearDomainMarkers();
        combinedRangeXYPlot8.setRangePannable(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation17 = combinedRangeXYPlot13.getRangeAxisLocation();
        combinedRangeXYPlot8.setDomainAxisLocation(100, axisLocation17, false);
        combinedRangeXYPlot8.setRangeCrosshairVisible(true);
        boolean boolean22 = combinedRangeXYPlot3.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        barRenderer3D0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        barRenderer3D0.setShadowVisible(false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = axisSpace0.expand(rectangle2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        java.awt.Paint paint5 = null;
        try {
            combinedRangeXYPlot0.setDomainZeroBaselinePaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        try {
            xYSeries1.updateByIndex(255, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getLabelPadding();
        double double3 = rectangleInsets1.calculateTopOutset((double) (short) -1);
        double double4 = rectangleInsets1.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator1 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) standardXYToolTipGenerator1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj2 = xYSeries1.clone();
        try {
            org.jfree.data.xy.XYDataItem xYDataItem4 = xYSeries1.remove((java.lang.Number) 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getRootPlot();
        xYLineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot23.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        double double26 = piePlot23.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer29.getItemOutlineStroke((int) 'a', 0, false);
        piePlot23.setBaseSectionOutlineStroke(stroke33);
        xYBarRenderer1.drawDomainLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, paint22, stroke33);
        xYBarRenderer1.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot1.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray3 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot1.setDomainAxes(valueAxisArray3);
        combinedRangeXYPlot1.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = combinedRangeXYPlot1.getDomainAxisEdge();
        try {
            double double7 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        categoryAxis1.setLabelFont(font6);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextPaint();
        piePlot11.setLabelLinkPaint(paint14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape18 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape19 = defaultDrawingSupplier16.getNextShape();
        piePlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font6, (org.jfree.chart.plot.Plot) piePlot11, false);
        try {
            java.awt.image.BufferedImage bufferedImage25 = jFreeChart22.createBufferedImage(100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (100) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot6.getDataset();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        boolean boolean13 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        combinedRangeXYPlot6.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        timeSeries5.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year16);
        periodAxis20.setMinorTickMarkInsideLength(0.0f);
        periodAxis20.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions29 = categoryAxis26.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState35 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis26.drawTickMarks(graphics2D30, (double) (short) 100, rectangle2D32, rectangleEdge33, axisState35);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list39 = periodAxis20.refreshTicks(graphics2D25, axisState35, rectangle2D37, rectangleEdge38);
        try {
            org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list39, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions29);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(list39);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator13 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot0.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator13);
        boolean boolean15 = piePlot0.getAutoPopulateSectionOutlinePaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer16.setUseFillPaint(false);
        boolean boolean19 = xYAreaRenderer16.getBaseSeriesVisible();
        java.awt.Paint paint23 = xYAreaRenderer16.getItemLabelPaint(0, 255, true);
        piePlot0.setOutlinePaint(paint23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj2 = xYSeries1.clone();
        boolean boolean4 = xYSeries1.equals((java.lang.Object) (short) 10);
        try {
            org.jfree.data.xy.XYDataItem xYDataItem6 = xYSeries1.remove(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        boolean boolean15 = xYAreaRenderer0.getPlotArea();
        boolean boolean16 = xYAreaRenderer0.getUseFillPaint();
        java.lang.Boolean boolean18 = xYAreaRenderer0.getSeriesVisibleInLegend((-1));
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator20 = new org.jfree.chart.urls.StandardXYURLGenerator();
        try {
            xYAreaRenderer0.setSeriesURLGenerator((int) (short) -1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(boolean18);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        boolean boolean11 = xYLineAndShapeRenderer2.getItemShapeFilled((-1), 1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            xYLineAndShapeRenderer2.addAnnotation(xYAnnotation12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        try {
            xYStepRenderer0.setSeriesCreateEntities((int) (short) -1, (java.lang.Boolean) false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        java.awt.Paint paint6 = categoryAxis0.getLabelPaint();
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("February");
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        boolean boolean10 = combinedRangeXYPlot0.equals((java.lang.Object) 10.0f);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot11.getRangeAxisLocation();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        combinedRangeXYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        try {
            double double22 = timeSeriesCollection17.getStartYValue(15, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions28 = categoryAxis25.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState34 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis25.drawTickMarks(graphics2D29, (double) (short) 100, rectangle2D31, rectangleEdge32, axisState34);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list38 = periodAxis19.refreshTicks(graphics2D24, axisState34, rectangle2D36, rectangleEdge37);
        try {
            java.util.Collection collection39 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list38);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions28);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray10);
        org.jfree.data.xy.XYDataset xYDataset12 = combinedRangeXYPlot8.getDataset();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeZone13);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        combinedRangeXYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        timeSeries7.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection14);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis22 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year5, (org.jfree.data.time.RegularTimePeriod) year18);
        periodAxis22.setMinorTickMarkInsideLength(0.0f);
        periodAxis22.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions31 = categoryAxis28.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState37 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis28.drawTickMarks(graphics2D32, (double) (short) 100, rectangle2D34, rectangleEdge35, axisState37);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list41 = periodAxis22.refreshTicks(graphics2D27, axisState37, rectangle2D39, rectangleEdge40);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            barRenderer3D0.drawRangeGridline(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) periodAxis22, rectangle2D42, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions31);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 100.0f, 0.05d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions4);
        categoryAxis0.setMinorTickMarkInsideLength((float) (byte) 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor17, textAnchor18);
        xYStepAreaRenderer1.setSeriesNegativeItemLabelPosition(7, itemLabelPosition19);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = textTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions9);
        org.jfree.chart.entity.AxisEntity axisEntity11 = new org.jfree.chart.entity.AxisEntity(shape1, (org.jfree.chart.axis.Axis) categoryAxis5);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions18 = categoryAxis15.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState24 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis15.drawTickMarks(graphics2D19, (double) (short) 100, rectangle2D21, rectangleEdge22, axisState24);
        try {
            double double26 = categoryAxis5.getCategoryMiddle((int) (short) 100, 0, rectangle2D14, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(categoryLabelPositions18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        java.util.List list4 = combinedRangeXYPlot0.getSubplots();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        combinedRangeXYPlot0.zoomRangeAxes(2.0d, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = combinedRangeXYPlot0.getDomainAxisEdge();
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 0L);
        double double9 = range8.getLength();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(range8);
        boolean boolean11 = rectangleEdge5.equals((java.lang.Object) range8);
        org.jfree.data.Range range13 = org.jfree.data.Range.scale(range8, (double) 1L);
        double double14 = range8.getLength();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        org.jfree.data.xy.XYDataset xYDataset10 = combinedRangeXYPlot6.getDataset();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        boolean boolean13 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        combinedRangeXYPlot6.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection12);
        timeSeries5.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis20 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year3, (org.jfree.data.time.RegularTimePeriod) year16);
        periodAxis20.setMinorTickMarkInsideLength(0.0f);
        periodAxis20.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis26.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions29 = categoryAxis26.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState35 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis26.drawTickMarks(graphics2D30, (double) (short) 100, rectangle2D32, rectangleEdge33, axisState35);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list39 = periodAxis20.refreshTicks(graphics2D25, axisState35, rectangle2D37, rectangleEdge38);
        try {
            org.jfree.data.Range range41 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list39, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(xYDataset10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions29);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(list39);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("DateTickMarkPosition.MIDDLE", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarksVisible(true);
        java.lang.Class class24 = null;
        try {
            periodAxis19.setMajorTickTimePeriodClass(class24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year2.next();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year2.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "January" + "'", str1.equals("January"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        int int5 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (byte) 0, 5);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot14.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot14.setDomainAxes(valueAxisArray16);
        java.util.List list18 = combinedRangeXYPlot14.getSubplots();
        combinedRangeXYPlot10.drawDomainTickBands(graphics2D12, rectangle2D13, list18);
        try {
            combinedRangeXYPlot0.mapDatasetToRangeAxes(0, list18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("February", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setShadowXOffset((double) ' ');
        java.awt.Shape shape3 = piePlot0.getLegendItemShape();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Point2D point2D6 = null;
        org.jfree.chart.plot.PlotState plotState7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            piePlot0.draw(graphics2D4, rectangle2D5, point2D6, plotState7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat2 = standardPieToolTipGenerator1.getPercentFormat();
        java.lang.String str4 = numberFormat2.format((long) (byte) 0);
        numberFormat2.setMaximumFractionDigits((int) (byte) 10);
        numberFormat2.setGroupingUsed(false);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0%" + "'", str4.equals("0%"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 1);
        boolean boolean15 = xYLineAndShapeRenderer2.getBaseLinesVisible();
        java.lang.Boolean boolean17 = xYLineAndShapeRenderer2.getSeriesShapesFilled((int) '#');
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("DateTickMarkPosition.MIDDLE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("Nearest", font1, paint3);
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textLine4.calculateDimensions(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Point2D point2D17 = null;
        org.jfree.chart.plot.PlotState plotState18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            combinedRangeXYPlot6.draw(graphics2D15, rectangle2D16, point2D17, plotState18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        org.jfree.data.general.DatasetGroup datasetGroup2 = piePlot0.getDatasetGroup();
        java.awt.Paint paint3 = piePlot0.getBaseSectionPaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNull(datasetGroup2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeFilled();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setOutlinePaint(paint4);
        java.awt.Paint paint6 = legendItem2.getFillPaint();
        java.awt.Font font7 = legendItem2.getLabelFont();
        legendItem2.setShapeVisible(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        boolean boolean3 = piePlot0.isCircular();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        boolean boolean15 = xYAreaRenderer0.getPlotLines();
        boolean boolean16 = xYAreaRenderer0.isOutline();
        org.jfree.chart.LegendItem legendItem19 = xYAreaRenderer0.getLegendItem((int) (short) 1, 15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(legendItem19);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getGreen();
        boolean boolean3 = color0.equals((java.lang.Object) "NO_CHANGE");
        java.lang.String str4 = color0.toString();
        int int5 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str4.equals("java.awt.Color[r=128,g=128,b=128]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = combinedRangeXYPlot6.getInsets();
        combinedRangeXYPlot6.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.util.TimeZone timeZone16 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        xYItemRendererState15.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection17);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(timeZone16);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        combinedRangeXYPlot10.setRangePannable(true);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        combinedRangeXYPlot10.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Color color17 = java.awt.Color.GRAY;
        combinedRangeXYPlot10.setRangeGridlinePaint((java.awt.Paint) color17);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color21 = java.awt.Color.GRAY;
        int int22 = color21.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("", font20, (java.awt.Paint) color21);
        combinedRangeXYPlot10.setRangeTickBandPaint((java.awt.Paint) color21);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot30 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot30.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot30.setDomainAxes(valueAxisArray32);
        org.jfree.data.xy.XYDataset xYDataset34 = combinedRangeXYPlot30.getDataset();
        java.util.TimeZone timeZone35 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection36 = new org.jfree.data.time.TimeSeriesCollection(timeZone35);
        boolean boolean37 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection36);
        combinedRangeXYPlot30.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection36);
        timeSeries29.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection36);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) year40, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis44 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year27, (org.jfree.data.time.RegularTimePeriod) year40);
        periodAxis44.setMinorTickMarkInsideLength(0.0f);
        periodAxis44.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis50.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions53 = categoryAxis50.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState59 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis50.drawTickMarks(graphics2D54, (double) (short) 100, rectangle2D56, rectangleEdge57, axisState59);
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list63 = periodAxis44.refreshTicks(graphics2D49, axisState59, rectangle2D61, rectangleEdge62);
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        java.awt.Paint paint66 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Color color67 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer70 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition74 = xYLineAndShapeRenderer70.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer70.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator78 = null;
        xYLineAndShapeRenderer70.setSeriesURLGenerator(0, xYURLGenerator78, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator81 = null;
        xYLineAndShapeRenderer70.setLegendItemToolTipGenerator(xYSeriesLabelGenerator81);
        boolean boolean83 = xYLineAndShapeRenderer70.getBaseItemLabelsVisible();
        java.awt.Stroke stroke85 = xYLineAndShapeRenderer70.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot86 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = piePlot86.getLabelPadding();
        double double89 = rectangleInsets87.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder90 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color67, stroke85, rectangleInsets87);
        try {
            xYLineAndShapeRenderer2.drawDomainLine(graphics2D9, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot10, (org.jfree.chart.axis.ValueAxis) periodAxis44, rectangle2D64, (double) (byte) 10, paint66, stroke85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 128 + "'", int22 == 128);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions53);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(list63);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(itemLabelPosition74);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 2.0d + "'", double89 == 2.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat3 = standardPieToolTipGenerator2.getPercentFormat();
        boolean boolean4 = textAnchor0.equals((java.lang.Object) numberFormat3);
        java.lang.String str6 = numberFormat3.format((long) 15);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1,500%" + "'", str6.equals("1,500%"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("Nearest");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textFragment1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYLineAndShapeRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        boolean boolean15 = xYLineAndShapeRenderer2.getBaseItemLabelsVisible();
        boolean boolean16 = xYLineAndShapeRenderer2.getDrawSeriesLineAsPath();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = xYStepAreaRenderer0.getSeriesPositiveItemLabelPosition(255);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = null;
        try {
            timeSeries1.add(timeSeriesDataItem16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 0L);
        double double3 = range2.getLength();
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange(range2);
        double double5 = dateRange4.getLength();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (short) -1, (double) 9223372036854775807L, 0.0d);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        barRenderer3D5.setDrawBarOutline(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer3D5.getBaseToolTipGenerator();
        java.awt.geom.RectangularShape rectangularShape12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        combinedRangeXYPlot13.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = combinedRangeXYPlot13.getDomainAxisEdge();
        boolean boolean19 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge18);
        try {
            gradientBarPainter3.paintBarShadow(graphics2D4, (org.jfree.chart.renderer.category.BarRenderer) barRenderer3D5, 5, 5, false, rectangularShape12, rectangleEdge18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = combinedRangeXYPlot0.getDomainAxisEdge();
        org.jfree.data.Range range6 = null;
        org.jfree.data.Range range8 = org.jfree.data.Range.expandToInclude(range6, (double) 0L);
        double double9 = range8.getLength();
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange(range8);
        boolean boolean11 = rectangleEdge5.equals((java.lang.Object) range8);
        org.jfree.data.Range range13 = org.jfree.data.Range.scale(range8, (double) 1L);
        boolean boolean15 = range8.contains((double) 7);
        double double16 = range8.getLength();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer1);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = null;
        org.jfree.chart.util.Size2D size2D21 = legendTitle18.arrange(graphics2D19, rectangleConstraint20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D24 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = xYLineAndShapeRenderer27.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer27.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator35 = null;
        xYLineAndShapeRenderer27.setSeriesURLGenerator(0, xYURLGenerator35, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator38 = null;
        xYLineAndShapeRenderer27.setLegendItemToolTipGenerator(xYSeriesLabelGenerator38);
        boolean boolean40 = xYLineAndShapeRenderer27.getBaseItemLabelsVisible();
        java.awt.Stroke stroke42 = xYLineAndShapeRenderer27.lookupSeriesStroke((int) (short) 1);
        barRenderer3D24.setBaseStroke(stroke42, false);
        try {
            java.lang.Object obj45 = legendTitle18.draw(graphics2D22, rectangle2D23, (java.lang.Object) false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(size2D21);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        boolean boolean15 = xYAreaRenderer0.getPlotArea();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot17.clearDomainMarkers();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot21.setDomainAxes(valueAxisArray23);
        java.util.List list25 = combinedRangeXYPlot21.getSubplots();
        combinedRangeXYPlot17.drawDomainTickBands(graphics2D19, rectangle2D20, list25);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            xYAreaRenderer0.fillRangeGridBand(graphics2D16, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot17, valueAxis27, rectangle2D28, (double) '#', (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection11, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.axis.NumberAxis numberAxis0 = null;
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint8 = defaultDrawingSupplier7.getNextPaint();
        org.jfree.chart.text.TextLine textLine9 = new org.jfree.chart.text.TextLine("Nearest", font6, paint8);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, 0.05d, (double) 1, (double) 1L, (double) 'a', font6);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        markerAxisBand10.draw(graphics2D11, rectangle2D12, rectangle2D13, 0.0d, (double) 0L);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        boolean boolean2 = timeSeries1.isEmpty();
        timeSeries1.setMaximumItemCount(100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape1, (double) 10L, (float) 10L, (float) (short) 1);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color8 = java.awt.Color.GRAY;
        int int9 = color8.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("", font7, (java.awt.Paint) color8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = labelBlock10.getTextAnchor();
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, rectangleAnchor11, (double) 100.0f, 0.08d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 128 + "'", int9 == 128);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        org.jfree.data.general.DatasetGroup datasetGroup2 = piePlot0.getDatasetGroup();
        piePlot0.setShadowXOffset((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNull(datasetGroup2);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("{0}");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = combinedRangeXYPlot4.getDomainAxisEdge();
        org.jfree.data.Range range10 = null;
        org.jfree.data.Range range12 = org.jfree.data.Range.expandToInclude(range10, (double) 0L);
        double double13 = range12.getLength();
        org.jfree.data.time.DateRange dateRange14 = new org.jfree.data.time.DateRange(range12);
        boolean boolean15 = rectangleEdge9.equals((java.lang.Object) range12);
        try {
            double double16 = numberAxis3D1.java2DToValue((double) 7, rectangle2D3, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        java.util.TimeZone timeZone2 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        org.jfree.data.Range range4 = xYBarRenderer1.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        double double5 = xYBarRenderer1.getMargin();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        xYStepAreaRenderer1.setShapesFilled(false);
        boolean boolean4 = xYStepAreaRenderer1.getAutoPopulateSeriesFillPaint();
        java.awt.Font font6 = null;
        xYStepAreaRenderer1.setSeriesItemLabelFont((int) (short) 1, font6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = xYAreaRenderer0.getGradientTransformer();
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = xYLineAndShapeRenderer2.getBaseURLGenerator();
        java.awt.Paint paint17 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator18 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.DateFormat dateFormat19 = standardXYToolTipGenerator18.getXDateFormat();
        xYLineAndShapeRenderer2.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator18);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(xYURLGenerator15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(dateFormat19);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions28 = categoryAxis25.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState34 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis25.drawTickMarks(graphics2D29, (double) (short) 100, rectangle2D31, rectangleEdge32, axisState34);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list38 = periodAxis19.refreshTicks(graphics2D24, axisState34, rectangle2D36, rectangleEdge37);
        axisState34.cursorUp((double) ' ');
        axisState34.cursorDown((double) (-2208960000000L));
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions28);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month((int) (byte) 10, year2);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        combinedRangeXYPlot0.panRangeAxes((double) 255, plotRenderingInfo5, point2D6);
        combinedRangeXYPlot0.setRangeMinorGridlinesVisible(false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat3 = standardPieToolTipGenerator2.getPercentFormat();
        boolean boolean4 = textAnchor0.equals((java.lang.Object) numberFormat3);
        java.math.RoundingMode roundingMode5 = numberFormat3.getRoundingMode();
        numberFormat3.setMinimumIntegerDigits(5);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode5.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.clearDomainMarkers();
        combinedRangeXYPlot3.setRangePannable(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation12 = combinedRangeXYPlot8.getRangeAxisLocation();
        combinedRangeXYPlot3.setDomainAxisLocation(100, axisLocation12, false);
        try {
            combinedRangeXYPlot0.setRangeAxisLocation((int) (byte) -1, axisLocation12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        double double6 = categoryAxis0.getCategoryMargin();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color9 = java.awt.Color.GRAY;
        int int10 = color9.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("", font8, (java.awt.Paint) color9);
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color9);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot16.setDomainAxes(valueAxisArray18);
        org.jfree.data.xy.XYDataset xYDataset20 = combinedRangeXYPlot16.getDataset();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        boolean boolean23 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        combinedRangeXYPlot16.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection22);
        timeSeries15.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection22);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year26, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeSeries15);
        java.util.List list31 = timeSeries15.getItems();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis33.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions36 = categoryAxis33.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState42 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis33.drawTickMarks(graphics2D37, (double) (short) 100, rectangle2D39, rectangleEdge40, axisState42);
        try {
            double double44 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) true, list31, rectangle2D32, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 128 + "'", int10 == 128);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(categoryLabelPositions36);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        java.awt.Paint paint12 = piePlot0.getLabelShadowPaint();
        boolean boolean13 = piePlot0.getSimpleLabels();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Point2D point2D16 = null;
        org.jfree.chart.plot.PlotState plotState17 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            piePlot0.draw(graphics2D14, rectangle2D15, point2D16, plotState17, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Paint paint2 = blockBorder1.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        boolean boolean15 = xYAreaRenderer0.getPlotArea();
        boolean boolean16 = xYAreaRenderer0.getUseFillPaint();
        java.lang.Boolean boolean18 = xYAreaRenderer0.getSeriesVisibleInLegend((-1));
        xYAreaRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(boolean18);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer3D0.getLegendItems();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D6 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = barRenderer3D6.getURLGenerator((int) '4', 0, true);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = barRenderer3D6.getLegendItems();
        legendItemCollection5.addAll(legendItemCollection11);
        java.awt.Color color14 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color14);
        boolean boolean16 = legendItem15.isShapeFilled();
        legendItemCollection5.add(legendItem15);
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        long long2 = timeSeries1.getMaximumItemAge();
        java.lang.Class class3 = timeSeries1.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9223372036854775807L + "'", long2 == 9223372036854775807L);
        org.junit.Assert.assertNull(class3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot9.getRangeAxisLocation();
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation13, false);
        boolean boolean16 = combinedRangeXYPlot0.isDomainZoomable();
        java.awt.Stroke stroke17 = combinedRangeXYPlot0.getDomainMinorGridlineStroke();
        java.awt.Stroke stroke18 = combinedRangeXYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape2 = defaultDrawingSupplier1.getNextShape();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis0.setDownArrow(shape6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray10);
        org.jfree.data.xy.XYDataset xYDataset12 = combinedRangeXYPlot8.getDataset();
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeZone13);
        boolean boolean15 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        combinedRangeXYPlot8.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection14);
        org.jfree.chart.entity.XYItemEntity xYItemEntity21 = new org.jfree.chart.entity.XYItemEntity(shape6, (org.jfree.data.xy.XYDataset) timeSeriesCollection14, 0, (int) (short) 1, "DateTickMarkPosition.MIDDLE", "");
        java.lang.String str22 = xYItemEntity21.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNull(xYDataset12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        combinedRangeXYPlot2.setGap((double) 255);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation15 = combinedRangeXYPlot11.getRangeAxisLocation();
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        double double17 = axisSpace16.getRight();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean19 = axisSpace16.equals((java.lang.Object) itemLabelAnchor18);
        axisSpace16.setRight(0.2d);
        combinedRangeXYPlot11.setFixedDomainAxisSpace(axisSpace16, false);
        axisSpace16.setTop(0.0d);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace26 = numberAxis0.reserveSpace(graphics2D1, (org.jfree.chart.plot.Plot) combinedRangeXYPlot2, rectangle2D9, rectangleEdge10, axisSpace16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        java.util.List list17 = timeSeries1.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Color color0 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYLineAndShapeRenderer3.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer3.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYLineAndShapeRenderer3.setSeriesURLGenerator(0, xYURLGenerator11, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        xYLineAndShapeRenderer3.setLegendItemToolTipGenerator(xYSeriesLabelGenerator14);
        boolean boolean16 = xYLineAndShapeRenderer3.getBaseItemLabelsVisible();
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer3.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = piePlot19.getLabelPadding();
        double double22 = rectangleInsets20.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke18, rectangleInsets20);
        double double25 = rectangleInsets20.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        double double2 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-5d + "'", double2 == 1.0E-5d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 9223372036854775807L, (double) 1.0f, 0.2d, (double) 0);
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot();
        double double6 = piePlot5.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint8 = defaultDrawingSupplier7.getNextPaint();
        piePlot5.setLabelLinkPaint(paint8);
        double double10 = piePlot5.getStartAngle();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot12.setDomainAxes(valueAxisArray14);
        combinedRangeXYPlot12.clearRangeAxes();
        java.awt.Stroke stroke17 = combinedRangeXYPlot12.getDomainZeroBaselineStroke();
        java.awt.Paint paint18 = combinedRangeXYPlot12.getRangeZeroBaselinePaint();
        piePlot5.setSectionPaint((java.lang.Comparable) (-1.0f), paint18);
        boolean boolean20 = blockBorder4.equals((java.lang.Object) (-1.0f));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 90.0d + "'", double6 == 90.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        int int2 = xYSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        try {
            org.jfree.chart.plot.XYPlot xYPlot29 = jFreeChart27.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.PiePlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot2.getLabelPadding();
        piePlot1.setSimpleLabelOffset(rectangleInsets3);
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        piePlot1.clearSectionOutlineStrokes(true);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        double double7 = combinedRangeXYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot10.getDataset();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        combinedRangeXYPlot10.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        combinedRangeXYPlot0.setDataset(0, (org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        try {
            java.lang.Number number22 = timeSeriesCollection16.getEndX(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) 7, (double) 10L, (double) 100L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE2" + "'", str1.equals("ItemLabelAnchor.INSIDE2"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        boolean boolean10 = combinedRangeXYPlot0.equals((java.lang.Object) 10.0f);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot0);
        java.lang.Object obj12 = plotChangeEvent11.getSource();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        plotChangeEvent11.setChart(jFreeChart13);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        java.awt.Stroke stroke5 = combinedRangeXYPlot0.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot6 = combinedRangeXYPlot0.getRootPlot();
        combinedRangeXYPlot0.mapDatasetToDomainAxis(5, 2);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(plot6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator1 = null;
        xYAreaRenderer0.setLegendItemURLGenerator(xYSeriesLabelGenerator1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        timeSeries1.setRangeDescription("0%");
        try {
            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries1.createCopy(100, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        java.awt.Font font7 = xYLineAndShapeRenderer2.getBaseLegendTextFont();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean11 = numberAxis10.getAutoRangeStickyZero();
        double double12 = numberAxis10.getFixedAutoRange();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation19 = combinedRangeXYPlot15.getRangeAxisLocation();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeZone20);
        combinedRangeXYPlot15.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection21);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = combinedRangeXYPlot15.getDomainMarkers(layer23);
        java.awt.Paint paint25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        combinedRangeXYPlot15.setDomainCrosshairPaint(paint25);
        java.awt.Color color27 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = xYLineAndShapeRenderer30.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer30.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator38 = null;
        xYLineAndShapeRenderer30.setSeriesURLGenerator(0, xYURLGenerator38, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator41 = null;
        xYLineAndShapeRenderer30.setLegendItemToolTipGenerator(xYSeriesLabelGenerator41);
        boolean boolean43 = xYLineAndShapeRenderer30.getBaseItemLabelsVisible();
        java.awt.Stroke stroke45 = xYLineAndShapeRenderer30.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot46 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = piePlot46.getLabelPadding();
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder50 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color27, stroke45, rectangleInsets47);
        try {
            xYLineAndShapeRenderer2.drawRangeLine(graphics2D8, xYPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis10, rectangle2D13, (double) (byte) 0, paint25, stroke45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.0d + "'", double49 == 2.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = columnArrangement0.arrange(blockContainer2, graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("Nearest", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        textTitle1.setURLText("");
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle1.arrange(graphics2D4, rectangleConstraint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'c' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        java.lang.Boolean boolean14 = xYLineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator15 = xYLineAndShapeRenderer2.getBaseURLGenerator();
        java.awt.Paint paint17 = xYLineAndShapeRenderer2.lookupSeriesFillPaint((int) (short) 10);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        piePlot19.setShadowXOffset(0.0d);
        java.awt.Paint paint22 = piePlot19.getBaseSectionOutlinePaint();
        xYLineAndShapeRenderer2.setSeriesPaint(2, paint22, false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNull(xYURLGenerator15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock0.draw(graphics2D1, (float) (byte) 0, (float) ' ', textBlockAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        combinedRangeXYPlot11.setRangePannable(true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        combinedRangeXYPlot11.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        combinedRangeXYPlot11.setRangeGridlinePaint((java.awt.Paint) color18);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color22 = java.awt.Color.GRAY;
        int int23 = color22.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color22);
        combinedRangeXYPlot11.setRangeTickBandPaint((java.awt.Paint) color22);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYLineAndShapeRenderer29.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer29.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        xYLineAndShapeRenderer29.setSeriesURLGenerator(0, xYURLGenerator37, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator40 = null;
        xYLineAndShapeRenderer29.setLegendItemToolTipGenerator(xYSeriesLabelGenerator40);
        boolean boolean42 = xYLineAndShapeRenderer29.getBaseItemLabelsVisible();
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer29.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = piePlot45.getLabelPadding();
        double double48 = rectangleInsets46.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color26, stroke44, rectangleInsets46);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot54.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot54.setDomainAxes(valueAxisArray56);
        combinedRangeXYPlot54.clearRangeAxes();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeZone59);
        boolean boolean61 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState65 = xYStepAreaRenderer51.initialise(graphics2D52, rectangle2D53, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot54, (org.jfree.data.xy.XYDataset) timeSeriesCollection60, plotRenderingInfo64);
        java.awt.Paint paint67 = xYStepAreaRenderer51.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape10, (java.awt.Paint) color22, stroke44, paint67);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint67);
        java.awt.Color color71 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color71);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer73 = legendItem72.getFillPaintTransformer();
        intervalMarker69.setGradientPaintTransformer(gradientPaintTransformer73);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = intervalMarker69.getLabelOffset();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor76 = null;
        try {
            intervalMarker69.setLabelAnchor(rectangleAnchor76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 128 + "'", int23 == 128);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNotNull(xYItemRendererState65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(gradientPaintTransformer73);
        org.junit.Assert.assertNotNull(rectangleInsets75);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        combinedRangeXYPlot11.setRangePannable(true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        combinedRangeXYPlot11.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        combinedRangeXYPlot11.setRangeGridlinePaint((java.awt.Paint) color18);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color22 = java.awt.Color.GRAY;
        int int23 = color22.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color22);
        combinedRangeXYPlot11.setRangeTickBandPaint((java.awt.Paint) color22);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYLineAndShapeRenderer29.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer29.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        xYLineAndShapeRenderer29.setSeriesURLGenerator(0, xYURLGenerator37, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator40 = null;
        xYLineAndShapeRenderer29.setLegendItemToolTipGenerator(xYSeriesLabelGenerator40);
        boolean boolean42 = xYLineAndShapeRenderer29.getBaseItemLabelsVisible();
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer29.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = piePlot45.getLabelPadding();
        double double48 = rectangleInsets46.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color26, stroke44, rectangleInsets46);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot54.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot54.setDomainAxes(valueAxisArray56);
        combinedRangeXYPlot54.clearRangeAxes();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeZone59);
        boolean boolean61 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState65 = xYStepAreaRenderer51.initialise(graphics2D52, rectangle2D53, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot54, (org.jfree.data.xy.XYDataset) timeSeriesCollection60, plotRenderingInfo64);
        java.awt.Paint paint67 = xYStepAreaRenderer51.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape10, (java.awt.Paint) color22, stroke44, paint67);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint67);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType70 = intervalMarker69.getLabelOffsetType();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 128 + "'", int23 == 128);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNotNull(xYItemRendererState65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(lengthAdjustmentType70);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        java.util.TimeZone timeZone20 = periodAxis19.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone20;
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone20);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYLineAndShapeRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        java.lang.Boolean boolean16 = xYLineAndShapeRenderer2.getSeriesCreateEntities((int) (byte) 10);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator17 = new org.jfree.chart.urls.StandardXYURLGenerator();
        xYLineAndShapeRenderer2.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator17, false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNull(boolean16);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 15, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        java.lang.String str2 = axisSpace0.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer3D0.setBaseItemLabelGenerator(categoryItemLabelGenerator5);
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.clearDomainMarkers();
        combinedRangeXYPlot3.setRangePannable(true);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) combinedRangeXYPlot3);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        combinedRangeXYPlot3.markerChanged(markerChangeEvent8);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setMinorTickCount(0);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis4.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis4.drawTickMarks(graphics2D8, (double) (short) 100, rectangle2D10, rectangleEdge11, axisState13);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot16.setDomainAxes(valueAxisArray18);
        combinedRangeXYPlot16.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = combinedRangeXYPlot16.getDomainAxisEdge();
        try {
            java.util.List list22 = logAxis0.refreshTicks(graphics2D3, axisState13, rectangle2D15, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        try {
            org.jfree.data.time.TimeSeries timeSeries17 = timeSeriesCollection10.getSeries((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        piePlot1.setIgnoreNullValues(true);
        boolean boolean7 = rotation0.equals((java.lang.Object) true);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) rotation0, seriesChangeInfo8);
        java.lang.String str10 = rotation0.toString();
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Rotation.CLOCKWISE" + "'", str10.equals("Rotation.CLOCKWISE"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        java.lang.Object obj1 = standardPieSectionLabelGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        xYLineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean15 = xYLineAndShapeRenderer2.getBaseLinesVisible();
        java.awt.Shape shape17 = xYLineAndShapeRenderer2.getLegendShape(0);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(shape17);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        xYSeries1.clear();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Color color0 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYLineAndShapeRenderer3.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer3.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYLineAndShapeRenderer3.setSeriesURLGenerator(0, xYURLGenerator11, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        xYLineAndShapeRenderer3.setLegendItemToolTipGenerator(xYSeriesLabelGenerator14);
        boolean boolean16 = xYLineAndShapeRenderer3.getBaseItemLabelsVisible();
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer3.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = piePlot19.getLabelPadding();
        double double22 = rectangleInsets20.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke18, rectangleInsets20);
        java.lang.String str24 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str24.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            barRenderer3D0.drawOutline(graphics2D1, categoryPlot2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.lang.Object obj2 = standardPieToolTipGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.GRAY;
        int int5 = color4.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font3, (java.awt.Paint) color4);
        java.lang.Object obj7 = null;
        columnArrangement0.add((org.jfree.chart.block.Block) labelBlock6, obj7);
        columnArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        piePlot0.setLabelLinkPaint(paint3);
        double double5 = piePlot0.getStartAngle();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor6 = piePlot0.getLabelDistributor();
        java.awt.Stroke stroke7 = piePlot0.getLabelOutlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 90.0d + "'", double5 == 90.0d);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        jFreeChart27.setNotify(true);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection34 = null;
        chartRenderingInfo33.setEntityCollection(entityCollection34);
        try {
            jFreeChart27.draw(graphics2D31, rectangle2D32, chartRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        boolean boolean9 = xYLineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot15.setDomainAxes(valueAxisArray17);
        combinedRangeXYPlot15.clearRangeAxes();
        java.util.TimeZone timeZone20 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection(timeZone20);
        boolean boolean22 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection21);
        org.jfree.data.Range range24 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection21, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYStepAreaRenderer12.initialise(graphics2D13, rectangle2D14, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.data.xy.XYDataset) timeSeriesCollection21, plotRenderingInfo25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        combinedRangeXYPlot15.panRangeAxes((-1.0d), plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setUpperBound(0.0d);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) 7);
        org.jfree.chart.entity.ChartEntity chartEntity39 = new org.jfree.chart.entity.ChartEntity(shape36, "", "");
        numberAxis31.setDownArrow(shape36);
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        xYLineAndShapeRenderer2.drawDomainGridLine(graphics2D10, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) numberAxis31, rectangle2D41, 0.4d);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNotNull(shape36);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        jFreeChart27.setNotify(true);
        try {
            org.jfree.chart.title.Title title32 = jFreeChart27.getSubtitle((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "DateTickMarkPosition.MIDDLE", "DateTickMarkPosition.MIDDLE", image3, "Nearest", "0%", "0%");
        java.lang.String str8 = projectInfo7.getLicenceText();
        projectInfo7.setVersion("1,500%");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0%" + "'", str8.equals("0%"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot3.setDomainAxes(valueAxisArray5);
        org.jfree.data.xy.XYDataset xYDataset7 = combinedRangeXYPlot3.getDataset();
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        boolean boolean10 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        combinedRangeXYPlot3.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection9);
        timeSeries2.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection9);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        timeSeries2.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeSeries2);
        java.util.List list18 = timeSeries2.getItems();
        try {
            org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(categoryDataset0, list18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray5);
        org.junit.Assert.assertNull(xYDataset7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
        xYStepAreaRenderer0.setShapesVisible(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            xYStepAreaRenderer0.addAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.GRAY;
        int int5 = color4.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font3, (java.awt.Paint) color4);
        java.lang.Object obj7 = null;
        columnArrangement0.add((org.jfree.chart.block.Block) labelBlock6, obj7);
        org.jfree.chart.block.ColumnArrangement columnArrangement9 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement9);
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        blockContainer10.add((org.jfree.chart.block.Block) textTitle12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = null;
        try {
            org.jfree.chart.util.Size2D size2D16 = columnArrangement0.arrange(blockContainer10, graphics2D14, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = barRenderer3D0.initialise(graphics2D5, rectangle2D6, categoryPlot7, 1900, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositionOffset(0);
        double double6 = categoryAxis0.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        combinedRangeXYPlot13.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = combinedRangeXYPlot13.getDomainAxisEdge();
        boolean boolean19 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge18);
        boolean boolean20 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge18);
        try {
            double double21 = categoryAxis0.getCategorySeriesMiddle((int) ' ', 128, 4, (int) 'a', 0.0d, rectangle2D12, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape3 = defaultDrawingSupplier2.getNextShape();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape3, (double) 10L, (float) 10L, (float) (short) 1);
        numberAxis1.setDownArrow(shape7);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape7, 0.4d, 10.0f, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = null;
        java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D2, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D2);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4145152) + "'", int1 == (-4145152));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape7, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        combinedRangeXYPlot11.setRangePannable(true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        combinedRangeXYPlot11.drawBackgroundImage(graphics2D15, rectangle2D16);
        java.awt.Color color18 = java.awt.Color.GRAY;
        combinedRangeXYPlot11.setRangeGridlinePaint((java.awt.Paint) color18);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color22 = java.awt.Color.GRAY;
        int int23 = color22.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("", font21, (java.awt.Paint) color22);
        combinedRangeXYPlot11.setRangeTickBandPaint((java.awt.Paint) color22);
        java.awt.Color color26 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = xYLineAndShapeRenderer29.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer29.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator37 = null;
        xYLineAndShapeRenderer29.setSeriesURLGenerator(0, xYURLGenerator37, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator40 = null;
        xYLineAndShapeRenderer29.setLegendItemToolTipGenerator(xYSeriesLabelGenerator40);
        boolean boolean42 = xYLineAndShapeRenderer29.getBaseItemLabelsVisible();
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer29.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot45 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = piePlot45.getLabelPadding();
        double double48 = rectangleInsets46.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color26, stroke44, rectangleInsets46);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot54.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot54.setDomainAxes(valueAxisArray56);
        combinedRangeXYPlot54.clearRangeAxes();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeZone59);
        boolean boolean61 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        org.jfree.data.Range range63 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection60, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState65 = xYStepAreaRenderer51.initialise(graphics2D52, rectangle2D53, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot54, (org.jfree.data.xy.XYDataset) timeSeriesCollection60, plotRenderingInfo64);
        java.awt.Paint paint67 = xYStepAreaRenderer51.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape10, (java.awt.Paint) color22, stroke44, paint67);
        org.jfree.chart.plot.IntervalMarker intervalMarker69 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint67);
        java.awt.Color color71 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color71);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer73 = legendItem72.getFillPaintTransformer();
        intervalMarker69.setGradientPaintTransformer(gradientPaintTransformer73);
        org.jfree.chart.util.RectangleInsets rectangleInsets75 = intervalMarker69.getLabelOffset();
        double double77 = rectangleInsets75.calculateLeftInset(4.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 128 + "'", int23 == 128);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.0d + "'", double48 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNotNull(xYItemRendererState65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(gradientPaintTransformer73);
        org.junit.Assert.assertNotNull(rectangleInsets75);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 3.0d + "'", double77 == 3.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.zoomRange((-1.0d), (double) 9223372036854775807L);
        int int5 = numberAxis0.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        org.jfree.chart.entity.EntityCollection entityCollection16 = xYItemRendererState15.getEntityCollection();
        int int17 = xYItemRendererState15.getFirstItemIndex();
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNull(entityCollection16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setFixedDimension((double) (-1L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("hi!", 2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        java.util.TimeZone timeZone20 = periodAxis19.getTimeZone();
        java.util.TimeZone timeZone21 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone21;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone21;
        periodAxis19.setTimeZone(timeZone21);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(timeZone21);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot33.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot33.setDomainAxes(valueAxisArray35);
        combinedRangeXYPlot33.clearRangeAxes();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeZone38);
        boolean boolean40 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection39, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState44 = xYStepAreaRenderer30.initialise(graphics2D31, rectangle2D32, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot33, (org.jfree.data.xy.XYDataset) timeSeriesCollection39, plotRenderingInfo43);
        java.awt.Paint paint46 = xYStepAreaRenderer30.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer30);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = null;
        org.jfree.chart.util.Size2D size2D50 = legendTitle47.arrange(graphics2D48, rectangleConstraint49);
        jFreeChart27.addLegend(legendTitle47);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(valueAxisArray35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(xYItemRendererState44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(size2D50);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        categoryAxis1.setLabelFont(font6);
        int int11 = objectList0.indexOf((java.lang.Object) categoryAxis1);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        int int5 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D4);
        combinedRangeXYPlot0.mapDatasetToRangeAxis((int) (byte) 0, 5);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = combinedRangeXYPlot0.getDomainAxisEdge((int) (byte) 100);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.lang.Object obj2 = null;
        boolean boolean3 = columnArrangement0.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        double double7 = combinedRangeXYPlot0.getRangeCrosshairValue();
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer8 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Shape shape9 = xYStepRenderer8.getLegendLine();
        java.lang.Boolean boolean11 = xYStepRenderer8.getSeriesLinesVisible((int) (short) -1);
        combinedRangeXYPlot0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYStepRenderer8);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        numberAxis13.setUpperBound(0.0d);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 'a', (float) 7);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape18, "", "");
        numberAxis13.setDownArrow(shape18);
        org.jfree.data.Range range23 = combinedRangeXYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(range23);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot4.setDomainAxes(valueAxisArray6);
        combinedRangeXYPlot4.clearRangeAxes();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        boolean boolean11 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState15 = xYStepAreaRenderer1.initialise(graphics2D2, rectangle2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot4, (org.jfree.data.xy.XYDataset) timeSeriesCollection10, plotRenderingInfo14);
        java.awt.Paint paint17 = xYStepAreaRenderer1.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem20 = xYStepAreaRenderer1.getLegendItem((int) (byte) 1, 1);
        org.junit.Assert.assertNotNull(valueAxisArray6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(xYItemRendererState15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(legendItem20);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeFilled();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setOutlinePaint(paint4);
        java.awt.Paint paint6 = legendItem2.getFillPaint();
        boolean boolean7 = legendItem2.isShapeFilled();
        java.awt.Stroke stroke8 = legendItem2.getLineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer30 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot33 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot33.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot33.setDomainAxes(valueAxisArray35);
        combinedRangeXYPlot33.clearRangeAxes();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeZone38);
        boolean boolean40 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection39, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState44 = xYStepAreaRenderer30.initialise(graphics2D31, rectangle2D32, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot33, (org.jfree.data.xy.XYDataset) timeSeriesCollection39, plotRenderingInfo43);
        java.awt.Paint paint46 = xYStepAreaRenderer30.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer30);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = null;
        org.jfree.chart.util.Size2D size2D50 = legendTitle47.arrange(graphics2D48, rectangleConstraint49);
        jFreeChart27.addSubtitle((org.jfree.chart.title.Title) legendTitle47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendTitle47.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        try {
            legendTitle47.draw(graphics2D53, rectangle2D54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(valueAxisArray35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(xYItemRendererState44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart27.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo33);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer36 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot39 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot39.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot39.setDomainAxes(valueAxisArray41);
        combinedRangeXYPlot39.clearRangeAxes();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection45 = new org.jfree.data.time.TimeSeriesCollection(timeZone44);
        boolean boolean46 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection45);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection45, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState50 = xYStepAreaRenderer36.initialise(graphics2D37, rectangle2D38, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot39, (org.jfree.data.xy.XYDataset) timeSeriesCollection45, plotRenderingInfo49);
        java.awt.Paint paint52 = xYStepAreaRenderer36.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer36);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = null;
        org.jfree.chart.util.Size2D size2D56 = legendTitle53.arrange(graphics2D54, rectangleConstraint55);
        org.jfree.chart.LegendItemSource[] legendItemSourceArray57 = legendTitle53.getSources();
        jFreeChart27.removeSubtitle((org.jfree.chart.title.Title) legendTitle53);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(bufferedImage34);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(xYItemRendererState50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertNotNull(legendItemSourceArray57);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot2.getLabelPadding();
        piePlot1.setSimpleLabelOffset(rectangleInsets3);
        java.awt.Paint paint5 = piePlot1.getLabelLinkPaint();
        piePlot1.clearSectionOutlineStrokes(false);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = labelBlock4.getTextAnchor();
        org.jfree.chart.block.BlockFrame blockFrame6 = labelBlock4.getFrame();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = labelBlock4.getTextAnchor();
        java.lang.String str8 = labelBlock4.getID();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(blockFrame6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        try {
            textFragment1.draw(graphics2D2, 0.0f, 2.0f, textAnchor5, (float) 7, (float) 4, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setUseOutlinePaint(false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        labelBlock4.setToolTipText("ItemLabelAnchor.INSIDE2");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        java.awt.geom.Point2D point2D4 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D2, rectangleAnchor3);
        crosshairState1.setAnchor(point2D4);
        java.io.ObjectOutputStream objectOutputStream6 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePoint2D(point2D4, objectOutputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj3 = xYSeries2.clone();
        boolean boolean5 = xYSeries2.equals((java.lang.Object) (short) 10);
        int int6 = xYSeriesCollection0.indexOf(xYSeries2);
        try {
            java.lang.Number number9 = xYSeriesCollection0.getEndY(4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        xYSeries1.setMaximumItemCount((int) (short) 0);
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.addOrUpdate(0.2d, (double) 0);
        java.lang.String str8 = xYSeries1.getDescription();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = piePlot2.getLabelPadding();
        piePlot1.setSimpleLabelOffset(rectangleInsets3);
        boolean boolean5 = piePlot1.getAutoPopulateSectionOutlinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.lang.Object obj1 = barRenderer3D0.clone();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        barRenderer3D0.setSeriesURLGenerator((int) '#', categoryURLGenerator3);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.GRAY;
        int int5 = color4.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font3, (java.awt.Paint) color4);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color4);
        java.lang.String str8 = multiplePiePlot1.getPlotType();
        multiplePiePlot1.setAggregatedItemsKey((java.lang.Comparable) 7);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Multiple Pie Plot" + "'", str8.equals("Multiple Pie Plot"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot15.setDomainAxes(valueAxisArray17);
        org.jfree.data.xy.XYDataset xYDataset19 = combinedRangeXYPlot15.getDataset();
        combinedRangeXYPlot6.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder21 = combinedRangeXYPlot6.getDatasetRenderingOrder();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot22.clearDomainMarkers();
        combinedRangeXYPlot22.setRangePannable(true);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        combinedRangeXYPlot22.drawBackgroundImage(graphics2D26, rectangle2D27);
        java.awt.Color color29 = java.awt.Color.GRAY;
        combinedRangeXYPlot22.setRangeGridlinePaint((java.awt.Paint) color29);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot31.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation35 = combinedRangeXYPlot31.getRangeAxisLocation();
        combinedRangeXYPlot22.setRangeAxisLocation(axisLocation35, false);
        boolean boolean38 = combinedRangeXYPlot22.isDomainZoomable();
        java.awt.Stroke stroke39 = combinedRangeXYPlot22.getDomainZeroBaselineStroke();
        combinedRangeXYPlot6.setRangeMinorGridlineStroke(stroke39);
        java.io.ObjectOutputStream objectOutputStream41 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke39, objectOutputStream41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNotNull(datasetRenderingOrder21);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = legendItem2.getFillPaintTransformer();
        java.lang.String str4 = legendItem2.getURLText();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        java.awt.geom.Point2D point2D4 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D2, rectangleAnchor3);
        crosshairState1.setAnchor(point2D4);
        int int6 = crosshairState1.getDatasetIndex();
        org.junit.Assert.assertNotNull(point2D4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer7.setUseFillPaint(false);
        boolean boolean10 = xYAreaRenderer7.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        boolean boolean19 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState21 = xYAreaRenderer7.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, (org.jfree.data.xy.XYDataset) timeSeriesCollection18, plotRenderingInfo20);
        org.jfree.chart.plot.PiePlot piePlot22 = new org.jfree.chart.plot.PiePlot();
        double double23 = piePlot22.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint25 = defaultDrawingSupplier24.getNextPaint();
        piePlot22.setLabelLinkPaint(paint25);
        timeSeriesCollection18.removeChangeListener((org.jfree.data.general.DatasetChangeListener) piePlot22);
        int int28 = combinedRangeXYPlot0.indexOf((org.jfree.data.xy.XYDataset) timeSeriesCollection18);
        try {
            double double31 = timeSeriesCollection18.getXValue(0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 90.0d + "'", double23 == 90.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation4 = combinedRangeXYPlot0.getRangeAxisLocation();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        combinedRangeXYPlot0.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection6);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot10.setDomainAxes(valueAxisArray12);
        org.jfree.data.xy.XYDataset xYDataset14 = combinedRangeXYPlot10.getDataset();
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        combinedRangeXYPlot10.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection16);
        timeSeries9.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection16);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) year20, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeSeries9);
        java.util.List list25 = timeSeries9.getItems();
        org.jfree.data.Range range26 = null;
        org.jfree.data.Range range28 = org.jfree.data.Range.expandToInclude(range26, (double) 0L);
        try {
            org.jfree.data.Range range30 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection6, list25, range28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(valueAxisArray12);
        org.junit.Assert.assertNull(xYDataset14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean2 = xYBarRenderer1.getShadowsVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        combinedRangeXYPlot11.clearRangeAxes();
        java.awt.Stroke stroke16 = combinedRangeXYPlot11.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot17 = combinedRangeXYPlot11.getRootPlot();
        xYLineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D19 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.Paint paint22 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot23 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot23.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator24);
        double double26 = piePlot23.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer29.getItemOutlineStroke((int) 'a', 0, false);
        piePlot23.setBaseSectionOutlineStroke(stroke33);
        xYBarRenderer1.drawDomainLine(graphics2D3, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot11, (org.jfree.chart.axis.ValueAxis) numberAxis3D19, rectangle2D20, (double) (byte) -1, paint22, stroke33);
        double double36 = xYBarRenderer1.getBarAlignmentFactor();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions41 = categoryAxis38.getCategoryLabelPositions();
        java.awt.Font font43 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color44 = java.awt.Color.GRAY;
        int int45 = color44.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock46 = new org.jfree.chart.block.LabelBlock("", font43, (java.awt.Paint) color44);
        categoryAxis38.setLabelFont(font43);
        xYBarRenderer1.setLegendTextFont((int) '#', font43);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot50 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot50.clearDomainMarkers();
        combinedRangeXYPlot50.setRangePannable(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot55 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot55.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation59 = combinedRangeXYPlot55.getRangeAxisLocation();
        combinedRangeXYPlot50.setDomainAxisLocation(100, axisLocation59, false);
        combinedRangeXYPlot50.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D67 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer70 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition71 = xYLineAndShapeRenderer70.getBaseNegativeItemLabelPosition();
        barRenderer3D67.setNegativeItemLabelPositionFallback(itemLabelPosition71);
        boolean boolean73 = barRenderer3D67.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator75 = null;
        barRenderer3D67.setSeriesToolTipGenerator(0, categoryToolTipGenerator75);
        java.awt.Paint paint80 = barRenderer3D67.getItemOutlinePaint(5, 1, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer83 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke87 = xYLineAndShapeRenderer83.getItemOutlineStroke((int) 'a', 0, false);
        try {
            xYBarRenderer1.drawRangeLine(graphics2D49, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot50, valueAxis64, rectangle2D65, 2.0d, paint80, stroke87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36 == (-1.0d));
        org.junit.Assert.assertNotNull(categoryLabelPositions41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 128 + "'", int45 == 128);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(itemLabelPosition71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(stroke87);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setLabelToolTip("hi!");
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        periodAxis19.setTimeZone(timeZone22);
        float float24 = periodAxis19.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 0.0f + "'", float24 == 0.0f);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        boolean boolean7 = combinedRangeXYPlot0.isRangePannable();
        org.jfree.chart.plot.Marker marker8 = null;
        boolean boolean9 = combinedRangeXYPlot0.removeDomainMarker(marker8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            combinedRangeXYPlot0.handleClick(0, (int) (byte) 0, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj3 = xYSeries2.clone();
        boolean boolean5 = xYSeries2.equals((java.lang.Object) (short) 10);
        int int6 = xYSeriesCollection0.indexOf(xYSeries2);
        try {
            xYSeriesCollection0.removeSeries((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Color color0 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = xYLineAndShapeRenderer3.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer3.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator11 = null;
        xYLineAndShapeRenderer3.setSeriesURLGenerator(0, xYURLGenerator11, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        xYLineAndShapeRenderer3.setLegendItemToolTipGenerator(xYSeriesLabelGenerator14);
        boolean boolean16 = xYLineAndShapeRenderer3.getBaseItemLabelsVisible();
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer3.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = piePlot19.getLabelPadding();
        double double22 = rectangleInsets20.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke18, rectangleInsets20);
        java.awt.Stroke stroke24 = lineBorder23.getStroke();
        java.awt.Stroke stroke25 = lineBorder23.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot9.getRangeAxisLocation();
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape23 = defaultDrawingSupplier22.getNextShape();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot27.clearDomainMarkers();
        combinedRangeXYPlot27.setRangePannable(true);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        combinedRangeXYPlot27.drawBackgroundImage(graphics2D31, rectangle2D32);
        java.awt.Color color34 = java.awt.Color.GRAY;
        combinedRangeXYPlot27.setRangeGridlinePaint((java.awt.Paint) color34);
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color38 = java.awt.Color.GRAY;
        int int39 = color38.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("", font37, (java.awt.Paint) color38);
        combinedRangeXYPlot27.setRangeTickBandPaint((java.awt.Paint) color38);
        java.awt.Color color42 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer45 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = xYLineAndShapeRenderer45.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer45.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator53 = null;
        xYLineAndShapeRenderer45.setSeriesURLGenerator(0, xYURLGenerator53, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator56 = null;
        xYLineAndShapeRenderer45.setLegendItemToolTipGenerator(xYSeriesLabelGenerator56);
        boolean boolean58 = xYLineAndShapeRenderer45.getBaseItemLabelsVisible();
        java.awt.Stroke stroke60 = xYLineAndShapeRenderer45.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = piePlot61.getLabelPadding();
        double double64 = rectangleInsets62.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder65 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color42, stroke60, rectangleInsets62);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer67 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot70 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot70.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot70.setDomainAxes(valueAxisArray72);
        combinedRangeXYPlot70.clearRangeAxes();
        java.util.TimeZone timeZone75 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection76 = new org.jfree.data.time.TimeSeriesCollection(timeZone75);
        boolean boolean77 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection76);
        org.jfree.data.Range range79 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection76, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState81 = xYStepAreaRenderer67.initialise(graphics2D68, rectangle2D69, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot70, (org.jfree.data.xy.XYDataset) timeSeriesCollection76, plotRenderingInfo80);
        java.awt.Paint paint83 = xYStepAreaRenderer67.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem84 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape26, (java.awt.Paint) color38, stroke60, paint83);
        org.jfree.chart.plot.IntervalMarker intervalMarker85 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint83);
        org.jfree.chart.util.Layer layer86 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean87 = combinedRangeXYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker85, layer86);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType88 = intervalMarker85.getLabelOffsetType();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 128 + "'", int39 == 128);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(itemLabelPosition49);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.0d + "'", double64 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNull(range79);
        org.junit.Assert.assertNotNull(xYItemRendererState81);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(layer86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType88);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot7.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot7.setDomainAxes(valueAxisArray9);
        org.jfree.data.xy.XYDataset xYDataset11 = combinedRangeXYPlot7.getDataset();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeZone12);
        boolean boolean14 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        combinedRangeXYPlot7.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection13);
        timeSeries6.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) year17, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis21 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year4, (org.jfree.data.time.RegularTimePeriod) year17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year4.next();
        java.util.TimeZone timeZone23 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone23;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone23;
        java.util.Locale locale26 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis27 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=128,g=128,b=128]", regularTimePeriod1, (org.jfree.data.time.RegularTimePeriod) year4, timeZone23, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeZone23);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year2.next();
        java.util.Calendar calendar21 = null;
        try {
            year2.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("Nearest", font1, paint3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.TickType tickType8 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick(tickType8, (double) 100L, "1,500%", textAnchor12, textAnchor14, (-1.0d));
        try {
            textLine4.draw(graphics2D5, (float) 1900, 10.0f, textAnchor14, 2.0f, (float) 0, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean3 = axisSpace0.equals((java.lang.Object) itemLabelAnchor2);
        axisSpace0.setRight(0.2d);
        double double6 = axisSpace0.getBottom();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot8.setDomainAxes(valueAxisArray10);
        combinedRangeXYPlot8.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = combinedRangeXYPlot8.getDomainAxisEdge();
        boolean boolean14 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge13);
        boolean boolean15 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge13);
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = axisSpace0.reserved(rectangle2D7, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(valueAxisArray10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot9.getRangeAxisLocation();
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation13, false);
        boolean boolean16 = combinedRangeXYPlot0.isDomainZoomable();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        categoryAxis1.setLabelFont(font6);
        org.jfree.chart.plot.PiePlot piePlot11 = new org.jfree.chart.plot.PiePlot();
        double double12 = piePlot11.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint14 = defaultDrawingSupplier13.getNextPaint();
        piePlot11.setLabelLinkPaint(paint14);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape18 = defaultDrawingSupplier16.getNextShape();
        java.awt.Shape shape19 = defaultDrawingSupplier16.getNextShape();
        piePlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.jfree.chart.JFreeChart jFreeChart22 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font6, (org.jfree.chart.plot.Plot) piePlot11, false);
        try {
            piePlot11.setInteriorGap((double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'percent' (7.0) argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        java.lang.Object obj3 = xYSeries2.clone();
        boolean boolean5 = xYSeries2.equals((java.lang.Object) (short) 10);
        int int6 = xYSeriesCollection0.indexOf(xYSeries2);
        try {
            java.lang.Number number9 = xYSeriesCollection0.getX(255, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getInteriorGap();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        piePlot0.setSimpleLabelOffset(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08d + "'", double3 == 0.08d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeFilled();
        java.awt.Paint paint4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        legendItem2.setOutlinePaint(paint4);
        java.awt.Paint paint6 = legendItem2.getFillPaint();
        boolean boolean7 = legendItem2.isShapeFilled();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color10 = java.awt.Color.GRAY;
        int int11 = color10.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("", font9, (java.awt.Paint) color10);
        legendItem2.setFillPaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 128 + "'", int11 == 128);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        org.jfree.data.general.DatasetGroup datasetGroup19 = timeSeriesCollection15.getGroup();
        try {
            int[] intArray23 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) timeSeriesCollection15, (int) (short) 10, (double) '#', (double) 2.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNotNull(datasetGroup19);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.block.ColumnArrangement columnArrangement2 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer3 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement2);
        boolean boolean4 = color0.equals((java.lang.Object) columnArrangement2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.clearDomainMarkers();
        combinedRangeXYPlot10.setRangePannable(true);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        combinedRangeXYPlot10.drawBackgroundImage(graphics2D14, rectangle2D15);
        java.awt.Color color17 = java.awt.Color.GRAY;
        combinedRangeXYPlot10.setRangeGridlinePaint((java.awt.Paint) color17);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot19.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation23 = combinedRangeXYPlot19.getRangeAxisLocation();
        combinedRangeXYPlot10.setRangeAxisLocation(axisLocation23, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape33 = defaultDrawingSupplier32.getNextShape();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape33, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot37.clearDomainMarkers();
        combinedRangeXYPlot37.setRangePannable(true);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        combinedRangeXYPlot37.drawBackgroundImage(graphics2D41, rectangle2D42);
        java.awt.Color color44 = java.awt.Color.GRAY;
        combinedRangeXYPlot37.setRangeGridlinePaint((java.awt.Paint) color44);
        java.awt.Font font47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color48 = java.awt.Color.GRAY;
        int int49 = color48.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock50 = new org.jfree.chart.block.LabelBlock("", font47, (java.awt.Paint) color48);
        combinedRangeXYPlot37.setRangeTickBandPaint((java.awt.Paint) color48);
        java.awt.Color color52 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer55 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = xYLineAndShapeRenderer55.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer55.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator63 = null;
        xYLineAndShapeRenderer55.setSeriesURLGenerator(0, xYURLGenerator63, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator66 = null;
        xYLineAndShapeRenderer55.setLegendItemToolTipGenerator(xYSeriesLabelGenerator66);
        boolean boolean68 = xYLineAndShapeRenderer55.getBaseItemLabelsVisible();
        java.awt.Stroke stroke70 = xYLineAndShapeRenderer55.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot71 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = piePlot71.getLabelPadding();
        double double74 = rectangleInsets72.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder75 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color52, stroke70, rectangleInsets72);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer77 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D78 = null;
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot80 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot80.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray82 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot80.setDomainAxes(valueAxisArray82);
        combinedRangeXYPlot80.clearRangeAxes();
        java.util.TimeZone timeZone85 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection86 = new org.jfree.data.time.TimeSeriesCollection(timeZone85);
        boolean boolean87 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection86);
        org.jfree.data.Range range89 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection86, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo90 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState91 = xYStepAreaRenderer77.initialise(graphics2D78, rectangle2D79, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot80, (org.jfree.data.xy.XYDataset) timeSeriesCollection86, plotRenderingInfo90);
        java.awt.Paint paint93 = xYStepAreaRenderer77.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem94 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape36, (java.awt.Paint) color48, stroke70, paint93);
        org.jfree.chart.plot.IntervalMarker intervalMarker95 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint93);
        org.jfree.chart.util.Layer layer96 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean97 = combinedRangeXYPlot10.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker95, layer96);
        try {
            xYLineAndShapeRenderer2.addAnnotation(xYAnnotation9, layer96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 128 + "'", int49 == 128);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(itemLabelPosition59);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.0d + "'", double74 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray82);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNull(range89);
        org.junit.Assert.assertNotNull(xYItemRendererState91);
        org.junit.Assert.assertNotNull(paint93);
        org.junit.Assert.assertNotNull(layer96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarksVisible(true);
        java.awt.Paint paint24 = periodAxis19.getAxisLinePaint();
        org.jfree.data.Range range25 = periodAxis19.getRange();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions28 = categoryAxis25.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState34 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis25.drawTickMarks(graphics2D29, (double) (short) 100, rectangle2D31, rectangleEdge32, axisState34);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list38 = periodAxis19.refreshTicks(graphics2D24, axisState34, rectangle2D36, rectangleEdge37);
        axisState34.cursorUp((double) ' ');
        axisState34.cursorUp((double) 2);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions28);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        java.awt.Paint paint24 = periodAxis19.getMinorTickMarkPaint();
        org.jfree.data.Range range25 = null;
        org.jfree.data.Range range27 = org.jfree.data.Range.expandToInclude(range25, (double) 0L);
        double double28 = range27.getLength();
        periodAxis19.setRange(range27, true, false);
        boolean boolean32 = periodAxis19.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) true);
        double double2 = xYSeries1.getMinX();
        xYSeries1.setMaximumItemCount((int) (short) 0);
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries1.addOrUpdate(0.2d, (double) 0);
        double[][] doubleArray8 = xYSeries1.toArray();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator3);
        double double5 = piePlot2.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke12 = xYLineAndShapeRenderer8.getItemOutlineStroke((int) 'a', 0, false);
        piePlot2.setBaseSectionOutlineStroke(stroke12);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator15 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot2.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator15);
        boolean boolean17 = piePlot2.getIgnoreZeroValues();
        java.awt.Font font18 = piePlot2.getNoDataMessageFont();
        boolean boolean19 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        java.lang.Object obj20 = chartRenderingInfo0.clone();
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        double double1 = piePlot0.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint3 = defaultDrawingSupplier2.getNextPaint();
        piePlot0.setLabelLinkPaint(paint3);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape6 = defaultDrawingSupplier5.getNextShape();
        java.awt.Shape shape7 = defaultDrawingSupplier5.getNextShape();
        java.awt.Shape shape8 = defaultDrawingSupplier5.getNextShape();
        piePlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier5);
        java.awt.Color color10 = java.awt.Color.GRAY;
        int int11 = color10.getGreen();
        boolean boolean13 = color10.equals((java.lang.Object) "NO_CHANGE");
        java.lang.String str14 = color10.toString();
        piePlot0.setLabelShadowPaint((java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 128 + "'", int11 == 128);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str14.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        blockContainer1.add((org.jfree.chart.block.Block) textTitle3);
        int int5 = textTitle3.getMaximumLinesToDisplay();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.zoomRange((-1.0d), (double) 9223372036854775807L);
        numberAxis0.setTickLabelsVisible(false);
        numberAxis0.setLowerBound((double) 10L);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.Object obj2 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem(0.0d, (double) (-1.0f));
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        int int4 = xYDataItem2.compareTo((java.lang.Object) textAnchor3);
        java.lang.Object obj5 = null;
        int int6 = xYDataItem2.compareTo(obj5);
        xYDataItem2.setY((java.lang.Number) 255);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        java.text.NumberFormat numberFormat2 = standardPieToolTipGenerator1.getPercentFormat();
        numberFormat2.setParseIntegerOnly(false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape12 = defaultDrawingSupplier11.getNextShape();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape12, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.clearDomainMarkers();
        combinedRangeXYPlot16.setRangePannable(true);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        combinedRangeXYPlot16.drawBackgroundImage(graphics2D20, rectangle2D21);
        java.awt.Color color23 = java.awt.Color.GRAY;
        combinedRangeXYPlot16.setRangeGridlinePaint((java.awt.Paint) color23);
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color27 = java.awt.Color.GRAY;
        int int28 = color27.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("", font26, (java.awt.Paint) color27);
        combinedRangeXYPlot16.setRangeTickBandPaint((java.awt.Paint) color27);
        java.awt.Color color31 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = xYLineAndShapeRenderer34.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer34.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator42 = null;
        xYLineAndShapeRenderer34.setSeriesURLGenerator(0, xYURLGenerator42, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator45 = null;
        xYLineAndShapeRenderer34.setLegendItemToolTipGenerator(xYSeriesLabelGenerator45);
        boolean boolean47 = xYLineAndShapeRenderer34.getBaseItemLabelsVisible();
        java.awt.Stroke stroke49 = xYLineAndShapeRenderer34.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot50 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = piePlot50.getLabelPadding();
        double double53 = rectangleInsets51.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder54 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color31, stroke49, rectangleInsets51);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer56 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot59 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot59.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray61 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot59.setDomainAxes(valueAxisArray61);
        combinedRangeXYPlot59.clearRangeAxes();
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection65 = new org.jfree.data.time.TimeSeriesCollection(timeZone64);
        boolean boolean66 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection65);
        org.jfree.data.Range range68 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection65, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo69 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState70 = xYStepAreaRenderer56.initialise(graphics2D57, rectangle2D58, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot59, (org.jfree.data.xy.XYDataset) timeSeriesCollection65, plotRenderingInfo69);
        java.awt.Paint paint72 = xYStepAreaRenderer56.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem73 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape15, (java.awt.Paint) color27, stroke49, paint72);
        org.jfree.chart.plot.IntervalMarker intervalMarker74 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint72);
        java.awt.Color color76 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem77 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color76);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer78 = legendItem77.getFillPaintTransformer();
        intervalMarker74.setGradientPaintTransformer(gradientPaintTransformer78);
        java.awt.Paint paint80 = intervalMarker74.getPaint();
        org.jfree.chart.text.TextAnchor textAnchor81 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        intervalMarker74.setLabelTextAnchor(textAnchor81);
        try {
            java.lang.String str83 = numberFormat2.format((java.lang.Object) intervalMarker74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 128 + "'", int28 == 128);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.0d + "'", double53 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNull(range68);
        org.junit.Assert.assertNotNull(xYItemRendererState70);
        org.junit.Assert.assertNotNull(paint72);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(gradientPaintTransformer78);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(textAnchor81);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer3D0.getURLGenerator((int) '4', 0, true);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer3D0.getLegendItems();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer3D0.getSeriesItemLabelGenerator(128);
        double double8 = barRenderer3D0.getLowerClip();
        org.junit.Assert.assertNull(categoryURLGenerator4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        boolean boolean2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            timeSeriesCollection1.removeSeries((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertEquals((double) number5, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        java.awt.Stroke stroke15 = combinedRangeXYPlot6.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.util.LogFormat logFormat1 = new org.jfree.chart.util.LogFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        java.lang.StringBuffer stringBuffer5 = logFormat1.format((double) (short) 10, stringBuffer3, fieldPosition4);
        java.text.DateFormat dateFormat6 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator7 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Nearest", (java.text.NumberFormat) logFormat1, dateFormat6);
        java.text.ParsePosition parsePosition9 = null;
        java.lang.Number number10 = logFormat1.parse("[size=-1]", parsePosition9);
        org.junit.Assert.assertNotNull(stringBuffer5);
        org.junit.Assert.assertNull(number10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot2.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot2.setDomainAxes(valueAxisArray4);
        org.jfree.data.xy.XYDataset xYDataset6 = combinedRangeXYPlot2.getDataset();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        combinedRangeXYPlot2.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection8);
        timeSeries1.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection8);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 100, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeSeries1);
        try {
            timeSeries1.delete((int) (byte) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray4);
        org.junit.Assert.assertNull(xYDataset6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color3 = java.awt.Color.GRAY;
        int int4 = color3.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("", font2, (java.awt.Paint) color3);
        boolean boolean6 = lengthConstraintType0.equals((java.lang.Object) font2);
        java.lang.String str7 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LengthConstraintType.FIXED" + "'", str7.equals("LengthConstraintType.FIXED"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.GRAY;
        int int3 = color2.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock4 = new org.jfree.chart.block.LabelBlock("", font1, (java.awt.Paint) color2);
        labelBlock4.setHeight(0.0d);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator8 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot7.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator8);
        double double10 = piePlot7.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer13.getItemOutlineStroke((int) 'a', 0, false);
        piePlot7.setBaseSectionOutlineStroke(stroke17);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer19.setUseFillPaint(false);
        boolean boolean22 = xYAreaRenderer19.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot25 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot25.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot25.setDomainAxes(valueAxisArray27);
        java.util.TimeZone timeZone29 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection30 = new org.jfree.data.time.TimeSeriesCollection(timeZone29);
        boolean boolean31 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState33 = xYAreaRenderer19.initialise(graphics2D23, rectangle2D24, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot25, (org.jfree.data.xy.XYDataset) timeSeriesCollection30, plotRenderingInfo32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = combinedRangeXYPlot25.getInsets();
        java.lang.String str35 = rectangleInsets34.toString();
        piePlot7.setSimpleLabelOffset(rectangleInsets34);
        double double37 = rectangleInsets34.getBottom();
        labelBlock4.setPadding(rectangleInsets34);
        double double40 = rectangleInsets34.trimWidth(0.0d);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str35.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + (-16.0d) + "'", double40 == (-16.0d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator1);
        double double3 = piePlot0.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer6.getItemOutlineStroke((int) 'a', 0, false);
        piePlot0.setBaseSectionOutlineStroke(stroke10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer12.setUseFillPaint(false);
        boolean boolean15 = xYAreaRenderer12.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot18.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot18.setDomainAxes(valueAxisArray20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState26 = xYAreaRenderer12.initialise(graphics2D16, rectangle2D17, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot18, (org.jfree.data.xy.XYDataset) timeSeriesCollection23, plotRenderingInfo25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = combinedRangeXYPlot18.getInsets();
        java.lang.String str28 = rectangleInsets27.toString();
        piePlot0.setSimpleLabelOffset(rectangleInsets27);
        double double30 = rectangleInsets27.getBottom();
        double double32 = rectangleInsets27.calculateLeftOutset(1.0E-5d);
        double double34 = rectangleInsets27.calculateBottomOutset((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str28.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 8.0d + "'", double32 == 8.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.GRAY;
        int int5 = color4.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("", font3, (java.awt.Paint) color4);
        multiplePiePlot1.setAggregatedItemsPaint((java.awt.Paint) color4);
        float[] floatArray8 = new float[] {};
        try {
            float[] floatArray9 = color4.getComponents(floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 128 + "'", int5 == 128);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer2.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer2.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator10 = null;
        xYLineAndShapeRenderer2.setSeriesURLGenerator(0, xYURLGenerator10, true);
        java.awt.Paint paint14 = null;
        xYLineAndShapeRenderer2.setSeriesFillPaint((int) (short) 0, paint14, false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.setBackgroundAlpha((float) '#');
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot11.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray13 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot11.setDomainAxes(valueAxisArray13);
        org.jfree.data.xy.XYDataset xYDataset15 = combinedRangeXYPlot11.getDataset();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        boolean boolean18 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        combinedRangeXYPlot11.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection17);
        timeSeries10.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection17);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) year21, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis25 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) year21);
        periodAxis25.setMinorTickMarkInsideLength(0.0f);
        periodAxis25.setMinorTickMarkInsideLength(0.0f);
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray30 = periodAxis25.getLabelInfo();
        int int31 = combinedRangeXYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) periodAxis25);
        java.awt.Stroke stroke32 = combinedRangeXYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(valueAxisArray13);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = piePlot0.getLabelPadding();
        java.awt.Paint paint3 = piePlot0.getSectionPaint((java.lang.Comparable) (-2208960000000L));
        java.lang.String str4 = piePlot0.getPlotType();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Pie Plot" + "'", str4.equals("Pie Plot"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        org.jfree.data.xy.XYDataset xYDataset4 = combinedRangeXYPlot0.getDataset();
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = combinedRangeXYPlot0.getDomainMarkers(layer5);
        double double7 = combinedRangeXYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation8 = combinedRangeXYPlot0.getRangeAxisLocation();
        combinedRangeXYPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNull(xYDataset4);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        piePlot1.setShadowXOffset(0.0d);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = piePlot1.getLegendLabelToolTipGenerator();
        piePlot1.setIgnoreNullValues(true);
        boolean boolean7 = rotation0.equals((java.lang.Object) true);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) rotation0, seriesChangeInfo8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        org.junit.Assert.assertNotNull(rotation0);
        org.junit.Assert.assertNull(pieSectionLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray2 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot0.setDomainAxes(valueAxisArray2);
        combinedRangeXYPlot0.clearRangeAxes();
        java.awt.Stroke stroke5 = combinedRangeXYPlot0.getDomainZeroBaselineStroke();
        combinedRangeXYPlot0.setBackgroundAlpha((float) (-1));
        java.awt.Paint paint8 = null;
        try {
            combinedRangeXYPlot0.setDomainMinorGridlinePaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(valueAxisArray2);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        java.lang.String str29 = jFreeChartEntity28.toString();
        jFreeChartEntity28.setURLText("JFreeChartEntity: tooltip = null");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "JFreeChartEntity: tooltip = null" + "'", str29.equals("JFreeChartEntity: tooltip = null"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer2.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator8 = xYLineAndShapeRenderer2.getSeriesURLGenerator(0);
        xYLineAndShapeRenderer2.setSeriesCreateEntities((int) (byte) 0, (java.lang.Boolean) false);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator12 = xYLineAndShapeRenderer2.getBaseURLGenerator();
        boolean boolean13 = xYLineAndShapeRenderer2.getBaseSeriesVisible();
        org.jfree.chart.plot.XYPlot xYPlot14 = null;
        xYLineAndShapeRenderer2.setPlot(xYPlot14);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(xYURLGenerator8);
        org.junit.Assert.assertNull(xYURLGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        boolean boolean3 = xYAreaRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot6.setDomainAxes(valueAxisArray8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState14 = xYAreaRenderer0.initialise(graphics2D4, rectangle2D5, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot6, (org.jfree.data.xy.XYDataset) timeSeriesCollection11, plotRenderingInfo13);
        java.awt.Color color15 = java.awt.Color.white;
        combinedRangeXYPlot6.setDomainGridlinePaint((java.awt.Paint) color15);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        combinedRangeXYPlot5.setRangePannable(true);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        combinedRangeXYPlot5.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Color color12 = java.awt.Color.GRAY;
        combinedRangeXYPlot5.setRangeGridlinePaint((java.awt.Paint) color12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState18 = xYAreaRenderer0.initialise(graphics2D3, rectangle2D4, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot5, (org.jfree.data.xy.XYDataset) timeSeriesCollection15, plotRenderingInfo17);
        org.jfree.data.general.DatasetGroup datasetGroup19 = timeSeriesCollection15.getGroup();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        timeSeriesCollection15.removeSeries(timeSeries21);
        timeSeries21.setMaximumItemAge((long) 5);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(xYItemRendererState18);
        org.junit.Assert.assertNotNull(datasetGroup19);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions28 = categoryAxis25.getCategoryLabelPositions();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisState axisState34 = new org.jfree.chart.axis.AxisState((double) (short) -1);
        categoryAxis25.drawTickMarks(graphics2D29, (double) (short) 100, rectangle2D31, rectangleEdge32, axisState34);
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.util.List list38 = periodAxis19.refreshTicks(graphics2D24, axisState34, rectangle2D36, rectangleEdge37);
        axisState34.cursorUp((double) ' ');
        double double41 = axisState34.getMax();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions28);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.getAutoRangeStickyZero();
        numberAxis0.zoomRange((-1.0d), (double) 9223372036854775807L);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange(range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(range5, (double) 0.0f);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot13.setDomainAxes(valueAxisArray15);
        combinedRangeXYPlot13.clearRangeAxes();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeZone18);
        boolean boolean20 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection19, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = xYStepAreaRenderer10.initialise(graphics2D11, rectangle2D12, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13, (org.jfree.data.xy.XYDataset) timeSeriesCollection19, plotRenderingInfo23);
        java.awt.Paint paint26 = xYStepAreaRenderer10.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.title.LegendTitle legendTitle27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) xYStepAreaRenderer10);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = null;
        org.jfree.chart.util.Size2D size2D30 = legendTitle27.arrange(graphics2D28, rectangleConstraint29);
        double double31 = size2D30.getHeight();
        org.jfree.chart.util.Size2D size2D32 = rectangleConstraint8.calculateConstrainedSize(size2D30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(valueAxisArray15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(xYItemRendererState24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(size2D32);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickCount((int) (byte) 10);
        periodAxis19.setMinorTickMarksVisible(true);
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers();
        combinedRangeXYPlot0.setRangePannable(true);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        combinedRangeXYPlot0.drawBackgroundImage(graphics2D4, rectangle2D5);
        java.awt.Color color7 = java.awt.Color.GRAY;
        combinedRangeXYPlot0.setRangeGridlinePaint((java.awt.Paint) color7);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.mapDatasetToRangeAxis(4, 1);
        org.jfree.chart.axis.AxisLocation axisLocation13 = combinedRangeXYPlot9.getRangeAxisLocation();
        combinedRangeXYPlot0.setRangeAxisLocation(axisLocation13, false);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape23 = defaultDrawingSupplier22.getNextShape();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape23, (double) 0.0f, (double) 'a');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot27.clearDomainMarkers();
        combinedRangeXYPlot27.setRangePannable(true);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        combinedRangeXYPlot27.drawBackgroundImage(graphics2D31, rectangle2D32);
        java.awt.Color color34 = java.awt.Color.GRAY;
        combinedRangeXYPlot27.setRangeGridlinePaint((java.awt.Paint) color34);
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color38 = java.awt.Color.GRAY;
        int int39 = color38.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("", font37, (java.awt.Paint) color38);
        combinedRangeXYPlot27.setRangeTickBandPaint((java.awt.Paint) color38);
        java.awt.Color color42 = java.awt.Color.gray;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer45 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = xYLineAndShapeRenderer45.getNegativeItemLabelPosition((int) (byte) 1, (int) ' ', false);
        xYLineAndShapeRenderer45.setItemLabelAnchorOffset((double) 100);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator53 = null;
        xYLineAndShapeRenderer45.setSeriesURLGenerator(0, xYURLGenerator53, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator56 = null;
        xYLineAndShapeRenderer45.setLegendItemToolTipGenerator(xYSeriesLabelGenerator56);
        boolean boolean58 = xYLineAndShapeRenderer45.getBaseItemLabelsVisible();
        java.awt.Stroke stroke60 = xYLineAndShapeRenderer45.lookupSeriesStroke((int) (short) 1);
        org.jfree.chart.plot.PiePlot piePlot61 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = piePlot61.getLabelPadding();
        double double64 = rectangleInsets62.calculateTopOutset((double) (short) -1);
        org.jfree.chart.block.LineBorder lineBorder65 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color42, stroke60, rectangleInsets62);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer67 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (short) 10);
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot70 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot70.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray72 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot70.setDomainAxes(valueAxisArray72);
        combinedRangeXYPlot70.clearRangeAxes();
        java.util.TimeZone timeZone75 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection76 = new org.jfree.data.time.TimeSeriesCollection(timeZone75);
        boolean boolean77 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection76);
        org.jfree.data.Range range79 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection76, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState81 = xYStepAreaRenderer67.initialise(graphics2D68, rectangle2D69, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot70, (org.jfree.data.xy.XYDataset) timeSeriesCollection76, plotRenderingInfo80);
        java.awt.Paint paint83 = xYStepAreaRenderer67.lookupSeriesFillPaint((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem84 = new org.jfree.chart.LegendItem("February", "java.awt.Color[r=128,g=128,b=128]", "hi!", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", shape26, (java.awt.Paint) color38, stroke60, paint83);
        org.jfree.chart.plot.IntervalMarker intervalMarker85 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) '4', paint83);
        org.jfree.chart.util.Layer layer86 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean87 = combinedRangeXYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker85, layer86);
        java.awt.Graphics2D graphics2D88 = null;
        java.awt.geom.Rectangle2D rectangle2D89 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo91 = null;
        org.jfree.chart.plot.CrosshairState crosshairState93 = new org.jfree.chart.plot.CrosshairState(false);
        crosshairState93.setAnchorY((double) 10L);
        boolean boolean96 = combinedRangeXYPlot0.render(graphics2D88, rectangle2D89, 4, plotRenderingInfo91, crosshairState93);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 128 + "'", int39 == 128);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(itemLabelPosition49);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.0d + "'", double64 == 2.0d);
        org.junit.Assert.assertNotNull(valueAxisArray72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNull(range79);
        org.junit.Assert.assertNotNull(xYItemRendererState81);
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertNotNull(layer86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis5.setCategoryLabelPositions(categoryLabelPositions9);
        org.jfree.chart.entity.AxisEntity axisEntity11 = new org.jfree.chart.entity.AxisEntity(shape1, (org.jfree.chart.axis.Axis) categoryAxis5);
        org.jfree.chart.axis.Axis axis12 = axisEntity11.getAxis();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(axis12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection1 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator3);
        double double5 = piePlot2.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke12 = xYLineAndShapeRenderer8.getItemOutlineStroke((int) 'a', 0, false);
        piePlot2.setBaseSectionOutlineStroke(stroke12);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator15 = new org.jfree.chart.labels.StandardPieToolTipGenerator("hi!");
        piePlot2.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator15);
        boolean boolean17 = piePlot2.getIgnoreZeroValues();
        java.awt.Font font18 = piePlot2.getNoDataMessageFont();
        boolean boolean19 = chartRenderingInfo0.equals((java.lang.Object) piePlot2);
        org.jfree.chart.entity.EntityCollection entityCollection20 = chartRenderingInfo0.getEntityCollection();
        org.jfree.chart.RenderingSource renderingSource21 = chartRenderingInfo0.getRenderingSource();
        org.junit.Assert.assertNotNull(entityCollection1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(entityCollection20);
        org.junit.Assert.assertNull(renderingSource21);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "ThreadContext", 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape1, (double) 0.0f, (double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis6.getCategoryLabelPositions();
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color12 = java.awt.Color.GRAY;
        int int13 = color12.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock14 = new org.jfree.chart.block.LabelBlock("", font11, (java.awt.Paint) color12);
        categoryAxis6.setLabelFont(font11);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        double double17 = piePlot16.getStartAngle();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint19 = defaultDrawingSupplier18.getNextPaint();
        piePlot16.setLabelLinkPaint(paint19);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape22 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape23 = defaultDrawingSupplier21.getNextShape();
        java.awt.Shape shape24 = defaultDrawingSupplier21.getNextShape();
        piePlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart("DateTickMarkPosition.MIDDLE", font11, (org.jfree.chart.plot.Plot) piePlot16, false);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity28 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart27);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        java.awt.image.BufferedImage bufferedImage34 = jFreeChart27.createBufferedImage((int) (byte) 10, (int) (byte) 100, (double) (-1.0f), 100.0d, chartRenderingInfo33);
        jFreeChart27.setTextAntiAlias(true);
        java.awt.Stroke stroke37 = jFreeChart27.getBorderStroke();
        org.jfree.chart.event.ChartProgressListener chartProgressListener38 = null;
        jFreeChart27.removeProgressListener(chartProgressListener38);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(bufferedImage34);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) '#');
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot5.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray7 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot5.setDomainAxes(valueAxisArray7);
        org.jfree.data.xy.XYDataset xYDataset9 = combinedRangeXYPlot5.getDataset();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        boolean boolean12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        combinedRangeXYPlot5.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection11);
        timeSeries4.addChangeListener((org.jfree.data.general.SeriesChangeListener) timeSeriesCollection11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year15, (java.lang.Number) 100, false);
        org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("{0}", (org.jfree.data.time.RegularTimePeriod) year2, (org.jfree.data.time.RegularTimePeriod) year15);
        periodAxis19.setMinorTickMarkInsideLength(0.0f);
        periodAxis19.setMinorTickMarksVisible(true);
        java.awt.Stroke stroke24 = periodAxis19.getAxisLineStroke();
        java.lang.Object obj25 = periodAxis19.clone();
        org.junit.Assert.assertNotNull(valueAxisArray7);
        org.junit.Assert.assertNull(xYDataset9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.String[] strArray1 = null;
        try {
            org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("DateTickUnitType.HOUR", strArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer5 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) (short) 0);
        boolean boolean6 = xYBarRenderer5.getShadowsVisible();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke14 = xYLineAndShapeRenderer10.getItemOutlineStroke((int) 'a', 0, false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.clearDomainMarkers();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray17 = new org.jfree.chart.axis.ValueAxis[] {};
        combinedRangeXYPlot15.setDomainAxes(valueAxisArray17);
        combinedRangeXYPlot15.clearRangeAxes();
        java.awt.Stroke stroke20 = combinedRangeXYPlot15.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.Plot plot21 = combinedRangeXYPlot15.getRootPlot();
        xYLineAndShapeRenderer10.addChangeListener((org.jfree.chart.event.RendererChangeListener) combinedRangeXYPlot15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.Paint paint26 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
        piePlot27.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator28);
        double double30 = piePlot27.getMaximumExplodePercent();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer33.getItemOutlineStroke((int) 'a', 0, false);
        piePlot27.setBaseSectionOutlineStroke(stroke37);
        xYBarRenderer5.drawDomainLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot15, (org.jfree.chart.axis.ValueAxis) numberAxis3D23, rectangle2D24, (double) (byte) -1, paint26, stroke37);
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder((-1.0d), (double) 255, 8.0d, 3.0d, paint26);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(valueAxisArray17);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(plot21);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis1.setLabel("Nearest");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.GRAY;
        int int8 = color7.getGreen();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("", font6, (java.awt.Paint) color7);
        categoryAxis1.setLabelFont(font6);
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("January", font6);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
    }
}

