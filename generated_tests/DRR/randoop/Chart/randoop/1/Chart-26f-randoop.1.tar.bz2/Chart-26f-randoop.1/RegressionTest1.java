import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = chartChangeEventType6.equals((java.lang.Object) dateAxis7);
        java.awt.Paint paint9 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean10 = chartChangeEventType6.equals((java.lang.Object) paint9);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "hi!", paint9);
        categoryAxis1.setTickLabelsVisible(true);
        categoryAxis1.setCategoryMargin(0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        int int3 = piePlot3D1.getPieIndex();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) 'a', 1, rectangle2D6, rectangleEdge7);
        java.lang.Object obj9 = categoryAxis1.clone();
        int int10 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.configure();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = standardGradientPaintTransformer1.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape4, stroke5, (java.awt.Paint) color6);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer12 = stackedBarRenderer3D11.getGradientPaintTransformer();
        legendItem7.setFillPaintTransformer(gradientPaintTransformer12);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D17.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D17.setDrawBarOutline(true);
        stackedBarRenderer3D17.setBaseSeriesVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = stackedBarRenderer3D17.getGradientPaintTransformer();
        legendItem7.setFillPaintTransformer(gradientPaintTransformer24);
        java.awt.Stroke stroke26 = legendItem7.getLineStroke();
        org.jfree.data.general.Dataset dataset27 = legendItem7.getDataset();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(gradientPaintTransformer12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(dataset27);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation5 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0, (java.lang.Number) (short) 0);
        boolean boolean6 = dateAxis1.equals((java.lang.Object) (short) 0);
        dateAxis1.setAxisLineVisible(false);
        java.lang.Object obj9 = dateAxis1.clone();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets11);
        dateAxis1.setAxisLinePaint((java.awt.Paint) color5);
        java.util.Date date14 = dateAxis1.getMinimumDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = null;
        piePlot16.setLegendLabelToolTipGenerator(pieSectionLabelGenerator17);
        java.awt.Paint paint19 = piePlot16.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = chartChangeEventType21.equals((java.lang.Object) dateAxis22);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) date14, jFreeChart20, chartChangeEventType21);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.entity.EntityCollection entityCollection27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo(entityCollection27);
        chartRenderingInfo28.clear();
        try {
            jFreeChart20.draw(graphics2D25, rectangle2D26, chartRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        java.lang.String str2 = dateAxis0.getLabelURL();
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer6.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer6.setBaseLinesVisible(false);
        java.lang.Boolean boolean13 = statisticalLineAndShapeRenderer6.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean14 = dateRange3.equals((java.lang.Object) boolean13);
        java.util.Date date15 = dateRange3.getUpperDate();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int19 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryAxis18.setUpperMargin((double) 'a');
        java.awt.Font font23 = categoryAxis18.getTickLabelFont((java.lang.Comparable) (byte) 100);
        categoryAxis18.setUpperMargin(0.05d);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double31 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor26, 11, (-1), rectangle2D29, rectangleEdge30);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer34.setUseFillPaint(false);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.configure();
        boolean boolean39 = statisticalLineAndShapeRenderer34.equals((java.lang.Object) numberAxis37);
        boolean boolean40 = rectangleEdge30.equals((java.lang.Object) numberAxis37);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType41 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        boolean boolean43 = areaRendererEndType41.equals((java.lang.Object) (short) -1);
        boolean boolean44 = rectangleEdge30.equals((java.lang.Object) areaRendererEndType41);
        try {
            double double45 = dateAxis0.dateToJava2D(date15, rectangle2D16, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(boolean13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(areaRendererEndType41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        java.awt.Color color43 = java.awt.Color.WHITE;
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color43);
        java.awt.geom.Point2D point2D45 = null;
        try {
            xYPlot10.setQuadrantOrigin(point2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        int int1 = color0.getGreen();
        int int2 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color1 = color0.darker();
        java.lang.String str2 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=255,g=255,b=128]" + "'", str2.equals("java.awt.Color[r=255,g=255,b=128]"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        stackedBarRenderer3D3.setBaseOutlinePaint(paint4, false);
        stackedBarRenderer3D3.setBaseSeriesVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = stackedBarRenderer3D3.getSeriesURLGenerator((int) (short) 10);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryURLGenerator10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj4 = stackedBarRenderer3D3.clone();
        double double5 = stackedBarRenderer3D3.getYOffset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj10 = stackedBarRenderer3D9.clone();
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        stackedBarRenderer3D9.setWallPaint((java.awt.Paint) color11);
        stackedBarRenderer3D3.setBasePaint((java.awt.Paint) color11, true);
        double double15 = stackedBarRenderer3D3.getYOffset();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = piePlot1.getLabelPaint();
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 100);
        java.lang.Class<?> wildcardClass5 = piePlot1.getClass();
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("TextAnchor.TOP_CENTER", (java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(uRL6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        java.awt.Paint paint13 = valueMarker8.getOutlinePaint();
        valueMarker8.setLabel("");
        java.awt.Stroke stroke16 = valueMarker8.getStroke();
        java.awt.Stroke stroke17 = null;
        try {
            valueMarker8.setStroke(stroke17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke16);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date21 = spreadsheetDate3.toDate();
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone22;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year24);
        long long26 = year24.getFirstMillisecond();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-2208960000000L) + "'", long26 == (-2208960000000L));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint3 = polarPlot2.getRadiusGridlinePaint();
        java.awt.Stroke stroke4 = polarPlot2.getRadiusGridlineStroke();
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot2);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        polarPlot2.setDataset(xYDataset6);
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color14 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape12, stroke13, (java.awt.Paint) color14);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = stackedBarRenderer3D19.getGradientPaintTransformer();
        legendItem15.setFillPaintTransformer(gradientPaintTransformer20);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D25.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D25.setDrawBarOutline(true);
        stackedBarRenderer3D25.setBaseSeriesVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer32 = stackedBarRenderer3D25.getGradientPaintTransformer();
        legendItem15.setFillPaintTransformer(gradientPaintTransformer32);
        java.awt.Stroke stroke34 = legendItem15.getLineStroke();
        polarPlot2.setAngleGridlineStroke(stroke34);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(gradientPaintTransformer32);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        textTitle2.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        textTitle2.setID("java.awt.Color[r=255,g=255,b=128]");
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        java.awt.Font font6 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) 100);
        categoryAxis1.setUpperMargin(0.05d);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 11, (-1), rectangle2D12, rectangleEdge13);
        boolean boolean15 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelPaint();
        java.lang.Object obj2 = piePlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1900);
        int int3 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Comparable comparable5 = keyedObjects2D0.getRowKey((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color3 = java.awt.Color.getColor("({0}, {1}) = {2}", color2);
        boolean boolean4 = borderArrangement0.equals((java.lang.Object) color2);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo9 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "");
        boolean boolean10 = borderArrangement0.equals((java.lang.Object) "");
        borderArrangement0.clear();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.Comparable comparable0 = null;
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator3 = null;
        piePlot2.setLegendLabelToolTipGenerator(pieSectionLabelGenerator3);
        java.awt.Paint paint5 = piePlot2.getShadowPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D9.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D9.setDrawBarOutline(true);
        stackedBarRenderer3D9.setBaseSeriesVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = stackedBarRenderer3D9.getGradientPaintTransformer();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        stackedBarRenderer3D9.setSeriesStroke((int) (byte) 100, stroke18);
        boolean boolean20 = piePlot2.equals((java.lang.Object) stroke18);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker(comparable0, paint1, stroke18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double7 = range5.constrain((double) (short) 10);
        numberAxis2.setRange(range5, true, true);
        double double11 = numberAxis2.getFixedAutoRange();
        boolean boolean12 = numberAxis2.getAutoRangeIncludesZero();
        boolean boolean13 = stackedBarRenderer1.equals((java.lang.Object) boolean12);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0L, "EXPAND", textAnchor2, textAnchor3, (double) 2.0f);
        org.jfree.chart.text.TextAnchor textAnchor6 = numberTick5.getRotationAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        double double5 = textTitle2.getContentYOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1900);
        java.util.List list3 = keyedObjects2D0.getColumnKeys();
        try {
            keyedObjects2D0.removeColumn(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        boolean boolean3 = ringPlot1.getSeparatorsVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "RangeType.NEGATIVE");
        java.lang.String str3 = contributor2.getEmail();
        java.lang.String str4 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RangeType.NEGATIVE" + "'", str3.equals("RangeType.NEGATIVE"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RangeType.NEGATIVE" + "'", str4.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean3 = statisticalLineAndShapeRenderer0.getItemShapeFilled(0, (int) (short) 0);
        boolean boolean4 = statisticalLineAndShapeRenderer0.getBaseLinesVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        statisticalLineAndShapeRenderer0.notifyListeners(rendererChangeEvent5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) 'a', 1, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double16 = categoryAxis1.getCategoryStart((-457), (int) '#', rectangle2D14, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        java.awt.Stroke stroke9 = stackedBarRenderer3D3.getSeriesStroke((int) (byte) 10);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        stackedBarRenderer3D3.setWallPaint((java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = areaRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 0);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = areaRenderer0.getBaseToolTipGenerator();
        java.awt.Paint paint5 = null;
        areaRenderer0.setSeriesPaint(7, paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        try {
            java.awt.Color color1 = java.awt.Color.decode("Polar Plot");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Polar Plot\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(2, (-1));
        int int3 = dateTickUnit2.getRollCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Color color4 = java.awt.Color.yellow;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 3, (double) 10.0f, (double) 12L, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("VerticalAlignment.BOTTOM");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        boolean boolean7 = textLine1.equals((java.lang.Object) '#');
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint10 = textFragment9.getPaint();
        java.lang.String str11 = textFragment9.getText();
        textLine1.removeFragment(textFragment9);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.String[] strArray6 = new java.lang.String[] { "({0}, {1}) = {2}", "CategoryLabelWidthType.RANGE", "LegendItemEntity: seriesKey=null, dataset=null", "hi!", "({0}, {1}) = {2}", "VerticalAlignment.BOTTOM" };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 10.0d, 10900L, (byte) 10 };
        java.lang.Number[] numberArray14 = new java.lang.Number[] { 10.0d, 10900L, (byte) 10 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 10.0d, 10900L, (byte) 10 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 10.0d, 10900L, (byte) 10 };
        java.lang.Number[] numberArray26 = new java.lang.Number[] { 10.0d, 10900L, (byte) 10 };
        java.lang.Number[][] numberArray27 = new java.lang.Number[][] { numberArray10, numberArray14, numberArray18, numberArray22, numberArray26 };
        java.lang.Number[] numberArray29 = new java.lang.Number[] { 11 };
        java.lang.Number[] numberArray31 = new java.lang.Number[] { 11 };
        java.lang.Number[] numberArray33 = new java.lang.Number[] { 11 };
        java.lang.Number[][] numberArray34 = new java.lang.Number[][] { numberArray29, numberArray31, numberArray33 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset35 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray6, numberArray27, numberArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray26);
        org.junit.Assert.assertNotNull(numberArray27);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(numberArray31);
        org.junit.Assert.assertNotNull(numberArray33);
        org.junit.Assert.assertNotNull(numberArray34);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double0 = org.jfree.chart.renderer.category.LevelRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D14.setUpperMargin((double) 4);
        xYPlot10.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D14);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = piePlot1.getLabelPaint();
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 100);
        java.lang.Class<?> wildcardClass5 = piePlot1.getClass();
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass5);
        boolean boolean7 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass5);
        boolean boolean8 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(uRL6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D0.setIgnoreNullValues(false);
        double double3 = piePlot3D0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-5d + "'", double3 == 1.0E-5d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        textTitle2.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle2.setPosition(rectangleEdge10);
        double double12 = textTitle2.getWidth();
        textTitle2.setWidth((double) 10);
        org.jfree.chart.block.BorderArrangement borderArrangement15 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color18 = java.awt.Color.getColor("({0}, {1}) = {2}", color17);
        boolean boolean19 = borderArrangement15.equals((java.lang.Object) color17);
        float[] floatArray25 = new float[] { (byte) 10, (short) 10, ' ', 10L, (-460) };
        float[] floatArray26 = color17.getRGBComponents(floatArray25);
        textTitle2.setPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        try {
            defaultKeyedValues2D0.removeRow((java.lang.Comparable) year2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        double double3 = numberAxis3D1.getUpperMargin();
        java.awt.Shape shape4 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        java.lang.String str6 = legendItemEntity5.toString();
        java.awt.Color color11 = java.awt.Color.yellow;
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder(10.0d, (double) 100, (double) 1, (double) 'a', (java.awt.Paint) color11);
        boolean boolean13 = legendItemEntity5.equals((java.lang.Object) blockBorder12);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str6.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint3 = polarPlot2.getRadiusGridlinePaint();
        java.awt.Stroke stroke4 = polarPlot2.getRadiusGridlineStroke();
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot2);
        polarPlot2.setRadiusGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = polarPlot2.getAxis();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(valueAxis8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) (short) -1, (java.lang.Number) 0L);
        try {
            defaultKeyedValues0.removeValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D3.setDrawBarOutline(true);
        stackedBarRenderer3D3.setBaseSeriesVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = stackedBarRenderer3D3.getGradientPaintTransformer();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        stackedBarRenderer3D3.setSeriesStroke((int) (byte) 100, stroke12);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer15 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = areaRenderer15.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer15.setBaseOutlineStroke(stroke18, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = areaRenderer15.getSeriesNegativeItemLabelPosition((int) (short) 0);
        stackedBarRenderer3D3.setSeriesPositiveItemLabelPosition(4, itemLabelPosition22, true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart4);
        int int6 = jFreeChart4.getBackgroundImageAlignment();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            jFreeChart4.draw(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = areaRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer0.setBaseOutlineStroke(stroke3, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = areaRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 0);
        double double8 = itemLabelPosition7.getAngle();
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.jfree.chart.entity.EntityCollection entityCollection2 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setVerticalTickLabels(false);
        java.text.DateFormat dateFormat4 = null;
        dateAxis0.setDateFormatOverride(dateFormat4);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int4 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        int int12 = spreadsheetDate10.getDayOfMonth();
        boolean boolean13 = spreadsheetDate2.isInRange(serialDate6, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        try {
            org.jfree.data.time.SerialDate serialDate15 = spreadsheetDate10.getPreviousDayOfWeek(89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke17 = dateAxis16.getAxisLineStroke();
        dateAxis16.setLabelToolTip("10");
        try {
            xYPlot10.setDomainAxis((-246), (org.jfree.chart.axis.ValueAxis) dateAxis16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        piePlot4.setLegendLabelToolTipGenerator(pieSectionLabelGenerator5);
        java.awt.Paint paint7 = piePlot4.getOutlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, (double) 15, (double) 0.0f, paint7);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) 'a', 1, rectangle2D6, rectangleEdge7);
        java.lang.Object obj9 = categoryAxis1.clone();
        categoryAxis1.setLabelAngle((double) 1900L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset1.getRowCount();
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean4 = defaultStatisticalCategoryDataset1.equals((java.lang.Object) paint3);
        try {
            java.lang.String str7 = standardCategoryToolTipGenerator0.generateToolTip((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, 255, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        boolean boolean15 = chartChangeEventType13.equals((java.lang.Object) dateAxis14);
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean17 = chartChangeEventType13.equals((java.lang.Object) paint16);
        markerChangeEvent12.setType(chartChangeEventType13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = markerChangeEvent12.getType();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setUpperMargin((double) 4);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D1.setUpArrow(shape4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            org.jfree.chart.axis.AxisState axisState12 = numberAxis3D1.draw(graphics2D6, 0.0d, rectangle2D8, rectangle2D9, rectangleEdge10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        textTitle2.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle2.setPosition(rectangleEdge10);
        double double12 = textTitle2.getWidth();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            textTitle2.setBounds(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setVerticalTickLabels(false);
        try {
            dateAxis0.setAutoRangeMinimumSize((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "DatasetRenderingOrder.FORWARD", image3, "hi!", "DatasetRenderingOrder.FORWARD", "({0}, {1}) = {2}");
        java.lang.String str8 = projectInfo7.getLicenceText();
        java.lang.String str9 = projectInfo7.getLicenceText();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "({0}, {1}) = {2}" + "'", str8.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "({0}, {1}) = {2}" + "'", str9.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        org.jfree.chart.block.CenterArrangement centerArrangement14 = new org.jfree.chart.block.CenterArrangement();
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement14);
        java.util.List list16 = blockContainer13.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem17 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 128, (java.lang.Number) 10.0f, (java.lang.Number) (short) -1, (java.lang.Number) 0.0d, (java.lang.Number) 1.0E-8d, (java.lang.Number) (short) 10, (java.lang.Number) 6, (java.lang.Number) 1.0E-8d, list16);
        java.lang.String str18 = boxAndWhiskerItem17.toString();
        java.util.List list19 = boxAndWhiskerItem17.getOutliers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = stackedBarRenderer3D23.getGradientPaintTransformer();
        boolean boolean25 = boxAndWhiskerItem17.equals((java.lang.Object) stackedBarRenderer3D23);
        java.lang.Number number26 = boxAndWhiskerItem17.getQ3();
        java.lang.Number number27 = boxAndWhiskerItem17.getMinRegularValue();
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 1.0E-8d + "'", number27.equals(1.0E-8d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D1.setTickUnit(numberTickUnit2, false, true);
        boolean boolean6 = numberAxis3D1.isAutoTickUnitSelection();
        double double7 = numberAxis3D1.getLowerMargin();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer1 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = areaRenderer1.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Font font4 = areaRenderer1.getBaseItemLabelFont();
        piePlot0.setLabelFont(font4);
        java.awt.Paint paint7 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) 1.0E-8d);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) (short) 100);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int8 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.util.Date date20 = spreadsheetDate2.toDate();
        java.util.TimeZone timeZone21 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone21;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20, timeZone21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year24.next();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.util.BooleanList booleanList1 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.getColor("({0}, {1}) = {2}", color3);
        boolean boolean5 = booleanList1.equals((java.lang.Object) color4);
        levelRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int9 = categoryAxis8.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis8.getCategoryJava2DCoordinate(categoryAnchor10, (int) 'a', 1, rectangle2D13, rectangleEdge14);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(2);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis8.setTickLabelFont((java.lang.Comparable) 2, font18);
        levelRenderer0.setBaseItemLabelFont(font18, true);
        java.awt.Paint paint23 = levelRenderer0.lookupSeriesPaint((int) (byte) 100);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        dateAxis0.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(2, (-1));
        dateAxis0.setTickUnit(dateTickUnit6, true, false);
        int int10 = dateTickUnit6.getCount();
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", graphics2D1, (float) (-1L), (float) 12L, (double) 89, (float) 10, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        double double5 = categoryAxis1.getLowerMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions6 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(categoryLabelPositions6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder16 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color9, stroke10, rectangleInsets15);
        double double18 = rectangleInsets15.extendHeight((double) '4');
        valueMarker8.setLabelOffset(rectangleInsets15);
        double double20 = rectangleInsets15.getRight();
        double double21 = rectangleInsets15.getRight();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 97.0d + "'", double18 == 97.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        java.awt.Paint paint1 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        boolean boolean2 = color0.equals((java.lang.Object) paint1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis1.setAxisLineStroke(stroke3);
        java.awt.Shape shape5 = dateAxis1.getUpArrow();
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        boolean boolean7 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = areaRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer0.setBaseOutlineStroke(stroke3, true);
        java.awt.Stroke stroke7 = areaRenderer0.getSeriesStroke(100);
        boolean boolean8 = areaRenderer0.getBaseSeriesVisible();
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer10 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.awt.Shape shape13 = areaRenderer10.getItemShape((int) (short) 100, 12);
        areaRenderer0.setSeriesShape(0, shape13, false);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 10.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.awt.Paint paint3 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = chartChangeEventType5.equals((java.lang.Object) dateAxis6);
        java.awt.Stroke stroke8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis6.setAxisLineStroke(stroke8);
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) '4', paint3, stroke8);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker10);
        valueMarker10.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker10);
        int int15 = objectList0.indexOf((java.lang.Object) markerChangeEvent14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke2 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent3 = null;
        polarPlot0.datasetChanged(datasetChangeEvent3);
        int int5 = polarPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "DatasetRenderingOrder.FORWARD", image3, "hi!", "DatasetRenderingOrder.FORWARD", "({0}, {1}) = {2}");
        java.lang.String str8 = projectInfo7.getLicenceText();
        java.lang.String str9 = projectInfo7.getLicenceName();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "({0}, {1}) = {2}" + "'", str8.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str9.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(100, false);
        boolean boolean8 = statisticalLineAndShapeRenderer2.getItemShapeFilled(1, 0);
        java.lang.Boolean boolean10 = statisticalLineAndShapeRenderer2.getSeriesVisible((-1));
        java.lang.Object obj11 = statisticalLineAndShapeRenderer2.clone();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(boolean10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "DatasetRenderingOrder.FORWARD", image3, "hi!", "DatasetRenderingOrder.FORWARD", "({0}, {1}) = {2}");
        java.lang.String str8 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        spreadsheetDate2.setDescription("hi!");
        java.awt.Paint paint8 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) spreadsheetDate2);
        java.awt.Stroke stroke9 = piePlot0.getOutlineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot0.removeChangeListener(plotChangeListener10);
        float float12 = piePlot0.getBackgroundAlpha();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        piePlot0.addChangeListener(plotChangeListener13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = piePlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertNotNull(legendItemCollection15);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener5 = null;
        jFreeChart4.addProgressListener(chartProgressListener5);
        int int7 = jFreeChart4.getSubtitleCount();
        int int8 = jFreeChart4.getSubtitleCount();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = null;
        try {
            jFreeChart4.titleChanged(titleChangeEvent9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (short) 0, (java.awt.Paint) color4);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (-457));
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D2.setUpperMargin((double) 4);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D2.setUpArrow(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5);
        boolean boolean8 = itemLabelAnchor0.equals((java.lang.Object) shape5);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        statisticalLineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getNoDataMessage();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            waferMapPlot1.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "DatasetRenderingOrder.FORWARD", image3, "hi!", "DatasetRenderingOrder.FORWARD", "({0}, {1}) = {2}");
        java.lang.String str8 = projectInfo7.getLicenceText();
        java.lang.String str9 = projectInfo7.getName();
        java.lang.String str10 = projectInfo7.getCopyright();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "({0}, {1}) = {2}" + "'", str8.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        boolean boolean5 = jFreeChart4.isBorderVisible();
        jFreeChart4.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.entity.EntityCollection entityCollection12 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo(entityCollection12);
        java.awt.image.BufferedImage bufferedImage14 = jFreeChart4.createBufferedImage((int) (short) 100, 89, (double) 1, 0.0d, chartRenderingInfo13);
        org.jfree.chart.event.ChartChangeListener chartChangeListener15 = null;
        try {
            jFreeChart4.removeChangeListener(chartChangeListener15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(bufferedImage14);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0L, "EXPAND", textAnchor2, textAnchor3, (double) 2.0f);
        java.lang.String str6 = numberTick5.getText();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "EXPAND" + "'", str6.equals("EXPAND"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke2 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double7 = stackedBarRenderer3D6.getItemMargin();
        stackedBarRenderer3D6.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer11 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = areaRenderer11.getSeriesPositiveItemLabelPosition((int) (short) 0);
        stackedBarRenderer3D6.setPositiveItemLabelPositionFallback(itemLabelPosition13);
        java.awt.Color color16 = java.awt.Color.WHITE;
        stackedBarRenderer3D6.setSeriesFillPaint(10, (java.awt.Paint) color16);
        polarPlot0.setAngleGridlinePaint((java.awt.Paint) color16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        polarPlot0.setRadiusGridlinePaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator3);
        try {
            double double5 = piePlot3D1.getMaximumExplodePercent();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        statisticalLineAndShapeRenderer2.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) true);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        java.lang.Boolean boolean15 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible(0);
        statisticalLineAndShapeRenderer2.setBaseCreateEntities(true, false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer5.setPadding((double) (byte) -1, (-1.0d), 0.5d, 0.0d);
        java.lang.Object obj11 = blockContainer5.clone();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.lang.String str2 = waferMapPlot1.getNoDataMessage();
        org.jfree.data.general.WaferMapDataset waferMapDataset3 = null;
        waferMapPlot1.setDataset(waferMapDataset3);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        try {
            axisSpace0.ensureAtLeast(axisSpace2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint9 = polarPlot8.getRadiusGridlinePaint();
        stackedBarRenderer3D3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot8);
        java.lang.String str11 = polarPlot8.getPlotType();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        polarPlot8.setRenderer(polarItemRenderer12);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean1 = statisticalLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.LegendItem legendItem4 = statisticalLineAndShapeRenderer0.getLegendItem(6, 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(legendItem4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke3 = levelRenderer0.getItemOutlineStroke(100, (int) (byte) 0);
        double double4 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis3D1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        numberAxis3D1.setUpperBound((double) (short) 10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D11.setTickUnit(numberTickUnit12, false, true);
        numberAxis3D1.setTickUnit(numberTickUnit12);
        org.jfree.data.Range range17 = numberAxis3D1.getRange();
        org.jfree.data.Range range18 = numberAxis3D1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(range18);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        blockContainer5.setPadding((double) (byte) -1, (-1.0d), 0.5d, 0.0d);
        org.jfree.chart.block.Arrangement arrangement11 = blockContainer5.getArrangement();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        double double18 = rectangleInsets16.calculateBottomInset((double) 0L);
        blockContainer5.setPadding(rectangleInsets16);
        blockContainer5.setHeight((double) 100);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(arrangement11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 35.0d + "'", double18 == 35.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke5 = dateAxis4.getAxisLineStroke();
        boolean boolean6 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis4.getTimeline();
        dateAxis0.setTimeline(timeline7);
        org.jfree.data.Range range9 = null;
        try {
            dateAxis0.setRangeWithMargins(range9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeline7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer4 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = areaRenderer4.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer4.setBaseOutlineStroke(stroke7, true);
        java.awt.Stroke stroke11 = areaRenderer4.getSeriesStroke(100);
        java.awt.Paint paint13 = areaRenderer4.lookupSeriesPaint(128);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder(2.0d, (double) 2.0f, (double) 1, (double) 89, paint13);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke5 = dateAxis4.getAxisLineStroke();
        boolean boolean6 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis4.getTimeline();
        dateAxis0.setTimeline(timeline7);
        java.lang.String str9 = dateAxis0.getLabelURL();
        dateAxis0.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint13 = piePlot12.getLabelPaint();
        piePlot12.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint18 = piePlot12.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) piePlot12);
        boolean boolean20 = piePlot12.getIgnoreZeroValues();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("{0}", "RangeType.NEGATIVE", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "TextAnchor.TOP_CENTER", "");
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo5.getOptionalLibraries();
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        textTitle2.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle2.setPosition(rectangleEdge10);
        double double12 = textTitle2.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle2.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        org.jfree.chart.block.CenterArrangement centerArrangement14 = new org.jfree.chart.block.CenterArrangement();
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement14);
        java.util.List list16 = blockContainer13.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem17 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 128, (java.lang.Number) 10.0f, (java.lang.Number) (short) -1, (java.lang.Number) 0.0d, (java.lang.Number) 1.0E-8d, (java.lang.Number) (short) 10, (java.lang.Number) 6, (java.lang.Number) 1.0E-8d, list16);
        java.lang.String str18 = boxAndWhiskerItem17.toString();
        java.util.List list19 = boxAndWhiskerItem17.getOutliers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = stackedBarRenderer3D23.getGradientPaintTransformer();
        boolean boolean25 = boxAndWhiskerItem17.equals((java.lang.Object) stackedBarRenderer3D23);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState31 = stackedBarRenderer3D23.initialise(graphics2D26, rectangle2D27, categoryPlot28, 5, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setUpperMargin((double) 4);
        java.awt.Paint paint4 = numberAxis3D1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        java.awt.Color color43 = java.awt.Color.WHITE;
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot10.setOrientation(plotOrientation45);
        org.jfree.chart.axis.AxisSpace axisSpace47 = new org.jfree.chart.axis.AxisSpace();
        double double48 = axisSpace47.getRight();
        xYPlot10.setFixedDomainAxisSpace(axisSpace47);
        int int50 = xYPlot10.getSeriesCount();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.awt.Paint paint4 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        stackedBarRenderer3D3.setBaseOutlinePaint(paint4, false);
        stackedBarRenderer3D3.setRenderAsPercentages(true);
        org.jfree.chart.plot.PiePlot piePlot9 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot9.setLegendLabelToolTipGenerator(pieSectionLabelGenerator10);
        java.awt.Paint paint12 = piePlot9.getOutlinePaint();
        stackedBarRenderer3D3.setBaseFillPaint(paint12, false);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot10.setDataset(xYDataset15);
        boolean boolean17 = xYPlot10.isRangeZoomable();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int16 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) boolean15);
        int int17 = defaultKeyedValues2D0.getRowCount();
        try {
            java.lang.Comparable comparable19 = defaultKeyedValues2D0.getRowKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = xYPlot10.getDomainMarkers(layer15);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(collection16);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate5);
        double double7 = piePlot0.getExplodePercent((java.lang.Comparable) serialDate6);
        boolean boolean8 = piePlot0.isSubplot();
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 0L);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.util.TimeZone timeZone0 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNotNull(timeZone0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        statisticalLineAndShapeRenderer2.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) true);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalLineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) (byte) 100, itemLabelPosition15, true);
        boolean boolean20 = statisticalLineAndShapeRenderer2.getItemShapeVisible((int) (short) -1, 1);
        statisticalLineAndShapeRenderer2.setBaseShapesVisible(true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets6);
        java.awt.Paint paint8 = lineBorder7.getPaint();
        java.awt.Paint paint9 = lineBorder7.getPaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, 128);
        java.lang.String str3 = month2.toString();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        java.lang.Object obj10 = legendItemEntity9.clone();
        boolean boolean11 = month2.equals(obj10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "October 128" + "'", str3.equals("October 128"));
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.lang.Boolean boolean2 = statisticalLineAndShapeRenderer0.getSeriesShapesVisible(3);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType3 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str4 = categoryLabelWidthType3.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2, categoryLabelWidthType3, (float) (byte) 100);
        double double7 = categoryLabelPosition6.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryLabelPosition6.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition6);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(categoryLabelWidthType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str4.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        try {
            org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem3 = defaultBoxAndWhiskerCategoryDataset0.getItem(89, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 89, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke2 = polarPlot0.getRadiusGridlineStroke();
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo6, point2D7);
        java.awt.Paint paint9 = polarPlot0.getAngleLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        polarPlot0.setDataset(xYDataset10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        try {
            polarPlot0.zoomRangeAxes((double) 10L, plotRenderingInfo13, point2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke2 = polarPlot0.getRadiusGridlineStroke();
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo6, point2D7);
        java.awt.Paint paint9 = polarPlot0.getAngleLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        polarPlot0.setDataset(xYDataset10);
        java.lang.Object obj12 = polarPlot0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=255,g=255,b=128]", graphics2D1, (float) 255, (float) 2, textAnchor4, (double) (short) -1, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate3.getPreviousDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer4.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer4.setBaseLinesVisible(false);
        java.lang.Boolean boolean11 = statisticalLineAndShapeRenderer4.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean12 = dateRange1.equals((java.lang.Object) boolean11);
        java.util.Date date13 = dateRange1.getUpperDate();
        segmentedTimeline0.addException(date13);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis15.getStandardTickUnits();
        dateAxis15.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit21 = new org.jfree.chart.axis.DateTickUnit(2, (-1));
        dateAxis15.setTickUnit(dateTickUnit21, true, false);
        java.util.TimeZone timeZone25 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone25;
        dateAxis15.setTimeZone(timeZone25);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date13, timeZone25);
        long long29 = month28.getLastMillisecond();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28799999L + "'", long29 == 28799999L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = xYPlot10.getRenderer((-1));
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.Point2D point2D20 = null;
        org.jfree.chart.plot.PlotState plotState21 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            xYPlot10.draw(graphics2D18, rectangle2D19, point2D20, plotState21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNull(xYItemRenderer17);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.entity.EntityCollection entityCollection0 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo(entityCollection0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            chartRenderingInfo1.setChartArea(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        java.awt.Paint paint13 = valueMarker8.getOutlinePaint();
        float float14 = valueMarker8.getAlpha();
        float float15 = valueMarker8.getAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays(1900, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        try {
            org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(182, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D8 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj9 = defaultKeyedValues2D8.clone();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = chartChangeEventType10.equals((java.lang.Object) dateAxis11);
        dateAxis11.setTickMarkOutsideLength((float) 1);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color15, stroke16, rectangleInsets21);
        dateAxis11.setAxisLinePaint((java.awt.Paint) color15);
        java.util.Date date24 = dateAxis11.getMinimumDate();
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance(date24);
        int int26 = defaultKeyedValues2D8.getColumnIndex((java.lang.Comparable) serialDate25);
        java.lang.Number number27 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) (byte) 10, (java.lang.Comparable) int26);
        try {
            java.lang.Number number30 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNull(number27);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        xYPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection19 = xYPlot10.getDomainMarkers(layer18);
        int int20 = xYPlot10.getSeriesCount();
        xYPlot10.clearDomainAxes();
        java.awt.Paint paint22 = xYPlot10.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getWidthConstraintType();
        double double2 = rectangleConstraint0.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.configure();
        boolean boolean7 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) numberAxis5);
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) statisticalLineAndShapeRenderer2, dataset8);
        boolean boolean10 = statisticalLineAndShapeRenderer2.getUseFillPaint();
        java.awt.Stroke stroke12 = statisticalLineAndShapeRenderer2.lookupSeriesOutlineStroke((int) '4');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double2 = rectangleInsets0.extendHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = dataPackageResources0.getKeys();
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int8 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.util.Date date20 = spreadsheetDate2.toDate();
        spreadsheetDate2.setDescription("Preceding");
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(paint6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) dateAxis9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis9.setAxisLineStroke(stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) '4', paint6, stroke11);
        stackedBarRenderer3D3.setBaseOutlineStroke(stroke11, false);
        boolean boolean17 = stackedBarRenderer3D3.equals((java.lang.Object) 6);
        java.lang.Boolean boolean19 = stackedBarRenderer3D3.getSeriesItemLabelsVisible(1900);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(boolean19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date21 = spreadsheetDate3.toDate();
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone22;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year24);
        task25.setDescription("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        dateAxis28.setInverted(true);
        java.awt.Shape shape31 = dateAxis28.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke33 = dateAxis32.getAxisLineStroke();
        boolean boolean34 = dateAxis32.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline35 = dateAxis32.getTimeline();
        dateAxis28.setTimeline(timeline35);
        java.lang.String str37 = dateAxis28.getLabelURL();
        dateAxis28.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot40 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint41 = piePlot40.getLabelPaint();
        piePlot40.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint46 = piePlot40.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis28.setPlot((org.jfree.chart.plot.Plot) piePlot40);
        boolean boolean48 = task25.equals((java.lang.Object) dateAxis28);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(timeline35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        xYPlot10.clearDomainAxes();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        textTitle2.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle2.setPosition(rectangleEdge10);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder();
        textTitle2.setFrame((org.jfree.chart.block.BlockFrame) blockBorder12);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle2);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = numberAxis3D4.getStandardTickUnits();
        dateAxis0.setStandardTickUnits(tickUnitSource5);
        dateAxis0.setFixedDimension((double) (-1L));
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D1.setTickUnit(numberTickUnit2, false, true);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int10 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setUpperMargin((double) 'a');
        java.awt.Font font14 = categoryAxis9.getTickLabelFont((java.lang.Comparable) (byte) 100);
        categoryAxis9.setUpperMargin(0.05d);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double22 = categoryAxis9.getCategoryJava2DCoordinate(categoryAnchor17, 11, (-1), rectangle2D20, rectangleEdge21);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer25.setUseFillPaint(false);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.configure();
        boolean boolean30 = statisticalLineAndShapeRenderer25.equals((java.lang.Object) numberAxis28);
        boolean boolean31 = rectangleEdge21.equals((java.lang.Object) numberAxis28);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke33 = dateAxis32.getAxisLineStroke();
        boolean boolean34 = rectangleEdge21.equals((java.lang.Object) dateAxis32);
        try {
            double double35 = numberAxis3D1.java2DToValue((double) 28799999L, rectangle2D7, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        statisticalLineAndShapeRenderer2.setBaseSeriesVisible(false, false);
        java.awt.Color color12 = java.awt.Color.LIGHT_GRAY;
        statisticalLineAndShapeRenderer2.setSeriesOutlinePaint((int) (byte) 1, (java.awt.Paint) color12, false);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        flowArrangement4.clear();
        org.junit.Assert.assertNotNull(verticalAlignment1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        xYPlot10.clearRangeMarkers((int) (short) 100);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelPaint();
        piePlot0.setMinimumArcAngleToDraw((double) (byte) 100);
        java.lang.Class<?> wildcardClass4 = piePlot0.getClass();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3D6.getStandardTickUnits();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = numberAxis3D6.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        org.jfree.data.Range range16 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double18 = range16.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(10.0d, range16);
        numberAxis3D6.setRangeWithMargins(range16, false, false);
        java.awt.Font font23 = numberAxis3D6.getTickLabelFont();
        piePlot0.setLabelFont(font23);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        java.lang.String str2 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str2.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font6 = legendTitle5.getItemFont();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer9.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer9.setBaseLinesVisible(false);
        java.awt.Paint paint15 = statisticalLineAndShapeRenderer9.getErrorIndicatorPaint();
        java.awt.Paint paint16 = statisticalLineAndShapeRenderer9.getBaseItemLabelPaint();
        legendTitle5.setItemPaint(paint16);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list1 = defaultBoxAndWhiskerCategoryDataset0.getRowKeys();
        try {
            java.lang.Number number4 = defaultBoxAndWhiskerCategoryDataset0.getQ1Value(11, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        java.awt.Color color43 = java.awt.Color.WHITE;
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot10.setOrientation(plotOrientation45);
        java.awt.Paint paint47 = xYPlot10.getRangeGridlinePaint();
        java.awt.Stroke stroke48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot10.setDomainZeroBaselineStroke(stroke48);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset2 = polarPlot0.getDataset();
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNull(xYDataset2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            double double1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Color color4 = java.awt.Color.yellow;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(10.0d, (double) 100, (double) 1, (double) 'a', (java.awt.Paint) color4);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer6 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.lang.Object obj7 = areaRenderer6.clone();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        areaRenderer6.setBaseOutlinePaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer10 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = areaRenderer10.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer10.setBaseOutlineStroke(stroke13, true);
        java.awt.Stroke stroke17 = areaRenderer10.getSeriesStroke(100);
        java.awt.Paint paint19 = areaRenderer10.lookupSeriesPaint(128);
        java.awt.Color color20 = java.awt.Color.gray;
        java.awt.Color color21 = color20.brighter();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color4, (java.awt.Paint) color8, paint19, (java.awt.Paint) color21);
        java.awt.Shape shape27 = null;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color29 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem30 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape27, stroke28, (java.awt.Paint) color29);
        java.lang.String str31 = legendItem30.getLabel();
        boolean boolean32 = waterfallBarRenderer22.equals((java.lang.Object) str31);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(stroke17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        piePlot3.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot6 = piePlot3.getParent();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset7 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset7, 100);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset9, (java.lang.Comparable) (byte) -1, (double) 10900L, 0);
        piePlot3.setDataset(pieDataset9);
        piePlot0.setDataset(pieDataset9);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.PiePlot piePlot18 = new org.jfree.chart.plot.PiePlot();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        spreadsheetDate20.setDescription("hi!");
        java.awt.Paint paint26 = piePlot18.getSectionOutlinePaint((java.lang.Comparable) spreadsheetDate20);
        java.awt.Stroke stroke27 = piePlot18.getOutlineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        piePlot18.removeChangeListener(plotChangeListener28);
        float float30 = piePlot18.getBackgroundAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState33 = piePlot0.initialise(graphics2D16, rectangle2D17, piePlot18, (java.lang.Integer) 9999, plotRenderingInfo32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(pieDataset13);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot3 = piePlot0.getParent();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        piePlot0.setDataset(pieDataset4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator6);
        piePlot0.setStartAngle((double) 0.0f);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor10 = piePlot0.getLabelDistributor();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(1900L);
        boolean boolean5 = segment4.inExcludeSegments();
        boolean boolean6 = segment4.inExcludeSegments();
        segment4.moveIndexToStart();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, (int) (short) 100);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Locale locale1 = dataPackageResources0.getLocale();
        boolean boolean3 = dataPackageResources0.containsKey("{0}");
        try {
            java.lang.String[] strArray5 = dataPackageResources0.getStringArray("DateTickUnit[DAY, -1]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key DateTickUnit[DAY, -1]");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        multiplePiePlot1.setDataset(categoryDataset2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 0, (double) 1900);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D6.setMaximumBarWidth((-1.0d));
        double double9 = stackedBarRenderer3D6.getUpperClip();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = stackedBarRenderer3D6.getSeriesPositiveItemLabelPosition((int) (short) 10);
        stackedBarRenderer3D2.setPositiveItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.LegendItem legendItem15 = stackedBarRenderer3D2.getLegendItem(1900, 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(legendItem15);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        dateAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis3D1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        java.awt.Paint paint8 = numberAxis3D1.getTickLabelPaint();
        numberAxis3D1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list1 = defaultBoxAndWhiskerCategoryDataset0.getRowKeys();
        try {
            java.lang.Number number4 = defaultBoxAndWhiskerCategoryDataset0.getMinRegularValue(4, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        boolean boolean2 = areaRendererEndType0.equals((java.lang.Object) (short) -1);
        java.lang.String str3 = areaRendererEndType0.toString();
        org.junit.Assert.assertNotNull(areaRendererEndType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AreaRendererEndType.TAPER" + "'", str3.equals("AreaRendererEndType.TAPER"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator3 = null;
        piePlot3D1.setLegendLabelURLGenerator(pieURLGenerator3);
        java.awt.Stroke stroke5 = piePlot3D1.getBaseSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("LegendItemEntity: seriesKey=null, dataset=null");
        dateAxis1.setLabelURL("");
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        areaRenderer0.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType5 = areaRenderer0.getEndType();
        org.junit.Assert.assertNotNull(areaRendererEndType5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.lang.String str1 = piePlot0.getNoDataMessage();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        piePlot0.setLabelShadowPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        statisticalLineAndShapeRenderer2.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) true);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalLineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) (byte) 100, itemLabelPosition15, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator18 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        statisticalLineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        java.lang.Object obj20 = standardCategorySeriesLabelGenerator18.clone();
        java.lang.Object obj21 = standardCategorySeriesLabelGenerator18.clone();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = areaRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = areaRenderer0.getSeriesNegativeItemLabelPosition(6);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis3D1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.data.Range range11 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double13 = range11.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(10.0d, range11);
        numberAxis3D1.setRangeWithMargins(range11, false, false);
        double double18 = range11.getLowerBound();
        double double19 = range11.getUpperBound();
        double double21 = range11.constrain((double) (byte) 0);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 52.0d + "'", double19 == 52.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        java.lang.String str3 = categoryLabelWidthType2.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) (byte) 100);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement10);
        org.jfree.chart.block.CenterArrangement centerArrangement12 = new org.jfree.chart.block.CenterArrangement();
        blockContainer11.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement12);
        java.util.List list14 = blockContainer11.getBlocks();
        boolean boolean15 = textBlockAnchor1.equals((java.lang.Object) list14);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str3.equals("CategoryLabelWidthType.RANGE"));
        org.junit.Assert.assertNotNull(verticalAlignment7);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getOutlinePaint();
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        int int6 = keyedObjects2D4.getRowIndex((java.lang.Comparable) 1900);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) 7, (long) '4');
        java.util.Date date10 = simpleTimePeriod9.getStart();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = dateAxis11.getStandardTickUnits();
        dateAxis11.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit17 = new org.jfree.chart.axis.DateTickUnit(2, (-1));
        dateAxis11.setTickUnit(dateTickUnit17, true, false);
        keyedObjects2D4.removeObject((java.lang.Comparable) date10, (java.lang.Comparable) dateTickUnit17);
        double double22 = piePlot0.getExplodePercent((java.lang.Comparable) dateTickUnit17);
        int int23 = dateTickUnit17.getCalendarField();
        java.lang.String str24 = dateTickUnit17.toString();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(tickUnitSource12);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DateTickUnit[DAY, -1]" + "'", str24.equals("DateTickUnit[DAY, -1]"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        java.awt.Paint paint3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        piePlot3D1.setBaseSectionPaint(paint3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot3D1.getLegendLabelURLGenerator();
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        piePlot3D6.setIgnoreNullValues(false);
        boolean boolean9 = piePlot3D1.equals((java.lang.Object) piePlot3D6);
        piePlot3D1.setCircular(true, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        java.awt.Color color43 = java.awt.Color.WHITE;
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot10.setOrientation(plotOrientation45);
        java.awt.Paint paint47 = xYPlot10.getRangeGridlinePaint();
        java.awt.Paint paint48 = xYPlot10.getRangeZeroBaselinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = xYPlot10.getAxisOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        java.awt.RenderingHints renderingHints5 = null;
        try {
            jFreeChart4.setRenderingHints(renderingHints5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener5 = null;
        jFreeChart4.addProgressListener(chartProgressListener5);
        int int7 = jFreeChart4.getSubtitleCount();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.entity.EntityCollection entityCollection10 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = new org.jfree.chart.ChartRenderingInfo(entityCollection10);
        chartRenderingInfo11.clear();
        try {
            jFreeChart4.draw(graphics2D8, rectangle2D9, chartRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        boolean boolean7 = chartChangeEventType5.equals((java.lang.Object) dateAxis6);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation10 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0, (java.lang.Number) (short) 0);
        boolean boolean11 = dateAxis6.equals((java.lang.Object) (short) 0);
        dateAxis6.setAxisLineVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis6);
        boolean boolean15 = columnArrangement4.equals((java.lang.Object) dateAxis6);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.lang.String str9 = categoryAxis8.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        numberAxis10.setUpperMargin((double) 0);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D16.setMaximumBarWidth((-1.0d));
        double double19 = stackedBarRenderer3D16.getUpperClip();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot21 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int26 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        boolean boolean36 = spreadsheetDate23.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate30, (org.jfree.data.time.SerialDate) spreadsheetDate34);
        java.lang.Number number38 = defaultStatisticalCategoryDataset20.getMeanValue((java.lang.Comparable) boolean36, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range39 = stackedBarRenderer3D16.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20);
        defaultStatisticalCategoryDataset20.add((java.lang.Number) 12L, (java.lang.Number) 100.0d, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0d);
        try {
            stackedBarRenderer1.drawItem(graphics2D2, categoryItemRendererState4, rectangle2D5, categoryPlot6, categoryAxis8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset20, 12, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertNotNull(range39);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = numberAxis3D2.getStandardTickUnits();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        java.util.List list8 = numberAxis3D2.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
        org.jfree.data.Range range12 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double14 = range12.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(10.0d, range12);
        numberAxis3D2.setRangeWithMargins(range12, false, false);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D24.setMaximumBarWidth((-1.0d));
        double double27 = stackedBarRenderer3D24.getUpperClip();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int34 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int39 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        java.lang.Number number46 = defaultStatisticalCategoryDataset28.getMeanValue((java.lang.Comparable) boolean44, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range47 = stackedBarRenderer3D24.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset28);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType49 = rectangleConstraint48.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint50 = new org.jfree.chart.block.RectangleConstraint(55.0d, range12, lengthConstraintType19, (double) 2, range47, lengthConstraintType49);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(number46);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(rectangleConstraint48);
        org.junit.Assert.assertNotNull(lengthConstraintType49);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D(pieDataset0);
        double double2 = piePlot3D1.getDepthFactor();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Point2D point2D5 = null;
        org.jfree.chart.plot.PlotState plotState6 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        try {
            piePlot3D1.draw(graphics2D3, rectangle2D4, point2D5, plotState6, plotRenderingInfo7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(paint6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) dateAxis9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis9.setAxisLineStroke(stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) '4', paint6, stroke11);
        stackedBarRenderer3D3.setBaseOutlineStroke(stroke11, false);
        boolean boolean17 = stackedBarRenderer3D3.equals((java.lang.Object) 6);
        org.jfree.chart.LegendItem legendItem20 = stackedBarRenderer3D3.getLegendItem(7, (int) (byte) -1);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer23.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment27 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint28 = textFragment27.getPaint();
        java.awt.Paint paint29 = textFragment27.getPaint();
        boolean boolean30 = statisticalLineAndShapeRenderer23.equals((java.lang.Object) textFragment27);
        statisticalLineAndShapeRenderer23.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) true);
        java.awt.Paint paint34 = statisticalLineAndShapeRenderer23.getErrorIndicatorPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = null;
        statisticalLineAndShapeRenderer23.setSeriesPositiveItemLabelPosition((int) (byte) 100, itemLabelPosition36, true);
        java.lang.Boolean boolean40 = statisticalLineAndShapeRenderer23.getSeriesShapesFilled(100);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer43 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer43.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment47 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint48 = textFragment47.getPaint();
        java.awt.Paint paint49 = textFragment47.getPaint();
        boolean boolean50 = statisticalLineAndShapeRenderer43.equals((java.lang.Object) textFragment47);
        statisticalLineAndShapeRenderer43.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) true);
        java.awt.Paint paint54 = statisticalLineAndShapeRenderer43.getErrorIndicatorPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = null;
        statisticalLineAndShapeRenderer43.setSeriesPositiveItemLabelPosition((int) (byte) 100, itemLabelPosition56, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator59 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        statisticalLineAndShapeRenderer43.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator59);
        java.lang.Object obj61 = standardCategorySeriesLabelGenerator59.clone();
        statisticalLineAndShapeRenderer23.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator59);
        stackedBarRenderer3D3.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator59);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(legendItem20);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNull(boolean40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(obj61);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        java.awt.Stroke stroke9 = stackedBarRenderer3D3.getSeriesStroke((int) (byte) 10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot10.getPieChart();
        boolean boolean12 = stackedBarRenderer3D3.equals((java.lang.Object) multiplePiePlot10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = null;
        multiplePiePlot10.notifyListeners(plotChangeEvent13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = multiplePiePlot10.getInsets();
        org.jfree.chart.plot.PolarPlot polarPlot16 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint17 = polarPlot16.getRadiusGridlinePaint();
        java.awt.Stroke stroke18 = polarPlot16.getRadiusGridlineStroke();
        java.awt.Paint paint19 = polarPlot16.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        polarPlot16.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo22, point2D23);
        java.awt.Paint paint25 = polarPlot16.getAngleLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        polarPlot16.setDataset(xYDataset26);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        boolean boolean30 = chartChangeEventType28.equals((java.lang.Object) dateAxis29);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation33 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0, (java.lang.Number) (short) 0);
        boolean boolean34 = dateAxis29.equals((java.lang.Object) (short) 0);
        dateAxis29.setAxisLineVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent37 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis29);
        polarPlot16.axisChanged(axisChangeEvent37);
        multiplePiePlot10.axisChanged(axisChangeEvent37);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(chartChangeEventType28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        lineRenderer3D0.setWallPaint((java.awt.Paint) color1);
        lineRenderer3D0.setYOffset(0.0d);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            lineRenderer3D0.drawOutline(graphics2D5, categoryPlot6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, 0.0d, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        textTitle3.addChangeListener(titleChangeListener4);
        textTitle3.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle3.setPosition(rectangleEdge11);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder();
        textTitle3.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        java.lang.Object obj15 = null;
        borderArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj15);
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder25 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color18, stroke19, rectangleInsets24);
        double double27 = rectangleInsets24.calculateTopOutset((double) 100.0f);
        double double29 = rectangleInsets24.calculateRightOutset((double) (-1));
        blockContainer17.setMargin(rectangleInsets24);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        java.lang.Object obj5 = textTitle2.clone();
        double double6 = textTitle2.getContentXOffset();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement12 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment8, verticalAlignment9, (double) 100L, (double) 10);
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment9, (double) 0L, (double) (-1.0f));
        textTitle2.setHorizontalAlignment(horizontalAlignment7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(verticalAlignment9);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer8 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = areaRenderer8.getSeriesPositiveItemLabelPosition((int) (short) 0);
        stackedBarRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Paint paint13 = stackedBarRenderer3D3.lookupSeriesPaint((-460));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke5 = dateAxis4.getAxisLineStroke();
        boolean boolean6 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis4.getTimeline();
        dateAxis0.setTimeline(timeline7);
        java.lang.String str9 = dateAxis0.getLabelURL();
        dateAxis0.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint13 = piePlot12.getLabelPaint();
        piePlot12.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint18 = piePlot12.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot12);
        try {
            java.awt.image.BufferedImage bufferedImage23 = jFreeChart20.createBufferedImage(0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (0) and height (5) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke5 = dateAxis4.getAxisLineStroke();
        boolean boolean6 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis4.getTimeline();
        dateAxis0.setTimeline(timeline7);
        java.lang.String str9 = dateAxis0.getLabelURL();
        dateAxis0.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint13 = piePlot12.getLabelPaint();
        piePlot12.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint18 = piePlot12.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot12);
        jFreeChart20.setTitle("TextAnchor.TOP_CENTER");
        jFreeChart20.setTextAntiAlias(false);
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator26 = null;
        piePlot25.setLegendLabelToolTipGenerator(pieSectionLabelGenerator26);
        java.awt.Paint paint28 = piePlot25.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot25);
        boolean boolean30 = jFreeChart29.isBorderVisible();
        jFreeChart29.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.entity.EntityCollection entityCollection37 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = new org.jfree.chart.ChartRenderingInfo(entityCollection37);
        java.awt.image.BufferedImage bufferedImage39 = jFreeChart29.createBufferedImage((int) (short) 100, 89, (double) 1, 0.0d, chartRenderingInfo38);
        jFreeChart20.setBackgroundImage((java.awt.Image) bufferedImage39);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(bufferedImage39);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        boolean boolean12 = chartChangeEventType10.equals((java.lang.Object) dateAxis11);
        java.awt.Paint paint13 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean14 = chartChangeEventType10.equals((java.lang.Object) paint13);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement19 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment15, verticalAlignment16, 100.0d, (double) (short) -1);
        boolean boolean20 = chartChangeEventType10.equals((java.lang.Object) flowArrangement19);
        markerChangeEvent9.setType(chartChangeEventType10);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1900);
        org.jfree.chart.entity.EntityCollection entityCollection3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo(entityCollection3);
        boolean boolean5 = keyedObjects2D0.equals((java.lang.Object) chartRenderingInfo4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int15 = spreadsheetDate12.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        boolean boolean20 = spreadsheetDate7.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate14, (org.jfree.data.time.SerialDate) spreadsheetDate18);
        keyedObjects2D0.removeObject((java.lang.Comparable) spreadsheetDate7, (java.lang.Comparable) 10L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj4 = stackedBarRenderer3D3.clone();
        java.awt.Paint paint5 = stackedBarRenderer3D3.getBaseFillPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = numberAxis3D9.getStandardTickUnits();
        double double11 = numberAxis3D9.getUpperMargin();
        org.jfree.chart.plot.Plot plot12 = numberAxis3D9.getPlot();
        java.awt.Paint paint14 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(paint14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = chartChangeEventType16.equals((java.lang.Object) dateAxis17);
        java.awt.Stroke stroke19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis17.setAxisLineStroke(stroke19);
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) '4', paint14, stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color22, stroke23, rectangleInsets28);
        double double31 = rectangleInsets28.extendHeight((double) '4');
        valueMarker21.setLabelOffset(rectangleInsets28);
        java.awt.Font font33 = valueMarker21.getLabelFont();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        stackedBarRenderer3D3.drawRangeMarker(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) numberAxis3D9, (org.jfree.chart.plot.Marker) valueMarker21, rectangle2D34);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(tickUnitSource10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 97.0d + "'", double31 == 97.0d);
        org.junit.Assert.assertNotNull(font33);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("TextAnchor.TOP_CENTER");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint3 = polarPlot2.getRadiusGridlinePaint();
        java.awt.Stroke stroke4 = polarPlot2.getRadiusGridlineStroke();
        java.awt.Paint paint5 = polarPlot2.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot2.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo8, point2D9);
        polarPlot2.clearCornerTextItems();
        java.awt.Paint paint12 = polarPlot2.getAngleGridlinePaint();
        boolean boolean13 = standardCategoryURLGenerator1.equals((java.lang.Object) paint12);
        java.io.ObjectOutputStream objectOutputStream14 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint12, objectOutputStream14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        double double6 = stackedBarRenderer3D3.getUpperClip();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Number number25 = defaultStatisticalCategoryDataset7.getMeanValue((java.lang.Comparable) boolean23, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range26 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        defaultStatisticalCategoryDataset7.add((java.lang.Number) 12L, (java.lang.Number) 100.0d, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0d);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        double double35 = dateAxis33.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = numberAxis3D37.getStandardTickUnits();
        double double39 = numberAxis3D37.getUpperMargin();
        java.awt.Shape shape40 = numberAxis3D37.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, xYItemRenderer41);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        boolean boolean46 = chartChangeEventType44.equals((java.lang.Object) dateAxis45);
        dateAxis45.setTickMarkOutsideLength((float) 1);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color49, stroke50, rectangleInsets55);
        dateAxis45.setAxisLinePaint((java.awt.Paint) color49);
        dateAxis45.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        dateAxis61.setInverted(true);
        java.awt.Shape shape64 = dateAxis61.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke66 = dateAxis65.getAxisLineStroke();
        boolean boolean67 = dateAxis65.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline68 = dateAxis65.getTimeline();
        dateAxis61.setTimeline(timeline68);
        dateAxis45.setTimeline(timeline68);
        dateAxis45.setVerticalTickLabels(false);
        xYPlot42.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis45, false);
        java.awt.Color color75 = java.awt.Color.WHITE;
        xYPlot42.setRangeTickBandPaint((java.awt.Paint) color75);
        org.jfree.chart.plot.PlotOrientation plotOrientation77 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot42.setOrientation(plotOrientation77);
        org.jfree.chart.axis.AxisSpace axisSpace79 = new org.jfree.chart.axis.AxisSpace();
        double double80 = axisSpace79.getRight();
        xYPlot42.setFixedDomainAxisSpace(axisSpace79);
        java.awt.Graphics2D graphics2D82 = null;
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        xYPlot42.drawBackgroundImage(graphics2D82, rectangle2D83);
        defaultStatisticalCategoryDataset7.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot42);
        java.awt.Paint paint87 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder88 = new org.jfree.chart.block.BlockBorder(paint87);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType89 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis90 = new org.jfree.chart.axis.DateAxis();
        boolean boolean91 = chartChangeEventType89.equals((java.lang.Object) dateAxis90);
        java.awt.Stroke stroke92 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis90.setAxisLineStroke(stroke92);
        org.jfree.chart.plot.ValueMarker valueMarker94 = new org.jfree.chart.plot.ValueMarker((double) '4', paint87, stroke92);
        xYPlot42.setRangeCrosshairStroke(stroke92);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis97 = xYPlot42.getRangeAxisForDataset(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(timeline68);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(plotOrientation77);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(chartChangeEventType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(stroke92);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        dateAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.Range range2 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double3 = range2.getLength();
        org.jfree.data.Range range6 = org.jfree.data.Range.expand(range2, (double) 0L, (double) 0L);
        double double7 = range2.getUpperBound();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 53.0d + "'", double3 == 53.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = chartChangeEventType2.equals((java.lang.Object) dateAxis3);
        dateAxis3.setTickMarkOutsideLength((float) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke8, rectangleInsets13);
        dateAxis3.setAxisLinePaint((java.awt.Paint) color7);
        java.util.Date date16 = dateAxis3.getMinimumDate();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        int int18 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) serialDate17);
        try {
            defaultKeyedValues2D0.removeRow(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.data.DefaultKeyedValues defaultKeyedValues1 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues1.removeValue((java.lang.Comparable) 1.0E-5d);
        java.util.List list4 = defaultKeyedValues1.getKeys();
        projectInfo0.setContributors(list4);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        java.lang.Boolean boolean11 = statisticalLineAndShapeRenderer2.getSeriesShapesFilled(7);
        statisticalLineAndShapeRenderer2.setSeriesVisibleInLegend(3, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.lang.Object obj2 = dataPackageResources0.handleGetObject("10");
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) -1);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke7 = dateAxis6.getAxisLineStroke();
        double double8 = dateAxis6.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = numberAxis3D10.getStandardTickUnits();
        double double12 = numberAxis3D10.getUpperMargin();
        java.awt.Shape shape13 = numberAxis3D10.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer14);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot15);
        java.lang.Object obj17 = xYPlot15.clone();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart4 = multiplePiePlot3.getPieChart();
        textTitle2.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart4);
        int int6 = jFreeChart4.getBackgroundImageAlignment();
        java.lang.Object obj7 = jFreeChart4.clone();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(jFreeChart4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        java.awt.Font font6 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) 100);
        categoryAxis1.setUpperMargin(0.05d);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 11, (-1), rectangle2D12, rectangleEdge13);
        double double15 = categoryAxis1.getLabelAngle();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 28799999L);
        categoryAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        spreadsheetDate2.setDescription("hi!");
        java.awt.Paint paint8 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) spreadsheetDate2);
        java.awt.Stroke stroke9 = piePlot0.getLabelLinkStroke();
        java.awt.Shape shape10 = piePlot0.getLegendItemShape();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity13 = new org.jfree.chart.entity.TickLabelEntity(shape10, "DateTickUnit[DAY, -1]", "java.awt.Color[r=255,g=255,b=128]");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot10.setDataset(xYDataset15);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer20.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer20.setBaseLinesVisible(false);
        java.lang.Boolean boolean27 = statisticalLineAndShapeRenderer20.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean28 = dateRange17.equals((java.lang.Object) boolean27);
        java.util.Date date29 = dateRange17.getUpperDate();
        org.jfree.data.general.Dataset dataset30 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateRange17, dataset30);
        xYPlot10.datasetChanged(datasetChangeEvent31);
        boolean boolean33 = xYPlot10.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean3 = statisticalLineAndShapeRenderer0.getItemLineVisible((int) '#', (int) (byte) -1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        statisticalLineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setInverted(true);
        java.awt.Shape shape10 = dateAxis7.getDownArrow();
        statisticalLineAndShapeRenderer0.setBaseShape(shape10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
        int int7 = defaultBoxAndWhiskerCategoryDataset0.getColumnIndex((java.lang.Comparable) "TextAnchor.TOP_CENTER");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int16 = spreadsheetDate13.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean26 = spreadsheetDate13.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate20, (org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean27 = spreadsheetDate10.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        int int28 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) boolean27);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer8 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = areaRenderer8.getSeriesPositiveItemLabelPosition((int) (short) 0);
        stackedBarRenderer3D3.setPositiveItemLabelPositionFallback(itemLabelPosition10);
        java.awt.Color color13 = java.awt.Color.WHITE;
        stackedBarRenderer3D3.setSeriesFillPaint(10, (java.awt.Paint) color13);
        java.awt.Paint paint16 = stackedBarRenderer3D3.lookupSeriesFillPaint(0);
        java.lang.Object obj17 = null;
        boolean boolean18 = stackedBarRenderer3D3.equals(obj17);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke3 = levelRenderer0.getItemOutlineStroke(100, (int) (byte) 0);
        levelRenderer0.setMaximumItemWidth((double) 100L);
        double double6 = levelRenderer0.getMaximumItemWidth();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis3D8.getStandardTickUnits();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        java.util.List list14 = numberAxis3D8.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge13);
        org.jfree.data.Range range18 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double20 = range18.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(10.0d, range18);
        numberAxis3D8.setRangeWithMargins(range18, false, false);
        java.awt.Font font25 = numberAxis3D8.getTickLabelFont();
        levelRenderer0.setBaseItemLabelFont(font25, false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Last" + "'", str1.equals("Last"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setUpperMargin((double) 4);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D1.setUpArrow(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "DatasetRenderingOrder.FORWARD");
        java.awt.Shape shape8 = chartEntity7.getArea();
        chartEntity7.setURLText("{0}");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) 7, (double) 1900L, true);
        java.awt.Paint paint4 = stackedBarRenderer3D3.getBasePaint();
        stackedBarRenderer3D3.setSeriesVisibleInLegend(10, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str2.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.lang.String str2 = categoryAxis1.getLabelToolTip();
        categoryAxis1.setMaximumCategoryLabelLines((int) (byte) -1);
        float float5 = categoryAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 1900L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) 1.0E-5d);
        java.util.List list3 = defaultKeyedValues0.getKeys();
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByValues(sortOrder4);
        java.lang.Number number7 = null;
        defaultKeyedValues0.addValue((java.lang.Comparable) "Preceding", number7);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(sortOrder4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(1900L);
        segment4.dec(10L);
        boolean boolean7 = segment4.inExcludeSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) 1.0E-5d);
        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues0.sortByValues(sortOrder3);
        defaultKeyedValues0.setValue((java.lang.Comparable) "LegendItemEntity: seriesKey=null, dataset=null", (double) 3);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.DESCENDING;
        defaultKeyedValues0.sortByValues(sortOrder8);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertNotNull(sortOrder8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (short) 100, 9, (int) (byte) 100);
        segmentedTimeline3.setAdjustForDaylightSaving(true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke3 = levelRenderer0.getItemOutlineStroke(100, (int) (byte) 0);
        levelRenderer0.setMaximumItemWidth((double) 100L);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        levelRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6);
        levelRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, true);
        java.lang.Boolean boolean13 = levelRenderer0.getSeriesItemLabelsVisible(4);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = jFreeChart4.getPadding();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.CenterArrangement centerArrangement6 = new org.jfree.chart.block.CenterArrangement();
        blockContainer5.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement6);
        boolean boolean8 = blockContainer5.isEmpty();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke5 = dateAxis4.getAxisLineStroke();
        boolean boolean6 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis4.getTimeline();
        dateAxis0.setTimeline(timeline7);
        java.lang.String str9 = dateAxis0.getLabelURL();
        dateAxis0.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint13 = piePlot12.getLabelPaint();
        piePlot12.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint18 = piePlot12.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) piePlot12);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            piePlot12.drawOutline(graphics2D20, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "DatasetRenderingOrder.FORWARD", image3, "hi!", "DatasetRenderingOrder.FORWARD", "({0}, {1}) = {2}");
        java.lang.String str8 = projectInfo7.getLicenceText();
        java.lang.String str9 = projectInfo7.getName();
        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list11 = projectInfo10.getContributors();
        projectInfo7.addLibrary((org.jfree.chart.ui.Library) projectInfo10);
        projectInfo10.setCopyright("October 128");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "({0}, {1}) = {2}" + "'", str8.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(projectInfo10);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint3 = polarPlot2.getRadiusGridlinePaint();
        java.awt.Stroke stroke4 = polarPlot2.getRadiusGridlineStroke();
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot2);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            polarPlot2.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        boolean boolean8 = chartChangeEventType6.equals((java.lang.Object) dateAxis7);
        java.awt.Paint paint9 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        boolean boolean10 = chartChangeEventType6.equals((java.lang.Object) paint9);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "hi!", paint9);
        categoryAxis1.setTickLabelsVisible(true);
        java.lang.Comparable comparable14 = null;
        try {
            categoryAxis1.removeCategoryLabelToolTip(comparable14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart3 = multiplePiePlot2.getPieChart();
        try {
            org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) plotRenderingInfo0, jFreeChart3, (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(jFreeChart3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        textTitle2.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle2.setPosition(rectangleEdge10);
        double double12 = textTitle2.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle2.getTextAlignment();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            textTitle2.setBounds(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int8 = spreadsheetDate5.compare((org.jfree.data.time.SerialDate) spreadsheetDate7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean18 = spreadsheetDate5.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate12, (org.jfree.data.time.SerialDate) spreadsheetDate16);
        boolean boolean19 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate16);
        java.util.Date date20 = spreadsheetDate2.toDate();
        java.util.TimeZone timeZone21 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone21;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20, timeZone21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int32 = spreadsheetDate29.compare((org.jfree.data.time.SerialDate) spreadsheetDate31);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate34 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int37 = spreadsheetDate34.compare((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean42 = spreadsheetDate29.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate36, (org.jfree.data.time.SerialDate) spreadsheetDate40);
        boolean boolean43 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate40);
        java.util.Date date44 = spreadsheetDate26.toDate();
        java.util.TimeZone timeZone45 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone45;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44, timeZone45);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date20, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year48.previous();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod49);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj4 = stackedBarRenderer3D3.clone();
        double double5 = stackedBarRenderer3D3.getYOffset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj10 = stackedBarRenderer3D9.clone();
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        stackedBarRenderer3D9.setWallPaint((java.awt.Paint) color11);
        stackedBarRenderer3D3.setBasePaint((java.awt.Paint) color11, true);
        float[] floatArray17 = new float[] { 12L, (-1L) };
        try {
            float[] floatArray18 = color11.getComponents(floatArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelPaint();
        piePlot0.setMinimumArcAngleToDraw((double) (byte) 100);
        java.lang.Class<?> wildcardClass4 = piePlot0.getClass();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = piePlot0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(pieURLGenerator5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        double double3 = numberAxis3D1.getUpperMargin();
        java.awt.Shape shape4 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        numberAxis3D1.setStandardTickUnits(tickUnitSource5);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint9 = polarPlot8.getRadiusGridlinePaint();
        stackedBarRenderer3D3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot8);
        java.lang.String str11 = polarPlot8.getPlotType();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        polarPlot8.rendererChanged(rendererChangeEvent12);
        try {
            polarPlot8.zoom((double) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        xYPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection19 = xYPlot10.getDomainMarkers(layer18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot10.getRangeAxisLocation();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        try {
            xYPlot10.setRenderer((-1), xYItemRenderer22, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int5 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) (-1.0f));
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, (int) (byte) -1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer2.getSeriesItemLabelPaint((int) '4');
        java.lang.Boolean boolean13 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible(11);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke3 = levelRenderer0.getItemOutlineStroke(100, (int) (byte) 0);
        levelRenderer0.setMaximumItemWidth((double) 100L);
        double double6 = levelRenderer0.getMaximumItemWidth();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = levelRenderer0.getLegendItems();
        boolean boolean9 = levelRenderer0.isSeriesVisible(11);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("Polar Plot");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("Polar Plot");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.String str5 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: Polar Plot" + "'", str5.equals("org.jfree.data.UnknownKeyException: Polar Plot"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation(number0, number1);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color3 = java.awt.Color.getColor("({0}, {1}) = {2}", color2);
        boolean boolean4 = borderArrangement0.equals((java.lang.Object) color2);
        float[] floatArray10 = new float[] { (byte) 10, (short) 10, ' ', 10L, (-460) };
        float[] floatArray11 = color2.getRGBComponents(floatArray10);
        float[] floatArray18 = new float[] { 0L, 10L, 1, 182, 1.0f, (byte) 1 };
        float[] floatArray19 = color2.getRGBComponents(floatArray18);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 7, (long) '4');
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D1.setTickUnit(numberTickUnit2, false, true);
        boolean boolean6 = numberAxis3D1.isAutoTickUnitSelection();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double11 = stackedBarRenderer3D10.getItemMargin();
        java.awt.Shape shape12 = stackedBarRenderer3D10.getBaseShape();
        numberAxis3D1.setRightArrow(shape12);
        double double14 = numberAxis3D1.getFixedAutoRange();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setUpperMargin((double) 4);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D1.setUpArrow(shape4);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape4, "DatasetRenderingOrder.FORWARD");
        chartEntity7.setURLText("");
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        java.awt.Font font6 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) 100);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke8, rectangleInsets13);
        categoryAxis1.setTickMarkStroke(stroke8);
        org.jfree.data.UnknownKeyException unknownKeyException17 = new org.jfree.data.UnknownKeyException("Polar Plot");
        org.jfree.data.UnknownKeyException unknownKeyException19 = new org.jfree.data.UnknownKeyException("Polar Plot");
        unknownKeyException17.addSuppressed((java.lang.Throwable) unknownKeyException19);
        boolean boolean21 = categoryAxis1.equals((java.lang.Object) unknownKeyException19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int31 = spreadsheetDate28.compare((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean41 = spreadsheetDate28.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, (org.jfree.data.time.SerialDate) spreadsheetDate39);
        boolean boolean42 = spreadsheetDate25.isOn((org.jfree.data.time.SerialDate) spreadsheetDate39);
        java.util.Date date43 = spreadsheetDate25.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate46);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate50);
        int int52 = spreadsheetDate50.toSerial();
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate56 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int59 = spreadsheetDate56.compare((org.jfree.data.time.SerialDate) spreadsheetDate58);
        int int60 = spreadsheetDate58.getDayOfMonth();
        boolean boolean61 = spreadsheetDate50.isInRange(serialDate54, (org.jfree.data.time.SerialDate) spreadsheetDate58);
        boolean boolean63 = spreadsheetDate25.isInRange(serialDate47, serialDate54, 128);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addDays((int) ' ', serialDate47);
        java.awt.Font font65 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 9 + "'", int60 == 9);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(font65);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(paint6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) dateAxis9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis9.setAxisLineStroke(stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) '4', paint6, stroke11);
        stackedBarRenderer3D3.setBaseOutlineStroke(stroke11, false);
        boolean boolean17 = stackedBarRenderer3D3.equals((java.lang.Object) 6);
        stackedBarRenderer3D3.setBaseCreateEntities(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        java.awt.Stroke stroke9 = stackedBarRenderer3D3.getSeriesStroke((int) (byte) 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset10 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list11 = defaultBoxAndWhiskerCategoryDataset10.getRowKeys();
        java.lang.Number number14 = defaultBoxAndWhiskerCategoryDataset10.getValue((java.lang.Comparable) 100, (java.lang.Comparable) (short) 1);
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        java.util.Date date19 = spreadsheetDate18.toDate();
        java.lang.Number number20 = defaultBoxAndWhiskerCategoryDataset10.getMaxRegularValue((java.lang.Comparable) (short) -1, (java.lang.Comparable) date19);
        try {
            java.lang.Number number23 = defaultBoxAndWhiskerCategoryDataset10.getQ3Value(182, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 182, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(number20);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer3 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = areaRenderer3.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer3.setBaseOutlineStroke(stroke6, true);
        java.awt.Stroke stroke10 = areaRenderer3.getSeriesStroke(100);
        java.awt.Stroke stroke11 = areaRenderer3.getBaseStroke();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint13 = polarPlot12.getRadiusGridlinePaint();
        java.awt.Stroke stroke14 = polarPlot12.getRadiusGridlineStroke();
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke11, stroke14 };
        java.awt.Stroke[] strokeArray16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = chartChangeEventType17.equals((java.lang.Object) dateAxis18);
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis18.setAxisLineStroke(stroke20);
        java.awt.Shape shape22 = dateAxis18.getUpArrow();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double27 = stackedBarRenderer3D26.getItemMargin();
        java.awt.Shape shape28 = stackedBarRenderer3D26.getBaseShape();
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] { shape22, shape28 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray15, strokeArray16, shapeArray29);
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextPaint();
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextPaint();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        xYPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot10.getRangeAxisEdge((int) 'a');
        boolean boolean20 = xYPlot10.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.CenterArrangement centerArrangement6 = new org.jfree.chart.block.CenterArrangement();
        blockContainer5.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement6);
        java.util.List list8 = blockContainer5.getBlocks();
        java.lang.String str9 = blockContainer5.getID();
        org.jfree.chart.block.Arrangement arrangement10 = blockContainer5.getArrangement();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(arrangement10);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.event.ChartProgressListener chartProgressListener5 = null;
        jFreeChart4.addProgressListener(chartProgressListener5);
        boolean boolean7 = jFreeChart4.getAntiAlias();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        java.awt.Color color43 = java.awt.Color.WHITE;
        xYPlot10.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        int int46 = xYPlot10.indexOf(xYDataset45);
        xYPlot10.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color1 = java.awt.Color.gray;
        java.awt.Color color2 = color1.brighter();
        boolean boolean3 = booleanList0.equals((java.lang.Object) color2);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer4.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer4.setBaseLinesVisible(false);
        java.lang.Boolean boolean11 = statisticalLineAndShapeRenderer4.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean12 = dateRange1.equals((java.lang.Object) boolean11);
        java.util.Date date13 = dateRange1.getUpperDate();
        segmentedTimeline0.addException(date13);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D15 = new org.jfree.data.DefaultKeyedValues2D();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = chartChangeEventType16.equals((java.lang.Object) dateAxis17);
        dateAxis17.setTickMarkOutsideLength((float) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color21, stroke22, rectangleInsets27);
        dateAxis17.setAxisLinePaint((java.awt.Paint) color21);
        java.util.Date date30 = dateAxis17.getMinimumDate();
        defaultKeyedValues2D15.removeColumn((java.lang.Comparable) date30);
        java.util.Date date32 = null;
        try {
            boolean boolean33 = segmentedTimeline0.containsDomainRange(date30, date32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets6);
        double double9 = rectangleInsets6.calculateTopOutset((double) 100.0f);
        double double11 = rectangleInsets6.calculateBottomInset((double) 10L);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 35.0d + "'", double11 == 35.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setUpperMargin((double) 4);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D1.setUpArrow(shape4);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) ' ');
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape8, "Polar Plot");
        numberAxis3D1.setUpArrow(shape8);
        java.awt.Paint paint12 = numberAxis3D1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        double double3 = numberAxis3D1.getUpperMargin();
        java.awt.Shape shape4 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape4);
        java.lang.String str6 = chartEntity5.getToolTipText();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        textTitle3.addChangeListener(titleChangeListener4);
        textTitle3.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle3.setPosition(rectangleEdge11);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder();
        textTitle3.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        java.lang.Object obj15 = null;
        borderArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj15);
        org.jfree.chart.block.BlockContainer blockContainer17 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) borderArrangement0);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement22 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment18, verticalAlignment19, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer23 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement22);
        org.jfree.chart.block.CenterArrangement centerArrangement24 = new org.jfree.chart.block.CenterArrangement();
        blockContainer23.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement24);
        java.util.List list26 = blockContainer23.getBlocks();
        java.lang.String str27 = blockContainer23.getID();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = rectangleConstraint29.toFixedWidth((double) (short) 10);
        try {
            org.jfree.chart.util.Size2D size2D32 = borderArrangement0.arrange(blockContainer23, graphics2D28, rectangleConstraint31);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(rectangleConstraint29);
        org.junit.Assert.assertNotNull(rectangleConstraint31);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) '#');
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer4.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint9 = textFragment8.getPaint();
        java.awt.Paint paint10 = textFragment8.getPaint();
        boolean boolean11 = statisticalLineAndShapeRenderer4.equals((java.lang.Object) textFragment8);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer4.getSeriesItemLabelPaint((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int23 = spreadsheetDate20.compare((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int28 = spreadsheetDate25.compare((org.jfree.data.time.SerialDate) spreadsheetDate27);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean33 = spreadsheetDate20.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate27, (org.jfree.data.time.SerialDate) spreadsheetDate31);
        boolean boolean34 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
        java.util.Date date35 = spreadsheetDate17.toDate();
        java.util.TimeZone timeZone36 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone36;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date35, timeZone36);
        org.jfree.data.gantt.Task task39 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year38);
        boolean boolean40 = statisticalLineAndShapeRenderer4.equals((java.lang.Object) year38);
        boolean boolean41 = numberTickUnit1.equals((java.lang.Object) statisticalLineAndShapeRenderer4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(1900L);
        segment4.dec(10L);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline7.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment11 = segmentedTimeline7.getSegment(1900L);
        boolean boolean12 = segment11.inExcludeSegments();
        boolean boolean13 = segment4.contains(segment11);
        boolean boolean16 = segment11.contained((long) (short) 0, (long) 2);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(segmentedTimeline7);
        org.junit.Assert.assertNotNull(segment11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 10, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = stackedBarRenderer3D3.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) dateAxis8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis8.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis8.getUpArrow();
        org.jfree.chart.plot.Plot plot13 = dateAxis8.getPlot();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        stackedBarRenderer3D3.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis8, rectangle2D14, 1.05d);
        java.awt.Color color17 = java.awt.Color.lightGray;
        stackedBarRenderer3D3.setBaseItemLabelPaint((java.awt.Paint) color17, true);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = stackedBarRenderer3D3.initialise(graphics2D20, rectangle2D21, categoryPlot22, (int) 'a', plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getOutlinePaint();
        java.awt.Stroke stroke4 = piePlot0.getLabelOutlineStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, 100);
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) 35.0d, (java.lang.Comparable) 1.0d);
        org.jfree.data.general.DatasetGroup datasetGroup6 = null;
        try {
            defaultBoxAndWhiskerCategoryDataset0.setGroup(datasetGroup6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.configure();
        boolean boolean7 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) numberAxis5);
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) statisticalLineAndShapeRenderer2, dataset8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalLineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 1);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        statisticalLineAndShapeRenderer2.setSeriesItemLabelPaint(12, paint13, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        statisticalLineAndShapeRenderer2.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) true);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalLineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) (byte) 100, itemLabelPosition15, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator18 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        statisticalLineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        statisticalLineAndShapeRenderer2.setDrawOutlines(false);
        statisticalLineAndShapeRenderer2.setBaseItemLabelsVisible(true, false);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int6 = spreadsheetDate3.compare((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int11 = spreadsheetDate8.compare((org.jfree.data.time.SerialDate) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        boolean boolean16 = spreadsheetDate3.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, (org.jfree.data.time.SerialDate) spreadsheetDate14);
        java.lang.Number number18 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) boolean16, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (short) 100);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(range21);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D3.setDrawBarOutline(true);
        stackedBarRenderer3D3.setBaseSeriesVisible(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = stackedBarRenderer3D3.getPositiveItemLabelPositionFallback();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent11);
        org.junit.Assert.assertNull(itemLabelPosition10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        java.awt.Shape shape8 = dateAxis4.getUpArrow();
        java.awt.Paint paint10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(paint10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        java.awt.Stroke stroke15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis13.setAxisLineStroke(stroke15);
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) '4', paint10, stroke15);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker17);
        valueMarker17.setValue(0.0d);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            lineRenderer3D0.drawRangeMarker(graphics2D1, categoryPlot2, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.plot.Marker) valueMarker17, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        java.lang.Object obj6 = blockContainer5.clone();
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D3.setDrawBarOutline(true);
        boolean boolean8 = stackedBarRenderer3D3.getBaseItemLabelsVisible();
        java.awt.Shape shape9 = stackedBarRenderer3D3.getBaseShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        stackedBarRenderer3D3.setBaseItemLabelGenerator(categoryItemLabelGenerator10);
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator13 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        stackedBarRenderer3D3.setSeriesToolTipGenerator(31, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator13, false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TextAnchor.TOP_CENTER");
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D3.setDrawBarOutline(true);
        boolean boolean8 = stackedBarRenderer3D3.getBaseItemLabelsVisible();
        java.awt.Shape shape9 = stackedBarRenderer3D3.getBaseShape();
        stackedBarRenderer3D3.setDrawBarOutline(false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis1.setAxisLineStroke(stroke3);
        java.lang.String str5 = dateAxis1.getLabelURL();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            polarPlot0.drawBackground(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        java.awt.Font font6 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) "EXPAND");
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            double double14 = categoryAxis1.getCategoryEnd((int) 'a', 7, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        boolean boolean5 = stackedBarRenderer3D3.isSeriesItemLabelsVisible((int) (short) 100);
        stackedBarRenderer3D3.setMinimumBarLength((double) 1900L);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        stackedBarRenderer3D3.notifyListeners(rendererChangeEvent8);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date21 = spreadsheetDate3.toDate();
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone22;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year24);
        task25.setDescription("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
        java.lang.String str28 = task25.getDescription();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str28.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        java.awt.Stroke stroke9 = stackedBarRenderer3D3.getSeriesStroke((int) (byte) 10);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset10 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list11 = defaultBoxAndWhiskerCategoryDataset10.getRowKeys();
        java.lang.Number number14 = defaultBoxAndWhiskerCategoryDataset10.getValue((java.lang.Comparable) 100, (java.lang.Comparable) (short) 1);
        org.jfree.data.Range range15 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset10);
        try {
            java.lang.Comparable comparable17 = defaultBoxAndWhiskerCategoryDataset10.getRowKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        java.awt.Stroke stroke2 = ringPlot1.getSeparatorStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setUpperMargin((double) 4);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis3D1.getTickLabelInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis3D1.setTickUnit(numberTickUnit5);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            double double10 = numberAxis3D1.lengthToJava2D((double) 12L, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = statisticalLineAndShapeRenderer2.getPlot();
        org.junit.Assert.assertNull(categoryPlot8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.RingPlot ringPlot1 = new org.jfree.chart.plot.RingPlot(pieDataset0);
        boolean boolean2 = ringPlot1.getSeparatorsVisible();
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot3.setLegendLabelToolTipGenerator(pieSectionLabelGenerator4);
        org.jfree.chart.plot.PiePlot piePlot6 = new org.jfree.chart.plot.PiePlot();
        piePlot6.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot9 = piePlot6.getParent();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset10 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset10, 100);
        org.jfree.data.general.PieDataset pieDataset16 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset12, (java.lang.Comparable) (byte) -1, (double) 10900L, 0);
        piePlot6.setDataset(pieDataset12);
        piePlot3.setDataset(pieDataset12);
        org.jfree.chart.util.Rotation rotation19 = piePlot3.getDirection();
        ringPlot1.setDirection(rotation19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(pieDataset12);
        org.junit.Assert.assertNotNull(pieDataset16);
        org.junit.Assert.assertNotNull(rotation19);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets11);
        dateAxis1.setAxisLinePaint((java.awt.Paint) color5);
        java.util.Date date14 = dateAxis1.getMinimumDate();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date14);
        org.jfree.chart.plot.PiePlot piePlot16 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator17 = null;
        piePlot16.setLegendLabelToolTipGenerator(pieSectionLabelGenerator17);
        java.awt.Paint paint19 = piePlot16.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        boolean boolean23 = chartChangeEventType21.equals((java.lang.Object) dateAxis22);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) date14, jFreeChart20, chartChangeEventType21);
        try {
            org.jfree.chart.title.Title title26 = jFreeChart20.getSubtitle((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("hi!", font1);
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        textTitle2.addChangeListener(titleChangeListener3);
        textTitle2.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle2.setPosition(rectangleEdge10);
        double double12 = textTitle2.getWidth();
        textTitle2.setWidth((double) 10);
        java.lang.String str15 = textTitle2.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Locale locale1 = dataPackageResources0.getLocale();
        java.util.Locale locale2 = dataPackageResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = rendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = areaRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer0.setBaseOutlineStroke(stroke3, true);
        java.awt.Paint paint7 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder(paint7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        boolean boolean11 = chartChangeEventType9.equals((java.lang.Object) dateAxis10);
        java.awt.Stroke stroke12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis10.setAxisLineStroke(stroke12);
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) '4', paint7, stroke12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker14);
        valueMarker14.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent18 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker14);
        java.awt.Paint paint19 = valueMarker14.getOutlinePaint();
        areaRenderer0.setBaseFillPaint(paint19);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 5);
        long long3 = segmentedTimeline0.getStartTime();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 28799999L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        org.jfree.chart.block.CenterArrangement centerArrangement14 = new org.jfree.chart.block.CenterArrangement();
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement14);
        java.util.List list16 = blockContainer13.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem17 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 128, (java.lang.Number) 10.0f, (java.lang.Number) (short) -1, (java.lang.Number) 0.0d, (java.lang.Number) 1.0E-8d, (java.lang.Number) (short) 10, (java.lang.Number) 6, (java.lang.Number) 1.0E-8d, list16);
        java.lang.String str18 = boxAndWhiskerItem17.toString();
        java.lang.Number number19 = boxAndWhiskerItem17.getQ3();
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0d + "'", number19.equals(0.0d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = valueMarker8.getLabelAnchor();
        try {
            valueMarker8.setAlpha((float) 60000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder7 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets6);
        double double9 = rectangleInsets6.calculateTopOutset((double) 100.0f);
        double double11 = rectangleInsets6.calculateRightOutset((double) (-1));
        double double13 = rectangleInsets6.calculateBottomOutset((double) (-2208960000000L));
        org.jfree.chart.util.UnitType unitType14 = rectangleInsets6.getUnitType();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int26 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean31 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.lang.Number number33 = defaultStatisticalCategoryDataset15.getMeanValue((java.lang.Comparable) boolean31, (java.lang.Comparable) 100.0d);
        boolean boolean34 = unitType14.equals((java.lang.Object) 100.0d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 35.0d + "'", double13 == 35.0d);
        org.junit.Assert.assertNotNull(unitType14);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(number33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        double double6 = stackedBarRenderer3D3.getUpperClip();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Number number25 = defaultStatisticalCategoryDataset7.getMeanValue((java.lang.Comparable) boolean23, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range26 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        defaultStatisticalCategoryDataset7.add((java.lang.Number) 12L, (java.lang.Number) 100.0d, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0d);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        double double35 = dateAxis33.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = numberAxis3D37.getStandardTickUnits();
        double double39 = numberAxis3D37.getUpperMargin();
        java.awt.Shape shape40 = numberAxis3D37.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, xYItemRenderer41);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        boolean boolean46 = chartChangeEventType44.equals((java.lang.Object) dateAxis45);
        dateAxis45.setTickMarkOutsideLength((float) 1);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color49, stroke50, rectangleInsets55);
        dateAxis45.setAxisLinePaint((java.awt.Paint) color49);
        dateAxis45.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        dateAxis61.setInverted(true);
        java.awt.Shape shape64 = dateAxis61.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke66 = dateAxis65.getAxisLineStroke();
        boolean boolean67 = dateAxis65.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline68 = dateAxis65.getTimeline();
        dateAxis61.setTimeline(timeline68);
        dateAxis45.setTimeline(timeline68);
        dateAxis45.setVerticalTickLabels(false);
        xYPlot42.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis45, false);
        java.awt.Color color75 = java.awt.Color.WHITE;
        xYPlot42.setRangeTickBandPaint((java.awt.Paint) color75);
        org.jfree.chart.plot.PlotOrientation plotOrientation77 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot42.setOrientation(plotOrientation77);
        org.jfree.chart.axis.AxisSpace axisSpace79 = new org.jfree.chart.axis.AxisSpace();
        double double80 = axisSpace79.getRight();
        xYPlot42.setFixedDomainAxisSpace(axisSpace79);
        java.awt.Graphics2D graphics2D82 = null;
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        xYPlot42.drawBackgroundImage(graphics2D82, rectangle2D83);
        defaultStatisticalCategoryDataset7.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot42);
        boolean boolean86 = xYPlot42.isDomainGridlinesVisible();
        java.awt.Stroke stroke87 = xYPlot42.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation89 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        xYPlot42.setDomainAxisLocation((int) (byte) 1, axisLocation89);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(timeline68);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(plotOrientation77);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(axisLocation89);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        xYPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot10.getRangeAxisEdge((int) 'a');
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder20 = null;
        try {
            xYPlot10.setSeriesRenderingOrder(seriesRenderingOrder20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis3D1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.data.Range range11 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double13 = range11.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(10.0d, range11);
        numberAxis3D1.setRangeWithMargins(range11, false, false);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange();
        numberAxis3D1.setRangeWithMargins((org.jfree.data.Range) dateRange18, true, true);
        double double22 = numberAxis3D1.getUpperBound();
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = numberAxis3D1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.05d + "'", double22 == 1.05d);
        org.junit.Assert.assertNotNull(tickUnitSource23);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) 1.0E-5d);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double6 = defaultBoxAndWhiskerCategoryDataset4.getRangeLowerBound(true);
        java.lang.Number number9 = defaultBoxAndWhiskerCategoryDataset4.getMaxOutlier((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
        int int11 = defaultBoxAndWhiskerCategoryDataset4.getColumnIndex((java.lang.Comparable) "TextAnchor.TOP_CENTER");
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset4, false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((long) 7, (long) '4');
        java.util.Date date17 = simpleTimePeriod16.getStart();
        java.lang.Number number19 = defaultBoxAndWhiskerCategoryDataset4.getQ3Value((java.lang.Comparable) date17, (java.lang.Comparable) 10900L);
        try {
            defaultKeyedValues0.insertValue(9999, (java.lang.Comparable) 10900L, (java.lang.Number) 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(number19);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        java.awt.Font font6 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) "EXPAND");
        org.jfree.data.general.PieDataset pieDataset10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D(pieDataset10);
        double double12 = piePlot3D11.getDepthFactor();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator13 = null;
        piePlot3D11.setLegendLabelURLGenerator(pieURLGenerator13);
        boolean boolean15 = piePlot3D11.isSubplot();
        piePlot3D11.setCircular(true);
        piePlot3D11.setDepthFactor((double) 3);
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("hi!", font21);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot23 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart24 = multiplePiePlot23.getPieChart();
        textTitle22.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart24);
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("hi!", font27);
        textTitle28.setURLText("({0}, {1}) = {2}");
        jFreeChart24.addSubtitle((org.jfree.chart.title.Title) textTitle28);
        piePlot3D11.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart24);
        boolean boolean33 = categoryAxis1.equals((java.lang.Object) piePlot3D11);
        org.jfree.chart.plot.Plot plot34 = piePlot3D11.getRootPlot();
        java.awt.Paint paint35 = piePlot3D11.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2d + "'", double12 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(jFreeChart24);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(plot34);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) 'a', 1, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        boolean boolean12 = categoryAxis1.isVisible();
        double double13 = categoryAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean3 = statisticalLineAndShapeRenderer0.getItemShapeFilled(0, (int) (short) 0);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState6 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
        org.jfree.chart.entity.EntityCollection entityCollection7 = categoryItemRendererState6.getEntityCollection();
        categoryItemRendererState6.setBarWidth((double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int14 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setUpperMargin((double) 'a');
        java.awt.Font font18 = categoryAxis13.getTickLabelFont((java.lang.Comparable) (byte) 100);
        categoryAxis13.setUpperMargin(0.05d);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double26 = categoryAxis13.getCategoryJava2DCoordinate(categoryAnchor21, 11, (-1), rectangle2D24, rectangleEdge25);
        double double27 = categoryAxis13.getLabelAngle();
        int int28 = categoryAxis13.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (short) 0, (double) 1900);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D36 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D36.setMaximumBarWidth((-1.0d));
        double double39 = stackedBarRenderer3D36.getUpperClip();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition41 = stackedBarRenderer3D36.getSeriesPositiveItemLabelPosition((int) (short) 10);
        stackedBarRenderer3D32.setPositiveItemLabelPositionFallback(itemLabelPosition41);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset43 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double45 = defaultBoxAndWhiskerCategoryDataset43.getRangeLowerBound(true);
        java.lang.Number number48 = defaultBoxAndWhiskerCategoryDataset43.getMaxOutlier((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate50 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D51 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj52 = defaultKeyedValues2D51.clone();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType53 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        boolean boolean55 = chartChangeEventType53.equals((java.lang.Object) dateAxis54);
        dateAxis54.setTickMarkOutsideLength((float) 1);
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder65 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color58, stroke59, rectangleInsets64);
        dateAxis54.setAxisLinePaint((java.awt.Paint) color58);
        java.util.Date date67 = dateAxis54.getMinimumDate();
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.createInstance(date67);
        int int69 = defaultKeyedValues2D51.getColumnIndex((java.lang.Comparable) serialDate68);
        java.lang.Number number70 = defaultBoxAndWhiskerCategoryDataset43.getMaxOutlier((java.lang.Comparable) (byte) 10, (java.lang.Comparable) int69);
        org.jfree.data.Range range71 = stackedBarRenderer3D32.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset43);
        try {
            statisticalLineAndShapeRenderer0.drawItem(graphics2D4, categoryItemRendererState6, rectangle2D10, categoryPlot11, categoryAxis13, valueAxis29, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset43, 3, 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(entityCollection7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition41);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNull(number48);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(chartChangeEventType53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNull(number70);
        org.junit.Assert.assertNull(range71);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis1.setAxisLineStroke(stroke3);
        java.awt.Shape shape5 = dateAxis1.getUpArrow();
        org.jfree.chart.plot.Plot plot6 = dateAxis1.getPlot();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.AxisState axisState8 = new org.jfree.chart.axis.AxisState();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("hi!", font11);
        org.jfree.chart.event.TitleChangeListener titleChangeListener13 = null;
        textTitle12.addChangeListener(titleChangeListener13);
        textTitle12.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle12.setPosition(rectangleEdge20);
        try {
            java.util.List list22 = dateAxis1.refreshTicks(graphics2D7, axisState8, rectangle2D9, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(plot6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        double double3 = numberAxis3D1.getUpperMargin();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        numberAxis3D1.centerRange((double) 9999);
        numberAxis3D1.setAutoRange(false);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        double double3 = numberAxis3D1.getUpperMargin();
        java.awt.Shape shape4 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        java.lang.Object obj6 = legendItemEntity5.clone();
        org.jfree.data.general.Dataset dataset7 = legendItemEntity5.getDataset();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(dataset7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, 128);
        try {
            org.jfree.data.time.Year year3 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (128) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        java.awt.Paint paint13 = valueMarker8.getOutlinePaint();
        valueMarker8.setLabel("");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset16);
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint19 = polarPlot18.getRadiusGridlinePaint();
        java.awt.Stroke stroke20 = polarPlot18.getRadiusGridlineStroke();
        defaultStatisticalCategoryDataset16.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot18);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        polarPlot18.setDataset(xYDataset22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = dateAxis24.getStandardTickUnits();
        dateAxis24.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = new org.jfree.chart.axis.DateTickUnit(2, (-1));
        dateAxis24.setTickUnit(dateTickUnit30, true, false);
        org.jfree.data.Range range34 = polarPlot18.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis24);
        valueMarker8.addChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot18);
        valueMarker8.setValue((double) 100.0f);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint9 = polarPlot8.getRadiusGridlinePaint();
        stackedBarRenderer3D3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot8);
        java.lang.String str11 = polarPlot8.getPlotType();
        polarPlot8.addCornerTextItem("Layer.BACKGROUND");
        java.lang.Object obj14 = polarPlot8.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.addOptionalLibrary("October 128");
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo2);
        org.jfree.chart.entity.EntityCollection entityCollection4 = categoryItemRendererState3.getEntityCollection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = categoryItemRendererState3.getInfo();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int10 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setUpperMargin((double) 'a');
        java.awt.Font font14 = categoryAxis9.getTickLabelFont((java.lang.Comparable) (byte) 100);
        categoryAxis9.setUpperMargin(0.05d);
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) (short) -1, "{0}");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D21.setUpperMargin((double) 4);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        numberAxis3D21.setUpArrow(shape24);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 1, (float) ' ');
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape28, "Polar Plot");
        numberAxis3D21.setUpArrow(shape28);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset32 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double34 = defaultBoxAndWhiskerCategoryDataset32.getRangeLowerBound(true);
        java.lang.Number number37 = defaultBoxAndWhiskerCategoryDataset32.getMaxOutlier((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
        int int39 = defaultBoxAndWhiskerCategoryDataset32.getColumnIndex((java.lang.Comparable) "TextAnchor.TOP_CENTER");
        try {
            waterfallBarRenderer0.drawItem(graphics2D1, categoryItemRendererState3, rectangle2D6, categoryPlot7, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset32, 3, 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(entityCollection4);
        org.junit.Assert.assertNull(plotRenderingInfo5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot10.getDomainAxisEdge(12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge14);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date21 = spreadsheetDate3.toDate();
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone22;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year24);
        java.lang.Double double26 = task25.getPercentComplete();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int36 = spreadsheetDate33.compare((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int41 = spreadsheetDate38.compare((org.jfree.data.time.SerialDate) spreadsheetDate40);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean46 = spreadsheetDate33.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate40, (org.jfree.data.time.SerialDate) spreadsheetDate44);
        boolean boolean47 = spreadsheetDate30.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
        java.util.Date date48 = spreadsheetDate30.toDate();
        java.util.TimeZone timeZone49 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone49;
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date48, timeZone49);
        org.jfree.data.gantt.Task task52 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year51);
        java.lang.Double double53 = task52.getPercentComplete();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int63 = spreadsheetDate60.compare((org.jfree.data.time.SerialDate) spreadsheetDate62);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate65 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int68 = spreadsheetDate65.compare((org.jfree.data.time.SerialDate) spreadsheetDate67);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate71);
        boolean boolean73 = spreadsheetDate60.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate67, (org.jfree.data.time.SerialDate) spreadsheetDate71);
        boolean boolean74 = spreadsheetDate57.isOn((org.jfree.data.time.SerialDate) spreadsheetDate71);
        java.util.Date date75 = spreadsheetDate57.toDate();
        java.util.TimeZone timeZone76 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone76;
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date75, timeZone76);
        org.jfree.data.gantt.Task task79 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year78);
        java.lang.Double double80 = task79.getPercentComplete();
        task52.addSubtask(task79);
        task25.removeSubtask(task79);
        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month((int) (short) 10, 128);
        task79.setDuration((org.jfree.data.time.TimePeriod) month85);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(double26);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(double53);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(double80);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = stackedBarRenderer3D3.getGradientPaintTransformer();
        java.awt.Paint paint5 = stackedBarRenderer3D3.getBasePaint();
        java.awt.Paint paint6 = null;
        try {
            stackedBarRenderer3D3.setBaseItemLabelPaint(paint6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        java.awt.Shape shape5 = stackedBarRenderer3D3.getBaseShape();
        boolean boolean6 = stackedBarRenderer3D3.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("hi!", font10);
        org.jfree.chart.event.TitleChangeListener titleChangeListener12 = null;
        textTitle11.addChangeListener(titleChangeListener12);
        textTitle11.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle11.setPosition(rectangleEdge19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = categoryAxis1.draw(graphics2D5, (double) 255, rectangle2D7, rectangle2D8, rectangleEdge19, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) 'a', 1, rectangle2D6, rectangleEdge7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(2);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 2, font11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int15 = categoryAxis14.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis14.getCategoryJava2DCoordinate(categoryAnchor16, (int) 'a', 1, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D23.setTickMarksVisible(false);
        boolean boolean26 = categoryAnchor16.equals((java.lang.Object) false);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor16, 9999, 0, rectangle2D29, rectangleEdge30);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer32 = new org.jfree.chart.renderer.category.AreaRenderer();
        areaRenderer32.setSeriesItemLabelsVisible((int) (short) 10, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition39 = areaRenderer32.getPositiveItemLabelPosition(9999, (int) (byte) 100);
        boolean boolean40 = categoryAnchor16.equals((java.lang.Object) 9999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        java.awt.Stroke stroke9 = stackedBarRenderer3D3.getSeriesStroke((int) (byte) 10);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot10 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart11 = multiplePiePlot10.getPieChart();
        boolean boolean12 = stackedBarRenderer3D3.equals((java.lang.Object) multiplePiePlot10);
        java.awt.Paint paint13 = multiplePiePlot10.getAggregatedItemsPaint();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.Point2D point2D16 = null;
        org.jfree.chart.plot.PlotState plotState17 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        try {
            multiplePiePlot10.draw(graphics2D14, rectangle2D15, point2D16, plotState17, plotRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNotNull(jFreeChart11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = valueMarker8.getLabelAnchor();
        java.awt.Stroke stroke11 = valueMarker8.getStroke();
        java.awt.Stroke stroke12 = valueMarker8.getStroke();
        float float13 = valueMarker8.getAlpha();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = new org.jfree.chart.plot.PlotState();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            piePlot3D0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font6 = legendTitle5.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        double double13 = rectangleInsets11.calculateRightInset((double) 89);
        legendTitle5.setItemLabelPadding(rectangleInsets11);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.util.Size2D size2D17 = legendTitle5.arrange(graphics2D15, rectangleConstraint16);
        org.jfree.data.Range range18 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = rectangleConstraint16.toRangeWidth(range18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint16);
        org.junit.Assert.assertNotNull(size2D17);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer3 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = areaRenderer3.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer3.setBaseOutlineStroke(stroke6, true);
        java.awt.Stroke stroke10 = areaRenderer3.getSeriesStroke(100);
        java.awt.Stroke stroke11 = areaRenderer3.getBaseStroke();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint13 = polarPlot12.getRadiusGridlinePaint();
        java.awt.Stroke stroke14 = polarPlot12.getRadiusGridlineStroke();
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke11, stroke14 };
        java.awt.Stroke[] strokeArray16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = chartChangeEventType17.equals((java.lang.Object) dateAxis18);
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis18.setAxisLineStroke(stroke20);
        java.awt.Shape shape22 = dateAxis18.getUpArrow();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double27 = stackedBarRenderer3D26.getItemMargin();
        java.awt.Shape shape28 = stackedBarRenderer3D26.getBaseShape();
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] { shape22, shape28 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray15, strokeArray16, shapeArray29);
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextPaint();
        java.awt.Shape shape32 = defaultDrawingSupplier30.getNextShape();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setBackgroundImageAlpha(0.0f);
        double double3 = piePlot0.getMaximumLabelWidth();
        java.awt.Paint paint4 = piePlot0.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        boolean boolean5 = jFreeChart4.isBorderVisible();
        jFreeChart4.setBackgroundImageAlignment((int) '#');
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = jFreeChart4.getPadding();
        org.jfree.chart.title.TextTitle textTitle9 = jFreeChart4.getTitle();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNull(textTitle9);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = areaRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer0.setBaseOutlineStroke(stroke3, true);
        java.awt.Stroke stroke7 = areaRenderer0.getSeriesStroke(100);
        boolean boolean8 = areaRenderer0.getBaseSeriesVisible();
        java.lang.Boolean boolean10 = areaRenderer0.getSeriesVisibleInLegend(1);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(boolean10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        double double6 = stackedBarRenderer3D3.getUpperClip();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Number number25 = defaultStatisticalCategoryDataset7.getMeanValue((java.lang.Comparable) boolean23, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range26 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        defaultStatisticalCategoryDataset7.add((java.lang.Number) 12L, (java.lang.Number) 100.0d, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0d);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        double double35 = dateAxis33.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = numberAxis3D37.getStandardTickUnits();
        double double39 = numberAxis3D37.getUpperMargin();
        java.awt.Shape shape40 = numberAxis3D37.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, xYItemRenderer41);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        boolean boolean46 = chartChangeEventType44.equals((java.lang.Object) dateAxis45);
        dateAxis45.setTickMarkOutsideLength((float) 1);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color49, stroke50, rectangleInsets55);
        dateAxis45.setAxisLinePaint((java.awt.Paint) color49);
        dateAxis45.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        dateAxis61.setInverted(true);
        java.awt.Shape shape64 = dateAxis61.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke66 = dateAxis65.getAxisLineStroke();
        boolean boolean67 = dateAxis65.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline68 = dateAxis65.getTimeline();
        dateAxis61.setTimeline(timeline68);
        dateAxis45.setTimeline(timeline68);
        dateAxis45.setVerticalTickLabels(false);
        xYPlot42.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis45, false);
        java.awt.Color color75 = java.awt.Color.WHITE;
        xYPlot42.setRangeTickBandPaint((java.awt.Paint) color75);
        org.jfree.chart.plot.PlotOrientation plotOrientation77 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot42.setOrientation(plotOrientation77);
        org.jfree.chart.axis.AxisSpace axisSpace79 = new org.jfree.chart.axis.AxisSpace();
        double double80 = axisSpace79.getRight();
        xYPlot42.setFixedDomainAxisSpace(axisSpace79);
        java.awt.Graphics2D graphics2D82 = null;
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        xYPlot42.drawBackgroundImage(graphics2D82, rectangle2D83);
        defaultStatisticalCategoryDataset7.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot42);
        boolean boolean86 = xYPlot42.isDomainGridlinesVisible();
        java.awt.Stroke stroke87 = xYPlot42.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation88 = xYPlot42.getRangeAxisLocation();
        java.awt.Color color89 = java.awt.Color.gray;
        java.awt.Color color90 = color89.brighter();
        xYPlot42.setDomainTickBandPaint((java.awt.Paint) color90);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(timeline68);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(plotOrientation77);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(axisLocation88);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(color90);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = stackedBarRenderer3D3.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        boolean boolean9 = chartChangeEventType7.equals((java.lang.Object) dateAxis8);
        java.awt.Stroke stroke10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis8.setAxisLineStroke(stroke10);
        java.awt.Shape shape12 = dateAxis8.getUpArrow();
        org.jfree.chart.plot.Plot plot13 = dateAxis8.getPlot();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        stackedBarRenderer3D3.drawRangeGridline(graphics2D5, categoryPlot6, (org.jfree.chart.axis.ValueAxis) dateAxis8, rectangle2D14, 1.05d);
        java.awt.Color color17 = java.awt.Color.lightGray;
        stackedBarRenderer3D3.setBaseItemLabelPaint((java.awt.Paint) color17, true);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        boolean boolean22 = chartChangeEventType20.equals((java.lang.Object) dateAxis21);
        dateAxis21.setTickMarkOutsideLength((float) 1);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color25, stroke26, rectangleInsets31);
        dateAxis21.setAxisLinePaint((java.awt.Paint) color25);
        java.awt.color.ColorSpace colorSpace34 = color25.getColorSpace();
        org.jfree.chart.block.BorderArrangement borderArrangement35 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color38 = java.awt.Color.getColor("({0}, {1}) = {2}", color37);
        boolean boolean39 = borderArrangement35.equals((java.lang.Object) color37);
        float[] floatArray45 = new float[] { (byte) 10, (short) 10, ' ', 10L, (-460) };
        float[] floatArray46 = color37.getRGBComponents(floatArray45);
        float[] floatArray47 = color17.getColorComponents(colorSpace34, floatArray45);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(plot13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1900);
        java.util.List list3 = keyedObjects2D0.getColumnKeys();
        keyedObjects2D0.removeColumn((java.lang.Comparable) "LegendItemEntity: seriesKey=null, dataset=null");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline6.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment(1900L);
        segment10.dec(10L);
        int int13 = keyedObjects2D0.getRowIndex((java.lang.Comparable) segment10);
        keyedObjects2D0.removeColumn((java.lang.Comparable) 182);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj4 = stackedBarRenderer3D3.clone();
        double double5 = stackedBarRenderer3D3.getYOffset();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj10 = stackedBarRenderer3D9.clone();
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        stackedBarRenderer3D9.setWallPaint((java.awt.Paint) color11);
        stackedBarRenderer3D3.setBasePaint((java.awt.Paint) color11, true);
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer16 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke19 = levelRenderer16.getItemOutlineStroke(100, (int) (byte) 0);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition();
        double double21 = itemLabelPosition20.getAngle();
        levelRenderer16.setBaseNegativeItemLabelPosition(itemLabelPosition20, true);
        stackedBarRenderer3D3.setSeriesPositiveItemLabelPosition(0, itemLabelPosition20, false);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        java.awt.Paint paint6 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(paint6);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        boolean boolean10 = chartChangeEventType8.equals((java.lang.Object) dateAxis9);
        java.awt.Stroke stroke11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis9.setAxisLineStroke(stroke11);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) '4', paint6, stroke11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color14, stroke15, rectangleInsets20);
        double double23 = rectangleInsets20.extendHeight((double) '4');
        valueMarker13.setLabelOffset(rectangleInsets20);
        jFreeChart4.setPadding(rectangleInsets20);
        double double27 = rectangleInsets20.extendHeight((double) (byte) 10);
        double double29 = rectangleInsets20.calculateLeftInset((double) 9999);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 97.0d + "'", double23 == 97.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 55.0d + "'", double27 == 55.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 35.0d + "'", double29 == 35.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke2 = polarPlot0.getRadiusGridlineStroke();
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo6, point2D7);
        java.awt.Paint paint9 = polarPlot0.getAngleLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        polarPlot0.setDataset(xYDataset10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation17 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0, (java.lang.Number) (short) 0);
        boolean boolean18 = dateAxis13.equals((java.lang.Object) (short) 0);
        dateAxis13.setAxisLineVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        polarPlot0.axisChanged(axisChangeEvent21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        polarPlot0.zoomDomainAxes((double) (byte) 0, plotRenderingInfo24, point2D25);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle8.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.lang.Object obj14 = textTitle8.draw(graphics2D11, rectangle2D12, (java.lang.Object) "{0}");
        boolean boolean15 = legendTitle5.equals((java.lang.Object) graphics2D11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str18 = rectangleConstraint17.toString();
        org.jfree.data.Range range21 = new org.jfree.data.Range((double) (-1L), (double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint17.toRangeHeight(range21);
        org.jfree.chart.util.Size2D size2D23 = legendTitle5.arrange(graphics2D16, rectangleConstraint17);
        double double24 = size2D23.getHeight();
        size2D23.setHeight((double) 4);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str18.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = null;
        try {
            xYPlot10.setSeriesRenderingOrder(seriesRenderingOrder13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint2 = textFragment1.getPaint();
        java.lang.String str3 = textFragment1.getText();
        java.awt.Paint paint4 = textFragment1.getPaint();
        float float5 = textFragment1.getBaselineOffset();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot3 = piePlot0.getParent();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        piePlot0.setDataset(pieDataset4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator6);
        piePlot0.setCircular(false, true);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        piePlot0.setBaseSectionOutlinePaint((java.awt.Paint) color11);
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.data.time.DateRange dateRange1 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer4.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer4.setBaseLinesVisible(false);
        java.lang.Boolean boolean11 = statisticalLineAndShapeRenderer4.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean12 = dateRange1.equals((java.lang.Object) boolean11);
        java.util.Date date13 = dateRange1.getUpperDate();
        long long14 = segmentedTimeline0.toTimelineValue(date13);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 644288400000L + "'", long14 == 644288400000L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double3 = defaultBoxAndWhiskerCategoryDataset1.getRangeLowerBound(true);
        java.lang.Number number6 = defaultBoxAndWhiskerCategoryDataset1.getMaxOutlier((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
        int int8 = defaultBoxAndWhiskerCategoryDataset1.getColumnIndex((java.lang.Comparable) "TextAnchor.TOP_CENTER");
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1, false);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((long) 7, (long) '4');
        java.util.Date date14 = simpleTimePeriod13.getStart();
        java.lang.Number number16 = defaultBoxAndWhiskerCategoryDataset1.getQ3Value((java.lang.Comparable) date14, (java.lang.Comparable) 10900L);
        try {
            java.lang.String str18 = standardCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(number16);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke2 = polarPlot0.getRadiusGridlineStroke();
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo6, point2D7);
        java.awt.Paint paint9 = polarPlot0.getAngleLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        polarPlot0.setDataset(xYDataset10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation17 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0, (java.lang.Number) (short) 0);
        boolean boolean18 = dateAxis13.equals((java.lang.Object) (short) 0);
        dateAxis13.setAxisLineVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent21 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis13);
        polarPlot0.axisChanged(axisChangeEvent21);
        polarPlot0.setNoDataMessage("VerticalAlignment.BOTTOM");
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) 'a', 1, rectangle2D6, rectangleEdge7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance(2);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 2, font11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int15 = categoryAxis14.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis14.getCategoryJava2DCoordinate(categoryAnchor16, (int) 'a', 1, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D23 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D23.setTickMarksVisible(false);
        boolean boolean26 = categoryAnchor16.equals((java.lang.Object) false);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor16, 9999, 0, rectangle2D29, rectangleEdge30);
        java.lang.String str32 = categoryAnchor16.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor16);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "CategoryAnchor.START" + "'", str32.equals("CategoryAnchor.START"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth(1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) 1.0E-5d);
        java.util.List list3 = defaultKeyedValues0.getKeys();
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder4);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline6.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment10 = segmentedTimeline6.getSegment(1900L);
        segment10.dec(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segment10.copy();
        defaultKeyedValues0.addValue((java.lang.Comparable) segment13, (java.lang.Number) 89);
        long long17 = segment13.calculateSegmentNumber((long) 1900);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNotNull(segmentedTimeline6);
        org.junit.Assert.assertNotNull(segment10);
        org.junit.Assert.assertNotNull(segment13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "", "AreaRendererEndType.TAPER");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color3 = java.awt.Color.getColor("({0}, {1}) = {2}", color2);
        boolean boolean4 = booleanList0.equals((java.lang.Object) color3);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("EXPAND");
        boolean boolean7 = booleanList0.equals((java.lang.Object) "EXPAND");
        org.jfree.data.Range range10 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double11 = range10.getLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = numberAxis3D13.getStandardTickUnits();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        java.util.List list19 = numberAxis3D13.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge18);
        boolean boolean20 = range10.equals((java.lang.Object) graphics2D15);
        boolean boolean21 = booleanList0.equals((java.lang.Object) graphics2D15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 53.0d + "'", double11 == 53.0d);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        textTitle3.addChangeListener(titleChangeListener4);
        textTitle3.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle3.setPosition(rectangleEdge11);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder();
        textTitle3.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        java.lang.Object obj15 = null;
        borderArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textTitle3.setTextAlignment(horizontalAlignment17);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint1 = piePlot0.getLabelPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D5.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D5.setDrawBarOutline(true);
        stackedBarRenderer3D5.setBaseCreateEntities(false, true);
        boolean boolean13 = piePlot0.equals((java.lang.Object) stackedBarRenderer3D5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        piePlot0.handleClick((int) '#', 3, plotRenderingInfo16);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setUpperMargin((double) 4);
        boolean boolean4 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) boolean4);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(1900L);
        boolean boolean6 = segment4.contains((long) 7);
        long long7 = segment4.getSegmentNumber();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        double double1 = axisSpace0.getRight();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(1900, (org.jfree.data.time.SerialDate) spreadsheetDate4);
        boolean boolean6 = axisSpace0.equals((java.lang.Object) spreadsheetDate4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = xYPlot10.getRenderer((-1));
        java.awt.Stroke stroke18 = xYPlot10.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot10.getDomainAxisLocation((-128));
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNull(xYItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation20);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) 100L, (double) 10);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment2, (double) 0L, (double) (-1.0f));
        java.lang.Class<?> wildcardClass9 = flowArrangement8.getClass();
        flowArrangement8.clear();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(horizontalAlignment1);
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        double double6 = stackedBarRenderer3D3.getUpperClip();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Number number25 = defaultStatisticalCategoryDataset7.getMeanValue((java.lang.Comparable) boolean23, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range26 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        defaultStatisticalCategoryDataset7.add((java.lang.Number) 12L, (java.lang.Number) 100.0d, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0d);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        double double35 = dateAxis33.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = numberAxis3D37.getStandardTickUnits();
        double double39 = numberAxis3D37.getUpperMargin();
        java.awt.Shape shape40 = numberAxis3D37.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, xYItemRenderer41);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        boolean boolean46 = chartChangeEventType44.equals((java.lang.Object) dateAxis45);
        dateAxis45.setTickMarkOutsideLength((float) 1);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color49, stroke50, rectangleInsets55);
        dateAxis45.setAxisLinePaint((java.awt.Paint) color49);
        dateAxis45.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        dateAxis61.setInverted(true);
        java.awt.Shape shape64 = dateAxis61.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke66 = dateAxis65.getAxisLineStroke();
        boolean boolean67 = dateAxis65.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline68 = dateAxis65.getTimeline();
        dateAxis61.setTimeline(timeline68);
        dateAxis45.setTimeline(timeline68);
        dateAxis45.setVerticalTickLabels(false);
        xYPlot42.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis45, false);
        java.awt.Color color75 = java.awt.Color.WHITE;
        xYPlot42.setRangeTickBandPaint((java.awt.Paint) color75);
        org.jfree.chart.plot.PlotOrientation plotOrientation77 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot42.setOrientation(plotOrientation77);
        org.jfree.chart.axis.AxisSpace axisSpace79 = new org.jfree.chart.axis.AxisSpace();
        double double80 = axisSpace79.getRight();
        xYPlot42.setFixedDomainAxisSpace(axisSpace79);
        java.awt.Graphics2D graphics2D82 = null;
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        xYPlot42.drawBackgroundImage(graphics2D82, rectangle2D83);
        defaultStatisticalCategoryDataset7.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot42);
        try {
            java.lang.Number number88 = defaultStatisticalCategoryDataset7.getMeanValue(89, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 89, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(timeline68);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(plotOrientation77);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint3 = polarPlot2.getRadiusGridlinePaint();
        java.awt.Stroke stroke4 = polarPlot2.getRadiusGridlineStroke();
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean24 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, (org.jfree.data.time.SerialDate) spreadsheetDate22);
        boolean boolean25 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        boolean boolean28 = chartChangeEventType26.equals((java.lang.Object) dateAxis27);
        org.jfree.chart.axis.DateTickUnit dateTickUnit31 = new org.jfree.chart.axis.DateTickUnit(2, (-1));
        dateAxis27.setTickUnit(dateTickUnit31);
        org.jfree.data.time.DateRange dateRange33 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer36 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer36.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer36.setBaseLinesVisible(false);
        java.lang.Boolean boolean43 = statisticalLineAndShapeRenderer36.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean44 = dateRange33.equals((java.lang.Object) boolean43);
        java.util.Date date45 = dateRange33.getUpperDate();
        java.lang.String str46 = dateTickUnit31.dateToString(date45);
        java.lang.Number number47 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) spreadsheetDate22, (java.lang.Comparable) dateTickUnit31);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(chartChangeEventType26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(boolean43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "12/31/69" + "'", str46.equals("12/31/69"));
        org.junit.Assert.assertNull(number47);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5);
        blockContainer6.setPadding((double) (byte) -1, (-1.0d), 0.5d, 0.0d);
        boolean boolean12 = tickUnits0.equals((java.lang.Object) 0.0d);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = dateAxis13.getStandardTickUnits();
        dateAxis13.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit19 = new org.jfree.chart.axis.DateTickUnit(2, (-1));
        dateAxis13.setTickUnit(dateTickUnit19, true, false);
        tickUnits0.add((org.jfree.chart.axis.TickUnit) dateTickUnit19);
        int int24 = dateTickUnit19.getCalendarField();
        org.junit.Assert.assertNotNull(verticalAlignment2);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D2 = new org.jfree.chart.plot.PiePlot3D(pieDataset1);
        double double3 = piePlot3D2.getDepthFactor();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator4 = null;
        piePlot3D2.setLegendLabelURLGenerator(pieURLGenerator4);
        boolean boolean6 = piePlot3D2.isSubplot();
        piePlot3D2.setCircular(true);
        piePlot3D2.setDepthFactor((double) 3);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot14.getPieChart();
        textTitle13.addChangeListener((org.jfree.chart.event.TitleChangeListener) jFreeChart15);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("hi!", font18);
        textTitle19.setURLText("({0}, {1}) = {2}");
        jFreeChart15.addSubtitle((org.jfree.chart.title.Title) textTitle19);
        piePlot3D2.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart15);
        org.jfree.chart.JFreeChart jFreeChart24 = new org.jfree.chart.JFreeChart("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", (org.jfree.chart.plot.Plot) piePlot3D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("10", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            lineRenderer3D0.drawDomainGridline(graphics2D1, categoryPlot2, rectangle2D3, (double) (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = piePlot1.getLabelPaint();
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 100);
        java.lang.Class<?> wildcardClass5 = piePlot1.getClass();
        java.io.InputStream inputStream6 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", (java.lang.Class) wildcardClass5);
        java.lang.ClassLoader classLoader7 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNull(inputStream6);
        org.junit.Assert.assertNotNull(classLoader7);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        double double6 = stackedBarRenderer3D3.getUpperClip();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot8 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int13 = spreadsheetDate10.compare((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int18 = spreadsheetDate15.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        boolean boolean23 = spreadsheetDate10.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate17, (org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.lang.Number number25 = defaultStatisticalCategoryDataset7.getMeanValue((java.lang.Comparable) boolean23, (java.lang.Comparable) 100.0d);
        org.jfree.data.Range range26 = stackedBarRenderer3D3.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        defaultStatisticalCategoryDataset7.add((java.lang.Number) 12L, (java.lang.Number) 100.0d, (java.lang.Comparable) 100.0f, (java.lang.Comparable) 1.0d);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        double double35 = dateAxis33.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D37 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = numberAxis3D37.getStandardTickUnits();
        double double39 = numberAxis3D37.getUpperMargin();
        java.awt.Shape shape40 = numberAxis3D37.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) numberAxis3D37, xYItemRenderer41);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        boolean boolean46 = chartChangeEventType44.equals((java.lang.Object) dateAxis45);
        dateAxis45.setTickMarkOutsideLength((float) 1);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets55 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder56 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color49, stroke50, rectangleInsets55);
        dateAxis45.setAxisLinePaint((java.awt.Paint) color49);
        dateAxis45.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        dateAxis61.setInverted(true);
        java.awt.Shape shape64 = dateAxis61.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke66 = dateAxis65.getAxisLineStroke();
        boolean boolean67 = dateAxis65.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline68 = dateAxis65.getTimeline();
        dateAxis61.setTimeline(timeline68);
        dateAxis45.setTimeline(timeline68);
        dateAxis45.setVerticalTickLabels(false);
        xYPlot42.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis45, false);
        java.awt.Color color75 = java.awt.Color.WHITE;
        xYPlot42.setRangeTickBandPaint((java.awt.Paint) color75);
        org.jfree.chart.plot.PlotOrientation plotOrientation77 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot42.setOrientation(plotOrientation77);
        org.jfree.chart.axis.AxisSpace axisSpace79 = new org.jfree.chart.axis.AxisSpace();
        double double80 = axisSpace79.getRight();
        xYPlot42.setFixedDomainAxisSpace(axisSpace79);
        java.awt.Graphics2D graphics2D82 = null;
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        xYPlot42.drawBackgroundImage(graphics2D82, rectangle2D83);
        defaultStatisticalCategoryDataset7.addChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot42);
        java.awt.Paint paint87 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder88 = new org.jfree.chart.block.BlockBorder(paint87);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType89 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis90 = new org.jfree.chart.axis.DateAxis();
        boolean boolean91 = chartChangeEventType89.equals((java.lang.Object) dateAxis90);
        java.awt.Stroke stroke92 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis90.setAxisLineStroke(stroke92);
        org.jfree.chart.plot.ValueMarker valueMarker94 = new org.jfree.chart.plot.ValueMarker((double) '4', paint87, stroke92);
        xYPlot42.setRangeCrosshairStroke(stroke92);
        org.jfree.chart.util.RectangleEdge rectangleEdge96 = xYPlot42.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(chartChangeEventType44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(timeline68);
        org.junit.Assert.assertNotNull(color75);
        org.junit.Assert.assertNotNull(plotOrientation77);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(paint87);
        org.junit.Assert.assertNotNull(chartChangeEventType89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(stroke92);
        org.junit.Assert.assertNotNull(rectangleEdge96);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        xYPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection19 = xYPlot10.getDomainMarkers(layer18);
        boolean boolean20 = xYPlot10.isDomainZoomable();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape4, stroke5, (java.awt.Paint) color6);
        java.text.AttributedString attributedString8 = legendItem7.getAttributedLabel();
        java.awt.Paint paint9 = legendItem7.getOutlinePaint();
        boolean boolean10 = legendItem7.isShapeFilled();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(attributedString8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = dateAxis0.getStandardTickUnits();
        java.lang.String str2 = dateAxis0.getLabelURL();
        dateAxis0.setNegativeArrowVisible(false);
        org.junit.Assert.assertNotNull(tickUnitSource1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int14 = spreadsheetDate11.compare((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean19 = spreadsheetDate6.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate13, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        boolean boolean20 = spreadsheetDate3.isOn((org.jfree.data.time.SerialDate) spreadsheetDate17);
        java.util.Date date21 = spreadsheetDate3.toDate();
        java.util.TimeZone timeZone22 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone22;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.gantt.Task task25 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year24);
        long long26 = year24.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year24.next();
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer28 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = areaRenderer28.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer28.setBaseOutlineStroke(stroke31, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = areaRenderer28.getSeriesNegativeItemLabelPosition((int) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor36 = itemLabelPosition35.getRotationAnchor();
        int int37 = year24.compareTo((java.lang.Object) itemLabelPosition35);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1900L + "'", long26 == 1900L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        xYPlot10.setDataset(xYDataset15);
        org.jfree.data.time.DateRange dateRange17 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer20.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer20.setBaseLinesVisible(false);
        java.lang.Boolean boolean27 = statisticalLineAndShapeRenderer20.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean28 = dateRange17.equals((java.lang.Object) boolean27);
        java.util.Date date29 = dateRange17.getUpperDate();
        org.jfree.data.general.Dataset dataset30 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent31 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateRange17, dataset30);
        xYPlot10.datasetChanged(datasetChangeEvent31);
        xYPlot10.clearDomainAxes();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        boolean boolean37 = chartChangeEventType35.equals((java.lang.Object) dateAxis36);
        java.awt.Stroke stroke38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis36.setAxisLineStroke(stroke38);
        java.awt.Shape shape40 = dateAxis36.getUpArrow();
        org.jfree.chart.plot.Plot plot41 = dateAxis36.getPlot();
        xYPlot10.setDomainAxis(4, (org.jfree.chart.axis.ValueAxis) dateAxis36, true);
        org.jfree.chart.axis.ValueAxis valueAxis44 = xYPlot10.getDomainAxis();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(boolean27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(chartChangeEventType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertNull(valueAxis44);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        java.awt.Paint paint13 = valueMarker8.getOutlinePaint();
        java.awt.Stroke stroke14 = valueMarker8.getOutlineStroke();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color17 = java.awt.Color.getColor("TextAnchor.TOP_CENTER", color16);
        valueMarker8.setOutlinePaint((java.awt.Paint) color17);
        java.lang.String str19 = valueMarker8.getLabel();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.util.List list7 = numberAxis3D1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge6);
        org.jfree.data.Range range11 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double13 = range11.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(10.0d, range11);
        numberAxis3D1.setRangeWithMargins(range11, false, false);
        org.jfree.data.time.DateRange dateRange18 = new org.jfree.data.time.DateRange();
        numberAxis3D1.setRangeWithMargins((org.jfree.data.Range) dateRange18, true, true);
        org.jfree.data.Range range24 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double26 = range24.constrain((double) (short) 10);
        org.jfree.data.Range range29 = org.jfree.data.Range.shift(range24, (double) (short) 1, true);
        org.jfree.data.Range range30 = org.jfree.data.Range.combine((org.jfree.data.Range) dateRange18, range24);
        double double31 = dateRange18.getUpperBound();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("ItemLabelAnchor.INSIDE2");
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        dateAxis13.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setInverted(true);
        java.awt.Shape shape32 = dateAxis29.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke34 = dateAxis33.getAxisLineStroke();
        boolean boolean35 = dateAxis33.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline36 = dateAxis33.getTimeline();
        dateAxis29.setTimeline(timeline36);
        dateAxis13.setTimeline(timeline36);
        dateAxis13.setVerticalTickLabels(false);
        xYPlot10.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        xYPlot10.mapDatasetToRangeAxis(11, 9999);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(timeline36);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        piePlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.Plot plot3 = piePlot0.getParent();
        org.jfree.data.general.PieDataset pieDataset4 = null;
        piePlot0.setDataset(pieDataset4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator6);
        java.awt.Paint paint9 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder(paint9);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        boolean boolean13 = chartChangeEventType11.equals((java.lang.Object) dateAxis12);
        java.awt.Stroke stroke14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis12.setAxisLineStroke(stroke14);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) '4', paint9, stroke14);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker16);
        valueMarker16.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent20 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker16);
        piePlot0.markerChanged(markerChangeEvent20);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator22 = piePlot0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(plot3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(chartChangeEventType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(pieSectionLabelGenerator22);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(100, false);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke8 = dateAxis7.getAxisLineStroke();
        double double9 = dateAxis7.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = numberAxis3D11.getStandardTickUnits();
        double double13 = numberAxis3D11.getUpperMargin();
        java.awt.Shape shape14 = numberAxis3D11.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, xYItemRenderer15);
        xYPlot16.clearRangeMarkers((int) (byte) -1);
        xYPlot16.setDomainCrosshairVisible(true);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot16.setDataset(xYDataset21);
        org.jfree.data.time.DateRange dateRange23 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer26.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer26.setBaseLinesVisible(false);
        java.lang.Boolean boolean33 = statisticalLineAndShapeRenderer26.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean34 = dateRange23.equals((java.lang.Object) boolean33);
        java.util.Date date35 = dateRange23.getUpperDate();
        org.jfree.data.general.Dataset dataset36 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateRange23, dataset36);
        xYPlot16.datasetChanged(datasetChangeEvent37);
        xYPlot16.clearDomainAxes();
        statisticalLineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) xYPlot16);
        org.jfree.chart.axis.AxisLocation axisLocation41 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot16.setDomainAxisLocation(axisLocation41);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(axisLocation41);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        java.lang.Object obj1 = defaultKeyedValues2D0.clone();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        boolean boolean4 = chartChangeEventType2.equals((java.lang.Object) dateAxis3);
        dateAxis3.setTickMarkOutsideLength((float) 1);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color7, stroke8, rectangleInsets13);
        dateAxis3.setAxisLinePaint((java.awt.Paint) color7);
        java.util.Date date16 = dateAxis3.getMinimumDate();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date16);
        int int18 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) serialDate17);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate23);
        defaultKeyedValues2D0.setValue((java.lang.Number) 3600000L, (java.lang.Comparable) 0.0f, (java.lang.Comparable) serialDate24);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline26 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline26.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment30 = segmentedTimeline26.getSegment(1900L);
        int int31 = defaultKeyedValues2D0.getColumnIndex((java.lang.Comparable) 1900L);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(segmentedTimeline26);
        org.junit.Assert.assertNotNull(segment30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font6 = legendTitle5.getItemFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        double double13 = rectangleInsets11.calculateRightInset((double) 89);
        legendTitle5.setItemLabelPadding(rectangleInsets11);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = legendTitle5.getItemLabelPadding();
        java.awt.Paint paint16 = legendTitle5.getItemPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj4 = stackedBarRenderer3D3.clone();
        stackedBarRenderer3D3.setMinimumBarLength((double) (short) -1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState9 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int14 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setUpperMargin((double) 'a');
        java.awt.Font font18 = categoryAxis13.getTickLabelFont((java.lang.Comparable) (byte) 100);
        categoryAxis13.setUpperMargin(0.05d);
        categoryAxis13.addCategoryLabelToolTip((java.lang.Comparable) (short) -1, "{0}");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis13.getTickLabelInsets();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        boolean boolean27 = chartChangeEventType25.equals((java.lang.Object) dateAxis26);
        dateAxis26.setTickMarkOutsideLength((float) 1);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder37 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color30, stroke31, rectangleInsets36);
        dateAxis26.setAxisLinePaint((java.awt.Paint) color30);
        org.jfree.data.Range range41 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double43 = range41.constrain((double) (short) 10);
        org.jfree.data.Range range46 = org.jfree.data.Range.shift(range41, (double) (short) 1, true);
        dateAxis26.setDefaultAutoRange(range46);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset48 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double50 = defaultBoxAndWhiskerCategoryDataset48.getRangeLowerBound(true);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset48);
        int int53 = defaultBoxAndWhiskerCategoryDataset48.getRowIndex((java.lang.Comparable) (-1.0f));
        try {
            stackedBarRenderer3D3.drawItem(graphics2D7, categoryItemRendererState9, rectangle2D10, categoryPlot11, categoryAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset48, 7, (-457), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(chartChangeEventType25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 10.0d + "'", double43 == 10.0d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("DatasetRenderingOrder.FORWARD");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer3 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = areaRenderer3.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer3.setBaseOutlineStroke(stroke6, true);
        java.awt.Stroke stroke10 = areaRenderer3.getSeriesStroke(100);
        java.awt.Stroke stroke11 = areaRenderer3.getBaseStroke();
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint13 = polarPlot12.getRadiusGridlinePaint();
        java.awt.Stroke stroke14 = polarPlot12.getRadiusGridlineStroke();
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke11, stroke14 };
        java.awt.Stroke[] strokeArray16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = chartChangeEventType17.equals((java.lang.Object) dateAxis18);
        java.awt.Stroke stroke20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis18.setAxisLineStroke(stroke20);
        java.awt.Shape shape22 = dateAxis18.getUpArrow();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D26 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double27 = stackedBarRenderer3D26.getItemMargin();
        java.awt.Shape shape28 = stackedBarRenderer3D26.getBaseShape();
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] { shape22, shape28 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray15, strokeArray16, shapeArray29);
        java.awt.Paint paint31 = defaultDrawingSupplier30.getNextPaint();
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextOutlinePaint();
        java.lang.Object obj33 = defaultDrawingSupplier30.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        double double3 = numberAxis3D1.getUpperMargin();
        java.awt.Shape shape4 = numberAxis3D1.getLeftArrow();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = new org.jfree.chart.axis.DateTickUnit(2, (-1));
        legendItemEntity5.setSeriesKey((java.lang.Comparable) dateTickUnit8);
        int int10 = dateTickUnit8.getCount();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke5 = dateAxis4.getAxisLineStroke();
        boolean boolean6 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis4.getTimeline();
        dateAxis0.setTimeline(timeline7);
        java.lang.String str9 = dateAxis0.getLabelURL();
        dateAxis0.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint13 = piePlot12.getLabelPaint();
        piePlot12.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint18 = piePlot12.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) piePlot12);
        dateAxis0.setAutoRangeMinimumSize((double) 1L, false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setUpperMargin((double) 4);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color4, stroke5, rectangleInsets10);
        double double13 = rectangleInsets10.extendHeight((double) '4');
        double double14 = rectangleInsets10.getLeft();
        numberAxis3D1.setLabelInsets(rectangleInsets10);
        double double17 = rectangleInsets10.calculateRightInset((double) 5L);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 97.0d + "'", double13 == 97.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        java.awt.Shape shape3 = dateAxis0.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke5 = dateAxis4.getAxisLineStroke();
        boolean boolean6 = dateAxis4.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline7 = dateAxis4.getTimeline();
        dateAxis0.setTimeline(timeline7);
        java.lang.String str9 = dateAxis0.getLabelURL();
        dateAxis0.setVisible(false);
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint13 = piePlot12.getLabelPaint();
        piePlot12.setMinimumArcAngleToDraw((double) (byte) 100);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(9999);
        java.awt.Paint paint18 = piePlot12.getSectionPaint((java.lang.Comparable) 9999);
        dateAxis0.setPlot((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot12);
        org.jfree.chart.entity.EntityCollection entityCollection23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo(entityCollection23);
        java.awt.image.BufferedImage bufferedImage25 = jFreeChart20.createBufferedImage((int) (short) 1, 255, chartRenderingInfo24);
        java.lang.Object obj26 = chartRenderingInfo24.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(bufferedImage25);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        java.awt.Paint paint13 = valueMarker8.getOutlinePaint();
        valueMarker8.setLabel("");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot17 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset16);
        org.jfree.chart.plot.PolarPlot polarPlot18 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint19 = polarPlot18.getRadiusGridlinePaint();
        java.awt.Stroke stroke20 = polarPlot18.getRadiusGridlineStroke();
        defaultStatisticalCategoryDataset16.addChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot18);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        polarPlot18.setDataset(xYDataset22);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = dateAxis24.getStandardTickUnits();
        dateAxis24.setVerticalTickLabels(false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit30 = new org.jfree.chart.axis.DateTickUnit(2, (-1));
        dateAxis24.setTickUnit(dateTickUnit30, true, false);
        org.jfree.data.Range range34 = polarPlot18.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis24);
        valueMarker8.addChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot18);
        org.jfree.chart.plot.PiePlot piePlot36 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator37 = null;
        piePlot36.setLegendLabelToolTipGenerator(pieSectionLabelGenerator37);
        java.awt.Paint paint39 = piePlot36.getShadowPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D43.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D43.setDrawBarOutline(true);
        stackedBarRenderer3D43.setBaseSeriesVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer50 = stackedBarRenderer3D43.getGradientPaintTransformer();
        java.awt.Stroke stroke52 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        stackedBarRenderer3D43.setSeriesStroke((int) (byte) 100, stroke52);
        boolean boolean54 = piePlot36.equals((java.lang.Object) stroke52);
        valueMarker8.setOutlineStroke(stroke52);
        org.jfree.chart.text.TextAnchor textAnchor56 = valueMarker8.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(tickUnitSource25);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(gradientPaintTransformer50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(textAnchor56);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setUpperMargin((double) 'a');
        java.awt.Font font6 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (byte) 100);
        categoryAxis1.setUpperMargin(0.05d);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double14 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor9, 11, (-1), rectangle2D12, rectangleEdge13);
        double double15 = categoryAxis1.getLabelAngle();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 28799999L);
        java.lang.Object obj18 = null;
        boolean boolean19 = categoryAxis1.equals(obj18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setInverted(true);
        java.awt.Shape shape16 = dateAxis13.getDownArrow();
        lineAndShapeRenderer11.setSeriesShape((int) (short) 10, shape16);
        dateAxis1.setLeftArrow(shape16);
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset21 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        java.util.List list22 = defaultBoxAndWhiskerCategoryDataset21.getRowKeys();
        java.lang.Number number25 = defaultBoxAndWhiskerCategoryDataset21.getValue((java.lang.Comparable) 100, (java.lang.Comparable) (short) 1);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity28 = new org.jfree.chart.entity.CategoryItemEntity(shape16, "AreaRendererEndType.TAPER", "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", (org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset21, (java.lang.Comparable) (short) 10, (java.lang.Comparable) (-128));
        java.lang.Comparable comparable29 = null;
        categoryItemEntity28.setColumnKey(comparable29);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(number25);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle("DatasetRenderingOrder.FORWARD", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        java.awt.Paint paint1 = ganttRenderer0.getIncompletePaint();
        double double2 = ganttRenderer0.getEndPercent();
        double double3 = ganttRenderer0.getStartPercent();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.65d + "'", double2 == 0.65d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.35d + "'", double3 == 0.35d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.plot.Plot plot2 = numberAxis3D1.getPlot();
        double double3 = numberAxis3D1.getLabelAngle();
        numberAxis3D1.setLowerMargin((double) 128);
        java.lang.Object obj6 = numberAxis3D1.clone();
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int4 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate3);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int9 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        boolean boolean14 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate8, (org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.lang.String str15 = spreadsheetDate12.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline21 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.data.time.DateRange dateRange22 = new org.jfree.data.time.DateRange();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer25.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer25.setBaseLinesVisible(false);
        java.lang.Boolean boolean32 = statisticalLineAndShapeRenderer25.getSeriesItemLabelsVisible((int) (short) 0);
        boolean boolean33 = dateRange22.equals((java.lang.Object) boolean32);
        java.util.Date date34 = dateRange22.getUpperDate();
        segmentedTimeline21.addException(date34);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance(date34);
        boolean boolean38 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate19, serialDate36, 11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(segmentedTimeline21);
        org.junit.Assert.assertNull(boolean32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, 128);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        java.lang.String str4 = month2.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "October 128" + "'", str4.equals("October 128"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        boolean boolean13 = xYPlot10.isRangeZoomable();
        xYPlot10.setDomainCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getRowCount();
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean3 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) paint2);
        int int4 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.removeValue((java.lang.Comparable) 1.0E-5d);
        java.util.List list3 = defaultKeyedValues0.getKeys();
        org.jfree.chart.util.SortOrder sortOrder4 = org.jfree.chart.util.SortOrder.ASCENDING;
        defaultKeyedValues0.sortByKeys(sortOrder4);
        defaultKeyedValues0.removeValue((java.lang.Comparable) 1.05d);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(sortOrder4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) 1, 1.05d);
        java.util.Date date3 = dateRange2.getLowerDate();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        double double3 = numberAxis3D1.getUpperMargin();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        numberAxis3D1.centerRange((double) 9999);
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.RingPlot ringPlot8 = new org.jfree.chart.plot.RingPlot(pieDataset7);
        boolean boolean9 = ringPlot8.getSeparatorsVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setInverted(true);
        java.awt.Shape shape15 = dateAxis12.getDownArrow();
        lineAndShapeRenderer10.setSeriesShape((int) (short) 10, shape15);
        ringPlot8.setLegendItemShape(shape15);
        numberAxis3D1.setLeftArrow(shape15);
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D7.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D7.setDrawBarOutline(true);
        stackedBarRenderer3D7.setBaseSeriesVisible(true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = stackedBarRenderer3D7.getGradientPaintTransformer();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        stackedBarRenderer3D7.setSeriesStroke((int) (byte) 100, stroke16);
        boolean boolean18 = piePlot0.equals((java.lang.Object) stroke16);
        double double19 = piePlot0.getMinimumArcAngleToDraw();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-5d + "'", double19 == 1.0E-5d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) dateAxis1);
        dateAxis1.setTickMarkOutsideLength((float) 1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color5, stroke6, rectangleInsets11);
        dateAxis1.setAxisLinePaint((java.awt.Paint) color5);
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = dateAxis1.getTickUnit();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(dateTickUnit14);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.BACKGROUND;
        java.lang.String str17 = layer16.toString();
        java.util.Collection collection18 = xYPlot10.getDomainMarkers(layer16);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int20 = defaultStatisticalCategoryDataset19.getRowCount();
        java.awt.Paint paint21 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        boolean boolean22 = defaultStatisticalCategoryDataset19.equals((java.lang.Object) paint21);
        xYPlot10.setDomainCrosshairPaint(paint21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot10.zoomRangeAxes(0.05d, plotRenderingInfo25, point2D26);
        double double28 = xYPlot10.getDomainCrosshairValue();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Layer.BACKGROUND" + "'", str17.equals("Layer.BACKGROUND"));
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100L, (double) 10);
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint6 = polarPlot5.getRadiusGridlinePaint();
        java.awt.Stroke stroke7 = polarPlot5.getRadiusGridlineStroke();
        java.awt.Paint paint8 = polarPlot5.getAngleLabelPaint();
        boolean boolean9 = columnArrangement4.equals((java.lang.Object) paint8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int19 = spreadsheetDate16.compare((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int24 = spreadsheetDate21.compare((org.jfree.data.time.SerialDate) spreadsheetDate23);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean29 = spreadsheetDate16.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, (org.jfree.data.time.SerialDate) spreadsheetDate27);
        boolean boolean30 = spreadsheetDate13.isOn((org.jfree.data.time.SerialDate) spreadsheetDate27);
        java.util.Date date31 = spreadsheetDate13.toDate();
        java.util.TimeZone timeZone32 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone32;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date31, timeZone32);
        org.jfree.data.gantt.Task task35 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year34);
        boolean boolean36 = columnArrangement4.equals((java.lang.Object) "LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        boolean boolean3 = statisticalLineAndShapeRenderer0.getItemLineVisible((int) '#', (int) (byte) -1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        statisticalLineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = statisticalLineAndShapeRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        spreadsheetDate2.setDescription("hi!");
        java.awt.Paint paint8 = piePlot0.getSectionOutlinePaint((java.lang.Comparable) spreadsheetDate2);
        java.awt.Stroke stroke9 = piePlot0.getOutlineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        piePlot0.removeChangeListener(plotChangeListener10);
        piePlot0.setInteriorGap(0.05d);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = null;
        piePlot0.setLegendLabelURLGenerator(pieURLGenerator14);
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator16 = piePlot0.getToolTipGenerator();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(pieToolTipGenerator16);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D3.setMaximumBarWidth(0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) (short) 100, 9, (int) (byte) 100);
        long long4 = segmentedTimeline3.getSegmentsGroupSize();
        long long7 = segmentedTimeline3.getExceptionSegmentCount((long) 15, 0L);
        long long9 = segmentedTimeline3.toTimelineValue((long) 12);
        long long11 = segmentedTimeline3.toTimelineValue((long) 5);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10900L + "'", long4 == 10900L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 12L + "'", long9 == 12L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        java.awt.Paint paint1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        boolean boolean5 = chartChangeEventType3.equals((java.lang.Object) dateAxis4);
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis4.setAxisLineStroke(stroke6);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) '4', paint1, stroke6);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        valueMarker8.setValue(0.0d);
        java.awt.Paint paint12 = valueMarker8.getPaint();
        boolean boolean14 = valueMarker8.equals((java.lang.Object) 60000L);
        java.awt.Paint paint15 = valueMarker8.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, 100.0d, (double) (short) -1);
        org.jfree.chart.block.BlockContainer blockContainer13 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement12);
        org.jfree.chart.block.CenterArrangement centerArrangement14 = new org.jfree.chart.block.CenterArrangement();
        blockContainer13.setArrangement((org.jfree.chart.block.Arrangement) centerArrangement14);
        java.util.List list16 = blockContainer13.getBlocks();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem17 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 128, (java.lang.Number) 10.0f, (java.lang.Number) (short) -1, (java.lang.Number) 0.0d, (java.lang.Number) 1.0E-8d, (java.lang.Number) (short) 10, (java.lang.Number) 6, (java.lang.Number) 1.0E-8d, list16);
        java.lang.String str18 = boxAndWhiskerItem17.toString();
        java.util.List list19 = boxAndWhiskerItem17.getOutliers();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer24 = stackedBarRenderer3D23.getGradientPaintTransformer();
        boolean boolean25 = boxAndWhiskerItem17.equals((java.lang.Object) stackedBarRenderer3D23);
        java.lang.Number number26 = boxAndWhiskerItem17.getQ3();
        java.lang.Object obj27 = null;
        boolean boolean28 = boxAndWhiskerItem17.equals(obj27);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("hi!", font2);
        org.jfree.chart.event.TitleChangeListener titleChangeListener4 = null;
        textTitle3.addChangeListener(titleChangeListener4);
        textTitle3.setMargin((double) 100, 0.0d, 0.0d, (double) 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        textTitle3.setPosition(rectangleEdge11);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder();
        textTitle3.setFrame((org.jfree.chart.block.BlockFrame) blockBorder13);
        java.lang.Object obj15 = null;
        borderArrangement0.add((org.jfree.chart.block.Block) textTitle3, obj15);
        java.awt.Color color21 = java.awt.Color.yellow;
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder(10.0d, (double) 100, (double) 1, (double) 'a', (java.awt.Paint) color21);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer23 = new org.jfree.chart.renderer.category.AreaRenderer();
        java.lang.Object obj24 = areaRenderer23.clone();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        areaRenderer23.setBaseOutlinePaint((java.awt.Paint) color25);
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer27 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = areaRenderer27.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer27.setBaseOutlineStroke(stroke30, true);
        java.awt.Stroke stroke34 = areaRenderer27.getSeriesStroke(100);
        java.awt.Paint paint36 = areaRenderer27.lookupSeriesPaint(128);
        java.awt.Color color37 = java.awt.Color.gray;
        java.awt.Color color38 = color37.brighter();
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer39 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color21, (java.awt.Paint) color25, paint36, (java.awt.Paint) color38);
        textTitle3.setBackgroundPaint((java.awt.Paint) color25);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = textTitle3.getTextAlignment();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(stroke34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke2 = polarPlot0.getRadiusGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation3 = polarPlot0.getOrientation();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D6 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis3D6.getStandardTickUnits();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = numberAxis3D6.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        org.jfree.data.Range range16 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double18 = range16.constrain((double) (short) 10);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(10.0d, range16);
        numberAxis3D6.setRangeWithMargins(range16, false, false);
        java.awt.Font font23 = numberAxis3D6.getTickLabelFont();
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        java.lang.Object obj28 = stackedBarRenderer3D27.clone();
        java.awt.Paint paint29 = stackedBarRenderer3D27.getBaseFillPaint();
        org.jfree.chart.text.TextFragment textFragment31 = new org.jfree.chart.text.TextFragment("DatasetRenderingOrder.FORWARD", font23, paint29, (float) (-128));
        polarPlot0.setAngleLabelFont(font23);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(plotOrientation3);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(1900L);
        long long6 = segmentedTimeline0.getTimeFromLong((long) 128);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 128L + "'", long6 == 128L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        boolean boolean1 = dateAxis0.isTickLabelsVisible();
        dateAxis0.resizeRange((double) 10L, (double) 5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape4, stroke5, (java.awt.Paint) color6);
        java.awt.Paint paint8 = legendItem7.getOutlinePaint();
        java.text.AttributedString attributedString9 = legendItem7.getAttributedLabel();
        java.text.AttributedString attributedString10 = legendItem7.getAttributedLabel();
        legendItem7.setSeriesKey((java.lang.Comparable) (byte) 10);
        java.awt.Paint paint13 = legendItem7.getLinePaint();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(attributedString9);
        org.junit.Assert.assertNull(attributedString10);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        dateAxis0.setRange((org.jfree.data.Range) dateRange3, true, false);
        java.util.Date date7 = dateRange3.getUpperDate();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        double double4 = stackedBarRenderer3D3.getItemMargin();
        stackedBarRenderer3D3.setSeriesVisibleInLegend((int) ' ', (java.lang.Boolean) false);
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint9 = polarPlot8.getRadiusGridlinePaint();
        stackedBarRenderer3D3.removeChangeListener((org.jfree.chart.event.RendererChangeListener) polarPlot8);
        java.lang.String str11 = polarPlot8.getPlotType();
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer14.setUseFillPaint(false);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        numberAxis17.configure();
        boolean boolean19 = statisticalLineAndShapeRenderer14.equals((java.lang.Object) numberAxis17);
        org.jfree.data.general.Dataset dataset20 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent21 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) statisticalLineAndShapeRenderer14, dataset20);
        polarPlot8.datasetChanged(datasetChangeEvent21);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = numberAxis3D1.getStandardTickUnits();
        double double3 = numberAxis3D1.getUpperMargin();
        org.jfree.chart.plot.Plot plot4 = numberAxis3D1.getPlot();
        numberAxis3D1.centerRange((double) 1.0f);
        double double7 = numberAxis3D1.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-8d + "'", double7 == 1.0E-8d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke3 = levelRenderer0.getItemOutlineStroke(100, (int) (byte) 0);
        levelRenderer0.setMaximumItemWidth((double) 100L);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        levelRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6);
        double double8 = levelRenderer0.getMaximumItemWidth();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        xYPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot10.getRangeAxisEdge((int) 'a');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot10.rendererChanged(rendererChangeEvent20);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot10.getRangeAxisForDataset((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(false);
        java.awt.Paint paint8 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        java.awt.Paint paint9 = statisticalLineAndShapeRenderer2.getBaseItemLabelPaint();
        boolean boolean12 = statisticalLineAndShapeRenderer2.getItemCreateEntity((-460), 3);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        stackedBarRenderer3D3.setMaximumBarWidth((-1.0d));
        stackedBarRenderer3D3.setDrawBarOutline(true);
        stackedBarRenderer3D3.setBaseSeriesVisible(true);
        double double10 = stackedBarRenderer3D3.getItemMargin();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            stackedBarRenderer3D3.drawDomainGridline(graphics2D11, categoryPlot12, rectangle2D13, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle8.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.lang.Object obj14 = textTitle8.draw(graphics2D11, rectangle2D12, (java.lang.Object) "{0}");
        boolean boolean15 = legendTitle5.equals((java.lang.Object) graphics2D11);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str18 = rectangleConstraint17.toString();
        org.jfree.data.Range range21 = new org.jfree.data.Range((double) (-1L), (double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = rectangleConstraint17.toRangeHeight(range21);
        org.jfree.chart.util.Size2D size2D23 = legendTitle5.arrange(graphics2D16, rectangleConstraint17);
        size2D23.setHeight(1.05d);
        java.lang.Object obj26 = size2D23.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str18.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint22);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = polarPlot0.getRadiusGridlinePaint();
        java.awt.Stroke stroke2 = polarPlot0.getRadiusGridlineStroke();
        java.awt.Paint paint3 = polarPlot0.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        polarPlot0.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo6, point2D7);
        polarPlot0.clearCornerTextItems();
        java.awt.Paint paint10 = polarPlot0.getAngleGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        polarPlot0.zoomDomainAxes(53.0d, plotRenderingInfo12, point2D13);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        java.lang.String str2 = projectInfo0.getCopyright();
        java.lang.String str3 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "October 128" + "'", str2.equals("October 128"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "October 128" + "'", str3.equals("October 128"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = null;
        try {
            groupedStackedBarRenderer0.setSeriesToGroupMap(keyToGroupMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'map' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("TextAnchor.TOP_CENTER");
        org.jfree.chart.plot.PolarPlot polarPlot2 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint3 = polarPlot2.getRadiusGridlinePaint();
        java.awt.Stroke stroke4 = polarPlot2.getRadiusGridlineStroke();
        java.awt.Paint paint5 = polarPlot2.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        polarPlot2.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo8, point2D9);
        polarPlot2.clearCornerTextItems();
        java.awt.Paint paint12 = polarPlot2.getAngleGridlinePaint();
        boolean boolean13 = standardCategoryURLGenerator1.equals((java.lang.Object) paint12);
        java.lang.Object obj14 = standardCategoryURLGenerator1.clone();
        java.lang.Object obj15 = standardCategoryURLGenerator1.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 10, 128);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = numberAxis3D4.getStandardTickUnits();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        java.util.List list10 = numberAxis3D4.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
        java.awt.Paint paint11 = numberAxis3D4.getTickLabelPaint();
        org.jfree.data.KeyedObject keyedObject12 = new org.jfree.data.KeyedObject((java.lang.Comparable) month2, (java.lang.Object) numberAxis3D4);
        java.lang.Comparable comparable13 = keyedObject12.getKey();
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(comparable13);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(1900L);
        segment4.dec(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segment4.copy();
        boolean boolean8 = segment4.inIncludeSegments();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(segment7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("DateTickUnit[DAY, -1]", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1900);
        int int3 = keyedObjects2D0.getRowCount();
        java.util.List list4 = keyedObjects2D0.getColumnKeys();
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer6 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = null;
        piePlot7.setLegendLabelToolTipGenerator(pieSectionLabelGenerator8);
        java.awt.Paint paint10 = piePlot7.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot7);
        org.jfree.chart.title.LegendTitle legendTitle12 = jFreeChart11.getLegend();
        java.awt.Font font13 = legendTitle12.getItemFont();
        boolean boolean14 = stackedBarRenderer6.equals((java.lang.Object) legendTitle12);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate17);
        keyedObjects2D0.setObject((java.lang.Object) stackedBarRenderer6, (java.lang.Comparable) 0, (java.lang.Comparable) "DatasetRenderingOrder.FORWARD");
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint23 = polarPlot22.getRadiusGridlinePaint();
        java.awt.Stroke stroke24 = polarPlot22.getRadiusGridlineStroke();
        java.awt.Paint paint25 = polarPlot22.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        polarPlot22.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo28, point2D29);
        java.awt.Paint paint31 = polarPlot22.getAngleLabelPaint();
        stackedBarRenderer6.setSeriesItemLabelPaint(11, paint31, true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(legendTitle12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        java.awt.Paint paint11 = statisticalLineAndShapeRenderer2.getSeriesItemLabelPaint((int) '4');
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate20 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int21 = spreadsheetDate18.compare((org.jfree.data.time.SerialDate) spreadsheetDate20);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int26 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean31 = spreadsheetDate18.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate25, (org.jfree.data.time.SerialDate) spreadsheetDate29);
        boolean boolean32 = spreadsheetDate15.isOn((org.jfree.data.time.SerialDate) spreadsheetDate29);
        java.util.Date date33 = spreadsheetDate15.toDate();
        java.util.TimeZone timeZone34 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone34;
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date33, timeZone34);
        org.jfree.data.gantt.Task task37 = new org.jfree.data.gantt.Task("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.TimePeriod) year36);
        boolean boolean38 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) year36);
        statisticalLineAndShapeRenderer2.setBaseLinesVisible(true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("");
        numberAxis3D1.setTickMarksVisible(false);
        numberAxis3D1.setTickMarkOutsideLength((float) 0L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D0 = new org.jfree.data.DefaultKeyedValues2D();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int5 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate4);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate7 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int10 = spreadsheetDate7.compare((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        boolean boolean15 = spreadsheetDate2.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate9, (org.jfree.data.time.SerialDate) spreadsheetDate13);
        int int16 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) boolean15);
        java.lang.Object obj17 = defaultKeyedValues2D0.clone();
        org.jfree.chart.ui.Licences licences18 = new org.jfree.chart.ui.Licences();
        boolean boolean19 = defaultKeyedValues2D0.equals((java.lang.Object) licences18);
        int int21 = defaultKeyedValues2D0.getRowIndex((java.lang.Comparable) (-246));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot();
        java.awt.Paint paint2 = piePlot1.getLabelPaint();
        piePlot1.setMinimumArcAngleToDraw((double) (byte) 100);
        java.lang.Class<?> wildcardClass5 = piePlot1.getClass();
        java.net.URL uRL6 = org.jfree.chart.util.ObjectUtilities.getResource("", (java.lang.Class) wildcardClass5);
        boolean boolean7 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass5);
        java.lang.Class class8 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass5);
        boolean boolean9 = org.jfree.chart.util.SerialUtilities.isSerializable((java.lang.Class) wildcardClass5);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(uRL6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("VerticalAlignment.BOTTOM");
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        boolean boolean7 = textLine1.equals((java.lang.Object) '#');
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer10 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer10.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint15 = textFragment14.getPaint();
        java.awt.Paint paint16 = textFragment14.getPaint();
        boolean boolean17 = statisticalLineAndShapeRenderer10.equals((java.lang.Object) textFragment14);
        textLine1.removeFragment(textFragment14);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setStartTime((long) 5);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline0.getSegment(1900L);
        segment4.dec(10L);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment9 = segment4.intersect((long) ' ', (long) ' ');
        long long10 = segment4.getSegmentNumber();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNull(segment9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-10L) + "'", long10 == (-10L));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_RED;
        lineRenderer3D0.setWallPaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = lineRenderer3D0.getWallPaint();
        double double4 = lineRenderer3D0.getYOffset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "RangeType.NEGATIVE", "RangeType.NEGATIVE", shape4, stroke5, (java.awt.Paint) color6);
        java.lang.String str8 = legendItem7.getLabel();
        boolean boolean9 = legendItem7.isShapeVisible();
        java.lang.String str10 = legendItem7.getURLText();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RangeType.NEGATIVE" + "'", str10.equals("RangeType.NEGATIVE"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) 'a');
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays(1900, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate6);
        int int8 = spreadsheetDate6.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int13 = spreadsheetDate11.toSerial();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int20 = spreadsheetDate17.compare((org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int21 = spreadsheetDate19.getDayOfMonth();
        boolean boolean22 = spreadsheetDate11.isInRange(serialDate15, (org.jfree.data.time.SerialDate) spreadsheetDate19);
        int int23 = spreadsheetDate6.compare((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int24 = spreadsheetDate11.toSerial();
        org.jfree.data.time.SerialDate serialDate25 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int34 = spreadsheetDate31.compare((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate38 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int39 = spreadsheetDate36.compare((org.jfree.data.time.SerialDate) spreadsheetDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean44 = spreadsheetDate31.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate38, (org.jfree.data.time.SerialDate) spreadsheetDate42);
        boolean boolean45 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate42);
        java.util.Date date46 = spreadsheetDate28.toDate();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate49);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate53);
        int int55 = spreadsheetDate53.toSerial();
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance(2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate61 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10);
        int int62 = spreadsheetDate59.compare((org.jfree.data.time.SerialDate) spreadsheetDate61);
        int int63 = spreadsheetDate61.getDayOfMonth();
        boolean boolean64 = spreadsheetDate53.isInRange(serialDate57, (org.jfree.data.time.SerialDate) spreadsheetDate61);
        boolean boolean66 = spreadsheetDate28.isInRange(serialDate50, serialDate57, 128);
        org.jfree.data.time.SerialDate serialDate67 = null;
        try {
            boolean boolean68 = spreadsheetDate11.isInRange(serialDate50, serialDate67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 9 + "'", int21 == 9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 9 + "'", int63 == 9);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setUpperMargin((double) 10.0f);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setInverted(true);
        org.jfree.data.Range range12 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double14 = range12.constrain((double) (short) 10);
        dateAxis7.setDefaultAutoRange(range12);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke17 = dateAxis16.getAxisLineStroke();
        dateAxis7.setTickMarkStroke(stroke17);
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        dateAxis7.setLabelFont(font19);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand21 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis0, (double) (short) 100, (double) (-460), 8.0d, 10.0d, font19);
        java.awt.Graphics2D graphics2D22 = null;
        double double23 = markerAxisBand21.getHeight(graphics2D22);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        boolean boolean25 = markerAxisBand21.equals((java.lang.Object) textBlockAnchor24);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        boolean boolean4 = piePlot0.isCircular();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke7 = dateAxis6.getAxisLineStroke();
        double double8 = dateAxis6.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = numberAxis3D10.getStandardTickUnits();
        double double12 = numberAxis3D10.getUpperMargin();
        java.awt.Shape shape13 = numberAxis3D10.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, xYItemRenderer14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        boolean boolean19 = chartChangeEventType17.equals((java.lang.Object) dateAxis18);
        dateAxis18.setTickMarkOutsideLength((float) 1);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder29 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color22, stroke23, rectangleInsets28);
        dateAxis18.setAxisLinePaint((java.awt.Paint) color22);
        dateAxis18.setRangeWithMargins(0.0d, 10.0d);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setInverted(true);
        java.awt.Shape shape37 = dateAxis34.getDownArrow();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke39 = dateAxis38.getAxisLineStroke();
        boolean boolean40 = dateAxis38.isAutoTickUnitSelection();
        org.jfree.chart.axis.Timeline timeline41 = dateAxis38.getTimeline();
        dateAxis34.setTimeline(timeline41);
        dateAxis18.setTimeline(timeline41);
        dateAxis18.setVerticalTickLabels(false);
        xYPlot15.setRangeAxis(5, (org.jfree.chart.axis.ValueAxis) dateAxis18, false);
        java.awt.Color color48 = java.awt.Color.WHITE;
        xYPlot15.setRangeTickBandPaint((java.awt.Paint) color48);
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot15.setOrientation(plotOrientation50);
        java.awt.Paint paint52 = xYPlot15.getRangeGridlinePaint();
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint54 = polarPlot53.getRadiusGridlinePaint();
        java.awt.Stroke stroke55 = polarPlot53.getRadiusGridlineStroke();
        java.awt.Paint paint56 = polarPlot53.getAngleLabelPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        polarPlot53.zoomDomainAxes(0.2d, (double) (byte) 1, plotRenderingInfo59, point2D60);
        java.awt.Paint paint62 = polarPlot53.getAngleLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        polarPlot53.setDataset(xYDataset63);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType65 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis();
        boolean boolean67 = chartChangeEventType65.equals((java.lang.Object) dateAxis66);
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation70 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0, (java.lang.Number) (short) 0);
        boolean boolean71 = dateAxis66.equals((java.lang.Object) (short) 0);
        dateAxis66.setAxisLineVisible(false);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent74 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) dateAxis66);
        polarPlot53.axisChanged(axisChangeEvent74);
        xYPlot15.axisChanged(axisChangeEvent74);
        piePlot0.axisChanged(axisChangeEvent74);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeline41);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(chartChangeEventType65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType1 = rectangleConstraint0.getWidthConstraintType();
        java.lang.Object obj2 = null;
        boolean boolean3 = lengthConstraintType1.equals(obj2);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(lengthConstraintType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        java.lang.Number number5 = defaultBoxAndWhiskerCategoryDataset0.getMaxOutlier((java.lang.Comparable) 15, (java.lang.Comparable) Double.NaN);
        int int7 = defaultBoxAndWhiskerCategoryDataset0.getColumnIndex((java.lang.Comparable) "TextAnchor.TOP_CENTER");
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0, false);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot0);
        org.jfree.chart.title.LegendTitle legendTitle5 = jFreeChart4.getLegend();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font7);
        textTitle8.setURLText("({0}, {1}) = {2}");
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.lang.Object obj14 = textTitle8.draw(graphics2D11, rectangle2D12, (java.lang.Object) "{0}");
        boolean boolean15 = legendTitle5.equals((java.lang.Object) graphics2D11);
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((double) (-1), 10.0d, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = stackedBarRenderer3D19.getGradientPaintTransformer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        boolean boolean25 = chartChangeEventType23.equals((java.lang.Object) dateAxis24);
        java.awt.Stroke stroke26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis24.setAxisLineStroke(stroke26);
        java.awt.Shape shape28 = dateAxis24.getUpArrow();
        org.jfree.chart.plot.Plot plot29 = dateAxis24.getPlot();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        stackedBarRenderer3D19.drawRangeGridline(graphics2D21, categoryPlot22, (org.jfree.chart.axis.ValueAxis) dateAxis24, rectangle2D30, 1.05d);
        java.awt.Color color33 = java.awt.Color.lightGray;
        stackedBarRenderer3D19.setBaseItemLabelPaint((java.awt.Paint) color33, true);
        legendTitle5.setItemPaint((java.awt.Paint) color33);
        java.awt.Paint paint38 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder39 = new org.jfree.chart.block.BlockBorder(paint38);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        boolean boolean42 = chartChangeEventType40.equals((java.lang.Object) dateAxis41);
        java.awt.Stroke stroke43 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        dateAxis41.setAxisLineStroke(stroke43);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) '4', paint38, stroke43);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker45);
        valueMarker45.setValue(0.0d);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker45);
        boolean boolean50 = legendTitle5.equals((java.lang.Object) markerChangeEvent49);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(legendTitle5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer20);
        org.junit.Assert.assertNotNull(chartChangeEventType23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(chartChangeEventType40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.category.AreaRenderer areaRenderer0 = new org.jfree.chart.renderer.category.AreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = areaRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 0);
        java.awt.Stroke stroke3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        areaRenderer0.setBaseOutlineStroke(stroke3, true);
        java.awt.Stroke stroke7 = areaRenderer0.getSeriesStroke(100);
        java.awt.Paint paint8 = areaRenderer0.getBasePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = areaRenderer0.getSeriesItemLabelGenerator(7);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        int int2 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) 'a', 1, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer15 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer15.setSeriesLinesVisible(100, false);
        statisticalLineAndShapeRenderer15.setBaseLinesVisible(false);
        java.awt.Font font23 = statisticalLineAndShapeRenderer15.getItemLabelFont((int) (byte) 1, 7);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 0.0f, font23);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis1.getCategoryStart(15, 0, rectangle2D27, rectangleEdge28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset defaultBoxAndWhiskerCategoryDataset0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
        double double2 = defaultBoxAndWhiskerCategoryDataset0.getRangeLowerBound(true);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultBoxAndWhiskerCategoryDataset0);
        int int5 = defaultBoxAndWhiskerCategoryDataset0.getRowIndex((java.lang.Comparable) (-1.0f));
        try {
            java.util.List list8 = defaultBoxAndWhiskerCategoryDataset0.getOutliers((-128), (-128));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.lang.String str7 = textAnchor6.toString();
        try {
            java.awt.Shape shape8 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("LegendItemEntity: seriesKey=null, dataset=null", graphics2D1, (float) 1L, (float) (short) 100, textAnchor4, (double) 0L, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.TOP_CENTER" + "'", str7.equals("TextAnchor.TOP_CENTER"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        java.lang.String str1 = rectangleConstraint0.toString();
        org.jfree.data.Range range4 = new org.jfree.data.Range((double) (-1L), (double) '4');
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint0.toRangeHeight(range4);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint0.getHeightConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]" + "'", str1.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.plot.PiePlot piePlot0 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot0.setLegendLabelToolTipGenerator(pieSectionLabelGenerator1);
        java.awt.Paint paint3 = piePlot0.getShadowPaint();
        java.awt.Stroke stroke4 = piePlot0.getBaseSectionOutlineStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        xYPlot10.setDomainGridlinesVisible(true);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot10.getRangeAxisEdge((int) 'a');
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        xYPlot10.rendererChanged(rendererChangeEvent20);
        boolean boolean22 = xYPlot10.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
        statisticalLineAndShapeRenderer2.setUseFillPaint(false);
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint7 = textFragment6.getPaint();
        java.awt.Paint paint8 = textFragment6.getPaint();
        boolean boolean9 = statisticalLineAndShapeRenderer2.equals((java.lang.Object) textFragment6);
        statisticalLineAndShapeRenderer2.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) true);
        java.awt.Paint paint13 = statisticalLineAndShapeRenderer2.getErrorIndicatorPaint();
        java.lang.Boolean boolean15 = statisticalLineAndShapeRenderer2.getSeriesLinesVisible(0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        boolean boolean18 = chartChangeEventType16.equals((java.lang.Object) dateAxis17);
        dateAxis17.setTickMarkOutsideLength((float) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color21, stroke22, rectangleInsets27);
        dateAxis17.setAxisLinePaint((java.awt.Paint) color21);
        java.awt.color.ColorSpace colorSpace30 = color21.getColorSpace();
        statisticalLineAndShapeRenderer2.setErrorIndicatorPaint((java.awt.Paint) color21);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(colorSpace30);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setInverted(true);
        org.jfree.data.Range range5 = new org.jfree.data.Range((double) (-1L), (double) '4');
        double double7 = range5.constrain((double) (short) 10);
        dateAxis0.setDefaultAutoRange(range5);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke10 = dateAxis9.getAxisLineStroke();
        dateAxis0.setTickMarkStroke(stroke10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        boolean boolean14 = chartChangeEventType12.equals((java.lang.Object) dateAxis13);
        dateAxis13.setTickMarkOutsideLength((float) 1);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) '#', (double) '#', 0.0d);
        org.jfree.chart.block.LineBorder lineBorder24 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color17, stroke18, rectangleInsets23);
        dateAxis13.setAxisLinePaint((java.awt.Paint) color17);
        java.util.Date date26 = dateAxis13.getMinimumDate();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date26);
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator29 = null;
        piePlot28.setLegendLabelToolTipGenerator(pieSectionLabelGenerator29);
        java.awt.Paint paint31 = piePlot28.getShadowPaint();
        org.jfree.chart.JFreeChart jFreeChart32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) piePlot28);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        boolean boolean35 = chartChangeEventType33.equals((java.lang.Object) dateAxis34);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) date26, jFreeChart32, chartChangeEventType33);
        dateAxis0.setMaximumDate(date26);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(chartChangeEventType33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke2 = dateAxis1.getAxisLineStroke();
        double double3 = dateAxis1.getFixedAutoRange();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("");
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = numberAxis3D5.getStandardTickUnits();
        double double7 = numberAxis3D5.getUpperMargin();
        java.awt.Shape shape8 = numberAxis3D5.getLeftArrow();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, xYItemRenderer9);
        xYPlot10.clearRangeMarkers((int) (byte) -1);
        xYPlot10.setDomainCrosshairVisible(true);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = xYPlot10.getLegendItems();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor16 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor16, textAnchor17);
        boolean boolean19 = legendItemCollection15.equals((java.lang.Object) itemLabelAnchor16);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(itemLabelAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }
}

